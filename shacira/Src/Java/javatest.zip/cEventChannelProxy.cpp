
class PushConsumerImpl : virtual public CosEventComm::_sk_PushConsumer
{
public:
   PushConsumerImpl(cEventChannelProxy * channel, const char* objName=NULL)
   {
      _Channel = channel;
   }
   void push(const CORBA::Any& any)
   {
      _Channel->PushEvent((CORBA::Any)any);
   }
   void disconnect_push_consumer()
   {
      InfoPrintf("push consumer disconnect\n");
   }
private:
   cEventChannelProxy * _Channel;
};


BOOL_T cEventChannelProxy::ListenTo ()
{

CosEventChannelAdmin::EventChannel_var channel = irgendwoher zum Beispiel ueber ior;


   PushConsumerImpl * consumer = new PushConsumerImpl(this);
   consumer->_obj_is_ready(Broker()->Boa());

   CosEventChannelAdmin::ConsumerAdmin_varfor_consumer = channel->for_consumers();
   CosEventChannelAdmin::ProxyPushSupplier_var proxy_push_supplier = for_consumer->obtain_push_supplier();
   proxy_push_supplier->connect_push_consumer(consumer->_this());

   return true;
}

