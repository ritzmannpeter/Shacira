
import java.net.*;
import java.io.*;
import java.lang.*;
import DatagramReceiver.*;
import DatagramSender.*;

public class Receiver {
  public static void main(String[] arg) {
    DatagramReceiver receiver = new DatagramReceiver();
    try {
       receiver.empfange(21001);
    } catch (IOException e) {
    }
    System.out.println("done");
  }
}
