/*
 * File: ./ORG/OMG/COSEVENTCOMM/PUSHCONSUMER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public interface PushConsumer
    extends org.omg.CORBA.Object {
    void push(org.omg.CORBA.Any data)
        throws org.omg.CosEventComm.Disconnected;
    void disconnect_push_consumer()
;
}
