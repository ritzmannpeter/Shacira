/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_PROXYPUSHCONSUMERSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _ProxyPushConsumerStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.ProxyPushConsumer {

    public _ProxyPushConsumerStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/ProxyPushConsumer:1.0",
        "IDL:CosEventComm/PushConsumer:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventComm::PushConsumer::push
    public void push(org.omg.CORBA.Any data)
        throws org.omg.CosEventComm.Disconnected {
           org.omg.CORBA.Request r = _request("push");
           org.omg.CORBA.Any _data = r.add_in_arg();
           _data.insert_any(data);
           r.exceptions().add(org.omg.CosEventComm.DisconnectedHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosEventComm.DisconnectedHelper.type())) {
                   throw org.omg.CosEventComm.DisconnectedHelper.extract(__userEx.except);
               }
           }
   }
    //	    Implementation of ::CosEventComm::PushConsumer::disconnect_push_consumer
    public void disconnect_push_consumer()
 {
           org.omg.CORBA.Request r = _request("disconnect_push_consumer");
           r.invoke();
   }
    //	    Implementation of ::CosEventChannelAdmin::ProxyPushConsumer::connect_push_supplier
    public void connect_push_supplier(org.omg.CosEventComm.PushSupplier push_supplier)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected {
           org.omg.CORBA.Request r = _request("connect_push_supplier");
           org.omg.CORBA.Any _push_supplier = r.add_in_arg();
           org.omg.CosEventComm.PushSupplierHelper.insert(_push_supplier, push_supplier);
           r.exceptions().add(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type())) {
                   throw org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.extract(__userEx.except);
               }
           }
   }

};
