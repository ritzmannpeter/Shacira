/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/ALREADYCONNECTEDHOLDER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class AlreadyConnectedHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventChannelAdmin.AlreadyConnected value;
    //	constructors 
    public AlreadyConnectedHolder() {
	this(null);
    }
    public AlreadyConnectedHolder(org.omg.CosEventChannelAdmin.AlreadyConnected __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type();
    }
}
