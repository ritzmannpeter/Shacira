/*
 * File: ./ORG/OMG/COSEVENTCOMM/PULLSUPPLIER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public interface PullSupplier
    extends org.omg.CORBA.Object {
    org.omg.CORBA.Any pull()
        throws org.omg.CosEventComm.Disconnected;
    org.omg.CORBA.Any try_pull(org.omg.CORBA.BooleanHolder has_event)
        throws org.omg.CosEventComm.Disconnected;
    void disconnect_pull_supplier()
;
}
