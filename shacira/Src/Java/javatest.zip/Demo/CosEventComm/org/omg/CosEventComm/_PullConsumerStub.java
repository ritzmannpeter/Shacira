/*
 * File: ./ORG/OMG/COSEVENTCOMM/_PULLCONSUMERSTUB.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public class _PullConsumerStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventComm.PullConsumer {

    public _PullConsumerStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventComm/PullConsumer:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventComm::PullConsumer::disconnect_pull_consumer
    public void disconnect_pull_consumer()
 {
           org.omg.CORBA.Request r = _request("disconnect_pull_consumer");
           r.invoke();
   }

};
