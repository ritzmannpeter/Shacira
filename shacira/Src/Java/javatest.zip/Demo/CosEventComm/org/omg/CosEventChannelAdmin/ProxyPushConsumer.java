/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPUSHCONSUMER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public interface ProxyPushConsumer
    extends org.omg.CORBA.Object,
	    org.omg.CosEventComm.PushConsumer {
    void connect_push_supplier(org.omg.CosEventComm.PushSupplier push_supplier)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected;
}
