/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_PROXYPUSHSUPPLIERSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _ProxyPushSupplierStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.ProxyPushSupplier {

    public _ProxyPushSupplierStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/ProxyPushSupplier:1.0",
        "IDL:CosEventComm/PushSupplier:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventComm::PushSupplier::disconnect_push_supplier
    public void disconnect_push_supplier()
 {
           org.omg.CORBA.Request r = _request("disconnect_push_supplier");
           r.invoke();
   }
    //	    Implementation of ::CosEventChannelAdmin::ProxyPushSupplier::connect_push_consumer
    public void connect_push_consumer(org.omg.CosEventComm.PushConsumer push_consumer)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected, org.omg.CosEventChannelAdmin.TypeError {
           org.omg.CORBA.Request r = _request("connect_push_consumer");
           org.omg.CORBA.Any _push_consumer = r.add_in_arg();
           org.omg.CosEventComm.PushConsumerHelper.insert(_push_consumer, push_consumer);
           r.exceptions().add(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type());
           r.exceptions().add(org.omg.CosEventChannelAdmin.TypeErrorHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type())) {
                   throw org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosEventChannelAdmin.TypeErrorHelper.type())) {
                   throw org.omg.CosEventChannelAdmin.TypeErrorHelper.extract(__userEx.except);
               }
           }
   }

};
