/*
 * File: ./ORG/OMG/COSEVENTCOMM/PUSHCONSUMERHELPER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public class PushConsumerHelper {
     // It is useless to have instances of this class
     private PushConsumerHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosEventComm.PushConsumer that) {
        out.write_Object(that);
    }
    public static org.omg.CosEventComm.PushConsumer read(org.omg.CORBA.portable.InputStream in) {
        return org.omg.CosEventComm.PushConsumerHelper.narrow(in.read_Object());
    }
   public static org.omg.CosEventComm.PushConsumer extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosEventComm.PushConsumer that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "PushConsumer");
      return _tc;
   }
   public static String id() {
       return "IDL:CosEventComm/PushConsumer:1.0";
   }
   public static org.omg.CosEventComm.PushConsumer narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof org.omg.CosEventComm.PushConsumer)
            return (org.omg.CosEventComm.PushConsumer) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        org.omg.CosEventComm.PushConsumer result = new org.omg.CosEventComm._PushConsumerStub(dup);
        return result;
   }
}
