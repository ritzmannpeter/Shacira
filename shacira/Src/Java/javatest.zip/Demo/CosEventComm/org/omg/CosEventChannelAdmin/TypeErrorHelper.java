/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/TYPEERRORHELPER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class TypeErrorHelper {
     // It is useless to have instances of this class
     private TypeErrorHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosEventChannelAdmin.TypeError that) {
    out.write_string(id());
 }
    public static org.omg.CosEventChannelAdmin.TypeError read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosEventChannelAdmin.TypeError that = new org.omg.CosEventChannelAdmin.TypeError();
         // read and discard the repository id
        in.read_string();
    return that;
    }
   public static org.omg.CosEventChannelAdmin.TypeError extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosEventChannelAdmin.TypeError that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 0;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[0];
             _tc = org.omg.CORBA.ORB.init().create_exception_tc(id(), "TypeError", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:CosEventChannelAdmin/TypeError:1.0";
   }
}
