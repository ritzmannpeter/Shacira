/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPULLSUPPLIERHOLDER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class ProxyPullSupplierHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventChannelAdmin.ProxyPullSupplier value;
    //	constructors 
    public ProxyPullSupplierHolder() {
	this(null);
    }
    public ProxyPullSupplierHolder(org.omg.CosEventChannelAdmin.ProxyPullSupplier __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventChannelAdmin.ProxyPullSupplierHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventChannelAdmin.ProxyPullSupplierHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventChannelAdmin.ProxyPullSupplierHelper.type();
    }
}
