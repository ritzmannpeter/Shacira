/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPULLCONSUMER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public interface ProxyPullConsumer
    extends org.omg.CORBA.Object,
	    org.omg.CosEventComm.PullConsumer {
    void connect_pull_supplier(org.omg.CosEventComm.PullSupplier pull_supplier)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected, org.omg.CosEventChannelAdmin.TypeError;
}
