/*
 * File: ./ORG/OMG/COSEVENTCOMM/PUSHSUPPLIERHOLDER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public final class PushSupplierHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventComm.PushSupplier value;
    //	constructors 
    public PushSupplierHolder() {
	this(null);
    }
    public PushSupplierHolder(org.omg.CosEventComm.PushSupplier __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventComm.PushSupplierHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventComm.PushSupplierHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventComm.PushSupplierHelper.type();
    }
}
