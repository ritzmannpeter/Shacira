/*
 * File: ./ORG/OMG/COSEVENTCOMM/_PULLSUPPLIERIMPLBASE.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public abstract class _PullSupplierImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosEventComm.PullSupplier {
    // Constructor
    public _PullSupplierImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:CosEventComm/PullSupplier:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("pull", new java.lang.Integer(0));
      _methods.put("try_pull", new java.lang.Integer(1));
      _methods.put("disconnect_pull_supplier", new java.lang.Integer(2));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosEventComm.PullSupplier.pull
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              org.omg.CORBA.Any ___result;
              try {
                            ___result = this.pull();
              }
              catch (org.omg.CosEventComm.Disconnected e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosEventComm.DisconnectedHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_any(___result);
              r.result(__result);
              }
              break;
           case 1: // org.omg.CosEventComm.PullSupplier.try_pull
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              org.omg.CORBA.Any _has_event = _orb().create_any();
              _has_event.type(org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_boolean));
              _list.add_value("has_event", _has_event, org.omg.CORBA.ARG_OUT.value);
              r.params(_list);
              org.omg.CORBA.BooleanHolder has_event;
              has_event = new org.omg.CORBA.BooleanHolder();
              org.omg.CORBA.Any ___result;
              try {
                            ___result = this.try_pull(has_event);
              }
              catch (org.omg.CosEventComm.Disconnected e0) {
                            org.omg.CORBA.Any _except = _orb().create_any();
                            org.omg.CosEventComm.DisconnectedHelper.insert(_except, e0);
                            r.except(_except);
                            return;
              }
              _has_event.insert_boolean(has_event.value);
              org.omg.CORBA.Any __result = _orb().create_any();
              __result.insert_any(___result);
              r.result(__result);
              }
              break;
           case 2: // org.omg.CosEventComm.PullSupplier.disconnect_pull_supplier
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
                            this.disconnect_pull_supplier();
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
