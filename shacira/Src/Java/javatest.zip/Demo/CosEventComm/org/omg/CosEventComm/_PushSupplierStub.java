/*
 * File: ./ORG/OMG/COSEVENTCOMM/_PUSHSUPPLIERSTUB.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public class _PushSupplierStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventComm.PushSupplier {

    public _PushSupplierStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventComm/PushSupplier:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventComm::PushSupplier::disconnect_push_supplier
    public void disconnect_push_supplier()
 {
           org.omg.CORBA.Request r = _request("disconnect_push_supplier");
           r.invoke();
   }

};
