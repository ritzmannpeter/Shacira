/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_PROXYPULLCONSUMERSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _ProxyPullConsumerStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.ProxyPullConsumer {

    public _ProxyPullConsumerStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/ProxyPullConsumer:1.0",
        "IDL:CosEventComm/PullConsumer:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventComm::PullConsumer::disconnect_pull_consumer
    public void disconnect_pull_consumer()
 {
           org.omg.CORBA.Request r = _request("disconnect_pull_consumer");
           r.invoke();
   }
    //	    Implementation of ::CosEventChannelAdmin::ProxyPullConsumer::connect_pull_supplier
    public void connect_pull_supplier(org.omg.CosEventComm.PullSupplier pull_supplier)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected, org.omg.CosEventChannelAdmin.TypeError {
           org.omg.CORBA.Request r = _request("connect_pull_supplier");
           org.omg.CORBA.Any _pull_supplier = r.add_in_arg();
           org.omg.CosEventComm.PullSupplierHelper.insert(_pull_supplier, pull_supplier);
           r.exceptions().add(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type());
           r.exceptions().add(org.omg.CosEventChannelAdmin.TypeErrorHelper.type());
           r.invoke();
           java.lang.Exception __ex = r.env().exception();
           if (__ex instanceof org.omg.CORBA.UnknownUserException) {
               org.omg.CORBA.UnknownUserException __userEx = (org.omg.CORBA.UnknownUserException) __ex;
               if (__userEx.except.type().equals(org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.type())) {
                   throw org.omg.CosEventChannelAdmin.AlreadyConnectedHelper.extract(__userEx.except);
               }
               if (__userEx.except.type().equals(org.omg.CosEventChannelAdmin.TypeErrorHelper.type())) {
                   throw org.omg.CosEventChannelAdmin.TypeErrorHelper.extract(__userEx.except);
               }
           }
   }

};
