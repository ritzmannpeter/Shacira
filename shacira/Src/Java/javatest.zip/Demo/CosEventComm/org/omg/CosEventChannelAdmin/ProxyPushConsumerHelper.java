/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPUSHCONSUMERHELPER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class ProxyPushConsumerHelper {
     // It is useless to have instances of this class
     private ProxyPushConsumerHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosEventChannelAdmin.ProxyPushConsumer that) {
        out.write_Object(that);
    }
    public static org.omg.CosEventChannelAdmin.ProxyPushConsumer read(org.omg.CORBA.portable.InputStream in) {
        return org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.narrow(in.read_Object());
    }
   public static org.omg.CosEventChannelAdmin.ProxyPushConsumer extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosEventChannelAdmin.ProxyPushConsumer that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
          if (_tc == null)
             _tc = org.omg.CORBA.ORB.init().create_interface_tc(id(), "ProxyPushConsumer");
      return _tc;
   }
   public static String id() {
       return "IDL:CosEventChannelAdmin/ProxyPushConsumer:1.0";
   }
   public static org.omg.CosEventChannelAdmin.ProxyPushConsumer narrow(org.omg.CORBA.Object that)
	    throws org.omg.CORBA.BAD_PARAM {
        if (that == null)
            return null;
        if (that instanceof org.omg.CosEventChannelAdmin.ProxyPushConsumer)
            return (org.omg.CosEventChannelAdmin.ProxyPushConsumer) that;
	if (!that._is_a(id())) {
	    throw new org.omg.CORBA.BAD_PARAM();
	}
        org.omg.CORBA.portable.Delegate dup = ((org.omg.CORBA.portable.ObjectImpl)that)._get_delegate();
        org.omg.CosEventChannelAdmin.ProxyPushConsumer result = new org.omg.CosEventChannelAdmin._ProxyPushConsumerStub(dup);
        return result;
   }
}
