/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPULLSUPPLIER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public interface ProxyPullSupplier
    extends org.omg.CORBA.Object,
	    org.omg.CosEventComm.PullSupplier {
    void connect_pull_consumer(org.omg.CosEventComm.PullConsumer pull_consumer)
        throws org.omg.CosEventChannelAdmin.AlreadyConnected;
}
