/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_CONSUMERADMINSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _ConsumerAdminStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.ConsumerAdmin {

    public _ConsumerAdminStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/ConsumerAdmin:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventChannelAdmin::ConsumerAdmin::obtain_push_supplier
    public org.omg.CosEventChannelAdmin.ProxyPushSupplier obtain_push_supplier()
 {
           org.omg.CORBA.Request r = _request("obtain_push_supplier");
           r.set_return_type(org.omg.CosEventChannelAdmin.ProxyPushSupplierHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.ProxyPushSupplier __result;
           __result = org.omg.CosEventChannelAdmin.ProxyPushSupplierHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosEventChannelAdmin::ConsumerAdmin::obtain_pull_supplier
    public org.omg.CosEventChannelAdmin.ProxyPullSupplier obtain_pull_supplier()
 {
           org.omg.CORBA.Request r = _request("obtain_pull_supplier");
           r.set_return_type(org.omg.CosEventChannelAdmin.ProxyPullSupplierHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.ProxyPullSupplier __result;
           __result = org.omg.CosEventChannelAdmin.ProxyPullSupplierHelper.extract(r.return_value());
           return __result;
   }

};
