/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_EVENTCHANNELSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _EventChannelStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.EventChannel {

    public _EventChannelStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/EventChannel:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventChannelAdmin::EventChannel::for_consumers
    public org.omg.CosEventChannelAdmin.ConsumerAdmin for_consumers()
 {
           org.omg.CORBA.Request r = _request("for_consumers");
           r.set_return_type(org.omg.CosEventChannelAdmin.ConsumerAdminHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.ConsumerAdmin __result;
           __result = org.omg.CosEventChannelAdmin.ConsumerAdminHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosEventChannelAdmin::EventChannel::for_suppliers
    public org.omg.CosEventChannelAdmin.SupplierAdmin for_suppliers()
 {
           org.omg.CORBA.Request r = _request("for_suppliers");
           r.set_return_type(org.omg.CosEventChannelAdmin.SupplierAdminHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.SupplierAdmin __result;
           __result = org.omg.CosEventChannelAdmin.SupplierAdminHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosEventChannelAdmin::EventChannel::destroy
    public void destroy()
 {
           org.omg.CORBA.Request r = _request("destroy");
           r.invoke();
   }

};
