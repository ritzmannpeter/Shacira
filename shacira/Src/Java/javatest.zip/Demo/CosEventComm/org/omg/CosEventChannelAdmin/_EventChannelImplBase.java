/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_EVENTCHANNELIMPLBASE.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public abstract class _EventChannelImplBase extends org.omg.CORBA.DynamicImplementation implements org.omg.CosEventChannelAdmin.EventChannel {
    // Constructor
    public _EventChannelImplBase() {
         super();
    }
    // Type strings for this class and its superclases
    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/EventChannel:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    private static java.util.Dictionary _methods = new java.util.Hashtable();
    static {
      _methods.put("for_consumers", new java.lang.Integer(0));
      _methods.put("for_suppliers", new java.lang.Integer(1));
      _methods.put("destroy", new java.lang.Integer(2));
     }
    // DSI Dispatch call
    public void invoke(org.omg.CORBA.ServerRequest r) {
       switch (((java.lang.Integer) _methods.get(r.op_name())).intValue()) {
           case 0: // org.omg.CosEventChannelAdmin.EventChannel.for_consumers
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              org.omg.CosEventChannelAdmin.ConsumerAdmin ___result;
                            ___result = this.for_consumers();
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosEventChannelAdmin.ConsumerAdminHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 1: // org.omg.CosEventChannelAdmin.EventChannel.for_suppliers
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
              org.omg.CosEventChannelAdmin.SupplierAdmin ___result;
                            ___result = this.for_suppliers();
              org.omg.CORBA.Any __result = _orb().create_any();
              org.omg.CosEventChannelAdmin.SupplierAdminHelper.insert(__result, ___result);
              r.result(__result);
              }
              break;
           case 2: // org.omg.CosEventChannelAdmin.EventChannel.destroy
              {
              org.omg.CORBA.NVList _list = _orb().create_list(0);
              r.params(_list);
                            this.destroy();
              org.omg.CORBA.Any __return = _orb().create_any();
              __return.type(_orb().get_primitive_tc(org.omg.CORBA.TCKind.tk_void));
              r.result(__return);
              }
              break;
            default:
              throw new org.omg.CORBA.BAD_OPERATION(0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
       }
 }
}
