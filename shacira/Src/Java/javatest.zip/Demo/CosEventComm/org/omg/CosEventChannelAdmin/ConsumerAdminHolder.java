/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/CONSUMERADMINHOLDER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class ConsumerAdminHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventChannelAdmin.ConsumerAdmin value;
    //	constructors 
    public ConsumerAdminHolder() {
	this(null);
    }
    public ConsumerAdminHolder(org.omg.CosEventChannelAdmin.ConsumerAdmin __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventChannelAdmin.ConsumerAdminHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventChannelAdmin.ConsumerAdminHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventChannelAdmin.ConsumerAdminHelper.type();
    }
}
