/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/_SUPPLIERADMINSTUB.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public class _SupplierAdminStub
	extends org.omg.CORBA.portable.ObjectImpl
    	implements org.omg.CosEventChannelAdmin.SupplierAdmin {

    public _SupplierAdminStub(org.omg.CORBA.portable.Delegate d) {
          super();
          _set_delegate(d);
    }

    private static final String _type_ids[] = {
        "IDL:CosEventChannelAdmin/SupplierAdmin:1.0"
    };

    public String[] _ids() { return (String[]) _type_ids.clone(); }

    //	IDL operations
    //	    Implementation of ::CosEventChannelAdmin::SupplierAdmin::obtain_push_consumer
    public org.omg.CosEventChannelAdmin.ProxyPushConsumer obtain_push_consumer()
 {
           org.omg.CORBA.Request r = _request("obtain_push_consumer");
           r.set_return_type(org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.ProxyPushConsumer __result;
           __result = org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.extract(r.return_value());
           return __result;
   }
    //	    Implementation of ::CosEventChannelAdmin::SupplierAdmin::obtain_pull_consumer
    public org.omg.CosEventChannelAdmin.ProxyPullConsumer obtain_pull_consumer()
 {
           org.omg.CORBA.Request r = _request("obtain_pull_consumer");
           r.set_return_type(org.omg.CosEventChannelAdmin.ProxyPullConsumerHelper.type());
           r.invoke();
           org.omg.CosEventChannelAdmin.ProxyPullConsumer __result;
           __result = org.omg.CosEventChannelAdmin.ProxyPullConsumerHelper.extract(r.return_value());
           return __result;
   }

};
