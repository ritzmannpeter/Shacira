/*
 * File: ./ORG/OMG/COSEVENTCOMM/DISCONNECTEDHELPER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public class DisconnectedHelper {
     // It is useless to have instances of this class
     private DisconnectedHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, org.omg.CosEventComm.Disconnected that) {
    out.write_string(id());
 }
    public static org.omg.CosEventComm.Disconnected read(org.omg.CORBA.portable.InputStream in) {
        org.omg.CosEventComm.Disconnected that = new org.omg.CosEventComm.Disconnected();
         // read and discard the repository id
        in.read_string();
    return that;
    }
   public static org.omg.CosEventComm.Disconnected extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, org.omg.CosEventComm.Disconnected that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 0;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[0];
             _tc = org.omg.CORBA.ORB.init().create_exception_tc(id(), "Disconnected", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:CosEventComm/Disconnected:1.0";
   }
}
