/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/PROXYPUSHCONSUMERHOLDER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class ProxyPushConsumerHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventChannelAdmin.ProxyPushConsumer value;
    //	constructors 
    public ProxyPushConsumerHolder() {
	this(null);
    }
    public ProxyPushConsumerHolder(org.omg.CosEventChannelAdmin.ProxyPushConsumer __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventChannelAdmin.ProxyPushConsumerHelper.type();
    }
}
