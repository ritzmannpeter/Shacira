/*
 * File: ./ORG/OMG/COSEVENTCOMM/PUSHSUPPLIER.JAVA
 * From: IDL\COSEVENTCOMM.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventComm;
public interface PushSupplier
    extends org.omg.CORBA.Object {
    void disconnect_push_supplier()
;
}
