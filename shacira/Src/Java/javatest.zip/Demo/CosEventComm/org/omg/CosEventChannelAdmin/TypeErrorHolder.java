/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/TYPEERRORHOLDER.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class TypeErrorHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public org.omg.CosEventChannelAdmin.TypeError value;
    //	constructors 
    public TypeErrorHolder() {
	this(null);
    }
    public TypeErrorHolder(org.omg.CosEventChannelAdmin.TypeError __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        org.omg.CosEventChannelAdmin.TypeErrorHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = org.omg.CosEventChannelAdmin.TypeErrorHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return org.omg.CosEventChannelAdmin.TypeErrorHelper.type();
    }
}
