/*
 * File: ./ORG/OMG/COSEVENTCHANNELADMIN/TYPEERROR.JAVA
 * From: IDL\COSEVENTCHANNELADMIN.IDL
 * Date: Tue Mar 02 19:14:28 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package org.omg.CosEventChannelAdmin;
public final class TypeError
	extends org.omg.CORBA.UserException {
    //	constructor
    public TypeError() {
	super();
    }
}
