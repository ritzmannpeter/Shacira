/*
 * EventChannel.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventChannelAdmin._EventChannelImplBase;

public class EventChannel extends _EventChannelImplBase
{
  // Public interface.

  public void destroy()
  {
    // System.out.println( "destroy");
  }

  public org.omg.CosEventChannelAdmin.ConsumerAdmin for_consumers()
  {
    // System.out.println( "for_consumers");

    return m_consumerAdmin;
  }

  public org.omg.CosEventChannelAdmin.SupplierAdmin for_suppliers()
  {
    // System.out.println( "for_suppliers");

    return m_supplierAdmin;
  }

  // Internal EventChannel members and methods.

  protected ConsumerAdmin m_consumerAdmin;
  protected SupplierAdmin m_supplierAdmin;

  protected java.util.Vector m_consumers;
  protected java.util.Vector m_suppliers;

  protected EventQueue    m_eventQueue;

  public EventChannel()
  {
    m_consumerAdmin = new ConsumerAdmin( this);
    m_supplierAdmin = new SupplierAdmin( this);

    m_consumers = new java.util.Vector( 100);
    m_suppliers = new java.util.Vector( 100);

    m_eventQueue = new EventQueue();
  }

  public void addConsumer( ProxyPushConsumer ppc)
  {
    m_consumers.addElement( ppc);
  }

  public void addSupplier( ProxyPushSupplier pps)
  {
    m_suppliers.addElement( pps);
  }

  public void appendEvent( org.omg.CORBA.Any ev)
  {
    m_eventQueue.appendEvent( ev);
  }

  public org.omg.CORBA.Any getEvent( Long evIndex)
  {
    return m_eventQueue.getEvent( evIndex);
  }
}
