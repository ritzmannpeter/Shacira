/*
 * ConsumerAdmin.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CORBA.*;
import org.omg.CosEventChannelAdmin._ConsumerAdminImplBase;

public class ConsumerAdmin extends _ConsumerAdminImplBase
{
  protected EventChannel m_eventChannel;

  public ConsumerAdmin( EventChannel ec)
  {
    m_eventChannel = ec;
  }

  public org.omg.CosEventChannelAdmin.ProxyPushSupplier obtain_push_supplier()
  {
    // System.out.println( "obtain_push_supplier");

    ProxyPushSupplier pps = new ProxyPushSupplier( m_eventChannel);
    m_eventChannel.addSupplier( pps);
    new Thread( pps).start();

    return pps;
  }

  public org.omg.CosEventChannelAdmin.ProxyPullSupplier obtain_pull_supplier()
  {
    // System.out.println( "obtain_pull_supplier");

    return new ProxyPullSupplier();
  }
}
