/*
 * ProxyPushSupplier.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventComm.Disconnected;
import org.omg.CosEventChannelAdmin.AlreadyConnected;
import org.omg.CosEventChannelAdmin.TypeError;
import org.omg.CosEventChannelAdmin._ProxyPushSupplierImplBase;

import org.omg.CORBA.*;

public class ProxyPushSupplier extends _ProxyPushSupplierImplBase
  implements Runnable
{
  public    boolean                           m_stop;
  protected Long                              m_evIndex;
  protected EventChannel                      m_eventChannel;
  protected org.omg.CosEventComm.PushConsumer m_pushConsumer;

  public ProxyPushSupplier( EventChannel ec)
  {
    m_stop         = false;
    m_evIndex      = new Long( 0);
    m_eventChannel = ec;
    m_pushConsumer = null;
  }

  public void disconnect_push_supplier()
  {
    // System.out.println( "disconnect_push_supplier");

    m_pushConsumer = null;
    m_stop = true;
  }

  public void connect_push_consumer( org.omg.CosEventComm.PushConsumer push_consumer)
    throws AlreadyConnected, TypeError
  {
    // System.out.println( "connect_push_consumer");

    if (  push_consumer == null)
      throw new org.omg.CORBA.BAD_PARAM();
    if ( m_pushConsumer != null)
      throw new AlreadyConnected();
    else
      m_pushConsumer = push_consumer;
  }

  public void run()
  {
    while ( !m_stop)
    {
      if ( m_pushConsumer != null)
      {
        try
        {
          m_pushConsumer.push( m_eventChannel.getEvent( m_evIndex));
          m_evIndex = new Long( m_evIndex.longValue()+1);

          // System.out.println( m_evIndex.longValue());
        }
        catch ( Disconnected ex)
        {
        }
      }
    }
  }
}
