/*
 * ProxyPullSupplier.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventComm.Disconnected;
import org.omg.CosEventChannelAdmin.AlreadyConnected;
import org.omg.CosEventChannelAdmin._ProxyPullSupplierImplBase;

public class ProxyPullSupplier extends _ProxyPullSupplierImplBase
{
  public org.omg.CORBA.Any pull()
    throws Disconnected
  {
    // System.out.println( "pull");
    return null;
  }

  public org.omg.CORBA.Any try_pull( org.omg.CORBA.BooleanHolder has_event)
    throws Disconnected
  {
    // System.out.println( "try_pull");
    return null;
  }

  public void disconnect_pull_supplier()
  {
    // System.out.println( "disconnect_pull_supplier");
  }

  public void connect_pull_consumer( org.omg.CosEventComm.PullConsumer pull_consumer)
    throws AlreadyConnected
  {
    // System.out.println( "connect_pull_consumer");
  }
}
