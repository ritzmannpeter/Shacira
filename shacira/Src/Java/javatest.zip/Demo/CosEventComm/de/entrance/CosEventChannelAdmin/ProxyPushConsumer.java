/*
 * ProxyPushConsumer.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventComm.Disconnected;
import org.omg.CosEventChannelAdmin.AlreadyConnected;
import org.omg.CosEventChannelAdmin._ProxyPushConsumerImplBase;

public class ProxyPushConsumer extends _ProxyPushConsumerImplBase
{
  protected boolean      m_connected;
  protected EventChannel m_eventChannel;
  protected org.omg.CosEventComm.PushSupplier m_pushSupplier;

  public ProxyPushConsumer( EventChannel ec)
  {
    m_connected    = false;
    m_eventChannel = ec;
    m_pushSupplier = null;
  }

  public void push( org.omg.CORBA.Any data)
    throws Disconnected
  {
    // System.out.println( "push");

    if ( !m_connected)
      throw new Disconnected();
    else
      m_eventChannel.appendEvent( data);
  }

  public void disconnect_push_consumer()
  {
    // System.out.println( "disconnect_push_consumer");

    m_pushSupplier = null;
    m_connected    = false;
  }

  public void connect_push_supplier( org.omg.CosEventComm.PushSupplier push_supplier)
    throws AlreadyConnected
  {
    // System.out.println( "connect_push_supplier");

    if ( push_supplier == null)
      throw new org.omg.CORBA.BAD_PARAM();
    if ( m_pushSupplier != null)
      throw new AlreadyConnected();
    else
    {
      m_connected    = true;
      m_pushSupplier = push_supplier;
    }
  }
}
