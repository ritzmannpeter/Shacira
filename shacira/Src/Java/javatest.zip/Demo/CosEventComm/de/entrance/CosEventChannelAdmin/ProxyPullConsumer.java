/*
 * ProxyPullConsumer.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1999 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventComm.Disconnected;
import org.omg.CosEventChannelAdmin.AlreadyConnected;
import org.omg.CosEventChannelAdmin.TypeError;
import org.omg.CosEventChannelAdmin._ProxyPullConsumerImplBase;

public class ProxyPullConsumer extends _ProxyPullConsumerImplBase
{
  public void disconnect_pull_consumer()
  {
    // System.out.println( "disconnect_pull_consumer");
  }

  public void connect_pull_supplier( org.omg.CosEventComm.PullSupplier pull_supplier)
    throws AlreadyConnected, TypeError
  {
    // System.out.println( "connect_pull_supplier");
  }
}
