/*
 * EventQueue.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import java.util.Vector;
import org.omg.CORBA.*;

class EventQueue
{
  protected int    m_capacity;
  protected int    m_size;
  protected long   m_lastReceivedEvent = -1;
  protected Vector m_eventVec;

  // Create an event queue without capacity constraints.
  public EventQueue()
  {
    // No capacity constraints.
    m_capacity = -1;
    // Set initial capacity to 100.
    m_eventVec = new Vector( 100);
  }

  // Create an event queue with a maximum capacity.
  public EventQueue( int capacity)
  {
    // Maximum capacity. If the maximum capacity is reached,
    // following events will delete events from the top of
    // the queue (vector).
    m_capacity = capacity;
    m_eventVec = new Vector( capacity);
  }

  public synchronized void appendEvent( org.omg.CORBA.Any ev)
  {
    // Number of events in the event queue.
    int size = m_eventVec.size();

    // If the maximum capacity was reached,
    if ( size == m_capacity)
    {
      // remove the event at the top of the queue.
      m_eventVec.removeElementAt( 0);
    }
    // Add the new event at the bottom of the queue.
    m_eventVec.addElement( ev);
    // Increase the number of received events.
    ++m_lastReceivedEvent;
    // Let the waiting ProxyPushSuppliers know that an
    // event has arrived.
    notifyAll();
  }

  public synchronized org.omg.CORBA.Any getEvent( Long evIndex)
  {
    // That's the index of the next available event in
    // the queue. If the queue has a maximum capacity, 
    // events could be deleted before a PullConsumer
    // has got them.
    long nextAvailableEvent;

    // The Requested or the next available event.
    org.omg.CORBA.Any nextEvent;

    try
    {
      // Wait for an event with the required index
      // to be put into the vector.
      while ( m_lastReceivedEvent < evIndex.longValue())
        wait();
    }
    catch ( InterruptedException ex)
    {
    }
    // Get the index of the next available event.
    nextAvailableEvent = m_lastReceivedEvent-m_eventVec.size()+1;
    // If the consumer requests an event which no longer
    // exists (nextAvailableEvent is greater than evIndex),
    if ( evIndex.longValue() < nextAvailableEvent)
    {
      // set the consumer's iterator to the next available
      // event.
      evIndex = new Long( nextAvailableEvent);
    }
    // Return the requested or the next available event.
    nextEvent = (org.omg.CORBA.Any) m_eventVec.elementAt(
                  (int) ( evIndex.longValue()-nextAvailableEvent));
    return nextEvent;
  }
}
