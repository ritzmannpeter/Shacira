/*
 * SupplierAdmin.java - Implementation
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Package name changed to de.entrance.CosEventChannelAdmin.
 *
 * pwatzlaw@entrance.de
 *
 */

package de.entrance.CosEventChannelAdmin;

import org.omg.CosEventChannelAdmin._SupplierAdminImplBase;
import de.entrance.CosEventChannelAdmin.*;

public class SupplierAdmin extends _SupplierAdminImplBase
{
  protected EventChannel m_eventChannel;

  public SupplierAdmin( EventChannel ec)
  {
    m_eventChannel = ec;
  }

  public org.omg.CosEventChannelAdmin.ProxyPushConsumer obtain_push_consumer()
  {
    // System.out.println( "obtain_push_consumer");

    ProxyPushConsumer ppc = new ProxyPushConsumer( m_eventChannel);
    m_eventChannel.addConsumer( ppc);

    return ppc;
  }

  public org.omg.CosEventChannelAdmin.ProxyPullConsumer obtain_pull_consumer()
  {
    // System.out.println( "obtain_pull_consumer");

    return new de.entrance.CosEventChannelAdmin.ProxyPullConsumer();
  }
}
