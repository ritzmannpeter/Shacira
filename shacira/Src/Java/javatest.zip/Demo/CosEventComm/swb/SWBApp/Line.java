/*
 * Line.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *
 * pwatzlaw@entrance.de
 *
 */

import java.awt.*;
import DrawingObject;
import generated.*;

public class Line extends DrawingObject
{
  public Line()
  {
    super();
  }

  public Line( Point beginPoint)
  {
    super( beginPoint);
  }

  public Line( NetMsg msg)
  {
    super( msg);
  }

  public boolean contains( Point screenPoint)
  {
    super.contains( screenPoint);

    int     mouseHeight = 12;
    int     mouseWidth  = 5;
    boolean state;
    Point   mp[] = new Point[3];

    for ( int i = 0; i < 3; i++)
      mp[ i] = new Point();

    mp[0] = screenPoint;
    mp[1].x = screenPoint.x;
    mp[1].y = screenPoint.y+mouseHeight;
    mp[2].x = screenPoint.x+mouseWidth;
    mp[2].y = screenPoint.y;

    state =  ( (( ccw( m_beginPoint, m_endPoint, mp[0])*
                  ccw( m_beginPoint, m_endPoint, mp[1])) <= 0) &&
               (( ccw( mp[0], mp[1], m_beginPoint     )*
                  ccw( mp[0], mp[1], m_endPoint       )) <= 0)) ||
             ( (( ccw( m_beginPoint, m_endPoint, mp[0])*
                  ccw( m_beginPoint, m_endPoint, mp[2])) <= 0) &&
               (( ccw( mp[0], mp[2], m_beginPoint     )*
                  ccw( mp[0], mp[2], m_endPoint       )) <= 0));
  
    return state;
  }

  // Protected methods.

  protected int ccw( Point p0, Point p1, Point p2)
  {
    int dx1;
    int dx2;
    int dy1;
    int dy2;

    int state = 0;

    dx1 = p1.x-p0.x;
    dy1 = p1.y-p0.y;
    dx2 = p2.x-p0.x;
    dy2 = p2.y-p0.y;
    if ( dx1*dy2 > dy1*dx2)
      state = 1;
    else if ( dx1*dy2 < dy1*dx2)
      state = -1;
    else if ( ( dx1*dx2 < 0) || ( dy1*dy2 < 0))
      state = -1;
    else if (( dx1*dx1+dy1*dy1) < ( dx2*dx2+dy2*dy2))
      state = 1;

    return state;
  }

  protected void paint( Graphics g)
  {
    super.paint( g);
    g.drawLine( m_beginPoint.x, m_beginPoint.y,
                m_endPoint.x, m_endPoint.y);
  }
}
