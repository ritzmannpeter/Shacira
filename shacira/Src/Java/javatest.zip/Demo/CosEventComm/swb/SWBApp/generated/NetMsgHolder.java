/*
 * File: SWB\SWBAPP/GENERATED/NETMSGHOLDER.JAVA
 * From: SWB\IDL\SWB.IDL
 * Date: Thu Mar 18 10:43:26 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package generated;
public final class NetMsgHolder
     implements org.omg.CORBA.portable.Streamable{
    //	instance variable 
    public generated.NetMsg value;
    //	constructors 
    public NetMsgHolder() {
	this(null);
    }
    public NetMsgHolder(generated.NetMsg __arg) {
	value = __arg;
    }

    public void _write(org.omg.CORBA.portable.OutputStream out) {
        generated.NetMsgHelper.write(out, value);
    }

    public void _read(org.omg.CORBA.portable.InputStream in) {
        value = generated.NetMsgHelper.read(in);
    }

    public org.omg.CORBA.TypeCode _type() {
        return generated.NetMsgHelper.type();
    }
}
