/*
 * DrawingObject.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *
 * pwatzlaw@entrance.de
 *
 */

import java.awt.*;
import generated.*;

public class DrawingObject
{
  public static final int NONE         = 0;
  public static final int CREATED      = 1;
  public static final int SKETCHED     = 2;
  public static final int SELECTED     = 3;
  public static final int HIT          = 4;
  public static final int MOVED        = 5;
  public static final int EDGESELECTED = 6;
  public static final int RESIZED      = 7;

  public static final int HOLLOW       = 0;
  public static final int SOLID        = 1;

  public static final int numEdges     = 8;

  // m_beginPoint and m_endPoint define two edges of the
  // DrawingObject's bounding box. m_beginPoint need not to be
  // the top, left corner and m_endPoint the bottom, right.
  protected Point m_beginPoint;
  protected Point m_endPoint;
  protected Point m_lastMovedPoint;

  // Needed for resizing.
  protected Point m_topEdge;
  protected Point m_leftEdge;
  protected Point m_bottomEdge;
  protected Point m_rightEdge;

  // Attributes.
  protected Color m_color;
  protected int   m_fillStyle;
  protected int   m_objectID;
  protected int   m_penSize;

  // The bounding rect of the DrawingObject. The point
  // (m_boundX, m_boundY) is the top, left corner. The point
  // (m_boundX+m_Width, m_boundY+m_Height) ist the bottom,
  // right corner.
  protected int m_boundX;
  protected int m_boundY;
  protected int m_boundWidth;
  protected int m_boundHeight;

  protected Rectangle m_edges[] = new Rectangle[ numEdges];
  protected int       m_selectedEdge;

  // State of the DrawingObject, e.g. MOVED.
  protected int m_state;

  protected NetMsg    m_netMsg = null;

  public DrawingObject()
  {
  }

  public DrawingObject( Point beginPoint)
  {
    m_beginPoint = beginPoint;
  }
  
  public DrawingObject( NetMsg msg)
  {
    m_netMsg = msg;
  }

  public void calcBoundingRect()
  {
    Point ep[] = new Point[numEdges];

    for ( int i = 0; i < numEdges; i++)
      ep[ i] = new Point();

    ep[0].x = m_boundX;
    ep[0].y = m_boundY;
    ep[2].x = m_boundX+m_boundWidth;
    ep[2].y = ep[0].y;
    ep[1].x = ep[0].x+(int) ((ep[2].x-ep[0].x)/2.0+0.5);
    ep[1].y = ep[0].y;
    ep[4].x = ep[2].x;
    ep[4].y = m_boundY+m_boundHeight;
    ep[3].x = ep[2].x;
    ep[3].y = ep[2].y+(int) ((ep[4].y-ep[2].y)/2.0+0.5);
    ep[5].x = ep[1].x;
    ep[5].y = ep[4].y;
    ep[6].x = ep[0].x;
    ep[6].y = ep[4].y;
    ep[7].x = ep[0].x;
    ep[7].y = ep[3].y;

    for ( int i = 0; i < numEdges; i++)
    {
      m_edges[i].x      = ep[ i].x-5;
      m_edges[i].y      = ep[ i].y-5;
      m_edges[i].height = 10;
      m_edges[i].width  = 10;
    }
  }

  public void calcCoordinates( Point endPoint)
  {
    m_boundWidth  = endPoint.x - m_beginPoint.x;
    m_boundHeight = endPoint.y - m_beginPoint.y;
    if ( m_boundWidth < 0)
    {
      m_boundX = m_beginPoint.x + m_boundWidth;
      m_boundWidth = m_boundWidth * -1 ;
    }
    else
      m_boundX = m_beginPoint.x;
    if ( m_boundHeight < 0)
    {
      m_boundY = m_beginPoint.y + m_boundHeight;
      m_boundHeight = m_boundHeight * -1;
    }
    else
      m_boundY = m_beginPoint.y;

    m_endPoint = endPoint;
  }

  public boolean contains( Point screenPoint)
  {
    m_lastMovedPoint = screenPoint;

    return false;
  }

  public void draw( Graphics g)
  {
    g.setColor( m_color);
    paint( g);
  }

  public void draw( Graphics g, Point screenPoint)
  {
    Color invColor;

    // Don't use the object's color for the XORMode.

    invColor = new Color( 255-m_color.getRed(),
                          255-m_color.getGreen(),
                          255-m_color.getBlue());
    g.setColor( m_color);
    g.setXORMode( invColor);
    paint( g, screenPoint);
    g.setPaintMode();
  }

  public void drawShape( Graphics g)
  {
    Color invColor;

    invColor = new Color( 255-m_color.getRed(),
                          255-m_color.getGreen(),
                          255-m_color.getBlue());

    g.setColor( m_color);
    g.setXORMode( invColor);
    paint( g);
    g.setPaintMode();
  }

  public void drawBoundingRect( Graphics g)
  {
    Color invColor;

    invColor = new Color( 255-m_color.getRed(),
                          255-m_color.getGreen(),
                          255-m_color.getBlue());
    g.setColor( m_color);
    g.setXORMode( invColor);
    for ( int i = 0; i < numEdges; i++)
    {
      g.fillRect( m_edges[i].x,     m_edges[i].y,
                  m_edges[i].width, m_edges[i].height);
    }
    g.setPaintMode();
  }

  public boolean edgeSelected( Point screenPoint)
  {
    boolean state = false;

    for ( int i = 0; i < numEdges; i++)
    {
      if ( m_edges[i].x <= screenPoint.x &&
           screenPoint.x <= m_edges[i].x+m_edges[i].width-1 &&
           m_edges[i].y <= screenPoint.y &&
           screenPoint.y <= m_edges[i].y+m_edges[i].height-1)
      {
        m_selectedEdge = i;
        state = true;
        break;
      }
    }
    m_lastMovedPoint = screenPoint;

    m_topEdge    = m_beginPoint;
    m_leftEdge   = m_beginPoint;
    m_bottomEdge = m_endPoint;
    m_rightEdge  = m_endPoint;
    if ( m_beginPoint.x > m_endPoint.x)
    {
      m_leftEdge  = m_endPoint;
      m_rightEdge = m_beginPoint;
    }
    if ( m_beginPoint.y > m_endPoint.y)
    {
      m_topEdge    = m_endPoint;
      m_bottomEdge = m_beginPoint;
    }

    return state;
  }

  public int getObjectId()
  {
    return m_objectID;
  }

  public int getState()
  {
    return m_state;
  }

  public void init()
  {
    m_state     = CREATED;
    m_color     = Color.black;
    m_penSize   = 1;
    m_fillStyle = HOLLOW;

    for ( int i = 0; i < numEdges; i++)
      m_edges[ i] = new Rectangle();

    if ( m_netMsg != null)
    {
      m_state        = NONE;

      m_objectID     = m_netMsg.objectID;
      m_beginPoint   = new Point( m_netMsg.beginX, m_netMsg.beginY);
      m_endPoint     = new Point( m_netMsg.endX, m_netMsg.endY);

      calcCoordinates( m_endPoint);
    }
  }

  public void move( Point beginPoint, Point endPoint)
  {
    m_beginPoint = beginPoint;
    m_endPoint   = endPoint;

    calcCoordinates( m_endPoint);
  }

  public void move( Point screenPoint)
  {
    Point l = m_lastMovedPoint;
    Point p = screenPoint;

    m_beginPoint.x = m_beginPoint.x+p.x-l.x;
    m_beginPoint.y = m_beginPoint.y+p.y-l.y;
    m_endPoint.x   = m_endPoint.x+p.x-l.x;
    m_endPoint.y   = m_endPoint.y+p.y-l.y;

    calcCoordinates( m_endPoint);
  
    m_lastMovedPoint = screenPoint;
  }

  public void resize( Point screenPoint)
  {
    boolean top    = false;
    boolean left   = false;
    boolean bottom = false;
    boolean right  = false;

    Point   l = m_lastMovedPoint;
    Point   p = screenPoint;

    switch( m_selectedEdge)
    {
      case 0:
        top = true;
        left = true;
        break;
      case 1:
        top = true;
        break;
      case 2:
        top = true;
        right = true;
        break;
      case 3:
        right = true;
        break;
      case 4:
        right = true;
        bottom = true;
        break;
      case 5:
        bottom = true;
        break;
      case 6:
        bottom = true;
        left = true;
        break;
      case 7:
        left = true;
        break;
    }
    if ( top)
      m_topEdge.y = m_topEdge.y+p.y-l.y;
    if ( left)
      m_leftEdge.x = m_leftEdge.x+p.x-l.x;
    if ( bottom)
      m_bottomEdge.y = m_bottomEdge.y+p.y-l.y;
    if ( right)
      m_rightEdge.x = m_rightEdge.x+p.x-l.x;

    calcCoordinates( m_endPoint);

    m_lastMovedPoint = screenPoint;
  }

  public NetMsg serialize()
  {
    return new NetMsg( 0, m_objectID,
                       m_beginPoint.x, m_beginPoint.y,
                       m_endPoint.x, m_endPoint.y);
  }

  public void setColor( Color color)
  {
    m_color = color;
  }

  public void setFillStyle( int fillStyle)
  {
    if ( fillStyle == HOLLOW || fillStyle == SOLID)
      m_fillStyle = fillStyle;
  }

  public void setObjectId( int objectID)
  {
    m_objectID = objectID;
  }
                
  public void setPenSize( int penSize)
  {
    m_penSize = penSize;
  }
                
  public void setState( int state)
  {
    m_state = state;
  }
                
  // Protected methods.

  protected void paint( Graphics g)
  {
    calcBoundingRect();
  }

  protected void paint( Graphics g, Point currentPoint)
  {
    calcCoordinates( currentPoint);
    paint( g);
  }
}
