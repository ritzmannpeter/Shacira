/*
 * File: SWB\SWBAPP/GENERATED/NETMSG.JAVA
 * From: SWB\IDL\SWB.IDL
 * Date: Thu Mar 18 10:43:26 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package generated;
public final class NetMsg {
    //	instance variables
    public int type;
    public int objectID;
    public int beginX;
    public int beginY;
    public int endX;
    public int endY;
    //	constructors
    public NetMsg() { }
    public NetMsg(int __type, int __objectID, int __beginX, int __beginY, int __endX, int __endY) {
	type = __type;
	objectID = __objectID;
	beginX = __beginX;
	beginY = __beginY;
	endX = __endX;
	endY = __endY;
    }
}
