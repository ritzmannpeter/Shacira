/*
 * File: SWB\SWBAPP/GENERATED/NETMSGHELPER.JAVA
 * From: SWB\IDL\SWB.IDL
 * Date: Thu Mar 18 10:43:26 1999
 *   By: idltojava Java IDL 1.2 Nov 10 1997 13:52:11
 */

package generated;
public class NetMsgHelper {
     // It is useless to have instances of this class
     private NetMsgHelper() { }

    public static void write(org.omg.CORBA.portable.OutputStream out, generated.NetMsg that) {
	out.write_long(that.type);
	out.write_long(that.objectID);
	out.write_long(that.beginX);
	out.write_long(that.beginY);
	out.write_long(that.endX);
	out.write_long(that.endY);
    }
    public static generated.NetMsg read(org.omg.CORBA.portable.InputStream in) {
        generated.NetMsg that = new generated.NetMsg();
	that.type = in.read_long();
	that.objectID = in.read_long();
	that.beginX = in.read_long();
	that.beginY = in.read_long();
	that.endX = in.read_long();
	that.endY = in.read_long();
        return that;
    }
   public static generated.NetMsg extract(org.omg.CORBA.Any a) {
     org.omg.CORBA.portable.InputStream in = a.create_input_stream();
     return read(in);
   }
   public static void insert(org.omg.CORBA.Any a, generated.NetMsg that) {
     org.omg.CORBA.portable.OutputStream out = a.create_output_stream();
     write(out, that);
     a.read_value(out.create_input_stream(), type());
   }
   private static org.omg.CORBA.TypeCode _tc;
   synchronized public static org.omg.CORBA.TypeCode type() {
       int _memberCount = 6;
       org.omg.CORBA.StructMember[] _members = null;
          if (_tc == null) {
               _members= new org.omg.CORBA.StructMember[6];
               _members[0] = new org.omg.CORBA.StructMember(
                 "type",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[1] = new org.omg.CORBA.StructMember(
                 "objectID",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[2] = new org.omg.CORBA.StructMember(
                 "beginX",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[3] = new org.omg.CORBA.StructMember(
                 "beginY",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[4] = new org.omg.CORBA.StructMember(
                 "endX",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);

               _members[5] = new org.omg.CORBA.StructMember(
                 "endY",
                 org.omg.CORBA.ORB.init().get_primitive_tc(org.omg.CORBA.TCKind.tk_long),
                 null);
             _tc = org.omg.CORBA.ORB.init().create_struct_tc(id(), "NetMsg", _members);
          }
      return _tc;
   }
   public static String id() {
       return "IDL:NetMsg:1.0";
   }
}
