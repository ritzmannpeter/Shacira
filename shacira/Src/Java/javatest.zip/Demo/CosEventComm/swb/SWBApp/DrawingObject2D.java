/*
 * DrawingObject2D.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *
 * pwatzlaw@entrance.de
 *
 */

import java.awt.*;
import DrawingObject;
import generated.*;

public class DrawingObject2D extends DrawingObject
{
  public DrawingObject2D()
  {
    super();
  }

  public DrawingObject2D( Point beginPoint)
  {
    super( beginPoint);
  }

  public DrawingObject2D( NetMsg msg)
  {
    super( msg);
  }

  public boolean contains( Point screenPoint)
  {
    Point p = screenPoint;
  
    super.contains( screenPoint);

    return ( ( m_boundX <= p.x && p.x <= m_boundX+m_boundWidth) &&
             ( m_boundY <= p.y && p.y <= m_boundY+m_boundHeight));
  }

  // Protected methods.

  public void paint( Graphics g)
  {
    super.paint( g);
  }
}
