/*
 * SWBApp.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              01/15/1999 Paul Watzlaw
 *              Tested with ORBacus 3.1 on Linux and JDK 1.1.5.
 *
 * pwatzlaw@entrance.de
 *
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.URL;
import java.util.*;
import javax.swing.*; 
// Do I really need this?
import javax.swing.event.*;

import org.omg.CORBA.*;
import org.omg.CosEventComm.*;
import org.omg.CosEventChannelAdmin.*;

import generated.*;

import DrawingObject;
import Line;
import Rect;
import Circle;

public class SWBApp extends _PushConsumerImplBase
{
  protected static ORB        m_orb;

  protected SWBPanel          m_swbPanel;
  protected ProxyPushConsumer m_ppc;
  protected ProxyPushSupplier m_pps;

  public static void main( String args[])
  {
    m_orb = ORB.init( args, new java.util.Properties());

    new SWBApp( args);
  }

  public static ORB getORB()
  {
    return m_orb;
  }

  public SWBApp( String args[])
  {
    // Force SwingSet to come up in the Cross Platform L&F
    try
    {
      UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
      // If you want the System L&F instead, comment out the above line and
      // uncomment the following:
      // UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (Exception exc)
    {
      System.err.println("Error loading L&F: " + exc);
    }

    // javaIDL doesn't require a BOA to be created, but maybe other
    // ORBs.
    // BOA boa = m_orb.BOA_init( args, new java.util.Properties());

    // Get the reference to the event channel.
    String ref = null;
    try
    {
      String refFile = "../SWBChannel.ior";
      FileInputStream file = new FileInputStream( refFile);
      DataInputStream in = new DataInputStream( file);
      ref = in.readLine();
      file.close();
    }
    catch( IOException ex)
    {
      System.err.println( "Can't read from '" + ex.getMessage() + "'");
      System.exit(1);
    }
    org.omg.CORBA.Object obj = m_orb.string_to_object(ref);
    if( obj == null)
      throw new RuntimeException();
    EventChannel eventChannel = EventChannelHelper.narrow( obj);

    // Get the SupplierAdmin reference.
    SupplierAdmin supplierAdmin = eventChannel.for_suppliers();
    // Create a new ProxyPushConsumer for this client.
    m_ppc = supplierAdmin.obtain_push_consumer();
    // Get the ConsumerAdmin reference.
    ConsumerAdmin consumerAdmin = eventChannel.for_consumers();
    // Create a ProxyPushSupplier for this client.
    m_pps = consumerAdmin.obtain_push_supplier();

    // Create the paint Panel.
    JFrame frame = new JFrame();
    WindowListener l = new WindowAdapter()
    {
      public void windowClosing( WindowEvent e)
      {
        m_ppc.disconnect_push_consumer();
        m_pps.disconnect_push_supplier();
        System.exit(0);
      }
    }; 
    frame.addWindowListener( l);
    m_swbPanel = new SWBPanel( m_ppc, m_pps);
    m_swbPanel.addMouseListener( m_swbPanel);
    m_swbPanel.addMouseMotionListener( m_swbPanel);
    frame.getContentPane().setLayout( new BorderLayout());
    frame.getContentPane().add( "Center", m_swbPanel);
    frame.pack();
    frame.setSize( 400, 350);
    frame.show();
    // Connect this client (ProxyPushConsumer) to the
    // ProxyPushSupplier.
    try {
      m_pps.connect_push_consumer( this);
    }
    catch ( org.omg.CosEventChannelAdmin.AlreadyConnected ex) {
      System.out.println( "AlreadyConnected");
    }
    catch ( org.omg.CosEventChannelAdmin.TypeError ex) {
      System.out.println( "TypeError");
    }
    catch ( org.omg.CORBA.BAD_PARAM ex) {
      System.out.println( "Can't connect a null reference consumer to the channel!");
    }
    // Connect this client (ProxyPushSupplier) to the
    // ProxyPushConsumer.
    SWBPushSupplier sps = new SWBPushSupplier();
    try {
      m_ppc.connect_push_supplier( sps);
    }
    catch ( org.omg.CosEventChannelAdmin.AlreadyConnected ex) {
      System.out.println( "AlreadyConnected");
    }
    catch ( org.omg.CORBA.BAD_PARAM ex) {
      System.out.println( "Can't connect a null reference supplier to the channel!");
    }

    // Instead of calling boa.impl_is_ready, javaIDL uses the
    // following code.

    // javaIDL.
    m_orb.connect( this);

    try
    {
      java.lang.Object sync = new java.lang.Object();
      synchronized (sync)
      {
        sync.wait();
      }
    }
    catch( java.lang.InterruptedException ex)
    {
    }
    // javaIDL.

    // For other ORBs use boa.impl_is_ready.
    // boa.impl_is_ready( null);
  }

  // PushConsumer interface.

  public void disconnect_push_consumer()
  {
    // System.out.println( "disconnect_push_consumer");
  }

  public void push( org.omg.CORBA.Any data)
    throws Disconnected
  {
    m_swbPanel.insertElement( data);
  }

  // PushSupplier interface.

  class SWBPushSupplier extends _PushSupplierImplBase
  {
    public void disconnect_push_supplier()
    {
      // System.out.println( "Ouch, I've been disconnected!");
    }
  }
}

class SWBPanel extends JPanel
               implements MouseListener, MouseMotionListener
{
  public static final int TARROW     = 1;
  public static final int TLINE      = 2;
  public static final int TRECT      = 3;
  public static final int TCIRCLE    = 4;
  public static final int TMOVE      = 200;
  public static final int TDELETE    = 201;

  public static final String actionSuffix = "Action";
  public static final String imageSuffix  = "Image";

  // Has the left button been pressed or was it the right?
  protected boolean       m_leftButton;
  // Next possible DrawingObject's ID.
  protected int           m_currentID;
  // Currently selected element from the toolbar.
  protected int           m_elementType = TLINE;
  // Currently selected fillstyle.
  protected int           m_fillStyle   = DrawingObject.HOLLOW;
  // Currently selected line width.
  protected int           m_lineWidth   = 1;
  // Currently selected color.
  protected int           m_red         = Color.black.getRed();
  protected int           m_green       = Color.black.getGreen();
  protected int           m_blue        = Color.black.getBlue();
  protected Point         m_currentPoint;
  protected Vector        m_objectVec;
  protected Vector        m_actions;
  protected DrawingObject m_currentObject;
  protected JToolBar      m_toolbar;

  protected ProxyPushConsumer  m_ppc;
  protected ProxyPushSupplier  m_pps;

  protected SelectionRefresher m_sr = null;

  private static ResourceBundle resources;

  static
  {
    try
    {
      resources = ResourceBundle.getBundle("SWBPanel",
                                           Locale.getDefault());
    }
    catch ( MissingResourceException mre)
    {
      System.err.println( "SWBPanel.properties not found");
      System.exit( 1);
    }
  }

  public SWBPanel( ProxyPushConsumer ppc,
                   ProxyPushSupplier pps)
  {
    super();

    m_currentID     = 0;
    m_currentPoint  = new Point( -1, -1);
    m_objectVec     = new Vector( 100);
    m_actions       = new Vector( 10);
    m_currentObject = null;

    m_ppc           = ppc;
    m_pps           = pps;

//    JPanel panel;

    setBorder( BorderFactory.createEtchedBorder());
//    panel = new JPanel();
//    panel.setLayout( new BorderLayout());
//    panel.add( "Center", new JPanel());
    setLayout( new BorderLayout());
    add( "North", createToolbar());
//    add( "Center", panel);
  }

  public void insertElement( org.omg.CORBA.Any msg)
  {
    DrawingObject d = null;
    NetMsg        n;

    n = NetMsgHelper.extract( msg);

    if ( n.type >= TMOVE)
      d = locateObject( n.objectID);
    // Check the type of the message.
    switch( n.type)
    {
      // Object was moved.
      case TMOVE:
        if ( d != null)
        {
          // Only new coordinates were sent, move
          // the object to the new position.
          Point begin = new Point( n.beginX, n.beginY);
          Point end   = new Point( n.endX, n.endY);
          d.move( begin, end);
          d = null;
          repaint();
        }
        break;
      // Object was deleted.
      case TDELETE:
        break;
      // New object was created.
      default:
        // If someone else created this object,
        if ( n.objectID >= m_currentID)
        {
          // create this object too.

          // For more object types a factory would
          // be nice.
          if ( n.type == TLINE)
            d = new Line( n);
          else if ( n.type == TRECT)
            d = new Rect( n);
          else if ( n.type == TCIRCLE)
            d = new Circle( n);
        }
        break;
    }
    // A new object was really created.
    if ( d != null)
    {
      d.init();
      m_objectVec.addElement( d);
      m_currentID = ++n.objectID;
      repaint();
    }
  }

  // Interface MouseListener.

  public void mouseClicked( MouseEvent e)
  {
  }

  public void mouseEntered( MouseEvent e)
  {
  }

  public void mouseExited( MouseEvent e)
  {
  }

  public void mousePressed( MouseEvent e)
  {
    m_leftButton = false;

//    if ( (e.getModifiers()&InputEvent.BUTTON1_MASK) ==
//         InputEvent.BUTTON1_MASK)
    {
      // Strange, but button clicks outside this panel
      // are registered here.
      if ( contains( e.getPoint()))
      {
        m_leftButton = true;
        onLButtonDown( e);
      }
    }
  }

  public void mouseReleased( MouseEvent e)
  {
//    if ( (e.getModifiers()&InputEvent.BUTTON1_MASK) == InputEvent.BUTTON1_MASK)
      onLButtonUp( e);
  }

  // Interface MouseMotionListener.

  public void mouseDragged( MouseEvent e)
  {
//    if ( !m_leftButton)
//      return;

    boolean  state = true;
    Point    mousePoint;
    Graphics g = getGraphics();

    // The current mouse position in screen coordinates.
    mousePoint = e.getPoint();

    if ( m_currentObject != null)
    {
      // A new object is drawn.

      if ( mousePoint != m_currentPoint && m_elementType != TARROW)
      {
        if ( state)
        {
          // If the currently sketched object was already drawn
          // with the XORMode another draw with this mode will delete
          // the object from the screen.
          if ( m_currentObject.getState() == DrawingObject.SKETCHED)
            m_currentObject.draw( g, m_currentPoint);
          else
            m_currentObject.setState( DrawingObject.SKETCHED);

          // Store the new mouse position.
          m_currentPoint = mousePoint;

          // Draw the object with the XORMode at the new mouse position.
          m_currentObject.draw( g, m_currentPoint);
        }
      }

      else if ( m_elementType == TARROW)
      {
        // The selected object is moved.
        if ( m_currentObject.getState() == DrawingObject.HIT ||
             m_currentObject.getState() == DrawingObject.MOVED)
        {
          if ( m_currentObject.getState() == DrawingObject.MOVED)
            m_currentObject.drawShape( g);
          else
          {
            m_currentObject.drawBoundingRect( g);
            m_currentObject.setState( DrawingObject.MOVED);
          }
          m_currentObject.move( mousePoint);
          m_currentObject.drawShape( g);
        }

        // The selected object is resized.
        else if ( m_currentObject.getState() == DrawingObject.EDGESELECTED ||
                  m_currentObject.getState() == DrawingObject.RESIZED)
        {
          if ( m_currentObject.getState() == DrawingObject.RESIZED)
            m_currentObject.drawShape( g);
          else
          {
            m_currentObject.drawBoundingRect( g);
            m_currentObject.setState( DrawingObject.RESIZED);
          }
          m_currentObject.resize( mousePoint);
          m_currentObject.drawShape( g);
        }
      }
    }
  }

  public void mouseMoved( MouseEvent e)
  {
//    if ( !m_leftButton)
//      return;

    boolean  state = true;
    Point    mousePoint;
    Graphics g = getGraphics();

    // The current mouse position in screen coordinates.
    mousePoint = e.getPoint();

    if ( m_currentObject != null)
    {
      // The mouse entered an edge of the selected object. Now the
      // object may be resized.
      if ( m_currentObject.edgeSelected( mousePoint) &&
           m_elementType == TARROW)
      {
        if ( state)
          m_currentObject.setState( DrawingObject.EDGESELECTED);
      }
      // The mouse entered the selected object. Now the object may
      // be moved to another position.
      else if ( m_currentObject.contains( mousePoint) &&
                m_elementType == TARROW)
      {
        if ( state)
        {
          if ( m_currentObject.getState() == DrawingObject.SELECTED)
            m_currentObject.setState( DrawingObject.HIT);
        }
      }

      // Nothing happend.
      else
      {
        if ( m_currentObject.getState() == DrawingObject.HIT ||
             m_currentObject.getState() == DrawingObject.EDGESELECTED)
          m_currentObject.setState( DrawingObject.SELECTED);
      }
    }
  }

  synchronized public void paint( Graphics g)
  {
    super.paint( g);
  }

  public void paintComponent( Graphics g)
  {
    Rectangle     bounds = getBounds();
    DrawingObject d;

    g.setColor( Color.white);
    g.fillRect( bounds.x, bounds.y, bounds.width, bounds.height);
    for ( Enumeration e = m_objectVec.elements(); e.hasMoreElements();)
    {
      d = (DrawingObject) e.nextElement();
      d.draw( g);
    }
    // Oh my god, what's that for!?!
    //
    // Well, maybe I'm wrong, but it seems that setting
    // the XORMode doesn't work inside paintComponent.
    // Therefore a second thread is started to paint the
    // bounding rect of the selected object after paintComponent
    // returns.
    if ( m_sr == null)
    {
      // Sometimes paint is called twice (???).
      // In this case the first thread would paint the bounding rect
      // with XORMode. The following paint (in the second thread)
      // would delete the rect again. So only one SelectionRefresher
      // is allowed.
      m_sr = new SelectionRefresher();
      new Thread( new SelectionRefresher()).start();
    }
  }

  synchronized public void refreshSelection()
  {
    if ( m_currentObject != null)
      m_currentObject.drawBoundingRect( getGraphics());
  }

  // Protected methods.

  protected DrawingObject hit()
  {
    DrawingObject d;
    DrawingObject hit = null;

    for ( int i = m_objectVec.size()-1; i >= 0; i--)
    {
      d = (DrawingObject) m_objectVec.elementAt( i);
      if ( d.contains( m_currentPoint))
      {
        hit = d;
        break;
      }
    }
    return hit;
  }

  protected DrawingObject locateObject( int objectID)
  {
    DrawingObject d;
    DrawingObject l = null;

    for ( Enumeration e = m_objectVec.elements(); e.hasMoreElements();)
    {
      d = (DrawingObject) e.nextElement();
      if ( d.getObjectId() == objectID)
      {
        l = d;
        break;
      }
    }
    return l;
  }

  protected void onLButtonDown( MouseEvent e)
  {
    Graphics g = getGraphics();

    m_currentPoint = e.getPoint();

    // If an drawing object is selected, deselect it.
    if ( m_currentObject != null)
    {
      m_currentObject.setState( DrawingObject.NONE);

      // Remove the object's bounding rect.
      m_currentObject.drawBoundingRect( g);
    }

    // The arrow is selected from the toolbar. Therefore move or
    // resize the object.
    if ( m_elementType == TARROW)
      onLButtonDownSelect( g);
    // A drawing element is selected from the toolbar. Draw the new object.
    else
    {
      Point startPoint = e.getPoint();

      onLButtonDownDraw( g, startPoint);
    }
  }

  protected void onLButtonDownDraw( Graphics g, Point startPoint)
  {
    boolean state = true;

    m_currentObject = hit();

    // Create a new object and draw it. The object's state is set
    // to DrawingObject.CREATED.
  
    switch ( m_elementType)
    {
      case TLINE:
        m_currentObject = new Line( startPoint);
        break;
      case TRECT:
        m_currentObject = new Rect( startPoint);
        break;
      case TCIRCLE:
        m_currentObject = new Circle( startPoint);
        break;
      default:
        m_currentObject = new Line( startPoint);
    }
    if ( m_currentObject != null)
    {
      Color color = new Color( m_red, m_green, m_blue);

      m_currentObject.init();
      m_currentObject.setObjectId( m_currentID++);
      m_currentObject.setColor( color);
      m_currentObject.setPenSize( m_lineWidth);
      m_currentObject.setFillStyle( m_fillStyle);
    }
  }

  protected void onLButtonDownSelect( Graphics g)
  {
    boolean state = true;

    if ( m_currentObject != null)
    {
      if ( m_currentObject.edgeSelected( m_currentPoint))
      {
        m_currentObject.setState( DrawingObject.EDGESELECTED);
        state = false;
      }
    }

    if ( state)
    {
      m_currentObject = hit();

      if ( m_currentObject != null)
      {
        m_currentObject.drawBoundingRect( g);
        m_currentObject.setState( DrawingObject.HIT);
      }
    }
  }

  protected void onLButtonUp( MouseEvent e)
  {
    Graphics g = getGraphics();

    if ( m_elementType == TARROW)
      onLButtonUpSelect( g);
    else
      onLButtonUpDraw( g);
  }

  protected void onLButtonUpDraw( Graphics g)
  {
    if ( m_currentObject != null)
    {
      // The object was really sketched.
      if ( m_currentObject.getState() == DrawingObject.SKETCHED)
      {
        // Delete the objects shape drawn with the XOR-mode.
        m_currentObject.draw( g, m_currentPoint);

        // The new sketched object is also the selected object.
        m_currentObject.setState( DrawingObject.SELECTED);

        // Put the object at the bottom of the objects' vector. So the
        // object will be drawn as the topmost drawing element.
        m_objectVec.addElement( m_currentObject);

        // Draw the object with it's real attributes like color and
        // line width and then draw the object's 'bounding rectangle'.
        m_currentObject.draw( g);
        m_currentObject.drawBoundingRect( g);

        // Send a message to the event channel.
        sendElement( m_currentObject, m_elementType);
      }
      // If the object was only created and not sketched (e.g. one
      // point rectangle), don't append the object to the vector.
      else if ( m_currentObject.getState() == DrawingObject.CREATED)
        m_currentObject = null;
    }
    m_currentPoint = new Point( -1, -1);
  }

  protected void onLButtonUpSelect( Graphics g)
  {
    if ( m_currentObject != null)
    {
      if ( m_currentObject.getState() == DrawingObject.RESIZED)
      {
        m_currentObject.setState( DrawingObject.EDGESELECTED);
        repaint();
      }
      else if ( m_currentObject.getState() == DrawingObject.MOVED)
      {
        m_currentObject.setState( DrawingObject.HIT);
        repaint();
      }

      // Send a message to the event channel.
      sendElement( m_currentObject, TMOVE);
    }
  }

  protected void sendElement( DrawingObject d, int elementType)
  {
    org.omg.CORBA.Any msg = SWBApp.getORB().create_any();
    NetMsg            n   = d.serialize();

    n.type = elementType;
    NetMsgHelper.insert(msg, n);
    try
    {
      m_ppc.push( msg);
    }
    catch( Disconnected ex)
    {
    }
  }

  // Methods borrowed from the JFC-Notepad-example ;-).

  private Component createToolbar()
  {
    m_toolbar = new JToolBar();
    String[] toolKeys = tokenize( getResourceString("toolbar"));
    for ( int i = 0; i < toolKeys.length; i++)
    {
      if ( toolKeys[i].equals("-"))
      {
        m_toolbar.add( Box.createHorizontalStrut(5));
      }
      else
      {
        m_toolbar.add( createTool(toolKeys[i]));
      }
    }
    m_toolbar.add( Box.createHorizontalGlue());

    return m_toolbar;
  }

  protected Component createTool(String key)
  {
    return createToolbarButton( key);
  }

  protected JButton createToolbarButton(String key)
  {
    URL url = getResource( key + imageSuffix);
    JButton b = new JButton( new ImageIcon( url))
    {
      public float getAlignmentY() { return 0.5f; }
    };
    b.setRequestFocusEnabled( false);
    b.setMargin(new Insets( 1,1,1,1));

    String astr = getResourceString( key + actionSuffix);
    if ( astr == null)
    {
      astr = key;
    }
    m_actions.addElement( astr);
    Action a = new ToolAction( "");
    if (a != null)
    {
      b.setActionCommand(astr);
      b.addActionListener(a);
    }
    else
    {
      b.setEnabled(false);
    }
    return b;
  }

  protected String getResourceString(String nm)
  {
    String str;

    try
    {
      str = resources.getString(nm);
    }
    catch (MissingResourceException mre)
    {
      str = null;
    }
    return str;
  }

  protected URL getResource(String key)
  {
    String name = getResourceString(key);

    if (name != null)
    {
      URL url = this.getClass().getResource( name);

      return url;
    }
    return null;
  }

  protected String[] tokenize(String input)
  {
    Vector v = new Vector();
    StringTokenizer t = new StringTokenizer(input);
    String cmd[];

    while (t.hasMoreTokens())
      v.addElement(t.nextToken());
    cmd = new String[v.size()];
    for (int i = 0; i < cmd.length; i++)
      cmd[i] = (String) v.elementAt(i);

    return cmd;
  }

  // Actions.

  class ToolAction extends AbstractAction
  {
    ToolAction()
    {
      super( "ToolSelected");
    }

    ToolAction( String action)
    {
      super( action);
    }

    public void actionPerformed( ActionEvent a)
    {
      m_elementType = TARROW;

      for ( Enumeration e = m_actions.elements(); e.hasMoreElements();)
      {
        if ( ((String) e.nextElement()).equals( a.getActionCommand()))
          break;
        ++m_elementType;
      }
    }
  }

  // Very special SelectionRefresher.

  class SelectionRefresher implements Runnable
  {
    public void run()
    {
      refreshSelection();
      m_sr = null;
    }
  }
}
