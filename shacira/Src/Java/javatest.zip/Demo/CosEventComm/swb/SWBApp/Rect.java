/*
 * Rect.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1999 Paul Watzlaw
 *
 * pwatzlaw@entrance.de
 *
 */

import java.awt.*;
import DrawingObject2D;
import generated.*;

public class Rect extends DrawingObject2D
{
  public Rect()
  {
    super();
  }

  public Rect( Point beginPoint)
  {
    super( beginPoint);
  }

  public Rect( NetMsg msg)
  {
    super( msg);
  }

  // Protected methods.

  public void paint( Graphics g)
  {
    super.paint( g);

    g.drawRect( m_boundX, m_boundY, m_boundWidth, m_boundHeight);
  }
}
