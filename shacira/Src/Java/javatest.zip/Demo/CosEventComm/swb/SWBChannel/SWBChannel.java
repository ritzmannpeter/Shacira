/*
 * SWBChannel.java
 *
 * Copyright 1998, 1999 Entrance Software GmbH, Kassel  
 * All rights reserved
 *
 * Example for the COSS Event Service.
 *
 * Author: Paul Watzlaw
 * Last update: 07/15/1998 Paul Watzlaw
 *              03/18/1999 Paul Watzlaw
 *              Annotation for other event channel implementations.
 *
 * pwatzlaw@entrance.de
 *
 */

import java.io.*;
import org.omg.CORBA.*;
import de.entrance.CosEventChannelAdmin.*;

public class SWBChannel
{
  public static void main( String args[])
  {
    try
    {
      ORB orb = ORB.init( args, new java.util.Properties());
      // javaIDL doesn't require a BOA to be created, but maybe other
      // ORBs.
      // BOA boa = m_orb.BOA_init( args, new java.util.Properties());

      // Depending on the event service implementation you possibly
      // have to pass an argument to the constructor of EventChannel.
      // E.g. the event service of ORBacus 3.1 requires the orb object
      // to be passed: com.ooc.CosEventChannelAdmin.EventChannel( orb).
      org.omg.CosEventChannelAdmin.EventChannel eventChannel =
        new de.entrance.CosEventChannelAdmin.EventChannel();
      try
      {
        String ref = orb.object_to_string( eventChannel);
        String refFile = "../SWBChannel.ior";
        FileOutputStream file = new FileOutputStream( refFile);
        PrintStream out = new PrintStream( file);
        out.println( ref);
        out.flush();
        file.close();
      }
      catch( IOException ex)
      {
        System.err.println( "Can't write to '" + ex.getMessage() + "'");
        System.exit(1);
      }
      // Instead of calling boa.impl_is_ready, javaIDL uses the
      // following code.

      // javaIDL.
      orb.connect( eventChannel);

      try
      {
        java.lang.Object sync = new java.lang.Object();
        synchronized (sync)
        {
          sync.wait();
        }
      }
      catch( java.lang.InterruptedException ex)
      {
      }
      // javaIDL.

      // For other ORBs use boa.impl_is_ready.
      // boa.impl_is_ready( null);
    }
    catch( SystemException ex)
    {
      System.out.println( "SystemException");
    }
  }
}
