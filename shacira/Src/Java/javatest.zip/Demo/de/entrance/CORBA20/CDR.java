// CDR.java
//
// Copyright 1997, 1998, 1999 Entrance Software GmbH, Kassel
//
// Author     : 03/09/1997 Paul Watzlaw
// Last update: 11/10/1997
//              11/18/1997 Convert characters to lower case.
//                         To avoid an overflow use a char array instead of a
//                         byte array (_CDRArray).
//              12/29/1998 Paul Watzlaw
//                         Changed package name from DE.ENTRANCE.CORBA20
//                         to de.entrance.CORBA20.
//              12/30/1998 Paul Watzlaw
//                         Return stringLen-1 bytes in method getString.
//
// pwatzlaw@entrance.de

package de.entrance.CORBA20;

public class CDR {
  protected boolean _byteOrder;
  protected int     _byteLen,
                    _bytePos = 1;
  protected char[]  _CDRArray;

  public char getChar() {
    return (char) _CDRArray[_bytePos++];
  }

  public long getULong() {
    skip(4);

    return getBytes(4);
  }

  public int getUShort() {
    skip(2);

    return (int) getBytes(2);
  }

  public char[] getSequence()
  {
    char[] sequence;
    double seqLen;

    seqLen = getULong();
    sequence = new char[ (int) seqLen];
    for ( int i = 0; i < seqLen; i++)
      sequence[ i] = _CDRArray[ _bytePos++];
    return sequence;
  }

  public String getString() {
    // In IDL an unsigned long is a 32-bit unsigned integer. In Java a long
    // is a 64-bit signed two's-complement integer.

    double stringLen;

    stringLen = getULong();
    _bytePos += (int) stringLen;
    return new String(_CDRArray, _bytePos-(int) stringLen, (int) stringLen-1);
  }

  public void parseByteArray( char[] sequence)
  {
    _CDRArray = sequence;
    init();
  }

  public void parseHexString(String hexCDRString) {
    char cdrByte;

    _byteLen  = hexCDRString.length()/2;
    _CDRArray = new char[_byteLen];
    for (int i = 0; i < _byteLen*2; i+=2) {
      cdrByte = hex2dual(hexCDRString.charAt(i));
      cdrByte = (char) (cdrByte << 4);
      cdrByte |= hex2dual(hexCDRString.charAt(i+1));
      _CDRArray[i/2] = cdrByte;
    }
    init();
  }

  public String toHexString() {
    return new String();
  }

  // Protected methods.

  protected long getBytes(int count) {
    // Copy the octets depending on the server's byte order. Java Virtual
    // Machine uses ordering in big-endian (IOR flag is 0 = false).

    long buff = 0;

    if (_byteOrder) {
      // Server's ordering is little-endian (IOR flag is 1 = true).

      for (int i = count-1; i >= 0; i--)
      {
        buff += _CDRArray[_bytePos+i];
        if (i != 0)
          buff = (buff << 8);
      }
      _bytePos += count;
/*
      for ( int i = 0; i < count; i++)
        buff += _CDRArray[_bytePos++]*((long) Math.pow(256, i));
*/
    } else {
      // Server's ordering is big-endian (IOR flag is 0 = false).

      for (int i = 0; i < count; i++)
      {
        buff += _CDRArray[_bytePos++];
        if (i != count-1)
          buff = (buff << 8);
      }
/*
      for ( int i = 0; i < count; i++)
        buff += _CDRArray[_bytePos++]*((long) Math.pow(256, count-i-1));
*/
    }
    return buff;
  }

  protected char hex2dual(char hc) {
    char dual = 0;

    if (Character.isDigit(hc))
      dual = (char) (new Integer(""+hc).intValue());
    else {
      hc = Character.toLowerCase(hc);

      if (hc == 'a')
        dual = 10;
      if (hc == 'b')
        dual = 11;
      if (hc == 'c')
        dual = 12;
      if (hc == 'd')
        dual = 13;
      if (hc == 'e')
        dual = 14;
      if (hc == 'f')
        dual = 15;
    }
    return dual;
  }

  protected void init() {
    if (_CDRArray[0] == 0)
      _byteOrder = false;
    else
      _byteOrder = true;
  }

  protected void skip(int alignment) {
    double remainder;

    remainder = _bytePos%alignment;
    if (remainder > 0)
      _bytePos += (alignment - (int) remainder);
  }
}
