// IOR.java
//
// Copyright 1997, 1998, 1999 Entrance Software GmbH, Kassel
//
// Author     : 03/09/1997 Paul Watzlaw
// Last update: 11/10/1997
//              11/18/1997 Paul Watzlaw
//                         Skip a tagged profile's profile_data if the
//                         corresponding tag is TAG_MULTIPLE_COMPONENTS or
//                         a new tag.
//              12/29/1998 Paul Watzlaw
//                         Changed package name from DE.ENTRANCE.CORBA20
//                         to de.entrance.CORBA20.
//              12/30/1998 Paul Watzlaw
//                         Methods getNumProfiles, getProfileData, getTag
//                         and getTypeId added.
//
// pwatzlaw@entrance.de

package de.entrance.CORBA20;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import de.entrance.CORBA20.CDR;

// Class IOR is not an implementation of any CORBA20 module or class, but
// it contains some members of the modules IOP and IIOP as specified in
// The Common Object Request Broker : Architecture and Specification,
// Revision 2.0, July 1995 (pp. 10-15, 12-31).

public class IOR {
  // Module IOP.

  public static final long TAG_INTERNET_IOP        = 0;
  public static final long TAG_MULTIPLE_COMPONENTS = 1;

  protected long   _numProfiles;

  protected String _iorString,
                   _prefix,    // IOP::IOR.
                   _type_id;   // IOP::IOR.

  // IOP::IOR. This vector contains the tags (ProfileId) and the profile_data
  // (octet sequences).

  protected Vector _profiles = null;

  public IOR(String iorString)
  {
    _iorString = new String(iorString);
    parse();
  }

  public long getNumProfiles()
  {
    return _numProfiles;
  }

  public String getProfileData( long profileNo, String profileItem)
  {
    String    profile_item;
    Hashtable profile_data;

    profile_data = (Hashtable) _profiles.elementAt( (int) profileNo*2+1);
    profile_item = profile_data.get( profileItem).toString();

    return profile_item;
  }

  public int getProfileTag( long profileNo)
  {
    int  tag;
    Long tagObj;

    tagObj = (Long) _profiles.elementAt( (int) profileNo*2);
    tag    = tagObj.intValue();

    return tag;
  }

  public String getTypeId()
  {
    return _type_id;
  }

  public void print()
  {
    if ( _profiles != null)
    {
      int       tag;
      Hashtable profile_data;

      System.out.println("Type ID           : "+_type_id);
      System.out.println("Number of profiles: "+_numProfiles);
      for ( int i = 0; i < _numProfiles; i++)
      {
        System.out.println("Profile No. "+(i+1));
        tag = ((Long) _profiles.elementAt( i*2)).intValue();
        profile_data = (Hashtable) _profiles.elementAt( i*2+1);
        switch ( tag) {
          case (int) TAG_INTERNET_IOP:
            System.out.println("  Tag               : TAG_INTERNET_IOP");
            System.out.println("  Version.major     : "+profile_data.get("Version.major"));
            System.out.println("  Version.minor     : "+profile_data.get("Version.minor"));
            System.out.println("  Host              : "+profile_data.get("ProfileBody.host"));
            System.out.println("  Port              : "+profile_data.get("ProfileBody.port"));
            System.out.println("  Object key        : "+profile_data.get("ProfileBody.object_key"));
            break;
          case (int) TAG_MULTIPLE_COMPONENTS:
            System.out.println("  Tag               : TAG_MULTIPLE_COMPONENTS");
            System.out.println("  Profile data      : "+profile_data.get("ProfileData"));
            break;
          default:
            System.out.println("  New tag           : "+tag);
            System.out.println("  Profile data      : "+profile_data.get("ProfileData"));
            break;
        }
      }
    }
  }

  protected void parse()
  {
    long      tag;

    // IIOP::Version and IIOP::ProfileBody. This hashtable contains the
    // version (char major, char minor), the host (string), the port
    // (unsigned short) and the object_key (octet sequences).

    Hashtable profile_data;
    CDR       iorCdr;
    CDR       profileCdr;

    _prefix = _iorString.substring(0, 4);
    iorCdr = new CDR();
    iorCdr.parseHexString(_iorString.substring(4));
    _type_id = iorCdr.getString();
    _numProfiles = iorCdr.getULong();
    // Store the tags and the profile_data sequences from IOP::TaggedProfile
    // in the Vector _profiles.
    _profiles = new Vector((int) _numProfiles*2);
    for (int i = 0; i < _numProfiles; i++)
    {
      tag = iorCdr.getULong();
      _profiles.addElement( new Long( tag));
      profile_data = new Hashtable(5);
      if (tag == TAG_INTERNET_IOP)
      {
        profileCdr = new CDR();
        // In future use ByteArrays instead of Strings.

        profileCdr.parseByteArray( iorCdr.getSequence());

        profile_data.put("Version.major",    new Integer(profileCdr.getChar()));
        profile_data.put("Version.minor",    new Integer(profileCdr.getChar()));
        profile_data.put("ProfileBody.host", profileCdr.getString());
        profile_data.put("ProfileBody.port", new Integer(profileCdr.getUShort()));
        profile_data.put("ProfileBody.object_key", new String( profileCdr.getSequence()));
      }
      else
        // If a MultipleComponentProfile or a profile with a new tag was
        // discovered, skip the following sequence.
        profile_data.put("ProfileData", new String( iorCdr.getSequence()));
      _profiles.addElement( profile_data);
    }
  }
}
