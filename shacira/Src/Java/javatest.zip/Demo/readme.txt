To view the entries of an IOR type:

java IORTest <IOR>

The file IORTest.java contains five demo IORs. By now only IIOP IORs with the ProfileId TAG_INTERNET_IOP are supported. The program outputs profiles with the tag TAG_MULTIPLE_COMPONENTS or new tags as strings. Also object keys are
printed as strings. Because a profile_data or an object key is a sequence of octets (8 bit unsigned values), some octets are possibly not visible while printed as a string. They also could overwrite other (visible) characters.
