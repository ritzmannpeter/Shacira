import java.net.*;
import java.io.*;
import java.lang.*;


class cTransientObject
{
}

class cDataChange extends cTransientObject
{
}

class cChannelProxy {
   public void NewValue(cDataChange object)
   {
   }
}

class cCelllProxy {
   public String CellName()
   {
      return "?";
   }
   public String GetValue(String item)
   {
      return "?";
   }
}


public class CCSItf {
   static boolean ReceiveProxy(int port) throws IOException{
      try {
         byte[] msg = new byte[8192];
         DatagramPacket packet = new DatagramPacket(msg, msg.length);
         DatagramSocket socket = new DatagramSocket(port);
         socket.receive(packet);
         String s = new String(packet.getData(), 0, packet.getLength());
         System.out.println(s);
         socket.close();
         return true;
      } catch (InterruptedIOException i) {
         System.out.println(i.getMessage());
         return false;
      } catch(BindException b) {
         System.out.println(b.getMessage());
         return false;
      }
   }
   public static void main(String[] args) throws Exception {
      try {
         if (args.length != 1)
            throw new IllegalArgumentException("usage: CCSItf <port>");
         int port = Integer.parseInt(args[0]);
         String message = new String();
 	 message = "receiving at port ";
 	 message += args[0];
 	 message += ":";
 	 System.out.println(message);
         while (true) {
            ReceiveProxy(port);
         }
      } catch(IllegalArgumentException e) {
         System.err.println(e);
      }
   }
}

