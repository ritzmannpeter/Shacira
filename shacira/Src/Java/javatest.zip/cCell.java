import java.net.*;
import java.io.*;
import java.lang.*;
import java.text.*;

public class cCell {
   String _IOR;
   cCell(String ior) {
     _IOR = ior;
   }
}

