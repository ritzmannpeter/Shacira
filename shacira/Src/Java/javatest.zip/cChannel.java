import java.net.*;
import java.io.*;
import java.lang.*;
import java.text.*;

public class cChannel {
   String _IOR;
   cChannel(String ior) {
     _IOR = ior;
   }
}

