import java.net.*;
import java.io.*;
import java.lang.*;


public class DatagramSender{
    public static void main ( String[] args ) throws Exception {
        try {
            if (args.length != 3) throw new IllegalArgumentException
               ("Als Parameter muessen Host, Nachrichtentext und Port angegeben werden");
            String adresse = new String();
    	    adresse = args[0];
            InetAddress adr = InetAddress.getByName(adresse);
            String message = new String(args[1]);
            byte[] msg = message.getBytes();
            Integer portObj = new Integer(args[2]);
 	    int port = portObj.intValue();
            for (port=0; port<30000; port++) {
               String _msg = new String();
               _msg = "hallo ";
               _msg += port;
               byte[] __msg = _msg.getBytes();
               try {
                  DatagramSocket ds = new DatagramSocket();
                  DatagramPacket dp = new DatagramPacket(__msg,__msg.length, adr, port);
                  ds.send(dp);
                  ds.close();
                  System.out.println(_msg);
               } catch (java.net.BindException e) {
                 System.err.println(e);
               }
            }
        } catch(IllegalArgumentException i){
            System.err.println(i);
        }

     }
}