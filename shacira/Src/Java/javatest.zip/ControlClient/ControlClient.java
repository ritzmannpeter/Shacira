
import ../ChannelClient/Control/Control.*;
import ../Utility/Utility.*;
import org.omg.CORBA.*;
import java.io.*;
import java.lang.*;

public class ControlClient{
    public static void main(String[] args){
        try{
            String pfadIOR = "S:\\user\\sw\\Receiver\\object.ior";
            ORB orb = ORB.init(args, null);
            CorbaUtility ut = new CorbaUtility(orb, pfadIOR);
            org.omg.CORBA.Object obj =ut.ReadIORFromFile();
            iCell cell =  iCellHelper.narrow(obj);
            String name = cell.Name();
            System.out.println("Name: " + name);
            while(true){
               String toolPosition = cell.GetValue("ToolPosition",-1,-1,-1,-1);
               System.out.println("ToolPosition: " + toolPosition);
            }
        }catch(org.omg.CORBA.SystemException e){
            System.err.println(e);
        }catch(AppException ex){
            System.err.println("Fehler:");
            System.err.println("ErrorCode: "+ ex.ErrCode);
            System.err.println("NativeCode: "+ex.NativeCode);
            System.err.println("Param1: "+ex.Param1);
            System.err.println("Param2: "+ex.Param2);
            System.err.println("Param3: "+ex.Param3);
            System.err.println("Param4: "+ex.Param4);
            System.err.println("Param5: "+ex.Source);
        }catch(NullPointerException np){
            System.err.println(np + ": Objekt nicht gefunden!");
        }
    }
}