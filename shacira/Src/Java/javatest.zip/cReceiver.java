import java.net.*;
import java.io.*;
import java.lang.*;
import java.text.*;
import cCell.*;
import cChannel.*;

public class cReceiver {
   cCell _Cell;
   cChannel _Channel;
   cReceiver() {_Cell = null; _Channel = null;};
   cCell Cell() {return _Cell;};
   cChannel Channel() {return _Channel;};
   void Parse(String proxy) {
      int begin = proxy.indexOf("(") + 1;
      String proxy_type = proxy.substring(begin, 10);
      int end = proxy_type.indexOf(",");
      proxy_type = proxy_type.substring(0, end);
      begin = proxy.indexOf("IOR:");
      end = proxy.length() - 1;
      String ior = proxy.substring(begin, end);
      end = ior.indexOf(",");
      ior = ior.substring(0, end);
      Object _proxy_type = proxy_type;
//      int __proxy_type = _proxy_type;
      System.out.println(_proxy_type);
      System.out.println(ior);
  }
   boolean Receive(int port) throws IOException{
      try {
         byte[] msg = new byte[8192];
         DatagramPacket packet = new DatagramPacket(msg, msg.length);
         DatagramSocket socket = new DatagramSocket(port);
         socket.receive(packet);
         String s = new String(packet.getData(), 0, packet.getLength());
         Parse(s);
         socket.close();
         return true;
      } catch (InterruptedIOException i) {
         System.out.println(i.getMessage());
         return false;
      } catch(BindException b) {
         System.out.println(b.getMessage());
         return false;
      }
   }
}

