//## begin module%3E8469730242.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E8469730242.cm

//## begin module%3E8469730242.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E8469730242.cp

//## Module: cNodeContext%3E8469730242; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Namespace\cNodeContext.cpp

//## begin module%3E8469730242.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E8469730242.additionalIncludes

//## begin module%3E8469730242.includes preserve=yes
//## end module%3E8469730242.includes

// cNodeContext
#include "System/Namespace/cNodeContext.h"
// cTree
#include "System/Namespace/cTree.h"
//## begin module%3E8469730242.additionalDeclarations preserve=yes
//## end module%3E8469730242.additionalDeclarations


// Class cNodeContext 


cNodeContext::cNodeContext()
  //## begin cNodeContext::cNodeContext%.hasinit preserve=no
      : _Tree(NULL)
  //## end cNodeContext::cNodeContext%.hasinit
  //## begin cNodeContext::cNodeContext%.initialization preserve=yes
  //## end cNodeContext::cNodeContext%.initialization
{
  //## begin cNodeContext::cNodeContext%.body preserve=yes
  //## end cNodeContext::cNodeContext%.body
}

cNodeContext::cNodeContext(const cNodeContext &right)
  //## begin cNodeContext::cNodeContext%copy.hasinit preserve=no
      : _Tree(NULL)
  //## end cNodeContext::cNodeContext%copy.hasinit
  //## begin cNodeContext::cNodeContext%copy.initialization preserve=yes
  //## end cNodeContext::cNodeContext%copy.initialization
{
  //## begin cNodeContext::cNodeContext%copy.body preserve=yes
  //## end cNodeContext::cNodeContext%copy.body
}


cNodeContext::~cNodeContext()
{
  //## begin cNodeContext::~cNodeContext%.body preserve=yes
  //## end cNodeContext::~cNodeContext%.body
}


// Additional Declarations
  //## begin cNodeContext%3E8469730242.declarations preserve=yes
  //## end cNodeContext%3E8469730242.declarations

//## begin module%3E8469730242.epilog preserve=yes
//## end module%3E8469730242.epilog
