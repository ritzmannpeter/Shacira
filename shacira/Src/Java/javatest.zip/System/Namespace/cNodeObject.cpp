//## begin module%3E846A7A00BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E846A7A00BB.cm

//## begin module%3E846A7A00BB.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E846A7A00BB.cp

//## Module: cNodeObject%3E846A7A00BB; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Namespace\cNodeObject.cpp

//## begin module%3E846A7A00BB.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E846A7A00BB.additionalIncludes

//## begin module%3E846A7A00BB.includes preserve=yes
//## end module%3E846A7A00BB.includes

// cNodeObject
#include "System/Namespace/cNodeObject.h"
// cTree
#include "System/Namespace/cTree.h"
//## begin module%3E846A7A00BB.additionalDeclarations preserve=yes
//## end module%3E846A7A00BB.additionalDeclarations


// Class cNodeObject 


cNodeObject::cNodeObject()
  //## begin cNodeObject::cNodeObject%.hasinit preserve=no
      : _Tree(NULL)
  //## end cNodeObject::cNodeObject%.hasinit
  //## begin cNodeObject::cNodeObject%.initialization preserve=yes
  //## end cNodeObject::cNodeObject%.initialization
{
  //## begin cNodeObject::cNodeObject%.body preserve=yes
  //## end cNodeObject::cNodeObject%.body
}

cNodeObject::cNodeObject(const cNodeObject &right)
  //## begin cNodeObject::cNodeObject%copy.hasinit preserve=no
      : _Tree(NULL)
  //## end cNodeObject::cNodeObject%copy.hasinit
  //## begin cNodeObject::cNodeObject%copy.initialization preserve=yes
  //## end cNodeObject::cNodeObject%copy.initialization
{
  //## begin cNodeObject::cNodeObject%copy.body preserve=yes
  //## end cNodeObject::cNodeObject%copy.body
}


cNodeObject::~cNodeObject()
{
  //## begin cNodeObject::~cNodeObject%.body preserve=yes
  //## end cNodeObject::~cNodeObject%.body
}


// Additional Declarations
  //## begin cNodeObject%3E846A7A00BB.declarations preserve=yes
  //## end cNodeObject%3E846A7A00BB.declarations

//## begin module%3E846A7A00BB.epilog preserve=yes
//## end module%3E846A7A00BB.epilog
