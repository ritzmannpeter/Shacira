//## begin module%3A96767102D5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A96767102D5.cm

//## begin module%3A96767102D5.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3A96767102D5.cp

//## Module: cIO%3A96767102D5; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cIO.h

#ifndef cIO_h
#define cIO_h 1

//## begin module%3A96767102D5.includes preserve=yes
//## end module%3A96767102D5.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3A96767102D5.additionalDeclarations preserve=yes
//## end module%3A96767102D5.additionalDeclarations


//## begin cIO%3A96767102D5.preface preserve=yes
//## end cIO%3A96767102D5.preface

//## Class: cIO%3A96767102D5
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A57D402CB;cTransferObject { -> F}

class __DLL_EXPORT__ cIO : public cTransientObject  //## Inherits: <unnamed>%3A9676B50142
{
  //## begin cIO%3A96767102D5.initialDeclarations preserve=yes
public:
  //## end cIO%3A96767102D5.initialDeclarations

    //## Constructors (generated)
      cIO();

      cIO(const cIO &right);

    //## Constructors (specified)
      //## Operation: cIO%1046178222
      cIO (cStaticObject *source, CONST_STRING_T channel_name, CONST_STRING_T signal_name, BOOL_T signal_state);

    //## Destructor (generated)
      virtual ~cIO();


    //## Other Operations (specified)
      //## Operation: Serialize%1023780977
      virtual STRING_T Serialize ();

      //## Operation: Construct%1023780978
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ChannelName%3DDCDA88032C
      STRING_T get_ChannelName () const;
      void set_ChannelName (STRING_T value);

      //## Attribute: SignalName%3A9676DD03C1
      STRING_T get_SignalName () const;
      void set_SignalName (STRING_T value);

      //## Attribute: SignalState%3A9677310104
      BOOL_T get_SignalState () const;
      void set_SignalState (BOOL_T value);

  public:
    // Additional Public Declarations
      //## begin cIO%3A96767102D5.public preserve=yes
      //## end cIO%3A96767102D5.public

  protected:
    // Data Members for Class Attributes

      //## begin cIO::ChannelName%3DDCDA88032C.attr preserve=no  public: STRING_T {U} 
      STRING_T _ChannelName;
      //## end cIO::ChannelName%3DDCDA88032C.attr

      //## begin cIO::SignalName%3A9676DD03C1.attr preserve=no  public: STRING_T {U} 
      STRING_T _SignalName;
      //## end cIO::SignalName%3A9676DD03C1.attr

      //## begin cIO::SignalState%3A9677310104.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _SignalState;
      //## end cIO::SignalState%3A9677310104.attr

    // Additional Protected Declarations
      //## begin cIO%3A96767102D5.protected preserve=yes
      //## end cIO%3A96767102D5.protected

  private:
    // Additional Private Declarations
      //## begin cIO%3A96767102D5.private preserve=yes
      //## end cIO%3A96767102D5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cIO%3A96767102D5.implementation preserve=yes
      //## end cIO%3A96767102D5.implementation

};

//## begin cIO%3A96767102D5.postscript preserve=yes
//## end cIO%3A96767102D5.postscript

// Class cIO 

//## begin module%3A96767102D5.epilog preserve=yes
//## end module%3A96767102D5.epilog


#endif
