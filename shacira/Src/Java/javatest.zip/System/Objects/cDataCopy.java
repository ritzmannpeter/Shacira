//## begin module%3D05B2640010.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3D05B2640010.cm

//## begin module%3D05B2640010.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3D05B2640010.cp

//## Module: cDataCopy%3D05B2640010; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cDataCopy.cpp

//## begin module%3D05B2640010.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3D05B2640010.additionalIncludes

//## begin module%3D05B2640010.includes preserve=yes
//## end module%3D05B2640010.includes

// cTransferObject
#include "System/Objects/cTransferObject.h"
// cDataCopy
#include "System/Objects/cDataCopy.h"
//## begin module%3D05B2640010.additionalDeclarations preserve=yes
//## end module%3D05B2640010.additionalDeclarations


// Class cDataCopy 




cDataCopy::cDataCopy()
  //## begin cDataCopy::cDataCopy%.hasinit preserve=no
      : _VarId(-1)
  //## end cDataCopy::cDataCopy%.hasinit
  //## begin cDataCopy::cDataCopy%.initialization preserve=yes
  //## end cDataCopy::cDataCopy%.initialization
{
  //## begin cDataCopy::cDataCopy%.body preserve=yes
   _Type = OT_DATA_COPY;
  //## end cDataCopy::cDataCopy%.body
}

cDataCopy::cDataCopy(const cDataCopy &right)
  //## begin cDataCopy::cDataCopy%copy.hasinit preserve=no
      : _VarId(-1)
  //## end cDataCopy::cDataCopy%copy.hasinit
  //## begin cDataCopy::cDataCopy%copy.initialization preserve=yes
  //## end cDataCopy::cDataCopy%copy.initialization
{
  //## begin cDataCopy::cDataCopy%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cDataCopy::cDataCopy%copy.body
}

cDataCopy::cDataCopy (CONST_STRING_T var_name, LONG_T var_id, CONST_STRING_T value)
  //## begin cDataCopy::cDataCopy%1046178223.hasinit preserve=no
      : _VarId(-1)
  //## end cDataCopy::cDataCopy%1046178223.hasinit
  //## begin cDataCopy::cDataCopy%1046178223.initialization preserve=yes
  //## end cDataCopy::cDataCopy%1046178223.initialization
{
  //## begin cDataCopy::cDataCopy%1046178223.body preserve=yes
   _Type = OT_DATA_COPY;
   _VarName = var_name;
   _VarId = var_id;
   _Value = value;
  //## end cDataCopy::cDataCopy%1046178223.body
}


cDataCopy::~cDataCopy()
{
  //## begin cDataCopy::~cDataCopy%.body preserve=yes
  //## end cDataCopy::~cDataCopy%.body
}



//## Other Operations (implementation)
STRING_T cDataCopy::Serialize ()
{
  //## begin cDataCopy::Serialize%1023780995.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _VarName.c_str(), ObjectBody);
   obj.AddAttribute(1, _VarId, ObjectBody);
   obj.AddAttribute(2, _Value.c_str(), ObjectBody);
   return obj.Serialize().c_str();
  //## end cDataCopy::Serialize%1023780995.body
}

BOOL_T cDataCopy::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cDataCopy::Construct%1023780996.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _VarName, ObjectBody);
   obj.GetAttribute(1, _VarId, ObjectBody);
   obj.GetAttribute(2, _Value, ObjectBody);
   return true;
  //## end cDataCopy::Construct%1023780996.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cDataCopy::get_VarName () const
{
  //## begin cDataCopy::get_VarName%3DDBCB8F01BA.get preserve=no
  return _VarName;
  //## end cDataCopy::get_VarName%3DDBCB8F01BA.get
}

void cDataCopy::set_VarName (STRING_T value)
{
  //## begin cDataCopy::set_VarName%3DDBCB8F01BA.set preserve=no
  _VarName = value;
  //## end cDataCopy::set_VarName%3DDBCB8F01BA.set
}

LONG_T cDataCopy::get_VarId () const
{
  //## begin cDataCopy::get_VarId%3DDBCB8F01BB.get preserve=no
  return _VarId;
  //## end cDataCopy::get_VarId%3DDBCB8F01BB.get
}

void cDataCopy::set_VarId (LONG_T value)
{
  //## begin cDataCopy::set_VarId%3DDBCB8F01BB.set preserve=no
  _VarId = value;
  //## end cDataCopy::set_VarId%3DDBCB8F01BB.set
}

STRING_T cDataCopy::get_Value () const
{
  //## begin cDataCopy::get_Value%3DDBCB8F01C4.get preserve=no
  return _Value;
  //## end cDataCopy::get_Value%3DDBCB8F01C4.get
}

void cDataCopy::set_Value (STRING_T value)
{
  //## begin cDataCopy::set_Value%3DDBCB8F01C4.set preserve=no
  _Value = value;
  //## end cDataCopy::set_Value%3DDBCB8F01C4.set
}

// Additional Declarations
  //## begin cDataCopy%3D05B2640010.declarations preserve=yes
  //## end cDataCopy%3D05B2640010.declarations

//## begin module%3D05B2640010.epilog preserve=yes
//## end module%3D05B2640010.epilog
