//## begin module%3E6CE1BD0213.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E6CE1BD0213.cm

//## begin module%3E6CE1BD0213.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E6CE1BD0213.cp

//## Module: cAction%3E6CE1BD0213; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cAction.cpp

//## begin module%3E6CE1BD0213.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E6CE1BD0213.additionalIncludes

//## begin module%3E6CE1BD0213.includes preserve=yes
//## end module%3E6CE1BD0213.includes

// cAction
#include "System/Objects/cAction.h"
//## begin module%3E6CE1BD0213.additionalDeclarations preserve=yes
//## end module%3E6CE1BD0213.additionalDeclarations


// Class cAction 


cAction::cAction()
  //## begin cAction::cAction%.hasinit preserve=no
      : _ActionCode(UNDEFINED)
  //## end cAction::cAction%.hasinit
  //## begin cAction::cAction%.initialization preserve=yes
  //## end cAction::cAction%.initialization
{
  //## begin cAction::cAction%.body preserve=yes
  //## end cAction::cAction%.body
}

cAction::cAction(const cAction &right)
  //## begin cAction::cAction%copy.hasinit preserve=no
      : _ActionCode(UNDEFINED)
  //## end cAction::cAction%copy.hasinit
  //## begin cAction::cAction%copy.initialization preserve=yes
  //## end cAction::cAction%copy.initialization
{
  //## begin cAction::cAction%copy.body preserve=yes
  //## end cAction::cAction%copy.body
}

cAction::cAction (cStaticObject *source, INT_T action_code)
  //## begin cAction::cAction%1047319826.hasinit preserve=no
      : _ActionCode(UNDEFINED)
  //## end cAction::cAction%1047319826.hasinit
  //## begin cAction::cAction%1047319826.initialization preserve=yes
  //## end cAction::cAction%1047319826.initialization
{
  //## begin cAction::cAction%1047319826.body preserve=yes
  //## end cAction::cAction%1047319826.body
}


cAction::~cAction()
{
  //## begin cAction::~cAction%.body preserve=yes
  //## end cAction::~cAction%.body
}



//## Other Operations (implementation)
STRING_T cAction::Serialize ()
{
  //## begin cAction::Serialize%1047319827.body preserve=yes
return "?";
  //## end cAction::Serialize%1047319827.body
}

BOOL_T cAction::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cAction::Construct%1047319828.body preserve=yes
return false;
  //## end cAction::Construct%1047319828.body
}

//## Get and Set Operations for Class Attributes (implementation)

INT_T cAction::get_ActionCode () const
{
  //## begin cAction::get_ActionCode%3E6CE1FB031C.get preserve=no
  return _ActionCode;
  //## end cAction::get_ActionCode%3E6CE1FB031C.get
}

void cAction::set_ActionCode (INT_T value)
{
  //## begin cAction::set_ActionCode%3E6CE1FB031C.set preserve=no
  _ActionCode = value;
  //## end cAction::set_ActionCode%3E6CE1FB031C.set
}

// Additional Declarations
  //## begin cAction%3E6CE1BD0213.declarations preserve=yes
  //## end cAction%3E6CE1BD0213.declarations

//## begin module%3E6CE1BD0213.epilog preserve=yes
//## end module%3E6CE1BD0213.epilog
