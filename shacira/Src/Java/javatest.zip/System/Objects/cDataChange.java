//## begin module%3CFDF5550396.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3CFDF5550396.cm

//## begin module%3CFDF5550396.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3CFDF5550396.cp

//## Module: cDataChange%3CFDF5550396; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cDataChange.cpp

//## begin module%3CFDF5550396.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3CFDF5550396.additionalIncludes

//## begin module%3CFDF5550396.includes preserve=yes
//## end module%3CFDF5550396.includes

// cTransferObject
#include "System/Objects/cTransferObject.h"
// cDataChange
#include "System/Objects/cDataChange.h"
// cVarRef
#include "System/Database/cVarRef.h"
//## begin module%3CFDF5550396.additionalDeclarations preserve=yes
//## end module%3CFDF5550396.additionalDeclarations


// Class cDataChange 









cDataChange::cDataChange()
  //## begin cDataChange::cDataChange%.hasinit preserve=no
      : _VarId(-1), _Index1(-1), _Index2(-1), _Index3(-1), _Index4(-1)
  //## end cDataChange::cDataChange%.hasinit
  //## begin cDataChange::cDataChange%.initialization preserve=yes
  //## end cDataChange::cDataChange%.initialization
{
  //## begin cDataChange::cDataChange%.body preserve=yes
   _Type = OT_DATA_CHANGE;
  //## end cDataChange::cDataChange%.body
}

cDataChange::cDataChange(const cDataChange &right)
  //## begin cDataChange::cDataChange%copy.hasinit preserve=no
      : _VarId(-1), _Index1(-1), _Index2(-1), _Index3(-1), _Index4(-1)
  //## end cDataChange::cDataChange%copy.hasinit
  //## begin cDataChange::cDataChange%copy.initialization preserve=yes
  //## end cDataChange::cDataChange%copy.initialization
{
  //## begin cDataChange::cDataChange%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cDataChange::cDataChange%copy.body
}

cDataChange::cDataChange (CONST_STRING_T var_name, CONST_STRING_T value, LONG_T var_id, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
  //## begin cDataChange::cDataChange%1023287637.hasinit preserve=no
      : _VarId(-1), _Index1(-1), _Index2(-1), _Index3(-1), _Index4(-1)
  //## end cDataChange::cDataChange%1023287637.hasinit
  //## begin cDataChange::cDataChange%1023287637.initialization preserve=yes
  //## end cDataChange::cDataChange%1023287637.initialization
{
  //## begin cDataChange::cDataChange%1023287637.body preserve=yes
   _Type = OT_DATA_CHANGE;
   _VarName = var_name;
   _VarId = var_id;
   _Index1 = i1;
   _Index2 = i2;
   _Index3 = i3;
   _Index4 = i4;
   _Value = value;
  //## end cDataChange::cDataChange%1023287637.body
}


cDataChange::~cDataChange()
{
  //## begin cDataChange::~cDataChange%.body preserve=yes
  //## end cDataChange::~cDataChange%.body
}



//## Other Operations (implementation)
STRING_T cDataChange::Serialize ()
{
  //## begin cDataChange::Serialize%1023780987.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _VarName.c_str(), ObjectBody);
   obj.AddAttribute(1, _VarId, ObjectBody);
   obj.AddAttribute(2, _OldValue.c_str(), ObjectBody);
   obj.AddAttribute(3, _Value.c_str(), ObjectBody);
   obj.AddAttribute(4, _Index1, ObjectBody);
   obj.AddAttribute(5, _Index2, ObjectBody);
   obj.AddAttribute(6, _Index3, ObjectBody);
   obj.AddAttribute(7, _Index4, ObjectBody);
   return obj.Serialize().c_str();
  //## end cDataChange::Serialize%1023780987.body
}

BOOL_T cDataChange::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cDataChange::Construct%1023780988.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _VarName, ObjectBody);
   obj.GetAttribute(1, _VarId, ObjectBody);
   obj.GetAttribute(2, _OldValue, ObjectBody);
   obj.GetAttribute(3, _Value, ObjectBody);
   obj.GetAttribute(4, _Index1, ObjectBody);
   obj.GetAttribute(5, _Index2, ObjectBody);
   obj.GetAttribute(6, _Index3, ObjectBody);
   obj.GetAttribute(7, _Index4, ObjectBody);
   return true;
  //## end cDataChange::Construct%1023780988.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cDataChange::get_VarName () const
{
  //## begin cDataChange::get_VarName%3CFDF6240023.get preserve=no
  return _VarName;
  //## end cDataChange::get_VarName%3CFDF6240023.get
}

void cDataChange::set_VarName (STRING_T value)
{
  //## begin cDataChange::set_VarName%3CFDF6240023.set preserve=no
  _VarName = value;
  //## end cDataChange::set_VarName%3CFDF6240023.set
}

LONG_T cDataChange::get_VarId () const
{
  //## begin cDataChange::get_VarId%3D08572D0224.get preserve=no
  return _VarId;
  //## end cDataChange::get_VarId%3D08572D0224.get
}

void cDataChange::set_VarId (LONG_T value)
{
  //## begin cDataChange::set_VarId%3D08572D0224.set preserve=no
  _VarId = value;
  //## end cDataChange::set_VarId%3D08572D0224.set
}

STRING_T cDataChange::get_OldValue () const
{
  //## begin cDataChange::get_OldValue%3E79A29F035B.get preserve=no
  return _OldValue;
  //## end cDataChange::get_OldValue%3E79A29F035B.get
}

void cDataChange::set_OldValue (STRING_T value)
{
  //## begin cDataChange::set_OldValue%3E79A29F035B.set preserve=no
  _OldValue = value;
  //## end cDataChange::set_OldValue%3E79A29F035B.set
}

STRING_T cDataChange::get_Value () const
{
  //## begin cDataChange::get_Value%3CFDF624002D.get preserve=no
  return _Value;
  //## end cDataChange::get_Value%3CFDF624002D.get
}

void cDataChange::set_Value (STRING_T value)
{
  //## begin cDataChange::set_Value%3CFDF624002D.set preserve=no
  _Value = value;
  //## end cDataChange::set_Value%3CFDF624002D.set
}

LONG_T cDataChange::get_Index1 () const
{
  //## begin cDataChange::get_Index1%3D0856C6003B.get preserve=no
  return _Index1;
  //## end cDataChange::get_Index1%3D0856C6003B.get
}

void cDataChange::set_Index1 (LONG_T value)
{
  //## begin cDataChange::set_Index1%3D0856C6003B.set preserve=no
  _Index1 = value;
  //## end cDataChange::set_Index1%3D0856C6003B.set
}

LONG_T cDataChange::get_Index2 () const
{
  //## begin cDataChange::get_Index2%3D0856E0034F.get preserve=no
  return _Index2;
  //## end cDataChange::get_Index2%3D0856E0034F.get
}

void cDataChange::set_Index2 (LONG_T value)
{
  //## begin cDataChange::set_Index2%3D0856E0034F.set preserve=no
  _Index2 = value;
  //## end cDataChange::set_Index2%3D0856E0034F.set
}

LONG_T cDataChange::get_Index3 () const
{
  //## begin cDataChange::get_Index3%3D0856E20077.get preserve=no
  return _Index3;
  //## end cDataChange::get_Index3%3D0856E20077.get
}

void cDataChange::set_Index3 (LONG_T value)
{
  //## begin cDataChange::set_Index3%3D0856E20077.set preserve=no
  _Index3 = value;
  //## end cDataChange::set_Index3%3D0856E20077.set
}

LONG_T cDataChange::get_Index4 () const
{
  //## begin cDataChange::get_Index4%3D0856E301FF.get preserve=no
  return _Index4;
  //## end cDataChange::get_Index4%3D0856E301FF.get
}

void cDataChange::set_Index4 (LONG_T value)
{
  //## begin cDataChange::set_Index4%3D0856E301FF.set preserve=no
  _Index4 = value;
  //## end cDataChange::set_Index4%3D0856E301FF.set
}

// Additional Declarations
  //## begin cDataChange%3CFDF5550396.declarations preserve=yes
  //## end cDataChange%3CFDF5550396.declarations

//## begin module%3CFDF5550396.epilog preserve=yes
//## end module%3CFDF5550396.epilog
