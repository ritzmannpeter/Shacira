//## begin module%3D233867034A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3D233867034A.cm

//## begin module%3D233867034A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3D233867034A.cp

//## Module: cStaticObject%3D233867034A; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cStaticObject.cpp

//## begin module%3D233867034A.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3D233867034A.additionalIncludes

//## begin module%3D233867034A.includes preserve=yes
//## end module%3D233867034A.includes

// cStaticObject
#include "System/Objects/cStaticObject.h"
// cTransientObject
#include "System/Objects/cTransientObject.h"
//## begin module%3D233867034A.additionalDeclarations preserve=yes
//## end module%3D233867034A.additionalDeclarations


// Class cStaticObject 

//## begin cStaticObject::ObjectCount%3D23FCF80019.attr preserve=no  public: static ULONG_T {U} 0
ULONG_T cStaticObject::_ObjectCount = 0;
//## end cStaticObject::ObjectCount%3D23FCF80019.attr









cStaticObject::cStaticObject()
  //## begin cStaticObject::cStaticObject%.hasinit preserve=no
      : _Ident(0), _Type(UNDEFINED), _SubType(UNDEFINED)
  //## end cStaticObject::cStaticObject%.hasinit
  //## begin cStaticObject::cStaticObject%.initialization preserve=yes
  //## end cStaticObject::cStaticObject%.initialization
{
  //## begin cStaticObject::cStaticObject%.body preserve=yes
  //## end cStaticObject::cStaticObject%.body
}

cStaticObject::cStaticObject(const cStaticObject &right)
  //## begin cStaticObject::cStaticObject%copy.hasinit preserve=no
      : _Ident(0), _Type(UNDEFINED), _SubType(UNDEFINED)
  //## end cStaticObject::cStaticObject%copy.hasinit
  //## begin cStaticObject::cStaticObject%copy.initialization preserve=yes
  //## end cStaticObject::cStaticObject%copy.initialization
{
  //## begin cStaticObject::cStaticObject%copy.body preserve=yes
   _ObjectCount++;
   _Ident = _ObjectCount;
  //## end cStaticObject::cStaticObject%copy.body
}


cStaticObject::~cStaticObject()
{
  //## begin cStaticObject::~cStaticObject%.body preserve=yes
  //## end cStaticObject::~cStaticObject%.body
}



//## Other Operations (implementation)
void cStaticObject::Event (cTransientObject *object)
{
  //## begin cStaticObject::Event%1025715885.body preserve=yes
   throw cError(STATIC_OBJECT_EVENTFUNC_NOTIMPL, 0, _Name.c_str(), 
                cConvUtils::StringValue(object->get_Type()).c_str());
  //## end cStaticObject::Event%1025715885.body
}

void cStaticObject::RaiseEvent (cTransientObject *object, CONST_STRING_T signal_name)
{
  //## begin cStaticObject::RaiseEvent%1025715886.body preserve=yes
_ASSERT_COND(object != NULL)
   if (signal_name == NULL) {
      LISTENER_LIST_T::const_iterator i = _Listeners.begin();
      while (i != _Listeners.end()) {
         cStaticObject * target = *i;
         target->Event(object);
         i++;
      }
   } else {
      LISTENER_MAP_T::const_iterator i = _ListenerMap.find(signal_name);
      if (i != _ListenerMap.end()) {
         LISTENER_LIST_T listeners = (*i).second;
         LISTENER_LIST_T::const_iterator j = listeners.begin();
         while (j != listeners.end()) {
            cStaticObject * target = *j;
            target->Event(object);
            j++;
         }
      }
   }
  //## end cStaticObject::RaiseEvent%1025715886.body
}

void cStaticObject::ListenTo (cStaticObject *source, CONST_STRING_T signal_name)
{
  //## begin cStaticObject::ListenTo%1025715887.body preserve=yes
   source->AddListener(this, signal_name);
  //## end cStaticObject::ListenTo%1025715887.body
}

void cStaticObject::AddListener (cStaticObject *target, CONST_STRING_T signal_name)
{
  //## begin cStaticObject::AddListener%1025715888.body preserve=yes
   if (signal_name == NULL) {
      _Listeners.push_back(target);
   } else {
      _ListenerMap[signal_name].push_back(target);
   }
  //## end cStaticObject::AddListener%1025715888.body
}

//## Get and Set Operations for Class Attributes (implementation)

ULONG_T cStaticObject::get_ObjectCount ()
{
  //## begin cStaticObject::get_ObjectCount%3D23FCF80019.get preserve=no
  return _ObjectCount;
  //## end cStaticObject::get_ObjectCount%3D23FCF80019.get
}

STRING_T cStaticObject::get_Name () const
{
  //## begin cStaticObject::get_Name%3D2338F000DA.get preserve=no
  return _Name;
  //## end cStaticObject::get_Name%3D2338F000DA.get
}

void cStaticObject::set_Name (STRING_T value)
{
  //## begin cStaticObject::set_Name%3D2338F000DA.set preserve=no
  _Name = value;
  //## end cStaticObject::set_Name%3D2338F000DA.set
}

ULONG_T cStaticObject::get_Ident () const
{
  //## begin cStaticObject::get_Ident%3D23FC6703D2.get preserve=no
  return _Ident;
  //## end cStaticObject::get_Ident%3D23FC6703D2.get
}

void cStaticObject::set_Ident (ULONG_T value)
{
  //## begin cStaticObject::set_Ident%3D23FC6703D2.set preserve=no
  _Ident = value;
  //## end cStaticObject::set_Ident%3D23FC6703D2.set
}

INT_T cStaticObject::get_Type () const
{
  //## begin cStaticObject::get_Type%3FBF538B02CE.get preserve=no
  return _Type;
  //## end cStaticObject::get_Type%3FBF538B02CE.get
}

INT_T cStaticObject::get_SubType () const
{
  //## begin cStaticObject::get_SubType%3FBF53BA0167.get preserve=no
  return _SubType;
  //## end cStaticObject::get_SubType%3FBF53BA0167.get
}

// Additional Declarations
  //## begin cStaticObject%3D233867034A.declarations preserve=yes
  //## end cStaticObject%3D233867034A.declarations

//## begin module%3D233867034A.epilog preserve=yes
//## end module%3D233867034A.epilog
