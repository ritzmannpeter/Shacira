//## begin module%3D05B2640010.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3D05B2640010.cm

//## begin module%3D05B2640010.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3D05B2640010.cp

//## Module: cDataCopy%3D05B2640010; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cDataCopy.h

#ifndef cDataCopy_h
#define cDataCopy_h 1

//## begin module%3D05B2640010.includes preserve=yes
//## end module%3D05B2640010.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3D05B2640010.additionalDeclarations preserve=yes
//## end module%3D05B2640010.additionalDeclarations


//## begin cDataCopy%3D05B2640010.preface preserve=yes
//## end cDataCopy%3D05B2640010.preface

//## Class: cDataCopy%3D05B2640010
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A57F000AE;cTransferObject { -> F}

class __DLL_EXPORT__ cDataCopy : public cTransientObject  //## Inherits: <unnamed>%3E5A508202B2
{
  //## begin cDataCopy%3D05B2640010.initialDeclarations preserve=yes
public:
  //## end cDataCopy%3D05B2640010.initialDeclarations

    //## Constructors (generated)
      cDataCopy();

      cDataCopy(const cDataCopy &right);

    //## Constructors (specified)
      //## Operation: cDataCopy%1046178223
      cDataCopy (CONST_STRING_T var_name, LONG_T var_id, CONST_STRING_T value);

    //## Destructor (generated)
      virtual ~cDataCopy();


    //## Other Operations (specified)
      //## Operation: Serialize%1023780995
      virtual STRING_T Serialize ();

      //## Operation: Construct%1023780996
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: VarName%3DDBCB8F01BA
      STRING_T get_VarName () const;
      void set_VarName (STRING_T value);

      //## Attribute: VarId%3DDBCB8F01BB
      LONG_T get_VarId () const;
      void set_VarId (LONG_T value);

      //## Attribute: Value%3DDBCB8F01C4
      STRING_T get_Value () const;
      void set_Value (STRING_T value);

  public:
    // Additional Public Declarations
      //## begin cDataCopy%3D05B2640010.public preserve=yes
      //## end cDataCopy%3D05B2640010.public

  protected:
    // Data Members for Class Attributes

      //## begin cDataCopy::VarName%3DDBCB8F01BA.attr preserve=no  public: STRING_T {U} 
      STRING_T _VarName;
      //## end cDataCopy::VarName%3DDBCB8F01BA.attr

      //## begin cDataCopy::VarId%3DDBCB8F01BB.attr preserve=no  public: LONG_T {U} -1
      LONG_T _VarId;
      //## end cDataCopy::VarId%3DDBCB8F01BB.attr

      //## begin cDataCopy::Value%3DDBCB8F01C4.attr preserve=no  public: STRING_T {U} 
      STRING_T _Value;
      //## end cDataCopy::Value%3DDBCB8F01C4.attr

    // Additional Protected Declarations
      //## begin cDataCopy%3D05B2640010.protected preserve=yes
      //## end cDataCopy%3D05B2640010.protected

  private:
    // Additional Private Declarations
      //## begin cDataCopy%3D05B2640010.private preserve=yes
      //## end cDataCopy%3D05B2640010.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cDataCopy%3D05B2640010.implementation preserve=yes
      //## end cDataCopy%3D05B2640010.implementation

};

//## begin cDataCopy%3D05B2640010.postscript preserve=yes
//## end cDataCopy%3D05B2640010.postscript

// Class cDataCopy 

//## begin module%3D05B2640010.epilog preserve=yes
//## end module%3D05B2640010.epilog


#endif
