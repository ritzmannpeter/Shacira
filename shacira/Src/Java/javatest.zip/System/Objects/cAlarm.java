//## begin module%3DDBC52A0206.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC52A0206.cm

//## begin module%3DDBC52A0206.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC52A0206.cp

//## Module: cAlarm%3DDBC52A0206; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cAlarm.cpp

//## begin module%3DDBC52A0206.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3DDBC52A0206.additionalIncludes

//## begin module%3DDBC52A0206.includes preserve=yes
//## end module%3DDBC52A0206.includes

// cTransferObject
#include "System/Objects/cTransferObject.h"
// cAlarm
#include "System/Objects/cAlarm.h"
//## begin module%3DDBC52A0206.additionalDeclarations preserve=yes
//## end module%3DDBC52A0206.additionalDeclarations


// Class cAlarm 




cAlarm::cAlarm()
  //## begin cAlarm::cAlarm%.hasinit preserve=no
      : _AlarmState(false)
  //## end cAlarm::cAlarm%.hasinit
  //## begin cAlarm::cAlarm%.initialization preserve=yes
  //## end cAlarm::cAlarm%.initialization
{
  //## begin cAlarm::cAlarm%.body preserve=yes
  //## end cAlarm::cAlarm%.body
}

cAlarm::cAlarm(const cAlarm &right)
  //## begin cAlarm::cAlarm%copy.hasinit preserve=no
      : _AlarmState(false)
  //## end cAlarm::cAlarm%copy.hasinit
  //## begin cAlarm::cAlarm%copy.initialization preserve=yes
  //## end cAlarm::cAlarm%copy.initialization
{
  //## begin cAlarm::cAlarm%copy.body preserve=yes
   _AlarmState = right._AlarmState;
   _AlarmIdent = right._AlarmIdent;
   _AlarmText = right._AlarmText;
  //## end cAlarm::cAlarm%copy.body
}

cAlarm::cAlarm (cStaticObject *source, BOOL_T state, CONST_STRING_T ident)
  //## begin cAlarm::cAlarm%1043349076.hasinit preserve=no
      : _AlarmState(false)
  //## end cAlarm::cAlarm%1043349076.hasinit
  //## begin cAlarm::cAlarm%1043349076.initialization preserve=yes
  , cTransientObject(source)
  //## end cAlarm::cAlarm%1043349076.initialization
{
  //## begin cAlarm::cAlarm%1043349076.body preserve=yes
	_Type = OT_ALARM;
   _AlarmState = state;
   _AlarmIdent = ident;
  //## end cAlarm::cAlarm%1043349076.body
}


cAlarm::~cAlarm()
{
  //## begin cAlarm::~cAlarm%.body preserve=yes
  //## end cAlarm::~cAlarm%.body
}



//## Other Operations (implementation)
STRING_T cAlarm::Serialize ()
{
  //## begin cAlarm::Serialize%1043349077.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _AlarmState, ObjectBody);
   obj.AddAttribute(1, _AlarmIdent.c_str(), ObjectBody);
   obj.AddAttribute(2, _AlarmText.c_str(), ObjectBody);
   return obj.Serialize().c_str();
  //## end cAlarm::Serialize%1043349077.body
}

BOOL_T cAlarm::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cAlarm::Construct%1043349078.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _AlarmState, ObjectBody);
   obj.GetAttribute(1, _AlarmIdent, ObjectBody);
   obj.GetAttribute(2, _AlarmText, ObjectBody);
   return true;
  //## end cAlarm::Construct%1043349078.body
}

//## Get and Set Operations for Class Attributes (implementation)

BOOL_T cAlarm::get_AlarmState () const
{
  //## begin cAlarm::get_AlarmState%3E3042C303C8.get preserve=no
  return _AlarmState;
  //## end cAlarm::get_AlarmState%3E3042C303C8.get
}

void cAlarm::set_AlarmState (BOOL_T value)
{
  //## begin cAlarm::set_AlarmState%3E3042C303C8.set preserve=no
  _AlarmState = value;
  //## end cAlarm::set_AlarmState%3E3042C303C8.set
}

STRING_T cAlarm::get_AlarmIdent () const
{
  //## begin cAlarm::get_AlarmIdent%3DDCDB7B01C3.get preserve=no
  return _AlarmIdent;
  //## end cAlarm::get_AlarmIdent%3DDCDB7B01C3.get
}

void cAlarm::set_AlarmIdent (STRING_T value)
{
  //## begin cAlarm::set_AlarmIdent%3DDCDB7B01C3.set preserve=no
  _AlarmIdent = value;
  //## end cAlarm::set_AlarmIdent%3DDCDB7B01C3.set
}

STRING_T cAlarm::get_AlarmText () const
{
  //## begin cAlarm::get_AlarmText%3DDCDB9800CA.get preserve=no
  return _AlarmText;
  //## end cAlarm::get_AlarmText%3DDCDB9800CA.get
}

void cAlarm::set_AlarmText (STRING_T value)
{
  //## begin cAlarm::set_AlarmText%3DDCDB9800CA.set preserve=no
  _AlarmText = value;
  //## end cAlarm::set_AlarmText%3DDCDB9800CA.set
}

// Additional Declarations
  //## begin cAlarm%3DDBC52A0206.declarations preserve=yes
  //## end cAlarm%3DDBC52A0206.declarations

//## begin module%3DDBC52A0206.epilog preserve=yes
//## end module%3DDBC52A0206.epilog
