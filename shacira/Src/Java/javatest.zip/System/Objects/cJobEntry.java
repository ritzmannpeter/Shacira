//## begin module%3DDBC4B0023D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC4B0023D.cm

//## begin module%3DDBC4B0023D.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC4B0023D.cp

//## Module: cJobEntry%3DDBC4B0023D; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cJobEntry.cpp

//## begin module%3DDBC4B0023D.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3DDBC4B0023D.additionalIncludes

//## begin module%3DDBC4B0023D.includes preserve=yes
//## end module%3DDBC4B0023D.includes

// cTransferObject
#include "System/Objects/cTransferObject.h"
// cJobEntry
#include "System/Objects/cJobEntry.h"
//## begin module%3DDBC4B0023D.additionalDeclarations preserve=yes
//## end module%3DDBC4B0023D.additionalDeclarations


// Class cJobEntry 










cJobEntry::cJobEntry()
  //## begin cJobEntry::cJobEntry%.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0), _Shot(0), _Quality(NO_QUALITY)
  //## end cJobEntry::cJobEntry%.hasinit
  //## begin cJobEntry::cJobEntry%.initialization preserve=yes
  //## end cJobEntry::cJobEntry%.initialization
{
  //## begin cJobEntry::cJobEntry%.body preserve=yes
   _Type = OT_JOB_ENTRY;
  //## end cJobEntry::cJobEntry%.body
}

cJobEntry::cJobEntry(const cJobEntry &right)
  //## begin cJobEntry::cJobEntry%copy.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0), _Shot(0), _Quality(NO_QUALITY)
  //## end cJobEntry::cJobEntry%copy.hasinit
  //## begin cJobEntry::cJobEntry%copy.initialization preserve=yes
  //## end cJobEntry::cJobEntry%copy.initialization
{
  //## begin cJobEntry::cJobEntry%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cJobEntry::cJobEntry%copy.body
}

cJobEntry::cJobEntry (cStaticObject *source, CONST_STRING_T job_name, INT_T job_type, INT_T job_type_spec)
  //## begin cJobEntry::cJobEntry%1047655602.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0), _Shot(0), _Quality(NO_QUALITY)
  //## end cJobEntry::cJobEntry%1047655602.hasinit
  //## begin cJobEntry::cJobEntry%1047655602.initialization preserve=yes
  , cTransientObject(source)
  //## end cJobEntry::cJobEntry%1047655602.initialization
{
  //## begin cJobEntry::cJobEntry%1047655602.body preserve=yes
   _Type = OT_JOB_ENTRY;
	_JobName = job_name;
	_JobType = job_type;
	_JobTypeSpec = job_type_spec;
  //## end cJobEntry::cJobEntry%1047655602.body
}


cJobEntry::~cJobEntry()
{
  //## begin cJobEntry::~cJobEntry%.body preserve=yes
  //## end cJobEntry::~cJobEntry%.body
}



//## Other Operations (implementation)
ULONG_T cJobEntry::Properties ()
{
  //## begin cJobEntry::Properties%1047655603.body preserve=yes
	return _Properties.size();
  //## end cJobEntry::Properties%1047655603.body
}

BOOL_T cJobEntry::PropertyExists (CONST_STRING_T property_name)
{
  //## begin cJobEntry::PropertyExists%1047655618.body preserve=yes
	ULONG_MAP_T::const_iterator i = _PropertyMap.find(property_name);
	if (i != _PropertyMap.end()) {
		return true;
	} else {
		return false;
	}
  //## end cJobEntry::PropertyExists%1047655618.body
}

STRING_T cJobEntry::Property (ULONG_T index)
{
  //## begin cJobEntry::Property%1047655613.body preserve=yes
	if (index < _Properties.size()) {
		return _Properties[index];
	} else {
		throw cError(JOB_ENTRY_INVALID_PROPERTY_INDEX, 0, _JobName.c_str(),
						 cConvUtils::StringValue(index).c_str());
	}
  //## end cJobEntry::Property%1047655613.body
}

STRING_T cJobEntry::PropertyValue (ULONG_T index)
{
  //## begin cJobEntry::PropertyValue%1047655614.body preserve=yes
	if (index < _PropertyValues.size()) {
		return _PropertyValues[index];
	} else {
		throw cError(JOB_ENTRY_INVALID_VALUE_INDEX, 0, _JobName.c_str(),
						 cConvUtils::StringValue(index).c_str());
	}
  //## end cJobEntry::PropertyValue%1047655614.body
}

STRING_T cJobEntry::PropertyValue (CONST_STRING_T property_name)
{
  //## begin cJobEntry::PropertyValue%1047655615.body preserve=yes
	ULONG_MAP_T::const_iterator i = _PropertyMap.find(property_name);
	if (i != _PropertyMap.end()) {
		return PropertyValue((*i).second);
	} else {
		throw cError(JOB_ENTRY_INVALID_PROPERTY, 0, _JobName.c_str(), property_name);
	}
  //## end cJobEntry::PropertyValue%1047655615.body
}

void cJobEntry::AddProperty (CONST_STRING_T property_name)
{
  //## begin cJobEntry::AddProperty%1047655616.body preserve=yes
	ULONG_T index = _Properties.size();
	ULONG_MAP_T::const_iterator i = _PropertyMap.find(property_name);
	if (i != _PropertyMap.end()) {
		index = (*i).second;
		Resize(index);
	} else {
		index = _Properties.size();
		Resize(index);
		_PropertyMap[property_name] = index;
	}
	_Properties[index] = property_name;
  //## end cJobEntry::AddProperty%1047655616.body
}

void cJobEntry::AddPropertyValue (CONST_STRING_T property_name, CONST_STRING_T value)
{
  //## begin cJobEntry::AddPropertyValue%1047655617.body preserve=yes
	ULONG_T index = _Properties.size();
	ULONG_MAP_T::const_iterator i = _PropertyMap.find(property_name);
	if (i != _PropertyMap.end()) {
		index = (*i).second;
		Resize(index);
	} else {
		index = _Properties.size();
		Resize(index);
		_PropertyMap[property_name] = index;
	}
	_Properties[index] = property_name;
	_PropertyValues[index] = value;
  //## end cJobEntry::AddPropertyValue%1047655617.body
}

void cJobEntry::AddPropertyValue (ULONG_T index, CONST_STRING_T property_name, CONST_STRING_T value)
{
  //## begin cJobEntry::AddPropertyValue%1047655619.body preserve=yes
	if (index < _Properties.size()) {
		throw cError(JOB_ENTRY_INVALID_OPERATION, 0, _JobName.c_str(),
						 cConvUtils::StringValue(index).c_str(), "AddPropertyValue");
	} else {
		Resize(index);
		_PropertyMap[property_name] = index;
		_Properties[index] = property_name;
		_PropertyValues[index] = value;
	}
  //## end cJobEntry::AddPropertyValue%1047655619.body
}

STRING_T cJobEntry::Serialize ()
{
  //## begin cJobEntry::Serialize%1046160458.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _JobName.c_str(), ObjectBody);
   obj.AddAttribute(1, _JobType, ObjectBody);
   obj.AddAttribute(2, _JobTypeSpec, ObjectBody);
   obj.AddAttribute(3, _Shot, ObjectBody);
   obj.AddAttribute(4, _Quality, ObjectBody);
   obj.AddAttribute(5, _Ident.c_str(), ObjectBody);
	ULONG_T properties = _Properties.size();
	for (ULONG_T i=0; i<properties; i++) {
		obj.AddAttribute(i, _Properties[i].c_str(), ObjectParams);
		obj.AddAttribute(i, _PropertyValues[i].c_str(), ObjectParamValues);
	}
   return obj.Serialize().c_str();
  //## end cJobEntry::Serialize%1046160458.body
}

BOOL_T cJobEntry::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cJobEntry::Construct%1046160459.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _JobName, ObjectBody);
   obj.GetAttribute(1, _JobType, ObjectBody);
   obj.GetAttribute(2, _JobTypeSpec, ObjectBody);
   obj.GetAttribute(3, _Shot, ObjectBody);
   obj.GetAttribute(4, _Quality, ObjectBody);
   obj.GetAttribute(5, _Ident, ObjectBody);
	STRING_T property_name;
	STRING_T property_value;
	ULONG_T params = obj.Params();
	for (ULONG_T i=0; i<params; i++) {
		obj.GetAttribute(i, property_name, ObjectParams);
		obj.GetAttribute(i, property_value, ObjectParamValues);
		AddPropertyValue(i, property_name.c_str(), property_value.c_str());
	}
   return true;
  //## end cJobEntry::Construct%1046160459.body
}

void cJobEntry::Resize (ULONG_T index)
{
  //## begin cJobEntry::Resize%1047655606.body preserve=yes
	if (index >= _Properties.size()) {
		_Properties.resize(index + 1);
		_PropertyValues.resize(index + 1);
	}
  //## end cJobEntry::Resize%1047655606.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cJobEntry::get_JobName () const
{
  //## begin cJobEntry::get_JobName%3DDCDB590296.get preserve=no
  return _JobName;
  //## end cJobEntry::get_JobName%3DDCDB590296.get
}

void cJobEntry::set_JobName (STRING_T value)
{
  //## begin cJobEntry::set_JobName%3DDCDB590296.set preserve=no
  _JobName = value;
  //## end cJobEntry::set_JobName%3DDCDB590296.set
}

INT_T cJobEntry::get_JobType () const
{
  //## begin cJobEntry::get_JobType%3E71F78C0128.get preserve=no
  return _JobType;
  //## end cJobEntry::get_JobType%3E71F78C0128.get
}

void cJobEntry::set_JobType (INT_T value)
{
  //## begin cJobEntry::set_JobType%3E71F78C0128.set preserve=no
  _JobType = value;
  //## end cJobEntry::set_JobType%3E71F78C0128.set
}

ULONG_T cJobEntry::get_JobTypeSpec () const
{
  //## begin cJobEntry::get_JobTypeSpec%3E71F78C0129.get preserve=no
  return _JobTypeSpec;
  //## end cJobEntry::get_JobTypeSpec%3E71F78C0129.get
}

void cJobEntry::set_JobTypeSpec (ULONG_T value)
{
  //## begin cJobEntry::set_JobTypeSpec%3E71F78C0129.set preserve=no
  _JobTypeSpec = value;
  //## end cJobEntry::set_JobTypeSpec%3E71F78C0129.set
}

LONG_T cJobEntry::get_Shot () const
{
  //## begin cJobEntry::get_Shot%3E5B7F880157.get preserve=no
  return _Shot;
  //## end cJobEntry::get_Shot%3E5B7F880157.get
}

void cJobEntry::set_Shot (LONG_T value)
{
  //## begin cJobEntry::set_Shot%3E5B7F880157.set preserve=no
  _Shot = value;
  //## end cJobEntry::set_Shot%3E5B7F880157.set
}

INT_T cJobEntry::get_Quality () const
{
  //## begin cJobEntry::get_Quality%3E5B7FB30376.get preserve=no
  return _Quality;
  //## end cJobEntry::get_Quality%3E5B7FB30376.get
}

void cJobEntry::set_Quality (INT_T value)
{
  //## begin cJobEntry::set_Quality%3E5B7FB30376.set preserve=no
  _Quality = value;
  //## end cJobEntry::set_Quality%3E5B7FB30376.set
}

STRING_T cJobEntry::get_Ident () const
{
  //## begin cJobEntry::get_Ident%3E5B7FC60264.get preserve=no
  return _Ident;
  //## end cJobEntry::get_Ident%3E5B7FC60264.get
}

void cJobEntry::set_Ident (STRING_T value)
{
  //## begin cJobEntry::set_Ident%3E5B7FC60264.set preserve=no
  _Ident = value;
  //## end cJobEntry::set_Ident%3E5B7FC60264.set
}

// Additional Declarations
  //## begin cJobEntry%3DDBC4B0023D.declarations preserve=yes
  //## end cJobEntry%3DDBC4B0023D.declarations

//## begin module%3DDBC4B0023D.epilog preserve=yes
//## end module%3DDBC4B0023D.epilog
