//## begin module%3DDBC48B032A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC48B032A.cm

//## begin module%3DDBC48B032A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC48B032A.cp

//## Module: cJobSpec%3DDBC48B032A; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cJobSpec.h

#ifndef cJobSpec_h
#define cJobSpec_h 1

//## begin module%3DDBC48B032A.includes preserve=yes
//## end module%3DDBC48B032A.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3DDBC48B032A.additionalDeclarations preserve=yes
//## end module%3DDBC48B032A.additionalDeclarations


//## begin cJobSpec%3DDBC48B032A.preface preserve=yes
//## end cJobSpec%3DDBC48B032A.preface

//## Class: cJobSpec%3DDBC48B032A
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A57FB015F;cTransferObject { -> F}

class __DLL_EXPORT__ cJobSpec : public cTransientObject  //## Inherits: <unnamed>%3DDBC4A700D1
{
  //## begin cJobSpec%3DDBC48B032A.initialDeclarations preserve=yes
public:
  //## end cJobSpec%3DDBC48B032A.initialDeclarations

    //## Constructors (generated)
      cJobSpec();

      cJobSpec(const cJobSpec &right);

    //## Constructors (specified)
      //## Operation: cJobSpec%1047655597
      cJobSpec (cStaticObject *source, CONST_STRING_T job_name, INT_T job_type, INT_T job_type_spec = 0);

    //## Destructor (generated)
      virtual ~cJobSpec();


    //## Other Operations (specified)
      //## Operation: Properties%1047655598
      ULONG_T Properties ();

      //## Operation: Property%1047655599
      STRING_T Property (ULONG_T index);

      //## Operation: AddProperty%1047655600
      void AddProperty (CONST_STRING_T property);

      //## Operation: Exists%1048090498
      virtual BOOL_T Exists (CONST_STRING_T property_name);

      //## Operation: Serialize%1046160460
      virtual STRING_T Serialize ();

      //## Operation: Construct%1046160461
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: JobName%3DDCDB400236
      STRING_T get_JobName () const;
      void set_JobName (STRING_T value);

      //## Attribute: JobType%3E71F31500BB
      INT_T get_JobType () const;
      void set_JobType (INT_T value);

      //## Attribute: JobTypeSpec%3E71F3440290
      ULONG_T get_JobTypeSpec () const;
      void set_JobTypeSpec (ULONG_T value);

  public:
    // Additional Public Declarations
      //## begin cJobSpec%3DDBC48B032A.public preserve=yes
      //## end cJobSpec%3DDBC48B032A.public

  protected:
    // Data Members for Class Attributes

      //## begin cJobSpec::JobName%3DDCDB400236.attr preserve=no  public: STRING_T {U} 
      STRING_T _JobName;
      //## end cJobSpec::JobName%3DDCDB400236.attr

      //## begin cJobSpec::JobType%3E71F31500BB.attr preserve=no  public: INT_T {U} UNDEFINED
      INT_T _JobType;
      //## end cJobSpec::JobType%3E71F31500BB.attr

      //## begin cJobSpec::JobTypeSpec%3E71F3440290.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _JobTypeSpec;
      //## end cJobSpec::JobTypeSpec%3E71F3440290.attr

      //## Attribute: Properties%3E71F3610399
      //## begin cJobSpec::Properties%3E71F3610399.attr preserve=no  protected: STRING_VECTOR_T {U} 
      STRING_VECTOR_T _Properties;
      //## end cJobSpec::Properties%3E71F3610399.attr

    // Additional Protected Declarations
      //## begin cJobSpec%3DDBC48B032A.protected preserve=yes
      //## end cJobSpec%3DDBC48B032A.protected

  private:
    // Additional Private Declarations
      //## begin cJobSpec%3DDBC48B032A.private preserve=yes
      //## end cJobSpec%3DDBC48B032A.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: Resize%1047655601
      void Resize (ULONG_T index);

    // Additional Implementation Declarations
      //## begin cJobSpec%3DDBC48B032A.implementation preserve=yes
      //## end cJobSpec%3DDBC48B032A.implementation

};

//## begin cJobSpec%3DDBC48B032A.postscript preserve=yes
//## end cJobSpec%3DDBC48B032A.postscript

// Class cJobSpec 

//## begin module%3DDBC48B032A.epilog preserve=yes
//## end module%3DDBC48B032A.epilog


#endif
