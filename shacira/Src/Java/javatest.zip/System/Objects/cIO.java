//## begin module%3A96767102D5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A96767102D5.cm

//## begin module%3A96767102D5.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3A96767102D5.cp

//## Module: cIO%3A96767102D5; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cIO.cpp

//## begin module%3A96767102D5.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3A96767102D5.additionalIncludes

//## begin module%3A96767102D5.includes preserve=yes
//## end module%3A96767102D5.includes

// cIO
#include "System/Objects/cIO.h"
// cTransferObject
#include "System/Objects/cTransferObject.h"
//## begin module%3A96767102D5.additionalDeclarations preserve=yes
//## end module%3A96767102D5.additionalDeclarations


// Class cIO 




cIO::cIO()
  //## begin cIO::cIO%.hasinit preserve=no
      : _SignalState(false)
  //## end cIO::cIO%.hasinit
  //## begin cIO::cIO%.initialization preserve=yes
  //## end cIO::cIO%.initialization
{
  //## begin cIO::cIO%.body preserve=yes
   _Type = OT_IO;
  //## end cIO::cIO%.body
}

cIO::cIO(const cIO &right)
  //## begin cIO::cIO%copy.hasinit preserve=no
      : _SignalState(false)
  //## end cIO::cIO%copy.hasinit
  //## begin cIO::cIO%copy.initialization preserve=yes
  //## end cIO::cIO%copy.initialization
{
  //## begin cIO::cIO%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cIO::cIO%copy.body
}

cIO::cIO (cStaticObject *source, CONST_STRING_T channel_name, CONST_STRING_T signal_name, BOOL_T signal_state)
  //## begin cIO::cIO%1046178222.hasinit preserve=no
      : _SignalState(false)
  //## end cIO::cIO%1046178222.hasinit
  //## begin cIO::cIO%1046178222.initialization preserve=yes
  , cTransientObject(source)
  //## end cIO::cIO%1046178222.initialization
{
  //## begin cIO::cIO%1046178222.body preserve=yes
   _Type = OT_IO;
   _ChannelName = channel_name;
   _SignalName = signal_name;
   _SignalState = signal_state;
  //## end cIO::cIO%1046178222.body
}


cIO::~cIO()
{
  //## begin cIO::~cIO%.body preserve=yes
  //## end cIO::~cIO%.body
}



//## Other Operations (implementation)
STRING_T cIO::Serialize ()
{
  //## begin cIO::Serialize%1023780977.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _ChannelName.c_str(), ObjectBody);
   obj.AddAttribute(1, _SignalName.c_str(), ObjectBody);
   obj.AddAttribute(2, _SignalState, ObjectBody);
   return obj.Serialize().c_str();
  //## end cIO::Serialize%1023780977.body
}

BOOL_T cIO::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cIO::Construct%1023780978.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _ChannelName, ObjectBody);
   obj.GetAttribute(1, _SignalName, ObjectBody);
   obj.GetAttribute(2, _SignalState, ObjectBody);
   return true;
  //## end cIO::Construct%1023780978.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cIO::get_ChannelName () const
{
  //## begin cIO::get_ChannelName%3DDCDA88032C.get preserve=no
  return _ChannelName;
  //## end cIO::get_ChannelName%3DDCDA88032C.get
}

void cIO::set_ChannelName (STRING_T value)
{
  //## begin cIO::set_ChannelName%3DDCDA88032C.set preserve=no
  _ChannelName = value;
  //## end cIO::set_ChannelName%3DDCDA88032C.set
}

STRING_T cIO::get_SignalName () const
{
  //## begin cIO::get_SignalName%3A9676DD03C1.get preserve=no
  return _SignalName;
  //## end cIO::get_SignalName%3A9676DD03C1.get
}

void cIO::set_SignalName (STRING_T value)
{
  //## begin cIO::set_SignalName%3A9676DD03C1.set preserve=no
  _SignalName = value;
  //## end cIO::set_SignalName%3A9676DD03C1.set
}

BOOL_T cIO::get_SignalState () const
{
  //## begin cIO::get_SignalState%3A9677310104.get preserve=no
  return _SignalState;
  //## end cIO::get_SignalState%3A9677310104.get
}

void cIO::set_SignalState (BOOL_T value)
{
  //## begin cIO::set_SignalState%3A9677310104.set preserve=no
  _SignalState = value;
  //## end cIO::set_SignalState%3A9677310104.set
}

// Additional Declarations
  //## begin cIO%3A96767102D5.declarations preserve=yes
  //## end cIO%3A96767102D5.declarations

//## begin module%3A96767102D5.epilog preserve=yes
//## end module%3A96767102D5.epilog
