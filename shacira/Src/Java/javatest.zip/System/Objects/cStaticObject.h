//## begin module%3D233867034A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3D233867034A.cm

//## begin module%3D233867034A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3D233867034A.cp

//## Module: cStaticObject%3D233867034A; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cStaticObject.h

#ifndef cStaticObject_h
#define cStaticObject_h 1

//## begin module%3D233867034A.includes preserve=yes
//## end module%3D233867034A.includes

// eb_sema
#include "base/eb_sema.hpp"

class __DLL_EXPORT__ cTransientObject;

//## begin module%3D233867034A.additionalDeclarations preserve=yes
//## end module%3D233867034A.additionalDeclarations


//## begin cStaticObject%3D233867034A.preface preserve=yes
//## end cStaticObject%3D233867034A.preface

//## Class: cStaticObject%3D233867034A
//	Static objects are objects that are static while the
//	process is living. They are static with respect to the
//	2i Control infrastructure (process).
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3DC8FCDE037D;cTransientObject { -> F}
//## Uses: <unnamed>%3DC900CA02B8;cMutexSem { -> }

class __DLL_EXPORT__ cStaticObject 
{
  //## begin cStaticObject%3D233867034A.initialDeclarations preserve=yes
public:
   typedef std::list<cStaticObject*> LISTENER_LIST_T;
   typedef std::map<STRING_T,LISTENER_LIST_T> LISTENER_MAP_T;
  //## end cStaticObject%3D233867034A.initialDeclarations

    //## Constructors (generated)
      cStaticObject();

      cStaticObject(const cStaticObject &right);

    //## Destructor (generated)
      virtual ~cStaticObject();


    //## Other Operations (specified)
      //## Operation: Event%1025715885
      virtual void Event (cTransientObject *object);

      //## Operation: RaiseEvent%1025715886
      void RaiseEvent (cTransientObject *object, CONST_STRING_T signal_name = NULL);

      //## Operation: ListenTo%1025715887
      void ListenTo (cStaticObject *source, CONST_STRING_T signal_name = NULL);

      //## Operation: AddListener%1025715888
      void AddListener (cStaticObject *target, CONST_STRING_T signal_name = NULL);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ObjectCount%3D23FCF80019
      static ULONG_T get_ObjectCount ();

      //## Attribute: Name%3D2338F000DA
      STRING_T get_Name () const;
      void set_Name (STRING_T value);

      //## Attribute: Ident%3D23FC6703D2
      ULONG_T get_Ident () const;
      void set_Ident (ULONG_T value);

      //## Attribute: Type%3FBF538B02CE
      INT_T get_Type () const;

      //## Attribute: SubType%3FBF53BA0167
      INT_T get_SubType () const;

  public:
    // Additional Public Declarations
      //## begin cStaticObject%3D233867034A.public preserve=yes
      //## end cStaticObject%3D233867034A.public

  protected:
    // Data Members for Class Attributes

      //## begin cStaticObject::ObjectCount%3D23FCF80019.attr preserve=no  public: static ULONG_T {U} 0
      static ULONG_T _ObjectCount;
      //## end cStaticObject::ObjectCount%3D23FCF80019.attr

      //## begin cStaticObject::Name%3D2338F000DA.attr preserve=no  public: STRING_T {U} 
      STRING_T _Name;
      //## end cStaticObject::Name%3D2338F000DA.attr

      //## begin cStaticObject::Ident%3D23FC6703D2.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _Ident;
      //## end cStaticObject::Ident%3D23FC6703D2.attr

      //## begin cStaticObject::Type%3FBF538B02CE.attr preserve=no  public: INT_T {U} UNDEFINED
      INT_T _Type;
      //## end cStaticObject::Type%3FBF538B02CE.attr

      //## begin cStaticObject::SubType%3FBF53BA0167.attr preserve=no  public: INT_T {U} UNDEFINED
      INT_T _SubType;
      //## end cStaticObject::SubType%3FBF53BA0167.attr

      //## Attribute: LockMutex%3DC8F7F4003F
      //## begin cStaticObject::LockMutex%3DC8F7F4003F.attr preserve=no  protected: cMutexSem {U} 
      cMutexSem _LockMutex;
      //## end cStaticObject::LockMutex%3DC8F7F4003F.attr

    // Additional Protected Declarations
      //## begin cStaticObject%3D233867034A.protected preserve=yes
      //## end cStaticObject%3D233867034A.protected

  private:
    // Additional Private Declarations
      //## begin cStaticObject%3D233867034A.private preserve=yes
      //## end cStaticObject%3D233867034A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Listeners%3D233ED00191
      //## begin cStaticObject::Listeners%3D233ED00191.attr preserve=no  implementation: LISTENER_LIST_T {U} 
      LISTENER_LIST_T _Listeners;
      //## end cStaticObject::Listeners%3D233ED00191.attr

      //## Attribute: ListenerMap%3E2ED127004C
      //## begin cStaticObject::ListenerMap%3E2ED127004C.attr preserve=no  implementation: LISTENER_MAP_T {U} 
      LISTENER_MAP_T _ListenerMap;
      //## end cStaticObject::ListenerMap%3E2ED127004C.attr

    // Additional Implementation Declarations
      //## begin cStaticObject%3D233867034A.implementation preserve=yes
      //## end cStaticObject%3D233867034A.implementation

};

//## begin cStaticObject%3D233867034A.postscript preserve=yes
//## end cStaticObject%3D233867034A.postscript

// Class cStaticObject 

//## begin module%3D233867034A.epilog preserve=yes
//## end module%3D233867034A.epilog


#endif
