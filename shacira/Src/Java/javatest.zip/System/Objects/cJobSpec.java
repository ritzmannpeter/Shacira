//## begin module%3DDBC48B032A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC48B032A.cm

//## begin module%3DDBC48B032A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC48B032A.cp

//## Module: cJobSpec%3DDBC48B032A; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cJobSpec.cpp

//## begin module%3DDBC48B032A.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3DDBC48B032A.additionalIncludes

//## begin module%3DDBC48B032A.includes preserve=yes
//## end module%3DDBC48B032A.includes

// cTransferObject
#include "System/Objects/cTransferObject.h"
// cJobSpec
#include "System/Objects/cJobSpec.h"
//## begin module%3DDBC48B032A.additionalDeclarations preserve=yes
//## end module%3DDBC48B032A.additionalDeclarations


// Class cJobSpec 





cJobSpec::cJobSpec()
  //## begin cJobSpec::cJobSpec%.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0)
  //## end cJobSpec::cJobSpec%.hasinit
  //## begin cJobSpec::cJobSpec%.initialization preserve=yes
  //## end cJobSpec::cJobSpec%.initialization
{
  //## begin cJobSpec::cJobSpec%.body preserve=yes
   _Type = OT_JOB_SPEC;
  //## end cJobSpec::cJobSpec%.body
}

cJobSpec::cJobSpec(const cJobSpec &right)
  //## begin cJobSpec::cJobSpec%copy.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0)
  //## end cJobSpec::cJobSpec%copy.hasinit
  //## begin cJobSpec::cJobSpec%copy.initialization preserve=yes
  //## end cJobSpec::cJobSpec%copy.initialization
{
  //## begin cJobSpec::cJobSpec%copy.body preserve=yes
	_JobName = right._JobName;
	_JobType = right._JobType;
	_JobTypeSpec = right._JobTypeSpec;
	_Properties = right._Properties;
  //## end cJobSpec::cJobSpec%copy.body
}

cJobSpec::cJobSpec (cStaticObject *source, CONST_STRING_T job_name, INT_T job_type, INT_T job_type_spec)
  //## begin cJobSpec::cJobSpec%1047655597.hasinit preserve=no
      : _JobType(UNDEFINED), _JobTypeSpec(0)
  //## end cJobSpec::cJobSpec%1047655597.hasinit
  //## begin cJobSpec::cJobSpec%1047655597.initialization preserve=yes
  , cTransientObject(source)
  //## end cJobSpec::cJobSpec%1047655597.initialization
{
  //## begin cJobSpec::cJobSpec%1047655597.body preserve=yes
   _Type = OT_JOB_SPEC;
	_JobName = job_name;
	_JobType = job_type;
	_JobTypeSpec = job_type_spec;
  //## end cJobSpec::cJobSpec%1047655597.body
}


cJobSpec::~cJobSpec()
{
  //## begin cJobSpec::~cJobSpec%.body preserve=yes
  //## end cJobSpec::~cJobSpec%.body
}



//## Other Operations (implementation)
ULONG_T cJobSpec::Properties ()
{
  //## begin cJobSpec::Properties%1047655598.body preserve=yes
	return _Properties.size();
  //## end cJobSpec::Properties%1047655598.body
}

STRING_T cJobSpec::Property (ULONG_T index)
{
  //## begin cJobSpec::Property%1047655599.body preserve=yes
	if (index < _Properties.size()) {
		return _Properties[index];
	} else {
		throw cError(JOB_SPEC_INVALID_INDEX, 0, _JobName.c_str(),
						 cConvUtils::StringValue(index).c_str());
	}
  //## end cJobSpec::Property%1047655599.body
}

void cJobSpec::AddProperty (CONST_STRING_T property)
{
  //## begin cJobSpec::AddProperty%1047655600.body preserve=yes
	ULONG_T index = _Properties.size();
	Resize(index);
	_Properties[index] = property;
  //## end cJobSpec::AddProperty%1047655600.body
}

BOOL_T cJobSpec::Exists (CONST_STRING_T property_name)
{
  //## begin cJobSpec::Exists%1048090498.body preserve=yes
   ULONG_T names = _Properties.size();
   for (ULONG_T i=0; i<names; i++) {
      if (strcmp(property_name, _Properties[i].c_str()) == 0) return true;
   }
   return false;
  //## end cJobSpec::Exists%1048090498.body
}

STRING_T cJobSpec::Serialize ()
{
  //## begin cJobSpec::Serialize%1046160460.body preserve=yes
   cTransferObject obj;
   SerializeBase(obj);
   obj.AddAttribute(0, _JobName.c_str(), ObjectBody);
   obj.AddAttribute(1, _JobType, ObjectBody);
   obj.AddAttribute(2, _JobTypeSpec, ObjectBody);
	ULONG_T properties = _Properties.size();
	for (ULONG_T i=0; i<properties; i++) {
		obj.AddAttribute(i, _Properties[i].c_str(), ObjectParams);
	}
   return obj.Serialize().c_str();
  //## end cJobSpec::Serialize%1046160460.body
}

BOOL_T cJobSpec::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cJobSpec::Construct%1046160461.body preserve=yes
   cTransferObject obj(serialized_obj);
   if (!ConstructBase(obj)) return false;
   obj.GetAttribute(0, _JobName, ObjectBody);
   obj.GetAttribute(1, _JobType, ObjectBody);
   obj.GetAttribute(2, _JobTypeSpec, ObjectBody);
	STRING_T property;
	ULONG_T params = obj.Params();
	for (ULONG_T i=0; i<params; i++) {
		obj.GetAttribute(i, property, ObjectParams);
		AddProperty(property.c_str());
	}
   return true;
  //## end cJobSpec::Construct%1046160461.body
}

void cJobSpec::Resize (ULONG_T index)
{
  //## begin cJobSpec::Resize%1047655601.body preserve=yes
	if (index >= _Properties.size()) {
		_Properties.resize(index + 1);
	}
  //## end cJobSpec::Resize%1047655601.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cJobSpec::get_JobName () const
{
  //## begin cJobSpec::get_JobName%3DDCDB400236.get preserve=no
  return _JobName;
  //## end cJobSpec::get_JobName%3DDCDB400236.get
}

void cJobSpec::set_JobName (STRING_T value)
{
  //## begin cJobSpec::set_JobName%3DDCDB400236.set preserve=no
  _JobName = value;
  //## end cJobSpec::set_JobName%3DDCDB400236.set
}

INT_T cJobSpec::get_JobType () const
{
  //## begin cJobSpec::get_JobType%3E71F31500BB.get preserve=no
  return _JobType;
  //## end cJobSpec::get_JobType%3E71F31500BB.get
}

void cJobSpec::set_JobType (INT_T value)
{
  //## begin cJobSpec::set_JobType%3E71F31500BB.set preserve=no
  _JobType = value;
  //## end cJobSpec::set_JobType%3E71F31500BB.set
}

ULONG_T cJobSpec::get_JobTypeSpec () const
{
  //## begin cJobSpec::get_JobTypeSpec%3E71F3440290.get preserve=no
  return _JobTypeSpec;
  //## end cJobSpec::get_JobTypeSpec%3E71F3440290.get
}

void cJobSpec::set_JobTypeSpec (ULONG_T value)
{
  //## begin cJobSpec::set_JobTypeSpec%3E71F3440290.set preserve=no
  _JobTypeSpec = value;
  //## end cJobSpec::set_JobTypeSpec%3E71F3440290.set
}

// Additional Declarations
  //## begin cJobSpec%3DDBC48B032A.declarations preserve=yes
  //## end cJobSpec%3DDBC48B032A.declarations

//## begin module%3DDBC48B032A.epilog preserve=yes
//## end module%3DDBC48B032A.epilog
