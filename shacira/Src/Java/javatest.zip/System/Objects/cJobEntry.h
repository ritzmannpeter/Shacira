//## begin module%3DDBC4B0023D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC4B0023D.cm

//## begin module%3DDBC4B0023D.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC4B0023D.cp

//## Module: cJobEntry%3DDBC4B0023D; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cJobEntry.h

#ifndef cJobEntry_h
#define cJobEntry_h 1

//## begin module%3DDBC4B0023D.includes preserve=yes
//## end module%3DDBC4B0023D.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3DDBC4B0023D.additionalDeclarations preserve=yes
//## end module%3DDBC4B0023D.additionalDeclarations


//## begin cJobEntry%3DDBC4B0023D.preface preserve=yes
//## end cJobEntry%3DDBC4B0023D.preface

//## Class: cJobEntry%3DDBC4B0023D
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A5806006A;cTransferObject { -> F}

class __DLL_EXPORT__ cJobEntry : public cTransientObject  //## Inherits: <unnamed>%3DDBC4C700A5
{
  //## begin cJobEntry%3DDBC4B0023D.initialDeclarations preserve=yes
public:
  //## end cJobEntry%3DDBC4B0023D.initialDeclarations

    //## Constructors (generated)
      cJobEntry();

      cJobEntry(const cJobEntry &right);

    //## Constructors (specified)
      //## Operation: cJobEntry%1047655602
      cJobEntry (cStaticObject *source, CONST_STRING_T job_name, INT_T job_type, INT_T job_type_spec = 0);

    //## Destructor (generated)
      virtual ~cJobEntry();


    //## Other Operations (specified)
      //## Operation: Properties%1047655603
      ULONG_T Properties ();

      //## Operation: PropertyExists%1047655618
      BOOL_T PropertyExists (CONST_STRING_T property_name);

      //## Operation: Property%1047655613
      STRING_T Property (ULONG_T index);

      //## Operation: PropertyValue%1047655614
      STRING_T PropertyValue (ULONG_T index);

      //## Operation: PropertyValue%1047655615
      STRING_T PropertyValue (CONST_STRING_T property_name);

      //## Operation: AddProperty%1047655616
      void AddProperty (CONST_STRING_T property_name);

      //## Operation: AddPropertyValue%1047655617
      void AddPropertyValue (CONST_STRING_T property_name, CONST_STRING_T value);

      //## Operation: AddPropertyValue%1047655619
      void AddPropertyValue (ULONG_T index, CONST_STRING_T property_name, CONST_STRING_T value);

      //## Operation: Serialize%1046160458
      virtual STRING_T Serialize ();

      //## Operation: Construct%1046160459
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: JobName%3DDCDB590296
      STRING_T get_JobName () const;
      void set_JobName (STRING_T value);

      //## Attribute: JobType%3E71F78C0128
      INT_T get_JobType () const;
      void set_JobType (INT_T value);

      //## Attribute: JobTypeSpec%3E71F78C0129
      ULONG_T get_JobTypeSpec () const;
      void set_JobTypeSpec (ULONG_T value);

      //## Attribute: Shot%3E5B7F880157
      LONG_T get_Shot () const;
      void set_Shot (LONG_T value);

      //## Attribute: Quality%3E5B7FB30376
      INT_T get_Quality () const;
      void set_Quality (INT_T value);

      //## Attribute: Ident%3E5B7FC60264
      STRING_T get_Ident () const;
      void set_Ident (STRING_T value);

  public:
    // Additional Public Declarations
      //## begin cJobEntry%3DDBC4B0023D.public preserve=yes
      //## end cJobEntry%3DDBC4B0023D.public

  protected:
    // Data Members for Class Attributes

      //## begin cJobEntry::JobName%3DDCDB590296.attr preserve=no  public: STRING_T {U} 
      STRING_T _JobName;
      //## end cJobEntry::JobName%3DDCDB590296.attr

      //## begin cJobEntry::JobType%3E71F78C0128.attr preserve=no  public: INT_T {U} UNDEFINED
      INT_T _JobType;
      //## end cJobEntry::JobType%3E71F78C0128.attr

      //## begin cJobEntry::JobTypeSpec%3E71F78C0129.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _JobTypeSpec;
      //## end cJobEntry::JobTypeSpec%3E71F78C0129.attr

      //## begin cJobEntry::Shot%3E5B7F880157.attr preserve=no  public: LONG_T {U} 0
      LONG_T _Shot;
      //## end cJobEntry::Shot%3E5B7F880157.attr

      //## begin cJobEntry::Quality%3E5B7FB30376.attr preserve=no  public: INT_T {U} NO_QUALITY
      INT_T _Quality;
      //## end cJobEntry::Quality%3E5B7FB30376.attr

      //## begin cJobEntry::Ident%3E5B7FC60264.attr preserve=no  public: STRING_T {U} 
      STRING_T _Ident;
      //## end cJobEntry::Ident%3E5B7FC60264.attr

    // Additional Protected Declarations
      //## begin cJobEntry%3DDBC4B0023D.protected preserve=yes
      //## end cJobEntry%3DDBC4B0023D.protected

  private:
    // Additional Private Declarations
      //## begin cJobEntry%3DDBC4B0023D.private preserve=yes
      //## end cJobEntry%3DDBC4B0023D.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: Resize%1047655606
      void Resize (ULONG_T index);

    // Data Members for Class Attributes

      //## Attribute: Properties%3E72057402DE
      //## begin cJobEntry::Properties%3E72057402DE.attr preserve=no  implementation: STRING_VECTOR_T {U} 
      STRING_VECTOR_T _Properties;
      //## end cJobEntry::Properties%3E72057402DE.attr

      //## Attribute: PropertyValues%3E72057402DF
      //## begin cJobEntry::PropertyValues%3E72057402DF.attr preserve=no  implementation: STRING_VECTOR_T {U} 
      STRING_VECTOR_T _PropertyValues;
      //## end cJobEntry::PropertyValues%3E72057402DF.attr

      //## Attribute: PropertyMap%3E72057402EE
      //## begin cJobEntry::PropertyMap%3E72057402EE.attr preserve=no  implementation: ULONG_MAP_T {U} 
      ULONG_MAP_T _PropertyMap;
      //## end cJobEntry::PropertyMap%3E72057402EE.attr

    // Additional Implementation Declarations
      //## begin cJobEntry%3DDBC4B0023D.implementation preserve=yes
      //## end cJobEntry%3DDBC4B0023D.implementation

};

//## begin cJobEntry%3DDBC4B0023D.postscript preserve=yes
//## end cJobEntry%3DDBC4B0023D.postscript

// Class cJobEntry 

//## begin module%3DDBC4B0023D.epilog preserve=yes
//## end module%3DDBC4B0023D.epilog


#endif
