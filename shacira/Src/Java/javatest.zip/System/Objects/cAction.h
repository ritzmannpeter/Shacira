//## begin module%3E6CE1BD0213.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E6CE1BD0213.cm

//## begin module%3E6CE1BD0213.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E6CE1BD0213.cp

//## Module: cAction%3E6CE1BD0213; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cAction.h

#ifndef cAction_h
#define cAction_h 1

//## begin module%3E6CE1BD0213.includes preserve=yes
//## end module%3E6CE1BD0213.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"
// cTransferObject
#include "System/Objects/cTransferObject.h"


//## begin module%3E6CE1BD0213.additionalDeclarations preserve=yes
//## end module%3E6CE1BD0213.additionalDeclarations


//## begin cAction%3E6CE1BD0213.preface preserve=yes
//## end cAction%3E6CE1BD0213.preface

//## Class: cAction%3E6CE1BD0213
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E6CE21403B9;cTransferObject { -> }
//## Uses: <unnamed>%3E6CE24A01A5;cTransferObject { -> F}

class __DLL_EXPORT__ cAction : public cTransientObject  //## Inherits: <unnamed>%3E6CE1D60157
{
  //## begin cAction%3E6CE1BD0213.initialDeclarations preserve=yes
  //## end cAction%3E6CE1BD0213.initialDeclarations

    //## Constructors (generated)
      cAction();

      cAction(const cAction &right);

    //## Constructors (specified)
      //## Operation: cAction%1047319826
      cAction (cStaticObject *source, INT_T action_code);

    //## Destructor (generated)
      virtual ~cAction();


    //## Other Operations (specified)
      //## Operation: Serialize%1047319827
      virtual STRING_T Serialize ();

      //## Operation: Construct%1047319828
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ActionCode%3E6CE1FB031C
      INT_T get_ActionCode () const;
      void set_ActionCode (INT_T value);

  public:
    // Additional Public Declarations
      //## begin cAction%3E6CE1BD0213.public preserve=yes
      //## end cAction%3E6CE1BD0213.public

  protected:
    // Data Members for Class Attributes

      //## begin cAction::ActionCode%3E6CE1FB031C.attr preserve=no  public: INT_T {U} UNDEFINED
      INT_T _ActionCode;
      //## end cAction::ActionCode%3E6CE1FB031C.attr

    // Additional Protected Declarations
      //## begin cAction%3E6CE1BD0213.protected preserve=yes
      //## end cAction%3E6CE1BD0213.protected

  private:
    // Additional Private Declarations
      //## begin cAction%3E6CE1BD0213.private preserve=yes
      //## end cAction%3E6CE1BD0213.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cAction%3E6CE1BD0213.implementation preserve=yes
      //## end cAction%3E6CE1BD0213.implementation

};

//## begin cAction%3E6CE1BD0213.postscript preserve=yes
//## end cAction%3E6CE1BD0213.postscript

// Class cAction 

//## begin module%3E6CE1BD0213.epilog preserve=yes
//## end module%3E6CE1BD0213.epilog


#endif
