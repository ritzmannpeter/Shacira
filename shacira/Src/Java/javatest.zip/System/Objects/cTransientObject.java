//## begin module%3A6BF14C0281.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A6BF14C0281.cm

//## begin module%3A6BF14C0281.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3A6BF14C0281.cp

//## Module: cTransientObject%3A6BF14C0281; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cTransientObject.cpp

//## begin module%3A6BF14C0281.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3A6BF14C0281.additionalIncludes

//## begin module%3A6BF14C0281.includes preserve=yes
//## end module%3A6BF14C0281.includes

// cIO
#include "System/Objects/cIO.h"
// cState
#include "System/Objects/cState.h"
// cStaticObject
#include "System/Objects/cStaticObject.h"
// cEvent
#include "System/Objects/cEvent.h"
// cInfo
#include "System/Objects/cInfo.h"
// cTransientObject
#include "System/Objects/cTransientObject.h"
// cAction
#include "System/Objects/cAction.h"
// cProxy
#include "System/Objects/cProxy.h"
// cAlarm
#include "System/Objects/cAlarm.h"
// cJobEntry
#include "System/Objects/cJobEntry.h"
// cJobSpec
#include "System/Objects/cJobSpec.h"
// cDataCopy
#include "System/Objects/cDataCopy.h"
// cDataChange
#include "System/Objects/cDataChange.h"
// cCosEventChannelProxy
#include "Orb/cCosEventChannelProxy.h"
// cCorbaCellProxy
#include "Orb/cCorbaCellProxy.h"
//## begin module%3A6BF14C0281.additionalDeclarations preserve=yes

#undef REGISTER_OBJECTS
std::map<cTransientObject*, cTransientObject*> _ObjectList;

#define BEGIN_PATTERN	0xABCDEF
#define END_PATTERN		0xABCDEF

//## end module%3A6BF14C0281.additionalDeclarations


// Class cTransientObject 


//## begin cTransientObject::ObjectCount%3A9242F001F3.attr preserve=no  public: static ULONG_T {U} 0
ULONG_T cTransientObject::_ObjectCount = 0;
//## end cTransientObject::ObjectCount%3A9242F001F3.attr

//## begin cTransientObject::ObjectNo%3A9FEAA100E4.attr preserve=no  public: static ULONG_T {U} 0
ULONG_T cTransientObject::_ObjectNo = 0;
//## end cTransientObject::ObjectNo%3A9FEAA100E4.attr












cTransientObject::cTransientObject()
  //## begin cTransientObject::cTransientObject%.hasinit preserve=no
      : _BeginPattern(BEGIN_PATTERN), _ObjectIdent(0), _Type(UNDEFINED), _SubType(UNDEFINED), _EventCode(UNDEFINED), _RefCount(0), _EndPattern(END_PATTERN), _Source(NULL)
  //## end cTransientObject::cTransientObject%.hasinit
  //## begin cTransientObject::cTransientObject%.initialization preserve=yes
  //## end cTransientObject::cTransientObject%.initialization
{
  //## begin cTransientObject::cTransientObject%.body preserve=yes
   _ObjectCount++;
   _ObjectNo++;
   _ObjectIdent = _ObjectNo;
   _RefCount++;
#ifdef REGISTER_OBJECTS
   _ObjectList[this] = this;
#endif
   _TimeStamp.Now();
//printf("%d objects\n", _ObjectCount);
  //## end cTransientObject::cTransientObject%.body
}

cTransientObject::cTransientObject(const cTransientObject &right)
  //## begin cTransientObject::cTransientObject%copy.hasinit preserve=no
      : _BeginPattern(BEGIN_PATTERN), _ObjectIdent(0), _Type(UNDEFINED), _SubType(UNDEFINED), _EventCode(UNDEFINED), _RefCount(0), _EndPattern(END_PATTERN), _Source(NULL)
  //## end cTransientObject::cTransientObject%copy.hasinit
  //## begin cTransientObject::cTransientObject%copy.initialization preserve=yes
  //## end cTransientObject::cTransientObject%copy.initialization
{
  //## begin cTransientObject::cTransientObject%copy.body preserve=yes
   _Type = right._Type;
   _SubType = right._SubType;
   _ObjectCount++;
   _ObjectNo++;
   _ObjectIdent = _ObjectNo;
   _TimeStamp = right._TimeStamp;
   _SourceName = right._SourceName;
   _CellName = right._CellName;
//printf("%d objects\n", _ObjectCount);
  //## end cTransientObject::cTransientObject%copy.body
}

cTransientObject::cTransientObject (cStaticObject *source)
  //## begin cTransientObject::cTransientObject%985248929.hasinit preserve=no
      : _BeginPattern(BEGIN_PATTERN), _ObjectIdent(0), _Type(UNDEFINED), _SubType(UNDEFINED), _EventCode(UNDEFINED), _RefCount(0), _EndPattern(END_PATTERN), _Source(NULL)
  //## end cTransientObject::cTransientObject%985248929.hasinit
  //## begin cTransientObject::cTransientObject%985248929.initialization preserve=yes
  //## end cTransientObject::cTransientObject%985248929.initialization
{
  //## begin cTransientObject::cTransientObject%985248929.body preserve=yes
   _ObjectCount++;
   _ObjectNo++;
   _ObjectIdent = _ObjectNo;
   _RefCount++;
#ifdef REGISTER_OBJECTS
   _ObjectList[this] = this;
#endif
   _TimeStamp.Now();
   _Source = source;
   if (_Source != NULL) {
      _SourceName = _Source->get_Name().c_str();
   }
//printf("%d objects\n", _ObjectCount);
  //## end cTransientObject::cTransientObject%985248929.body
}


cTransientObject::~cTransientObject()
{
  //## begin cTransientObject::~cTransientObject%.body preserve=yes
	_BeginPattern = _EndPattern = 0;
   if (_RefCount > 1) {
_ASSERT_UNCOND
   }
   _ObjectCount--;
#ifdef REGISTER_OBJECTS
   _ObjectList.erase(this);
#endif
  //## end cTransientObject::~cTransientObject%.body
}



//## Other Operations (implementation)
void cTransientObject::AddRef ()
{
  //## begin cTransientObject::AddRef%982663969.body preserve=yes
   _RefCount++;
  //## end cTransientObject::AddRef%982663969.body
}

void cTransientObject::Release ()
{
  //## begin cTransientObject::Release%982663970.body preserve=yes
   _RefCount--;
   if (_RefCount == 0) {
      delete this;
   }
  //## end cTransientObject::Release%982663970.body
}

STRING_T cTransientObject::Serialize ()
{
  //## begin cTransientObject::Serialize%1023780985.body preserve=yes
   throw cError(VIRTUAL_METHOD_NOT_IMPLEMENTED, 0, "cTransientObject::Serialize", "cTransientObject");
  //## end cTransientObject::Serialize%1023780985.body
}

BOOL_T cTransientObject::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cTransientObject::Construct%1023780986.body preserve=yes
   throw cError(VIRTUAL_METHOD_NOT_IMPLEMENTED, 0, "cTransientObject::Construct", "cTransientObject");
  //## end cTransientObject::Construct%1023780986.body
}

cTransientObject * cTransientObject::Parse (CONST_STRING_T serialized_obj)
{
  //## begin cTransientObject::Parse%1046160463.body preserve=yes
   INT_T object_type = cTransferObject::ObjectType(serialized_obj);
   cTransientObject * obj = NULL;
   if (object_type == OT_EVENT) {
      obj = new cEvent;
   } else if (object_type == OT_ALARM) {
      obj = new cAlarm;
   } else if (object_type == OT_INFO) {
      obj = new cInfo;
   } else if (object_type == OT_STATE) {
      obj = new cState;
   } else if (object_type == OT_IO) {
      obj = new cIO;
   } else if (object_type == OT_DATA_CHANGE) {
      obj = new cDataChange;
   } else if (object_type == OT_DATA_COPY) {
      obj = new cDataCopy;
   } else if (object_type == OT_JOB_SPEC) {
      obj = new cJobSpec;
   } else if (object_type == OT_JOB_ENTRY) {
      obj = new cJobEntry;
#ifdef CONSTRUCT_PROXY_OBJECTS
// proxy objects must be constructed by a proxy receiver
// proxy objects are not intended to transfer
// via standard channels
   } else if (object_type == OT_ORB_PROCESS_PROXY) {
      obj = new cCorbaProcessProxy;
   } else if (object_type == OT_ORB_CELL_PROXY) {
      obj = new cCorbaCellProxy;
   } else if (object_type == OT_COS_EVENTCHANNEL_PROXY) {
      obj = new cCosEventChannelProxy;
#endif
   } else {
      return NULL;
   }
	if (obj->Construct(serialized_obj)) {
		STRING_T test_obj = obj->Serialize();
		if (strcmp(test_obj.c_str(), serialized_obj) != 0) {
			return NULL;
		} else {
			return obj;
		}
	} else {
		return NULL;
	}
  //## end cTransientObject::Parse%1046160463.body
}

BOOL_T cTransientObject::IsInvalid ()
{
  //## begin cTransientObject::IsInvalid%1047469644.body preserve=yes
	if (_BeginPattern != BEGIN_PATTERN) return true;
	if (_EndPattern != END_PATTERN) return true;
	return false;
  //## end cTransientObject::IsInvalid%1047469644.body
}

void cTransientObject::SerializeBase (cTransferObject &transfer_obj)
{
  //## begin cTransientObject::SerializeBase%1046095018.body preserve=yes
   transfer_obj.set_Type(_Type);
   transfer_obj.set_SubType(_SubType);
   transfer_obj.AddAttribute(0, _Type, ObjectHeader);
   transfer_obj.AddAttribute(1, _SubType, ObjectHeader);
   transfer_obj.AddAttribute(2, _ObjectIdent, ObjectHeader);
   transfer_obj.AddAttribute(3, _TimeStamp, ObjectHeader);
   transfer_obj.AddAttribute(4, _CellName.c_str(), ObjectHeader);
   transfer_obj.AddAttribute(5, _SourceName.c_str(), ObjectHeader);
   transfer_obj.AddAttribute(6, _Key.c_str(), ObjectHeader);
  //## end cTransientObject::SerializeBase%1046095018.body
}

BOOL_T cTransientObject::ConstructBase (cTransferObject &transfer_obj)
{
  //## begin cTransientObject::ConstructBase%1046095019.body preserve=yes
   transfer_obj.GetAttribute(0, _Type, ObjectHeader);
   transfer_obj.GetAttribute(1, _SubType, ObjectHeader);
   transfer_obj.GetAttribute(2, _ObjectIdent, ObjectHeader);
   transfer_obj.GetAttribute(3, _TimeStamp, ObjectHeader);
   transfer_obj.GetAttribute(4, _CellName, ObjectHeader);
   transfer_obj.GetAttribute(5, _SourceName, ObjectHeader);
   transfer_obj.GetAttribute(6, _Key, ObjectHeader);
   return true;
  //## end cTransientObject::ConstructBase%1046095019.body
}

//## Get and Set Operations for Class Attributes (implementation)

ULONG_T cTransientObject::get_ObjectCount ()
{
  //## begin cTransientObject::get_ObjectCount%3A9242F001F3.get preserve=no
  return _ObjectCount;
  //## end cTransientObject::get_ObjectCount%3A9242F001F3.get
}

ULONG_T cTransientObject::get_ObjectNo ()
{
  //## begin cTransientObject::get_ObjectNo%3A9FEAA100E4.get preserve=no
  return _ObjectNo;
  //## end cTransientObject::get_ObjectNo%3A9FEAA100E4.get
}

ULONG_T cTransientObject::get_ObjectIdent () const
{
  //## begin cTransientObject::get_ObjectIdent%3A9FE9F80357.get preserve=no
  return _ObjectIdent;
  //## end cTransientObject::get_ObjectIdent%3A9FE9F80357.get
}

void cTransientObject::set_ObjectIdent (ULONG_T value)
{
  //## begin cTransientObject::set_ObjectIdent%3A9FE9F80357.set preserve=no
  _ObjectIdent = value;
  //## end cTransientObject::set_ObjectIdent%3A9FE9F80357.set
}

INT_T cTransientObject::get_Type () const
{
  //## begin cTransientObject::get_Type%3A6BFFAC02AB.get preserve=no
  return _Type;
  //## end cTransientObject::get_Type%3A6BFFAC02AB.get
}

void cTransientObject::set_Type (INT_T value)
{
  //## begin cTransientObject::set_Type%3A6BFFAC02AB.set preserve=no
  _Type = value;
  //## end cTransientObject::set_Type%3A6BFFAC02AB.set
}

INT_T cTransientObject::get_SubType () const
{
  //## begin cTransientObject::get_SubType%3FBF550A000F.get preserve=no
  return _SubType;
  //## end cTransientObject::get_SubType%3FBF550A000F.get
}

void cTransientObject::set_SubType (INT_T value)
{
  //## begin cTransientObject::set_SubType%3FBF550A000F.set preserve=no
  _SubType = value;
  //## end cTransientObject::set_SubType%3FBF550A000F.set
}

INT_T cTransientObject::get_EventCode () const
{
  //## begin cTransientObject::get_EventCode%3ED39DC901B5.get preserve=no
  return _EventCode;
  //## end cTransientObject::get_EventCode%3ED39DC901B5.get
}

void cTransientObject::set_EventCode (INT_T value)
{
  //## begin cTransientObject::set_EventCode%3ED39DC901B5.set preserve=no
  _EventCode = value;
  //## end cTransientObject::set_EventCode%3ED39DC901B5.set
}

cTimeObject cTransientObject::get_TimeStamp () const
{
  //## begin cTransientObject::get_TimeStamp%3AF412B0004B.get preserve=no
  return _TimeStamp;
  //## end cTransientObject::get_TimeStamp%3AF412B0004B.get
}

void cTransientObject::set_TimeStamp (cTimeObject value)
{
  //## begin cTransientObject::set_TimeStamp%3AF412B0004B.set preserve=no
  _TimeStamp = value;
  //## end cTransientObject::set_TimeStamp%3AF412B0004B.set
}

STRING_T cTransientObject::get_CellName () const
{
  //## begin cTransientObject::get_CellName%3BC1E82502B0.get preserve=no
  return _CellName;
  //## end cTransientObject::get_CellName%3BC1E82502B0.get
}

void cTransientObject::set_CellName (STRING_T value)
{
  //## begin cTransientObject::set_CellName%3BC1E82502B0.set preserve=no
  _CellName = value;
  //## end cTransientObject::set_CellName%3BC1E82502B0.set
}

STRING_T cTransientObject::get_SourceName () const
{
  //## begin cTransientObject::get_SourceName%3E5A63C3016F.get preserve=no
  return _SourceName;
  //## end cTransientObject::get_SourceName%3E5A63C3016F.get
}

void cTransientObject::set_SourceName (STRING_T value)
{
  //## begin cTransientObject::set_SourceName%3E5A63C3016F.set preserve=no
  _SourceName = value;
  //## end cTransientObject::set_SourceName%3E5A63C3016F.set
}

STRING_T cTransientObject::get_Key () const
{
  //## begin cTransientObject::get_Key%3E5B7E9102F6.get preserve=no
  return _Key;
  //## end cTransientObject::get_Key%3E5B7E9102F6.get
}

void cTransientObject::set_Key (STRING_T value)
{
  //## begin cTransientObject::set_Key%3E5B7E9102F6.set preserve=no
  _Key = value;
  //## end cTransientObject::set_Key%3E5B7E9102F6.set
}

LONG_T cTransientObject::get_RefCount () const
{
  //## begin cTransientObject::get_RefCount%3A9242F00243.get preserve=no
  return _RefCount;
  //## end cTransientObject::get_RefCount%3A9242F00243.get
}

// Additional Declarations
  //## begin cTransientObject%3A6BF14C0281.declarations preserve=yes
  //## end cTransientObject%3A6BF14C0281.declarations

//## begin module%3A6BF14C0281.epilog preserve=yes
//## end module%3A6BF14C0281.epilog
