//## begin module%3DDBC52A0206.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DDBC52A0206.cm

//## begin module%3DDBC52A0206.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DDBC52A0206.cp

//## Module: cAlarm%3DDBC52A0206; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cAlarm.h

#ifndef cAlarm_h
#define cAlarm_h 1

//## begin module%3DDBC52A0206.includes preserve=yes
//## end module%3DDBC52A0206.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3DDBC52A0206.additionalDeclarations preserve=yes
//## end module%3DDBC52A0206.additionalDeclarations


//## begin cAlarm%3DDBC52A0206.preface preserve=yes
//## end cAlarm%3DDBC52A0206.preface

//## Class: cAlarm%3DDBC52A0206
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A5810019B;cTransferObject { -> F}

class __DLL_EXPORT__ cAlarm : public cTransientObject  //## Inherits: <unnamed>%3DDBC53F021A
{
  //## begin cAlarm%3DDBC52A0206.initialDeclarations preserve=yes
public:
  //## end cAlarm%3DDBC52A0206.initialDeclarations

    //## Constructors (generated)
      cAlarm();

      cAlarm(const cAlarm &right);

    //## Constructors (specified)
      //## Operation: cAlarm%1043349076
      cAlarm (cStaticObject *source, BOOL_T state, CONST_STRING_T ident);

    //## Destructor (generated)
      virtual ~cAlarm();


    //## Other Operations (specified)
      //## Operation: Serialize%1043349077
      virtual STRING_T Serialize ();

      //## Operation: Construct%1043349078
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AlarmState%3E3042C303C8
      BOOL_T get_AlarmState () const;
      void set_AlarmState (BOOL_T value);

      //## Attribute: AlarmIdent%3DDCDB7B01C3
      STRING_T get_AlarmIdent () const;
      void set_AlarmIdent (STRING_T value);

      //## Attribute: AlarmText%3DDCDB9800CA
      STRING_T get_AlarmText () const;
      void set_AlarmText (STRING_T value);

  public:
    // Additional Public Declarations
      //## begin cAlarm%3DDBC52A0206.public preserve=yes
      //## end cAlarm%3DDBC52A0206.public

  protected:
    // Data Members for Class Attributes

      //## begin cAlarm::AlarmState%3E3042C303C8.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _AlarmState;
      //## end cAlarm::AlarmState%3E3042C303C8.attr

      //## begin cAlarm::AlarmIdent%3DDCDB7B01C3.attr preserve=no  public: STRING_T {U} 
      STRING_T _AlarmIdent;
      //## end cAlarm::AlarmIdent%3DDCDB7B01C3.attr

      //## begin cAlarm::AlarmText%3DDCDB9800CA.attr preserve=no  public: STRING_T {U} 
      STRING_T _AlarmText;
      //## end cAlarm::AlarmText%3DDCDB9800CA.attr

    // Additional Protected Declarations
      //## begin cAlarm%3DDBC52A0206.protected preserve=yes
      //## end cAlarm%3DDBC52A0206.protected

  private:
    // Additional Private Declarations
      //## begin cAlarm%3DDBC52A0206.private preserve=yes
      //## end cAlarm%3DDBC52A0206.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cAlarm%3DDBC52A0206.implementation preserve=yes
      //## end cAlarm%3DDBC52A0206.implementation

};

//## begin cAlarm%3DDBC52A0206.postscript preserve=yes
//## end cAlarm%3DDBC52A0206.postscript

// Class cAlarm 

//## begin module%3DDBC52A0206.epilog preserve=yes
//## end module%3DDBC52A0206.epilog


#endif
