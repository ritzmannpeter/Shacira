//## begin module%3ABA1A7A023D.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3ABA1A7A023D.cm

//## begin module%3ABA1A7A023D.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3ABA1A7A023D.cp

//## Module: cInfo%3ABA1A7A023D; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Objects\cInfo.h

#ifndef cInfo_h
#define cInfo_h 1

//## begin module%3ABA1A7A023D.includes preserve=yes
//## end module%3ABA1A7A023D.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"

class __DLL_EXPORT__ cTransferObject;

//## begin module%3ABA1A7A023D.additionalDeclarations preserve=yes
#define PROGRAM_STATE_TYPE    1
#define PROGRAM_SPECIFIC_1    2
#define PROGRAM_SPECIFIC_2    3
#define PROGRAM_SPECIFIC_3    4
#define PROGRAM_SPECIFIC_4    5
#define PROGRAM_SPECIFIC_5    6
//## end module%3ABA1A7A023D.additionalDeclarations


//## begin cInfo%3ABA1A7A023D.preface preserve=yes
//## end cInfo%3ABA1A7A023D.preface

//## Class: cInfo%3ABA1A7A023D
//## Category: System::Objects%3DC816ED01FF
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E5A57C0013C;cTransferObject { -> F}

class __DLL_EXPORT__ cInfo : public cTransientObject  //## Inherits: <unnamed>%3ABA1B2F00FC
{
  //## begin cInfo%3ABA1A7A023D.initialDeclarations preserve=yes
public:
  //## end cInfo%3ABA1A7A023D.initialDeclarations

    //## Constructors (generated)
      cInfo();

      cInfo(const cInfo &right);

    //## Constructors (specified)
      //## Operation: cInfo%985267668
      cInfo (cStaticObject *source, INT_T info_type, INT_T info_code, CONST_STRING_T info_text);

    //## Destructor (generated)
      virtual ~cInfo();


    //## Other Operations (specified)
      //## Operation: Serialize%1023780979
      virtual STRING_T Serialize ();

      //## Operation: Construct%1023780980
      virtual BOOL_T Construct (CONST_STRING_T serialized_obj);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: InfoType%3E5B712C00D9
      INT_T get_InfoType () const;
      void set_InfoType (INT_T value);

      //## Attribute: InfoCode%3ABA1AA5005E
      INT_T get_InfoCode () const;
      void set_InfoCode (INT_T value);

      //## Attribute: InfoText%3ABA1AC40026
      STRING_T get_InfoText () const;
      void set_InfoText (STRING_T value);

  public:
    // Additional Public Declarations
      //## begin cInfo%3ABA1A7A023D.public preserve=yes
      //## end cInfo%3ABA1A7A023D.public

  protected:
    // Data Members for Class Attributes

      //## begin cInfo::InfoType%3E5B712C00D9.attr preserve=no  public: INT_T {U} 0
      INT_T _InfoType;
      //## end cInfo::InfoType%3E5B712C00D9.attr

      //## begin cInfo::InfoCode%3ABA1AA5005E.attr preserve=no  public: INT_T {U} 0
      INT_T _InfoCode;
      //## end cInfo::InfoCode%3ABA1AA5005E.attr

      //## begin cInfo::InfoText%3ABA1AC40026.attr preserve=no  public: STRING_T {U} 
      STRING_T _InfoText;
      //## end cInfo::InfoText%3ABA1AC40026.attr

    // Additional Protected Declarations
      //## begin cInfo%3ABA1A7A023D.protected preserve=yes
      //## end cInfo%3ABA1A7A023D.protected

  private:
    // Additional Private Declarations
      //## begin cInfo%3ABA1A7A023D.private preserve=yes
      //## end cInfo%3ABA1A7A023D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cInfo%3ABA1A7A023D.implementation preserve=yes
      //## end cInfo%3ABA1A7A023D.implementation

};

//## begin cInfo%3ABA1A7A023D.postscript preserve=yes
//## end cInfo%3ABA1A7A023D.postscript

// Class cInfo 

//## begin module%3ABA1A7A023D.epilog preserve=yes
//## end module%3ABA1A7A023D.epilog


#endif
