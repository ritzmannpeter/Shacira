//## begin module%3C348D8E0012.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C348D8E0012.cm

//## begin module%3C348D8E0012.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C348D8E0012.cp

//## Module: cCharRingBuffer%3C348D8E0012; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Memory\cCharRingBuffer.h

#ifndef cCharRingBuffer_h
#define cCharRingBuffer_h 1

//## begin module%3C348D8E0012.includes preserve=yes
//## end module%3C348D8E0012.includes


class __DLL_EXPORT__ cMemoryPtr;

//## begin module%3C348D8E0012.additionalDeclarations preserve=yes
//## end module%3C348D8E0012.additionalDeclarations


//## begin cCharRingBuffer%3C348D8E0012.preface preserve=yes
//## end cCharRingBuffer%3C348D8E0012.preface

//## Class: cCharRingBuffer%3C348D8E0012
//## Category: System::Memory%3DC92B0D00DE
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class __DLL_EXPORT__ cCharRingBuffer 
{
  //## begin cCharRingBuffer%3C348D8E0012.initialDeclarations preserve=yes
public:
  //## end cCharRingBuffer%3C348D8E0012.initialDeclarations

    //## Constructors (generated)
      cCharRingBuffer();

      cCharRingBuffer(const cCharRingBuffer &right);

    //## Constructors (specified)
      //## Operation: cCharRingBuffer%1010077552
      cCharRingBuffer (ULONG_T size);

    //## Destructor (generated)
      virtual ~cCharRingBuffer();


    //## Other Operations (specified)
      //## Operation: Put%1010077553
      ULONG_T Put (CONST_STRING_T buffer, ULONG_T amount);

      //## Operation: Get%1010077554
      ULONG_T Get (BUF_T buffer, ULONG_T amount);

      //## Operation: Clear%1010131285
      void Clear ();

      //## Operation: IsEmpty%1010077555
      BOOL_T IsEmpty ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Size%3C348DD5010E
      ULONG_T get_Size () const;

  public:
    // Additional Public Declarations
      //## begin cCharRingBuffer%3C348D8E0012.public preserve=yes
      //## end cCharRingBuffer%3C348D8E0012.public

  protected:
    // Data Members for Class Attributes

      //## begin cCharRingBuffer::Size%3C348DD5010E.attr preserve=no  public: ULONG_T {U} 256
      ULONG_T _Size;
      //## end cCharRingBuffer::Size%3C348DD5010E.attr

    // Data Members for Associations

      //## Association: System::<unnamed>%3C3490A401B2
      //## Role: cCharRingBuffer::Memory%3C3490A403B1
      //## begin cCharRingBuffer::Memory%3C3490A403B1.role preserve=no  public: cMemoryPtr { -> 1RFHN}
      cMemoryPtr *_Memory;
      //## end cCharRingBuffer::Memory%3C3490A403B1.role

    // Additional Protected Declarations
      //## begin cCharRingBuffer%3C348D8E0012.protected preserve=yes
      //## end cCharRingBuffer%3C348D8E0012.protected

  private:
    // Additional Private Declarations
      //## begin cCharRingBuffer%3C348D8E0012.private preserve=yes
      //## end cCharRingBuffer%3C348D8E0012.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: SetBuffer%1010077556
      void SetBuffer ();

    // Data Members for Class Attributes

      //## Attribute: ReadPtr%3C348E39037F
      //## begin cCharRingBuffer::ReadPtr%3C348E39037F.attr preserve=no  implementation: ULONG_T {U} 0
      ULONG_T _ReadPtr;
      //## end cCharRingBuffer::ReadPtr%3C348E39037F.attr

      //## Attribute: WritePtr%3C348E5902D1
      //## begin cCharRingBuffer::WritePtr%3C348E5902D1.attr preserve=no  implementation: ULONG_T {U} 0
      ULONG_T _WritePtr;
      //## end cCharRingBuffer::WritePtr%3C348E5902D1.attr

    // Additional Implementation Declarations
      //## begin cCharRingBuffer%3C348D8E0012.implementation preserve=yes
      //## end cCharRingBuffer%3C348D8E0012.implementation

};

//## begin cCharRingBuffer%3C348D8E0012.postscript preserve=yes
//## end cCharRingBuffer%3C348D8E0012.postscript

// Class cCharRingBuffer 

//## begin module%3C348D8E0012.epilog preserve=yes
//## end module%3C348D8E0012.epilog


#endif
