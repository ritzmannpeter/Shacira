//## begin module%3C348D8E0012.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C348D8E0012.cm

//## begin module%3C348D8E0012.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C348D8E0012.cp

//## Module: cCharRingBuffer%3C348D8E0012; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Memory\cCharRingBuffer.cpp

//## begin module%3C348D8E0012.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C348D8E0012.additionalIncludes

//## begin module%3C348D8E0012.includes preserve=yes
//## end module%3C348D8E0012.includes

// cMemoryPtr
#include "System/Memory/cMemoryPtr.h"
// cCharRingBuffer
#include "System/Memory/cCharRingBuffer.h"
//## begin module%3C348D8E0012.additionalDeclarations preserve=yes
//## end module%3C348D8E0012.additionalDeclarations


// Class cCharRingBuffer 








cCharRingBuffer::cCharRingBuffer()
  //## begin cCharRingBuffer::cCharRingBuffer%.hasinit preserve=no
      : _Size(256), _ReadPtr(0), _WritePtr(0), _Memory(NULL)
  //## end cCharRingBuffer::cCharRingBuffer%.hasinit
  //## begin cCharRingBuffer::cCharRingBuffer%.initialization preserve=yes
  //## end cCharRingBuffer::cCharRingBuffer%.initialization
{
  //## begin cCharRingBuffer::cCharRingBuffer%.body preserve=yes
   SetBuffer();
  //## end cCharRingBuffer::cCharRingBuffer%.body
}

cCharRingBuffer::cCharRingBuffer(const cCharRingBuffer &right)
  //## begin cCharRingBuffer::cCharRingBuffer%copy.hasinit preserve=no
      : _Size(256), _ReadPtr(0), _WritePtr(0), _Memory(NULL)
  //## end cCharRingBuffer::cCharRingBuffer%copy.hasinit
  //## begin cCharRingBuffer::cCharRingBuffer%copy.initialization preserve=yes
  //## end cCharRingBuffer::cCharRingBuffer%copy.initialization
{
  //## begin cCharRingBuffer::cCharRingBuffer%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cCharRingBuffer::cCharRingBuffer%copy.body
}

cCharRingBuffer::cCharRingBuffer (ULONG_T size)
  //## begin cCharRingBuffer::cCharRingBuffer%1010077552.hasinit preserve=no
      : _Size(256), _ReadPtr(0), _WritePtr(0), _Memory(NULL)
  //## end cCharRingBuffer::cCharRingBuffer%1010077552.hasinit
  //## begin cCharRingBuffer::cCharRingBuffer%1010077552.initialization preserve=yes
  //## end cCharRingBuffer::cCharRingBuffer%1010077552.initialization
{
  //## begin cCharRingBuffer::cCharRingBuffer%1010077552.body preserve=yes
   _Size = size;
   SetBuffer();
  //## end cCharRingBuffer::cCharRingBuffer%1010077552.body
}


cCharRingBuffer::~cCharRingBuffer()
{
  //## begin cCharRingBuffer::~cCharRingBuffer%.body preserve=yes
   if (_Memory != NULL) delete _Memory;
  //## end cCharRingBuffer::~cCharRingBuffer%.body
}



//## Other Operations (implementation)
ULONG_T cCharRingBuffer::Put (CONST_STRING_T buffer, ULONG_T amount)
{
  //## begin cCharRingBuffer::Put%1010077553.body preserve=yes
   for (unsigned long i=0; i<amount; i++) {
      if (_WritePtr == _Size) _WritePtr = 0;
      ((char*)(*_Memory))[_WritePtr] = buffer[i];
      _WritePtr++;
      if (_ReadPtr == _WritePtr) return i;
   }
   return 0;
  //## end cCharRingBuffer::Put%1010077553.body
}

ULONG_T cCharRingBuffer::Get (BUF_T buffer, ULONG_T amount)
{
  //## begin cCharRingBuffer::Get%1010077554.body preserve=yes
   for (unsigned long i=0; i<amount; i++) {
      if (_ReadPtr == _WritePtr) return i;
      if (_ReadPtr == _Size) _ReadPtr = 0;
      buffer[i] = ((char*)(*_Memory))[_ReadPtr];
      _ReadPtr++;
   }
   return amount;
  //## end cCharRingBuffer::Get%1010077554.body
}

void cCharRingBuffer::Clear ()
{
  //## begin cCharRingBuffer::Clear%1010131285.body preserve=yes
   _ReadPtr = _WritePtr = 0;
  //## end cCharRingBuffer::Clear%1010131285.body
}

BOOL_T cCharRingBuffer::IsEmpty ()
{
  //## begin cCharRingBuffer::IsEmpty%1010077555.body preserve=yes
   return (_ReadPtr == _WritePtr);
  //## end cCharRingBuffer::IsEmpty%1010077555.body
}

void cCharRingBuffer::SetBuffer ()
{
  //## begin cCharRingBuffer::SetBuffer%1010077556.body preserve=yes
   _Memory = new cMemoryPtr(_Size);
  //## end cCharRingBuffer::SetBuffer%1010077556.body
}

//## Get and Set Operations for Class Attributes (implementation)

ULONG_T cCharRingBuffer::get_Size () const
{
  //## begin cCharRingBuffer::get_Size%3C348DD5010E.get preserve=no
  return _Size;
  //## end cCharRingBuffer::get_Size%3C348DD5010E.get
}

// Additional Declarations
  //## begin cCharRingBuffer%3C348D8E0012.declarations preserve=yes
  //## end cCharRingBuffer%3C348D8E0012.declarations

//## begin module%3C348D8E0012.epilog preserve=yes
//## end module%3C348D8E0012.epilog
