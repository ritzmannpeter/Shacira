//## begin module%3DCAA12E00EB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DCAA12E00EB.cm

//## begin module%3DCAA12E00EB.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DCAA12E00EB.cp

//## Module: cCellProxy%3DCAA12E00EB; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cCellProxy.cpp

//## begin module%3DCAA12E00EB.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3DCAA12E00EB.additionalIncludes

//## begin module%3DCAA12E00EB.includes preserve=yes
//## end module%3DCAA12E00EB.includes

// cCellProxy
#include "System/Process/cCellProxy.h"
// cContext
#include "System/Database/cContext.h"
// cBroker
#include "Orb/cBroker.h"
//## begin module%3DCAA12E00EB.additionalDeclarations preserve=yes
//## end module%3DCAA12E00EB.additionalDeclarations


// Class cCellProxy 



cCellProxy::cCellProxy()
  //## begin cCellProxy::cCellProxy%.hasinit preserve=no
  //## end cCellProxy::cCellProxy%.hasinit
  //## begin cCellProxy::cCellProxy%.initialization preserve=yes
  //## end cCellProxy::cCellProxy%.initialization
{
  //## begin cCellProxy::cCellProxy%.body preserve=yes
  //## end cCellProxy::cCellProxy%.body
}

cCellProxy::cCellProxy(const cCellProxy &right)
  //## begin cCellProxy::cCellProxy%copy.hasinit preserve=no
  //## end cCellProxy::cCellProxy%copy.hasinit
  //## begin cCellProxy::cCellProxy%copy.initialization preserve=yes
  //## end cCellProxy::cCellProxy%copy.initialization
{
  //## begin cCellProxy::cCellProxy%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cCellProxy::cCellProxy%copy.body
}


cCellProxy::~cCellProxy()
{
  //## begin cCellProxy::~cCellProxy%.body preserve=yes
  //## end cCellProxy::~cCellProxy%.body
}



//## Other Operations (implementation)
void cCellProxy::SetValue (CONST_STRING_T item_name, LONG_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cCellProxy::SetValue%1036694754.body preserve=yes
   throw cError(VIRTUAL_METHOD_NOT_IMPLEMENTED, 0, "cCellProxy::SetValue/2", "cCellProxy");
  //## end cCellProxy::SetValue%1036694754.body
}

// Additional Declarations
  //## begin cCellProxy%3DCAA12E00EB.declarations preserve=yes
  //## end cCellProxy%3DCAA12E00EB.declarations

//## begin module%3DCAA12E00EB.epilog preserve=yes
//## end module%3DCAA12E00EB.epilog
