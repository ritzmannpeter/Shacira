//## begin module%3DCAA12E00EB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DCAA12E00EB.cm

//## begin module%3DCAA12E00EB.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DCAA12E00EB.cp

//## Module: cCellProxy%3DCAA12E00EB; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cCellProxy.h

#ifndef cCellProxy_h
#define cCellProxy_h 1

//## begin module%3DCAA12E00EB.includes preserve=yes
//## end module%3DCAA12E00EB.includes

// cProxy
#include "System/Objects/cProxy.h"
// cTransferObject
#include "System/Objects/cTransferObject.h"

class __DLL_EXPORT__ cContext;
class __DLL_EXPORT__ cBroker;

//## begin module%3DCAA12E00EB.additionalDeclarations preserve=yes
//## end module%3DCAA12E00EB.additionalDeclarations


//## begin cCellProxy%3DCAA12E00EB.preface preserve=yes
//## end cCellProxy%3DCAA12E00EB.preface

//## Class: cCellProxy%3DCAA12E00EB
//## Category: System::Process%3D3FFF4B0086
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3DCAA12E00ED;cBroker { -> F}
//## Uses: <unnamed>%3E5B2B0003B3;cTransferObject { -> }
//## Uses: <unnamed>%3EA6BB0E00DA;cContext { -> F}

class __DLL_EXPORT__ cCellProxy : public cProxy  //## Inherits: <unnamed>%3EDCC91C0242
{
  //## begin cCellProxy%3DCAA12E00EB.initialDeclarations preserve=yes
public:
  //## end cCellProxy%3DCAA12E00EB.initialDeclarations

    //## Constructors (generated)
      cCellProxy();

      cCellProxy(const cCellProxy &right);

    //## Destructor (generated)
      virtual ~cCellProxy();


    //## Other Operations (specified)
      //## Operation: Name%1036694746
      virtual STRING_T Name () = 0;

      //## Operation: GetVarDefs%1049277236
      //	Gets all variable definitions as a list of serialized
      //	objects.
      virtual ULONG_T GetVarDefs (STRING_LIST_T &obj_list) = 0;

      //## Operation: SlowChannelName%1050761310
      //	Gets a sender name.
      virtual STRING_T SlowChannelName () = 0;

      //## Operation: FastChannelName%1054632830
      //	Gets a sender name.
      virtual STRING_T FastChannelName () = 0;

      //## Operation: GetValue%1036694750
      virtual void GetValue (CONST_STRING_T item_name, STRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1) = 0;

      //## Operation: GetValue%1036694751
      //	This method returns the value of the item specified by
      //	item_name. The value of the item is returned using an
      //	object of type STRING_T &.
      virtual void GetValue (CONST_STRING_T item_name, LONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1) = 0;

      //## Operation: GetValue%1036694752
      //	This method returns the value of the item specified by
      //	item_name. The value of the item is returned using an
      //	object of type STRING_T &.
      virtual void GetValue (CONST_STRING_T item_name, DOUBLE_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1) = 0;

      //## Operation: SetValue%1036694753
      virtual void SetValue (CONST_STRING_T item_name, CONST_STRING_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1) = 0;

      //## Operation: SetValue%1036694754
      //	Sets the value of an item specified by item_name. The
      //	value is passed using an object of type CONST_STRING_T.
      virtual void SetValue (CONST_STRING_T item_name, LONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: SetValue%1036694755
      //	Sets the value of an item specified by item_name. The
      //	value is passed using an object of type CONST_STRING_T.
      virtual void SetValue (CONST_STRING_T item_name, DOUBLE_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1) = 0;

  public:
    // Additional Public Declarations
      //## begin cCellProxy%3DCAA12E00EB.public preserve=yes
      //## end cCellProxy%3DCAA12E00EB.public

  protected:
    // Additional Protected Declarations
      //## begin cCellProxy%3DCAA12E00EB.protected preserve=yes
      //## end cCellProxy%3DCAA12E00EB.protected

  private:
    // Additional Private Declarations
      //## begin cCellProxy%3DCAA12E00EB.private preserve=yes
      //## end cCellProxy%3DCAA12E00EB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cCellProxy%3DCAA12E00EB.implementation preserve=yes
      //## end cCellProxy%3DCAA12E00EB.implementation

};

//## begin cCellProxy%3DCAA12E00EB.postscript preserve=yes
//## end cCellProxy%3DCAA12E00EB.postscript

// Class cCellProxy 

//## begin module%3DCAA12E00EB.epilog preserve=yes
//## end module%3DCAA12E00EB.epilog


#endif
