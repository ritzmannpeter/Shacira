//## begin module%3C46E64A0182.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C46E64A0182.cm

//## begin module%3C46E64A0182.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C46E64A0182.cp

//## Module: cSHProcess%3C46E64A0182; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cSHProcess.cpp

//## begin module%3C46E64A0182.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C46E64A0182.additionalIncludes

//## begin module%3C46E64A0182.includes preserve=yes
//## end module%3C46E64A0182.includes

// cShutDownControl
#include "System/Process/cShutDownControl.h"
// cSHProcess
#include "System/Process/cSHProcess.h"
// cTransientObject
#include "System/Objects/cTransientObject.h"
// cProxy
#include "System/Objects/cProxy.h"
// cConfigurationObject
#include "System/Config/cConfigurationObject.h"
// cProxySender
#include "System/Comm/cProxySender.h"
// cProxyReceiver
#include "System/Comm/cProxyReceiver.h"
// cContext
#include "System/Database/cContext.h"
// cSystemUtils
#include "System/Sys/cSystemUtils.h"
// cCOSChannel
#include "System/Channel/cCOSChannel.h"
// cChannel
#include "System/Channel/cChannel.h"
// cCosEventChannelProxy
#include "Orb/cCosEventChannelProxy.h"
// cRemoteContext
#include "Client/RemoteDatabase/cRemoteContext.h"
//## begin module%3C46E64A0182.additionalDeclarations preserve=yes

#include "System/Objects/cInfo.h"
#define WAIT_INTERVAL   200

//## end module%3C46E64A0182.additionalDeclarations


// Class cSHProcess 























cSHProcess::cSHProcess()
  //## begin cSHProcess::cSHProcess%.hasinit preserve=no
      : _ProcessId(0), _ProcessActive(false), _ExitCode(0), _ShutDownRequest(false), _PulseDifference(0), _ShutDownControlTime(60000), _PulseInterval(1000), _ShutDownControl(NULL)
  //## end cSHProcess::cSHProcess%.hasinit
  //## begin cSHProcess::cSHProcess%.initialization preserve=yes
  //## end cSHProcess::cSHProcess%.initialization
{
  //## begin cSHProcess::cSHProcess%.body preserve=yes
   _ThreadName = "cSHProcess";
   _ProcessId = cSystemUtils::ProcessId();
   _Computer = cSystemUtils::ComputerName();
  //## end cSHProcess::cSHProcess%.body
}

cSHProcess::cSHProcess(const cSHProcess &right)
  //## begin cSHProcess::cSHProcess%copy.hasinit preserve=no
      : _ProcessId(0), _ProcessActive(false), _ExitCode(0), _ShutDownRequest(false), _PulseDifference(0), _ShutDownControlTime(60000), _PulseInterval(1000), _ShutDownControl(NULL)
  //## end cSHProcess::cSHProcess%copy.hasinit
  //## begin cSHProcess::cSHProcess%copy.initialization preserve=yes
  //## end cSHProcess::cSHProcess%copy.initialization
{
  //## begin cSHProcess::cSHProcess%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cSHProcess::cSHProcess%copy.body
}

cSHProcess::cSHProcess (cConfigurationObject *config_obj)
  //## begin cSHProcess::cSHProcess%1011276236.hasinit preserve=no
      : _ProcessId(0), _ProcessActive(false), _ExitCode(0), _ShutDownRequest(false), _PulseDifference(0), _ShutDownControlTime(60000), _PulseInterval(1000), _ShutDownControl(NULL)
  //## end cSHProcess::cSHProcess%1011276236.hasinit
  //## begin cSHProcess::cSHProcess%1011276236.initialization preserve=yes
  //## end cSHProcess::cSHProcess%1011276236.initialization
{
  //## begin cSHProcess::cSHProcess%1011276236.body preserve=yes
_ASSERT_COND(config_obj != NULL)
   _ThreadName = config_obj->get_Name().c_str();
   _IdleTime = config_obj->PropertyValue("IdleTime", _IdleTime);
   _PulseInterval = config_obj->PropertyValue("PulseInterval", _PulseInterval);
   _ShutDownControlTime = config_obj->PropertyValue("ShutDownControlTime", _ShutDownControlTime);
   _ProcessId = cSystemUtils::ProcessId();
   _Computer = cSystemUtils::ComputerName();
   int i = 0, size = 0;
   CONFOBJ_VECTOR_T proxy_receiver_objs;
   size = config_obj->PropertyValue("ProxyReceiver", proxy_receiver_objs);
   for (i=0; i<size; i++) {
      cConfigurationObject * proxy_receiver_obj = proxy_receiver_objs[i];
_ASSERT_COND(proxy_receiver_obj != NULL)
      cProxyReceiver * proxy_receiver = new cProxyReceiver(proxy_receiver_obj, this);
      STRING_T name = proxy_receiver->get_ThreadName();
      _ProxyReceiver[name.c_str()] = proxy_receiver;
   }
   CONFOBJ_VECTOR_T proxy_sender_objs;
   size = config_obj->PropertyValue("ProxySender", proxy_sender_objs);
   for (i=0; i<size; i++) {
      cConfigurationObject * proxy_sender_obj = proxy_sender_objs[i];
_ASSERT_COND(proxy_sender_obj != NULL)
      cProxySender * proxy_sender = new cProxySender(proxy_sender_obj);
      STRING_T name = proxy_sender->get_Name();
      _ProxySender[name.c_str()] = proxy_sender;
   }
   config_obj->PropertyValue("Receiver", _ReceiverNames);
   config_obj->PropertyValue("Sender", _SenderNames);
  //## end cSHProcess::cSHProcess%1011276236.body
}


cSHProcess::~cSHProcess()
{
  //## begin cSHProcess::~cSHProcess%.body preserve=yes
	ShutDown();
   PROXY_SENDER_MAP_T::const_iterator i = _ProxySender.begin();
   while (i != _ProxySender.end()) {
      cProxySender * sender = (*i).second;
      DELETE_OBJECT(cProxySender, sender)
      i++;
   }
   PROXY_RECEIVER_MAP_T::const_iterator k = _ProxyReceiver.begin();
   while (k != _ProxyReceiver.end()) {
      cProxyReceiver * proxy_receiver = (*k).second;
      DELETE_OBJECT(cProxyReceiver, proxy_receiver)
      k++;
   }
  //## end cSHProcess::~cSHProcess%.body
}



//## Other Operations (implementation)
INT_T cSHProcess::MainFunc (void *extra)
{
  //## begin cSHProcess::MainFunc%1037122841.body preserve=yes
MAINFUNC_PROLOG(_ThreadName.c_str())
   StartReceiving();
   OnStartUp();
   _ProcessActive = true;
   Pulse();
   while (!_Terminated) {
MAINFUNC_LOOP_PROLOG(_ThreadName.c_str())
      if (_PulseDifference >= _PulseInterval) {
         Pulse();
         _PulseDifference = 0;
      } else {
         _PulseDifference += _IdleTime;
      }
      if (!_Terminated) cSystemUtils::Suspend(_IdleTime);
MAINFUNC_LOOP_EPILOG
   }
   _ProcessActive = false;
   if (_ShutDownControlTime > 0 && _ShutDownControl == NULL) {
      _ShutDownControl = new cShutDownControl(_ShutDownControlTime);
      _ShutDownControl->StartUp();
	}
   StopReceiving();
   OnShutDown();
   Pulse();
   return 0;
MAINFUNC_EPILOG
  //## end cSHProcess::MainFunc%1037122841.body
}

BOOL_T cSHProcess::StartProcess (ULONG_T wait)
{
  //## begin cSHProcess::StartProcess%1051025201.body preserve=yes
   LONG_T time_left = wait;
   StartUp();
   while (true) {
      if (_ProcessActive) return true;
      if (_Terminated) return false;
      if (wait < 0) return false;
      cSystemUtils::Suspend(WAIT_INTERVAL);
      wait -= WAIT_INTERVAL;
   }
  //## end cSHProcess::StartProcess%1051025201.body
}

BOOL_T cSHProcess::StopProcess (INT_T exit_code, ULONG_T wait)
{
  //## begin cSHProcess::StopProcess%1054632816.body preserve=yes
   _ShutDownRequest = true; 
   while (true) {
      if (_Terminated) return true;
      if (wait < 0) return false;
      cSystemUtils::Suspend(WAIT_INTERVAL);
      wait -= WAIT_INTERVAL;
   }
   return true;
  //## end cSHProcess::StopProcess%1054632816.body
}

void cSHProcess::AddChannel (CONST_STRING_T name, cChannel *channel, BOOL_T remote)
{
  //## begin cSHProcess::AddChannel%1065778445.body preserve=yes
   if (remote) {
      _RemoteChannels[name] = channel;
   } else {
      _LocalChannels[name] = channel;
   }
  //## end cSHProcess::AddChannel%1065778445.body
}

cChannel * cSHProcess::Channel (CONST_STRING_T name)
{
  //## begin cSHProcess::Channel%1065778446.body preserve=yes
   CHANNEL_MAP_T::const_iterator i;
   i = _LocalChannels.find(name);
   if (i != _LocalChannels.end()) return (*i).second;
   i = _RemoteChannels.find(name);
   if (i != _RemoteChannels.end()) return (*i).second;
   return NULL;
  //## end cSHProcess::Channel%1065778446.body
}

void cSHProcess::AddContext (CONST_STRING_T name, cContext *context)
{
  //## begin cSHProcess::AddContext%1054828772.body preserve=yes
   BOOL_T is_remote = context->IsRemote();
   if (is_remote) {
      _RemoteContexts[name] = context;
   } else {
      _LocalContexts[name] = context;
   }
  //## end cSHProcess::AddContext%1054828772.body
}

cContext * cSHProcess::Context (CONST_STRING_T name, BOOL_T remote)
{
  //## begin cSHProcess::Context%1054632818.body preserve=yes
   CONTEXT_MAP_T::const_iterator i;
   if (!remote) {
      i = _LocalContexts.find(name);
      if (i != _LocalContexts.end()) return (*i).second;
   }
   i = _RemoteContexts.find(name);
   if (i != _RemoteContexts.end()) return (*i).second;
   return NULL;
  //## end cSHProcess::Context%1054632818.body
}

void cSHProcess::AddService (CONST_STRING_T service)
{
  //## begin cSHProcess::AddService%1054897237.body preserve=yes
   _Services.push_back(service);
  //## end cSHProcess::AddService%1054897237.body
}

void cSHProcess::NewProxy (cProxy *proxy)
{
  //## begin cSHProcess::NewProxy%1054890582.body preserve=yes
   INT_T object_type = proxy->get_Type();
   STRING_T proxy_name = proxy->get_ProxyName();
   if (object_type == OT_CORBA_CELL_PROXY) {
      if (Context(proxy_name.c_str(), true) == NULL) {
         cContext * context = new cRemoteContext((cCellProxy*)proxy, this);
         AddContext(proxy_name.c_str(), context);
      }
   } else if (object_type == OT_COS_EVENTCHANNEL_PROXY) {
      if (Channel(proxy_name.c_str()) == NULL) {
         cCOSChannel * channel = new cCOSChannel(proxy_name.c_str(), (cCosEventChannelProxy*)proxy);
         AddChannel(proxy_name.c_str(), channel, true);
      }
   } else {
   }
  //## end cSHProcess::NewProxy%1054890582.body
}

void cSHProcess::Send (cTransientObject *object)
{
  //## begin cSHProcess::Send%1054726244.body preserve=yes
   if (_ProcessActive) {
#ifdef do_we_use_that
      std::map<STRING_T, cEventChannel*>::const_iterator i = _Sender.begin();
      while (i != _Sender.end()) {
         cEventChannel * sender = (*i).second;
         sender->Send(object);
         i++;
      }
#endif
   }
  //## end cSHProcess::Send%1054726244.body
}

void cSHProcess::OnStartUp ()
{
  //## begin cSHProcess::OnStartUp%1051528397.body preserve=yes
  //## end cSHProcess::OnStartUp%1051528397.body
}

void cSHProcess::OnShutDown ()
{
  //## begin cSHProcess::OnShutDown%1051528398.body preserve=yes
  //## end cSHProcess::OnShutDown%1051528398.body
}

void cSHProcess::Pulse ()
{
  //## begin cSHProcess::Pulse%1011276239.body preserve=yes
   SERVICE_LIST_T::const_iterator s = _Services.begin();
   while (s != _Services.end()) {
      STRING_T serialized_proxy = (*s);
      PROXY_SENDER_MAP_T::const_iterator i = _ProxySender.begin();
      while (i != _ProxySender.end()) {
         cProxySender * sender = (*i).second;
         long nsend = sender->Send(serialized_proxy.c_str());
         i++;
      }
      s++;
   }
  //## end cSHProcess::Pulse%1011276239.body
}

void cSHProcess::StartReceiving ()
{
  //## begin cSHProcess::StartReceiving%1065795129.body preserve=yes
   PROXY_RECEIVER_MAP_T::const_iterator i = _ProxyReceiver.begin();
   while (i != _ProxyReceiver.end()) {
      cProxyReceiver * proxy_receiver = (*i).second;
      proxy_receiver->StartUp();
      i++;
   }
  //## end cSHProcess::StartReceiving%1065795129.body
}

void cSHProcess::StopReceiving ()
{
  //## begin cSHProcess::StopReceiving%1065795130.body preserve=yes
   PROXY_RECEIVER_MAP_T::const_iterator i = _ProxyReceiver.begin();
   while (i != _ProxyReceiver.end()) {
      cProxyReceiver * proxy_receiver = (*i).second;
      proxy_receiver->ShutDown();
      i++;
   }
  //## end cSHProcess::StopReceiving%1065795130.body
}

//## Get and Set Operations for Class Attributes (implementation)

ULONG_T cSHProcess::get_ProcessId () const
{
  //## begin cSHProcess::get_ProcessId%3C4D442B03C6.get preserve=no
  return _ProcessId;
  //## end cSHProcess::get_ProcessId%3C4D442B03C6.get
}

STRING_T cSHProcess::get_Computer () const
{
  //## begin cSHProcess::get_Computer%3C4D739601E0.get preserve=no
  return _Computer;
  //## end cSHProcess::get_Computer%3C4D739601E0.get
}

STRING_T cSHProcess::get_Path () const
{
  //## begin cSHProcess::get_Path%3C4D4453002A.get preserve=no
  return _Path;
  //## end cSHProcess::get_Path%3C4D4453002A.get
}

void cSHProcess::set_Path (STRING_T value)
{
  //## begin cSHProcess::set_Path%3C4D4453002A.set preserve=no
  _Path = value;
  //## end cSHProcess::set_Path%3C4D4453002A.set
}

BOOL_T cSHProcess::get_ProcessActive () const
{
  //## begin cSHProcess::get_ProcessActive%3CB68922039C.get preserve=no
  return _ProcessActive;
  //## end cSHProcess::get_ProcessActive%3CB68922039C.get
}

INT_T cSHProcess::get_ExitCode () const
{
  //## begin cSHProcess::get_ExitCode%3C47E37A0143.get preserve=no
  return _ExitCode;
  //## end cSHProcess::get_ExitCode%3C47E37A0143.get
}

BOOL_T cSHProcess::get_ShutDownRequest () const
{
  //## begin cSHProcess::get_ShutDownRequest%3DD4B353016D.get preserve=no
  return _ShutDownRequest;
  //## end cSHProcess::get_ShutDownRequest%3DD4B353016D.get
}

ULONG_T cSHProcess::get_PulseInterval () const
{
  //## begin cSHProcess::get_PulseInterval%3C4858FC0077.get preserve=no
  return _PulseInterval;
  //## end cSHProcess::get_PulseInterval%3C4858FC0077.get
}

// Additional Declarations
  //## begin cSHProcess%3C46E64A0182.declarations preserve=yes
  //## end cSHProcess%3C46E64A0182.declarations

//## begin module%3C46E64A0182.epilog preserve=yes
//## end module%3C46E64A0182.epilog
