//## begin module%3B87B9CC0371.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B87B9CC0371.cm

//## begin module%3B87B9CC0371.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3B87B9CC0371.cp

//## Module: cOptions%3B87B9CC0371; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cOptions.cpp

//## begin module%3B87B9CC0371.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3B87B9CC0371.additionalIncludes

//## begin module%3B87B9CC0371.includes preserve=yes
//## end module%3B87B9CC0371.includes

// cOptions
#include "System/Process/cOptions.h"
//## begin module%3B87B9CC0371.additionalDeclarations preserve=yes
#define OPTION_IDENTIFIER     "-"
//## end module%3B87B9CC0371.additionalDeclarations


// Class cOptions 






cOptions::cOptions()
  //## begin cOptions::cOptions%.hasinit preserve=no
  //## end cOptions::cOptions%.hasinit
  //## begin cOptions::cOptions%.initialization preserve=yes
  //## end cOptions::cOptions%.initialization
{
  //## begin cOptions::cOptions%.body preserve=yes
  //## end cOptions::cOptions%.body
}

cOptions::cOptions(const cOptions &right)
  //## begin cOptions::cOptions%copy.hasinit preserve=no
  //## end cOptions::cOptions%copy.hasinit
  //## begin cOptions::cOptions%copy.initialization preserve=yes
  //## end cOptions::cOptions%copy.initialization
{
  //## begin cOptions::cOptions%copy.body preserve=yes
  //## end cOptions::cOptions%copy.body
}

cOptions::cOptions (CONST_STRING_T options, CONST_STRING_T command_line)
  //## begin cOptions::cOptions%998750937.hasinit preserve=no
  //## end cOptions::cOptions%998750937.hasinit
  //## begin cOptions::cOptions%998750937.initialization preserve=yes
  //## end cOptions::cOptions%998750937.initialization
{
  //## begin cOptions::cOptions%998750937.body preserve=yes
   _OptionString = options;
   STRING_T _command_line = command_line;
   int pos = _command_line.find_first_of(" ");
   if (pos >= 0) {
      _Application = STRING_T(_command_line, pos);
      _Args = &(_command_line.c_str())[pos+1];
   } else {
      _Application = command_line;
   }
   Scan();
  //## end cOptions::cOptions%998750937.body
}

cOptions::cOptions (CONST_STRING_T options, INT_T argc, CHAR_T **argv)
  //## begin cOptions::cOptions%998750938.hasinit preserve=no
  //## end cOptions::cOptions%998750938.hasinit
  //## begin cOptions::cOptions%998750938.initialization preserve=yes
  //## end cOptions::cOptions%998750938.initialization
{
  //## begin cOptions::cOptions%998750938.body preserve=yes
   if (argc == 0 || argv == NULL) return;
   _OptionString = options;
   _Application = argv[0];
   for (int i=1; i<argc; i++) {
      if (i != 1) _Args += " ";
      _Args += argv[i];
   }
   Scan();
  //## end cOptions::cOptions%998750938.body
}


cOptions::~cOptions()
{
  //## begin cOptions::~cOptions%.body preserve=yes
  //## end cOptions::~cOptions%.body
}



//## Other Operations (implementation)
STRING_T cOptions::Option (CONST_STRING_T option)
{
  //## begin cOptions::Option%998750939.body preserve=yes
   OPTION_MAP_T::const_iterator opt = _OptionMap.find(option);
   if (opt == _OptionMap.end()) {
      return "";
   } else {
      return (*opt).second.c_str();
   }
  //## end cOptions::Option%998750939.body
}

BOOL_T cOptions::OptionSet (CONST_STRING_T option)
{
  //## begin cOptions::OptionSet%998750940.body preserve=yes
   OPTION_MAP_T::const_iterator opt = _OptionMap.find(option);
   if (opt == _OptionMap.end()) {
      return false;
   } else {
      return true;
   }
  //## end cOptions::OptionSet%998750940.body
}

BOOL_T cOptions::OptionValid (CONST_STRING_T option)
{
  //## begin cOptions::OptionValid%998750942.body preserve=yes
   OPTION_LIST_T::const_iterator opt = _OptionList.begin();
   while (opt != _OptionList.end()) {
      if (strncmp((*opt).c_str(), option, strlen(option)) == 0) return true;
      opt++;
   }
   return false;
  //## end cOptions::OptionValid%998750942.body
}

STRING_T cOptions::OptionSpec (CONST_STRING_T option)
{
  //## begin cOptions::OptionSpec%998750944.body preserve=yes
   OPTION_LIST_T::const_iterator opt = _OptionList.begin();
   while (opt != _OptionList.end()) {
      const char * opt_id = (*opt).c_str();
      if (strncmp(opt_id, option, strlen(opt_id)) == 0) {
         return opt_id;
      }
      opt++;
   }
   return "";
  //## end cOptions::OptionSpec%998750944.body
}

void cOptions::Scan ()
{
  //## begin cOptions::Scan%998750941.body preserve=yes
   LoadDescription();
   STRING_T option;
   STRING_T option_value;
   const char * token = NULL;
   cTokenizer tokenizer(_Args.c_str(), _Args.size());
   token = tokenizer.GetToken(" ");
   if (token != NULL) {
      do {
         if (strlen(token) > 0) {
            STRING_T option_spec = OptionSpec(token);
            if (option_spec.size() == 0) throw InvalidOption(token);
            option = option_spec.c_str();
            if (strlen(token) == option_spec.size()) {
               token = tokenizer.GetToken(" ");
               if (token != NULL && strlen(token) > 0) {
                  option_spec = OptionSpec(token);
                  if (option_spec.size() == 0) {
                     option_value = token;
                     token = tokenizer.GetToken(" ");
                  }
               }
            } else {
               option_value = &(token[option_spec.size()]);
               token = tokenizer.GetToken(" ");
            }
            _OptionMap[option.c_str()] = option_value.c_str();
            option = "";
            option_value = "";
         } else {
           token = tokenizer.GetToken(" ");
         }
      } while (token != NULL);
   }
  //## end cOptions::Scan%998750941.body
}

void cOptions::LoadDescription ()
{
  //## begin cOptions::LoadDescription%998750943.body preserve=yes
   const char * token = NULL;
   cTokenizer tokenizer(_OptionString.c_str(), _OptionString.size());
   while ((token = tokenizer.GetToken(OPTION_IDENTIFIER)) != NULL) {
      if (strlen(token) > 0) {
         STRING_T option = OPTION_IDENTIFIER;
         option += token;
         _OptionList.push_back(option.c_str());
      }
   }
  //## end cOptions::LoadDescription%998750943.body
}

// Additional Declarations
  //## begin cOptions%3B87B9CC0371.declarations preserve=yes
  //## end cOptions%3B87B9CC0371.declarations

//## begin module%3B87B9CC0371.epilog preserve=yes
//## end module%3B87B9CC0371.epilog
