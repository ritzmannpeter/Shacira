//## begin module%3DD3BCC70122.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DD3BCC70122.cm

//## begin module%3DD3BCC70122.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DD3BCC70122.cp

//## Module: cResources%3DD3BCC70122; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cResources.cpp

//## begin module%3DD3BCC70122.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3DD3BCC70122.additionalIncludes

//## begin module%3DD3BCC70122.includes preserve=yes

#include <time.h>

//## end module%3DD3BCC70122.includes

// cResources
#include "System/Process/cResources.h"
// cSHProcess
#include "System/Process/cSHProcess.h"
// cObjectLock
#include "System/Objects/cObjectLock.h"
// cFileConsole
#include "System/Console/cFileConsole.h"
// cSocketConsole
#include "System/Console/cSocketConsole.h"
// cMemoryConsole
#include "System/Console/cMemoryConsole.h"
// cStandardConsole
#include "System/Console/cStandardConsole.h"
// cConsole
#include "System/Console/cConsole.h"
// cFileSystemUtils
#include "System/Sys/cFileSystemUtils.h"
//## begin module%3DD3BCC70122.additionalDeclarations preserve=yes

static char _Text[0x8000];

//## end module%3DD3BCC70122.additionalDeclarations


// Class cResources 

//## begin cResources::LogPath%3DD3C67601D1.attr preserve=no  implementation: static STRING_T {U} "Log"
STRING_T cResources::_LogPath = "Log";
//## end cResources::LogPath%3DD3C67601D1.attr

//## begin cResources::RootConfigPath%3DE5D8A8009A.attr preserve=no  implementation: static STRING_T {U} "Cfg"
STRING_T cResources::_RootConfigPath = "Cfg";
//## end cResources::RootConfigPath%3DE5D8A8009A.attr

//## begin cResources::InfoConsole%3DD3C94000F1.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
CONSOLE_MAP_T cResources::_InfoConsole;
//## end cResources::InfoConsole%3DD3C94000F1.attr

//## begin cResources::ErrorConsole%3DD3C96A0047.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
CONSOLE_MAP_T cResources::_ErrorConsole;
//## end cResources::ErrorConsole%3DD3C96A0047.attr

//## begin cResources::DebugConsole%3DD3C974018C.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
CONSOLE_MAP_T cResources::_DebugConsole;
//## end cResources::DebugConsole%3DD3C974018C.attr

//## begin cResources::OutMutex%3DD3F23E0079.attr preserve=no  implementation: static cMutexSem {U} 
cMutexSem cResources::_OutMutex;
//## end cResources::OutMutex%3DD3F23E0079.attr

//## begin cResources::Process%3DD4B5820030.attr preserve=no  implementation: static cSHProcess * {U} NULL
cSHProcess *cResources::_Process = NULL;
//## end cResources::Process%3DD4B5820030.attr

//## begin cResources::RefCount%3E70820B02FD.attr preserve=no  implementation: static ULONG_T {U} 0
ULONG_T cResources::_RefCount = 0;
//## end cResources::RefCount%3E70820B02FD.attr

//## begin cResources::Argc%3E70824D034B.attr preserve=no  implementation: static int {U} 0
int cResources::_Argc = 0;
//## end cResources::Argc%3E70824D034B.attr

//## begin cResources::Argv%3E7082630280.attr preserve=no  implementation: static char ** {U} NULL
char **cResources::_Argv = NULL;
//## end cResources::Argv%3E7082630280.attr

//## begin cResources::InstanceHandle%3E7082880203.attr preserve=no  implementation: static ULONG_T {U} 0
ULONG_T cResources::_InstanceHandle = 0;
//## end cResources::InstanceHandle%3E7082880203.attr

cResources::cResources()
  //## begin cResources::cResources%.hasinit preserve=no
  //## end cResources::cResources%.hasinit
  //## begin cResources::cResources%.initialization preserve=yes
  //## end cResources::cResources%.initialization
{
  //## begin cResources::cResources%.body preserve=yes
_ASSERT_UNCOND
  //## end cResources::cResources%.body
}

cResources::cResources(const cResources &right)
  //## begin cResources::cResources%copy.hasinit preserve=no
  //## end cResources::cResources%copy.hasinit
  //## begin cResources::cResources%copy.initialization preserve=yes
  //## end cResources::cResources%copy.initialization
{
  //## begin cResources::cResources%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cResources::cResources%copy.body
}

cResources::cResources (int argc, char **argv)
  //## begin cResources::cResources%1047561050.hasinit preserve=no
  //## end cResources::cResources%1047561050.hasinit
  //## begin cResources::cResources%1047561050.initialization preserve=yes
  //## end cResources::cResources%1047561050.initialization
{
  //## begin cResources::cResources%1047561050.body preserve=yes
	_Argc = argc;
	_Argv = argv;
	StartResources();
  //## end cResources::cResources%1047561050.body
}

cResources::cResources (ULONG_T h_inst, CONST_STRING_T cmd_line)
  //## begin cResources::cResources%1047561051.hasinit preserve=no
  //## end cResources::cResources%1047561051.hasinit
  //## begin cResources::cResources%1047561051.initialization preserve=yes
  //## end cResources::cResources%1047561051.initialization
{
  //## begin cResources::cResources%1047561051.body preserve=yes
	_InstanceHandle = h_inst;
	// generate _Argc and _Argv from cmd_line
_ASSERT_UNCOND
  //## end cResources::cResources%1047561051.body
}


cResources::~cResources()
{
  //## begin cResources::~cResources%.body preserve=yes
  //## end cResources::~cResources%.body
}



//## Other Operations (implementation)
void cResources::EPrintf (CONST_STRING_T fmt_str, ... )
{
  //## begin cResources::EPrintf%1037286964.body preserve=yes
   try {
      if (_ErrorConsole.size() == 0) return;
      cObjectLock __lock__(&_OutMutex);
      va_list args;
      va_start(args, fmt_str);
      vsprintf(_Text, fmt_str, args);
      va_end(args);
      CONSOLE_MAP_T::const_iterator i = _ErrorConsole.begin();
      while (i != _ErrorConsole.end()) {
         cConsole * console = (*i).second;
         console->Write(_Text);
         i++;
      }
   } catch (...) {
   }
  //## end cResources::EPrintf%1037286964.body
}

void cResources::IPrintf (CONST_STRING_T fmt_str, ... )
{
  //## begin cResources::IPrintf%1037286965.body preserve=yes
   try {
      if (_InfoConsole.size() == 0) return;
      cObjectLock __lock__(&_OutMutex);
      va_list args;
      va_start(args, fmt_str);
      vsprintf(_Text, fmt_str, args);
      va_end(args);
      CONSOLE_MAP_T::const_iterator i = _InfoConsole.begin();
      while (i != _InfoConsole.end()) {
         cConsole * console = (*i).second;
         console->Write(_Text);
         i++;
      }
   } catch (...) {
   }
  //## end cResources::IPrintf%1037286965.body
}

void cResources::DPrintf (CONST_STRING_T channel, CONST_STRING_T fmt_str, ... )
{
  //## begin cResources::DPrintf%1037286966.body preserve=yes
   try {
      if (_DebugConsole.size() == 0) return;
      CONSOLE_MAP_T::const_iterator i = _DebugConsole.find(channel);
      if (i == _DebugConsole.end()) return;
      cObjectLock __lock__(&_OutMutex);
      va_list args;
      va_start(args, fmt_str);
      vsprintf(_Text, fmt_str, args);
      va_end(args);
      cConsole * console = (*i).second;
      console->Write(_Text);
   } catch (...) {
   }
  //## end cResources::DPrintf%1037286966.body
}

void cResources::FilePrintf (CONST_STRING_T file_name, CONST_STRING_T fmt_str, ... )
{
  //## begin cResources::FilePrintf%1047632191.body preserve=yes
   try {
      cObjectLock __lock__(&_OutMutex);
      va_list args;
      va_start(args, fmt_str);
      vsprintf(_Text, fmt_str, args);
      va_end(args);
      FILE * stream = fopen(file_name, "a");
      if (stream != NULL) {
         fprintf(stream, "%s", _Text);
         fclose(stream);
      }
   } catch (...) {
   }
  //## end cResources::FilePrintf%1047632191.body
}

INT_T cResources::Exit (INT_T exit_code)
{
  //## begin cResources::Exit%1037286967.body preserve=yes
   try {
      if (_Process != NULL) ErrorPrintf("Process %s aborting ...\n", _Process->get_ThreadName().c_str());
//   _exit(exit_code);
      ShutDown();
      return exit_code;
   } catch (...) {
      _exit(exit_code);
   }
  //## end cResources::Exit%1037286967.body
}

void cResources::ShutDown ()
{
  //## begin cResources::ShutDown%1037349735.body preserve=yes
   if (_Process != NULL) _Process->StopProcess();
  //## end cResources::ShutDown%1037349735.body
}

void cResources::RegisterProcess (cSHProcess *process)
{
  //## begin cResources::RegisterProcess%1037349736.body preserve=yes
   _Process = process;
  //## end cResources::RegisterProcess%1037349736.body
}

long __stdcall cResources::Filter (_EXCEPTION_POINTERS *exceptions)
{
  //## begin cResources::Filter%1037286968.body preserve=yes
   PrintException(exceptions);
   return EXCEPTION_EXECUTE_HANDLER;
  //## end cResources::Filter%1037286968.body
}

void cResources::AddErrorConsole (CONST_STRING_T name, cConsole *console)
{
  //## begin cResources::AddErrorConsole%1037286973.body preserve=yes
   _ErrorConsole[name] = console;
  //## end cResources::AddErrorConsole%1037286973.body
}

void cResources::AddInfoConsole (CONST_STRING_T name, cConsole *console)
{
  //## begin cResources::AddInfoConsole%1037286974.body preserve=yes
   _InfoConsole[name] = console;
  //## end cResources::AddInfoConsole%1037286974.body
}

void cResources::AddDebugConsole (CONST_STRING_T name, cConsole *console)
{
  //## begin cResources::AddDebugConsole%1043598187.body preserve=yes
   _DebugConsole[name] = console;
  //## end cResources::AddDebugConsole%1043598187.body
}

void cResources::SetLogFile (CONST_STRING_T log_file_name)
{
  //## begin cResources::SetLogFile%1037286980.body preserve=yes
   if (log_file_name != NULL) {
      STRING_T log_file = cFileSystemUtils::FullPath(log_file_name);
      _LogPath = cFileSystemUtils::DirName(log_file.c_str());
      cFileSystemUtils::CreateDir(_LogPath.c_str());
      cConsole * console = new cFileConsole(log_file.c_str());
      _ErrorConsole["LOG"] = console;
      SetFullPath(_LogPath);
   }
  //## end cResources::SetLogFile%1037286980.body
}

void cResources::SetRootConfigFile (CONST_STRING_T config_file_name)
{
  //## begin cResources::SetRootConfigFile%1038473718.body preserve=yes
   if (config_file_name != NULL) {
      STRING_T config_file = cFileSystemUtils::FullPath(config_file_name);
      _RootConfigPath = cFileSystemUtils::DirName(config_file.c_str()).c_str();
      SetFullPath(_RootConfigPath);
   }
  //## end cResources::SetRootConfigFile%1038473718.body
}

CONST_STRING_T cResources::LogPath ()
{
  //## begin cResources::LogPath%1038473719.body preserve=yes
   return _LogPath.c_str();
  //## end cResources::LogPath%1038473719.body
}

CONST_STRING_T cResources::RootConfigPath ()
{
  //## begin cResources::RootConfigPath%1038473720.body preserve=yes
   return _RootConfigPath.c_str();
  //## end cResources::RootConfigPath%1038473720.body
}

void cResources::StartResources (CONST_STRING_T log_file)
{
  //## begin cResources::StartResources%1037286970.body preserve=yes
   AddStandardInfoConsole();
   AddStandardErrorConsole();
   SetLogFile(log_file);
   SetFullPath(_LogPath);
   SetFullPath(_RootConfigPath);
  //## end cResources::StartResources%1037286970.body
}

void cResources::PrintException (_EXCEPTION_POINTERS *exceptions)
{
  //## begin cResources::PrintException%1037286969.body preserve=yes
   __TRY__ {
      FILE * stream = fopen("Exceptions.dat", "a");
      if (stream != NULL) {
         char time_text[128] = {0};
         time_t timer;
         struct tm * time_struct;
         timer = time(NULL);
         time_struct = localtime(&timer);
         sprintf(time_text, "%s", asctime(time_struct));
         PEXCEPTION_RECORD record = exceptions->ExceptionRecord;
         DWORD code = record->ExceptionCode;
         DWORD flags = record->ExceptionFlags;
         PVOID address = record->ExceptionAddress;
         DWORD params = record->NumberParameters;
         fprintf(stream,
                 "%s: Unhandled Exception:\n   code: %08x\n   flags: %08x\n   address %08x\n   params %d\n",
                 time_text, code, flags, address, params);
         for (unsigned int i=0; i<params; i++) {
            fprintf(stream, "      param %d: %08x\n", i, record->ExceptionInformation[i]);
         }
         fclose(stream);
      }
   } __EXCEPT__(EXCEPTION_EXECUTE_HANDLER) {
   }
  //## end cResources::PrintException%1037286969.body
}

void cResources::AddStandardInfoConsole ()
{
  //## begin cResources::AddStandardInfoConsole%1037286971.body preserve=yes
   cConsole * console = new cStandardConsole(stdout);
   _InfoConsole["STDOUT"] = console;
  //## end cResources::AddStandardInfoConsole%1037286971.body
}

void cResources::AddStandardErrorConsole ()
{
  //## begin cResources::AddStandardErrorConsole%1037286972.body preserve=yes
   cConsole * console = new cStandardConsole(stderr);
   _ErrorConsole["STDERR"] = console;
  //## end cResources::AddStandardErrorConsole%1037286972.body
}

void cResources::SetFullPath (STRING_T &path)
{
  //## begin cResources::SetFullPath%1038473721.body preserve=yes
   path = cFileSystemUtils::FullPath(path.c_str());
  //## end cResources::SetFullPath%1038473721.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cResources::get_LogPath ()
{
  //## begin cResources::get_LogPath%3DD3C67601D1.get preserve=no
  return _LogPath;
  //## end cResources::get_LogPath%3DD3C67601D1.get
}

STRING_T cResources::get_RootConfigPath ()
{
  //## begin cResources::get_RootConfigPath%3DE5D8A8009A.get preserve=no
  return _RootConfigPath;
  //## end cResources::get_RootConfigPath%3DE5D8A8009A.get
}

CONSOLE_MAP_T cResources::get_InfoConsole ()
{
  //## begin cResources::get_InfoConsole%3DD3C94000F1.get preserve=no
  return _InfoConsole;
  //## end cResources::get_InfoConsole%3DD3C94000F1.get
}

CONSOLE_MAP_T cResources::get_ErrorConsole ()
{
  //## begin cResources::get_ErrorConsole%3DD3C96A0047.get preserve=no
  return _ErrorConsole;
  //## end cResources::get_ErrorConsole%3DD3C96A0047.get
}

CONSOLE_MAP_T cResources::get_DebugConsole ()
{
  //## begin cResources::get_DebugConsole%3DD3C974018C.get preserve=no
  return _DebugConsole;
  //## end cResources::get_DebugConsole%3DD3C974018C.get
}

cSHProcess * cResources::get_Process ()
{
  //## begin cResources::get_Process%3DD4B5820030.get preserve=no
  return _Process;
  //## end cResources::get_Process%3DD4B5820030.get
}

// Additional Declarations
  //## begin cResources%3DD3BCC70122.declarations preserve=yes
  //## end cResources%3DD3BCC70122.declarations

//## begin module%3DD3BCC70122.epilog preserve=yes
//## end module%3DD3BCC70122.epilog
