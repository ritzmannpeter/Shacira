//## begin module%3EDDAD4C02CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EDDAD4C02CE.cm

//## begin module%3EDDAD4C02CE.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3EDDAD4C02CE.cp

//## Module: cCell%3EDDAD4C02CE; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cCell.h

#ifndef cCell_h
#define cCell_h 1

//## begin module%3EDDAD4C02CE.includes preserve=yes
//## end module%3EDDAD4C02CE.includes

//## begin module%3EDDAD4C02CE.additionalDeclarations preserve=yes
//## end module%3EDDAD4C02CE.additionalDeclarations


//## begin cCell%3EDDAD4C02CE.preface preserve=yes
//## end cCell%3EDDAD4C02CE.preface

//## Class: cCell%3EDDAD4C02CE
//## Category: System::Process%3D3FFF4B0086
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class cCell 
{
  //## begin cCell%3EDDAD4C02CE.initialDeclarations preserve=yes
  //## end cCell%3EDDAD4C02CE.initialDeclarations

  public:
    //## Constructors (generated)
      cCell();

      cCell(const cCell &right);

    //## Destructor (generated)
      virtual ~cCell();

    // Additional Public Declarations
      //## begin cCell%3EDDAD4C02CE.public preserve=yes
      //## end cCell%3EDDAD4C02CE.public

  protected:
    // Additional Protected Declarations
      //## begin cCell%3EDDAD4C02CE.protected preserve=yes
      //## end cCell%3EDDAD4C02CE.protected

  private:
    // Additional Private Declarations
      //## begin cCell%3EDDAD4C02CE.private preserve=yes
      //## end cCell%3EDDAD4C02CE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cCell%3EDDAD4C02CE.implementation preserve=yes
      //## end cCell%3EDDAD4C02CE.implementation

};

//## begin cCell%3EDDAD4C02CE.postscript preserve=yes
//## end cCell%3EDDAD4C02CE.postscript

// Class cCell 

//## begin module%3EDDAD4C02CE.epilog preserve=yes
//## end module%3EDDAD4C02CE.epilog


#endif
