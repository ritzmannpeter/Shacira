//## begin module%3C46E64A0182.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C46E64A0182.cm

//## begin module%3C46E64A0182.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C46E64A0182.cp

//## Module: cSHProcess%3C46E64A0182; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cSHProcess.h

#ifndef cSHProcess_h
#define cSHProcess_h 1

//## begin module%3C46E64A0182.includes preserve=yes
//## end module%3C46E64A0182.includes

// cControlThread
#include "System/Threads/cControlThread.h"

class __DLL_EXPORT__ cShutDownControl;
class __DLL_EXPORT__ cTransientObject;
class __DLL_EXPORT__ cProxy;
class __DLL_EXPORT__ cConfigurationObject;
class __DLL_EXPORT__ cProxySender;
class __DLL_EXPORT__ cProxyReceiver;
class __DLL_EXPORT__ cContext;
class __DLL_EXPORT__ cSystemUtils;
class __DLL_EXPORT__ cCOSChannel;
class __DLL_EXPORT__ cChannel;
class __DLL_EXPORT__ cCosEventChannelProxy;
class __DLL_EXPORT__ cRemoteContext;

//## begin module%3C46E64A0182.additionalDeclarations preserve=yes

typedef std::list<STRING_T> SERVICE_LIST_T;
typedef std::map<STRING_T,cChannel*> CHANNEL_MAP_T;
typedef std::map<STRING_T,cContext*> CONTEXT_MAP_T;
typedef std::map<STRING_T,cProxySender*> PROXY_SENDER_MAP_T;
typedef std::map<STRING_T,cProxyReceiver*> PROXY_RECEIVER_MAP_T;
typedef std::map<STRING_T,cChannel*> CHANNEL_MAP_T;

//## end module%3C46E64A0182.additionalDeclarations


//## begin cSHProcess%3C46E64A0182.preface preserve=yes
//## end cSHProcess%3C46E64A0182.preface

//## Class: cSHProcess%3C46E64A0182
//## Category: System::Process%3D3FFF4B0086
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C46ECAE02ED;cConfigurationObject { -> F}
//## Uses: <unnamed>%3C4D741D0040;cSystemUtils { -> F}
//## Uses: <unnamed>%3EDCB79E02CE;cContext { -> F}
//## Uses: <unnamed>%3EDCB914036B;cProxyReceiver { -> F}
//## Uses: <unnamed>%3EDCB92202FD;cProxySender { -> F}
//## Uses: <unnamed>%3EDE0E610157;cProxy { -> F}
//## Uses: <unnamed>%3EE05DAE01F4;cRemoteContext { -> F}
//## Uses: <unnamed>%3F8597E30148;cCosEventChannelProxy { -> F}
//## Uses: <unnamed>%3F867D2B003E;cCOSChannel { -> F}
//## Uses: <unnamed>%3F867EF902FD;cChannel { -> F}
//## Uses: <unnamed>%3FBF603B0222;cTransientObject { -> F}

class __DLL_EXPORT__ cSHProcess : public cControlThread  //## Inherits: <unnamed>%3C46E7AF0258
{
  //## begin cSHProcess%3C46E64A0182.initialDeclarations preserve=yes
public:
  //## end cSHProcess%3C46E64A0182.initialDeclarations

    //## Constructors (generated)
      cSHProcess();

      cSHProcess(const cSHProcess &right);

    //## Constructors (specified)
      //## Operation: cSHProcess%1011276236
      cSHProcess (cConfigurationObject *config_obj);

    //## Destructor (generated)
      virtual ~cSHProcess();


    //## Other Operations (specified)
      //## Operation: MainFunc%1037122841
      virtual INT_T MainFunc (void *extra);

      //## Operation: StartProcess%1051025201
      BOOL_T StartProcess (ULONG_T wait = 0);

      //## Operation: StopProcess%1054632816
      BOOL_T StopProcess (INT_T exit_code = 0, ULONG_T wait = 0);

      //## Operation: AddChannel%1065778445
      void AddChannel (CONST_STRING_T name, cChannel *channel, BOOL_T remote = false);

      //## Operation: Channel%1065778446
      cChannel * Channel (CONST_STRING_T name);

      //## Operation: AddContext%1054828772
      void AddContext (CONST_STRING_T name, cContext *context);

      //## Operation: Context%1054632818
      cContext * Context (CONST_STRING_T name, BOOL_T remote = false);

      //## Operation: AddService%1054897237
      void AddService (CONST_STRING_T service);

      //## Operation: NewProxy%1054890582
      void NewProxy (cProxy *proxy);

      //## Operation: Send%1054726244
      void Send (cTransientObject *object);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ProcessId%3C4D442B03C6
      ULONG_T get_ProcessId () const;

      //## Attribute: Computer%3C4D739601E0
      STRING_T get_Computer () const;

      //## Attribute: Path%3C4D4453002A
      STRING_T get_Path () const;
      void set_Path (STRING_T value);

      //## Attribute: ProcessActive%3CB68922039C
      BOOL_T get_ProcessActive () const;

      //## Attribute: ExitCode%3C47E37A0143
      INT_T get_ExitCode () const;

      //## Attribute: ShutDownRequest%3DD4B353016D
      BOOL_T get_ShutDownRequest () const;

  public:
    // Additional Public Declarations
      //## begin cSHProcess%3C46E64A0182.public preserve=yes
      //## end cSHProcess%3C46E64A0182.public

  protected:

    //## Other Operations (specified)
      //## Operation: OnStartUp%1051528397
      virtual void OnStartUp ();

      //## Operation: OnShutDown%1051528398
      virtual void OnShutDown ();

    // Data Members for Class Attributes

      //## begin cSHProcess::ProcessId%3C4D442B03C6.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _ProcessId;
      //## end cSHProcess::ProcessId%3C4D442B03C6.attr

      //## begin cSHProcess::Computer%3C4D739601E0.attr preserve=no  public: STRING_T {U} 
      STRING_T _Computer;
      //## end cSHProcess::Computer%3C4D739601E0.attr

      //## begin cSHProcess::Path%3C4D4453002A.attr preserve=no  public: STRING_T {U} 
      STRING_T _Path;
      //## end cSHProcess::Path%3C4D4453002A.attr

      //## begin cSHProcess::ProcessActive%3CB68922039C.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _ProcessActive;
      //## end cSHProcess::ProcessActive%3CB68922039C.attr

      //## begin cSHProcess::ExitCode%3C47E37A0143.attr preserve=no  public: INT_T {U} 0
      INT_T _ExitCode;
      //## end cSHProcess::ExitCode%3C47E37A0143.attr

      //## begin cSHProcess::ShutDownRequest%3DD4B353016D.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _ShutDownRequest;
      //## end cSHProcess::ShutDownRequest%3DD4B353016D.attr

      //## begin cSHProcess::PulseInterval%3C4858FC0077.attr preserve=no  implementation: ULONG_T {U} 1000
      ULONG_T _PulseInterval;
      //## end cSHProcess::PulseInterval%3C4858FC0077.attr

    // Data Members for Associations

      //## Association: System::<unnamed>%3C69007200BA
      //## Role: cSHProcess::ShutDownControl%3C69007203BD
      //## begin cSHProcess::ShutDownControl%3C69007203BD.role preserve=no  public: cShutDownControl { -> 0..1RFHN}
      cShutDownControl *_ShutDownControl;
      //## end cSHProcess::ShutDownControl%3C69007203BD.role

    // Additional Protected Declarations
      //## begin cSHProcess%3C46E64A0182.protected preserve=yes
      //## end cSHProcess%3C46E64A0182.protected

  private:
    // Additional Private Declarations
      //## begin cSHProcess%3C46E64A0182.private preserve=yes
      //## end cSHProcess%3C46E64A0182.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: Pulse%1011276239
      void Pulse ();

      //## Operation: StartReceiving%1065795129
      void StartReceiving ();

      //## Operation: StopReceiving%1065795130
      void StopReceiving ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: PulseInterval%3C4858FC0077
      ULONG_T get_PulseInterval () const;

    // Data Members for Class Attributes

      //## Attribute: SenderNames%3EDCCCE301A5
      //## begin cSHProcess::SenderNames%3EDCCCE301A5.attr preserve=no  implementation: STRING_VECTOR_T {U} 
      STRING_VECTOR_T _SenderNames;
      //## end cSHProcess::SenderNames%3EDCCCE301A5.attr

      //## Attribute: ReceiverNames%3EDCB44400DA
      //## begin cSHProcess::ReceiverNames%3EDCB44400DA.attr preserve=no  implementation: STRING_VECTOR_T {U} 
      STRING_VECTOR_T _ReceiverNames;
      //## end cSHProcess::ReceiverNames%3EDCB44400DA.attr

      //## Attribute: PulseDifference%3C485A820095
      //## begin cSHProcess::PulseDifference%3C485A820095.attr preserve=no  implementation: ULONG_T {U} 0
      ULONG_T _PulseDifference;
      //## end cSHProcess::PulseDifference%3C485A820095.attr

      //## Attribute: ShutDownControlTime%3C590A3F0028
      //## begin cSHProcess::ShutDownControlTime%3C590A3F0028.attr preserve=no  implementation: ULONG_T {U} 60000
      ULONG_T _ShutDownControlTime;
      //## end cSHProcess::ShutDownControlTime%3C590A3F0028.attr

      //## Attribute: Services%3EDCB3AB037A
      //## begin cSHProcess::Services%3EDCB3AB037A.attr preserve=no  implementation: SERVICE_LIST_T {U} 
      SERVICE_LIST_T _Services;
      //## end cSHProcess::Services%3EDCB3AB037A.attr

      //## Attribute: ProxySender%3EDCB3AB037B
      //## begin cSHProcess::ProxySender%3EDCB3AB037B.attr preserve=no  implementation: PROXY_SENDER_MAP_T {U} 
      PROXY_SENDER_MAP_T _ProxySender;
      //## end cSHProcess::ProxySender%3EDCB3AB037B.attr

      //## Attribute: ProxyReceiver%3EDCB3AB038A
      //## begin cSHProcess::ProxyReceiver%3EDCB3AB038A.attr preserve=no  implementation: PROXY_RECEIVER_MAP_T {U} 
      PROXY_RECEIVER_MAP_T _ProxyReceiver;
      //## end cSHProcess::ProxyReceiver%3EDCB3AB038A.attr

      //## Attribute: LocalContexts%3EDCB59102BF
      //## begin cSHProcess::LocalContexts%3EDCB59102BF.attr preserve=no  implementation: CONTEXT_MAP_T {U} 
      CONTEXT_MAP_T _LocalContexts;
      //## end cSHProcess::LocalContexts%3EDCB59102BF.attr

      //## Attribute: RemoteContexts%3EDF7576002E
      //## begin cSHProcess::RemoteContexts%3EDF7576002E.attr preserve=no  implementation: CONTEXT_MAP_T {U} 
      CONTEXT_MAP_T _RemoteContexts;
      //## end cSHProcess::RemoteContexts%3EDF7576002E.attr

      //## Attribute: LocalChannels%3F86C15602DE
      //## begin cSHProcess::LocalChannels%3F86C15602DE.attr preserve=no  implementation: CHANNEL_MAP_T {U} 
      CHANNEL_MAP_T _LocalChannels;
      //## end cSHProcess::LocalChannels%3F86C15602DE.attr

      //## Attribute: RemoteChannels%3F867ECB0203
      //## begin cSHProcess::RemoteChannels%3F867ECB0203.attr preserve=no  implementation: CHANNEL_MAP_T {U} 
      CHANNEL_MAP_T _RemoteChannels;
      //## end cSHProcess::RemoteChannels%3F867ECB0203.attr

    // Additional Implementation Declarations
      //## begin cSHProcess%3C46E64A0182.implementation preserve=yes
      //## end cSHProcess%3C46E64A0182.implementation

};

//## begin cSHProcess%3C46E64A0182.postscript preserve=yes
//## end cSHProcess%3C46E64A0182.postscript

// Class cSHProcess 

//## begin module%3C46E64A0182.epilog preserve=yes
//## end module%3C46E64A0182.epilog


#endif
