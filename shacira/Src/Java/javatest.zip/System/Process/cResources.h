//## begin module%3DD3BCC70122.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3DD3BCC70122.cm

//## begin module%3DD3BCC70122.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3DD3BCC70122.cp

//## Module: cResources%3DD3BCC70122; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cResources.h

#ifndef cResources_h
#define cResources_h 1

//## begin module%3DD3BCC70122.includes preserve=yes
//## end module%3DD3BCC70122.includes

// eb_sema
#include "base/eb_sema.hpp"

class __DLL_EXPORT__ cSHProcess;
class __DLL_EXPORT__ cObjectLock;
class __DLL_EXPORT__ cFileConsole;
class __DLL_EXPORT__ cSocketConsole;
class __DLL_EXPORT__ cMemoryConsole;
class __DLL_EXPORT__ cStandardConsole;
class __DLL_EXPORT__ cConsole;
class __DLL_EXPORT__ cFileSystemUtils;

//## begin module%3DD3BCC70122.additionalDeclarations preserve=yes

typedef std::map<STRING_T, cConsole *> CONSOLE_MAP_T;

//## end module%3DD3BCC70122.additionalDeclarations


//## begin cResources%3DD3BCC70122.preface preserve=yes
//## end cResources%3DD3BCC70122.preface

//## Class: cResources%3DD3BCC70122
//## Category: System::Process%3D3FFF4B0086
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3DD3C9F903B4;cConsole { -> F}
//## Uses: <unnamed>%3DD3CAE20110;cStandardConsole { -> F}
//## Uses: <unnamed>%3DD3CAE6017A;cMemoryConsole { -> F}
//## Uses: <unnamed>%3DD3CAEA0003;cSocketConsole { -> F}
//## Uses: <unnamed>%3DD3D38E02E9;cFileConsole { -> F}
//## Uses: <unnamed>%3DD3D66601C4;cFileSystemUtils { -> F}
//## Uses: <unnamed>%3DD3F274033D;cMutexSem { -> }
//## Uses: <unnamed>%3DD3F2A402F6;cObjectLock { -> F}
//## Uses: <unnamed>%3DD4B59B005E;cSHProcess { -> F}

class __DLL_EXPORT__ cResources 
{
  //## begin cResources%3DD3BCC70122.initialDeclarations preserve=yes
public:
  //## end cResources%3DD3BCC70122.initialDeclarations

    //## Constructors (generated)
      cResources();

      cResources(const cResources &right);

    //## Constructors (specified)
      //## Operation: cResources%1047561050
      cResources (int argc, char **argv);

      //## Operation: cResources%1047561051
      cResources (ULONG_T h_inst, CONST_STRING_T cmd_line);

    //## Destructor (generated)
      virtual ~cResources();


    //## Other Operations (specified)
      //## Operation: EPrintf%1037286964
      static void EPrintf (CONST_STRING_T fmt_str, ... );

      //## Operation: IPrintf%1037286965
      static void IPrintf (CONST_STRING_T fmt_str, ... );

      //## Operation: DPrintf%1037286966
      static void DPrintf (CONST_STRING_T channel, CONST_STRING_T fmt_str, ... );

      //## Operation: FilePrintf%1047632191
      static void FilePrintf (CONST_STRING_T file_name, CONST_STRING_T fmt_str, ... );

      //## Operation: Exit%1037286967
      static INT_T Exit (INT_T exit_code);

      //## Operation: ShutDown%1037349735
      static void ShutDown ();

      //## Operation: RegisterProcess%1037349736
      static void RegisterProcess (cSHProcess *process);

      //## Operation: Filter%1037286968
      static long __stdcall Filter (_EXCEPTION_POINTERS *exceptions);

      //## Operation: AddErrorConsole%1037286973
      static void AddErrorConsole (CONST_STRING_T name, cConsole *console);

      //## Operation: AddInfoConsole%1037286974
      static void AddInfoConsole (CONST_STRING_T name, cConsole *console);

      //## Operation: AddDebugConsole%1043598187
      static void AddDebugConsole (CONST_STRING_T name, cConsole *console);

      //## Operation: SetLogFile%1037286980
      static void SetLogFile (CONST_STRING_T log_file_name);

      //## Operation: SetRootConfigFile%1038473718
      static void SetRootConfigFile (CONST_STRING_T config_file_name);

      //## Operation: LogPath%1038473719
      static CONST_STRING_T LogPath ();

      //## Operation: RootConfigPath%1038473720
      static CONST_STRING_T RootConfigPath ();

  public:
    // Additional Public Declarations
      //## begin cResources%3DD3BCC70122.public preserve=yes
      //## end cResources%3DD3BCC70122.public

  protected:
    // Data Members for Class Attributes

      //## begin cResources::LogPath%3DD3C67601D1.attr preserve=no  implementation: static STRING_T {U} "Log"
      static STRING_T _LogPath;
      //## end cResources::LogPath%3DD3C67601D1.attr

      //## begin cResources::RootConfigPath%3DE5D8A8009A.attr preserve=no  implementation: static STRING_T {U} "Cfg"
      static STRING_T _RootConfigPath;
      //## end cResources::RootConfigPath%3DE5D8A8009A.attr

      //## begin cResources::InfoConsole%3DD3C94000F1.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
      static CONSOLE_MAP_T _InfoConsole;
      //## end cResources::InfoConsole%3DD3C94000F1.attr

      //## begin cResources::ErrorConsole%3DD3C96A0047.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
      static CONSOLE_MAP_T _ErrorConsole;
      //## end cResources::ErrorConsole%3DD3C96A0047.attr

      //## begin cResources::DebugConsole%3DD3C974018C.attr preserve=no  implementation: static CONSOLE_MAP_T {U} 
      static CONSOLE_MAP_T _DebugConsole;
      //## end cResources::DebugConsole%3DD3C974018C.attr

      //## begin cResources::Process%3DD4B5820030.attr preserve=no  implementation: static cSHProcess * {U} NULL
      static cSHProcess *_Process;
      //## end cResources::Process%3DD4B5820030.attr

    // Additional Protected Declarations
      //## begin cResources%3DD3BCC70122.protected preserve=yes
      //## end cResources%3DD3BCC70122.protected

  private:
    // Additional Private Declarations
      //## begin cResources%3DD3BCC70122.private preserve=yes
      //## end cResources%3DD3BCC70122.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: StartResources%1037286970
      static void StartResources (CONST_STRING_T log_file = NULL);

      //## Operation: PrintException%1037286969
      static void PrintException (_EXCEPTION_POINTERS *exceptions);

      //## Operation: AddStandardInfoConsole%1037286971
      static void AddStandardInfoConsole ();

      //## Operation: AddStandardErrorConsole%1037286972
      static void AddStandardErrorConsole ();

      //## Operation: SetFullPath%1038473721
      static void SetFullPath (STRING_T &path);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: LogPath%3DD3C67601D1
      static STRING_T get_LogPath ();

      //## Attribute: RootConfigPath%3DE5D8A8009A
      static STRING_T get_RootConfigPath ();

      //## Attribute: InfoConsole%3DD3C94000F1
      static CONSOLE_MAP_T get_InfoConsole ();

      //## Attribute: ErrorConsole%3DD3C96A0047
      static CONSOLE_MAP_T get_ErrorConsole ();

      //## Attribute: DebugConsole%3DD3C974018C
      static CONSOLE_MAP_T get_DebugConsole ();

      //## Attribute: Process%3DD4B5820030
      static cSHProcess * get_Process ();

    // Data Members for Class Attributes

      //## Attribute: OutMutex%3DD3F23E0079
      //## begin cResources::OutMutex%3DD3F23E0079.attr preserve=no  implementation: static cMutexSem {U} 
      static cMutexSem _OutMutex;
      //## end cResources::OutMutex%3DD3F23E0079.attr

      //## Attribute: RefCount%3E70820B02FD
      //## begin cResources::RefCount%3E70820B02FD.attr preserve=no  implementation: static ULONG_T {U} 0
      static ULONG_T _RefCount;
      //## end cResources::RefCount%3E70820B02FD.attr

      //## Attribute: Argc%3E70824D034B
      //## begin cResources::Argc%3E70824D034B.attr preserve=no  implementation: static int {U} 0
      static int _Argc;
      //## end cResources::Argc%3E70824D034B.attr

      //## Attribute: Argv%3E7082630280
      //## begin cResources::Argv%3E7082630280.attr preserve=no  implementation: static char ** {U} NULL
      static char **_Argv;
      //## end cResources::Argv%3E7082630280.attr

      //## Attribute: InstanceHandle%3E7082880203
      //## begin cResources::InstanceHandle%3E7082880203.attr preserve=no  implementation: static ULONG_T {U} 0
      static ULONG_T _InstanceHandle;
      //## end cResources::InstanceHandle%3E7082880203.attr

    // Additional Implementation Declarations
      //## begin cResources%3DD3BCC70122.implementation preserve=yes
      //## end cResources%3DD3BCC70122.implementation

};

//## begin cResources%3DD3BCC70122.postscript preserve=yes
//## end cResources%3DD3BCC70122.postscript

// Class cResources 

//## begin module%3DD3BCC70122.epilog preserve=yes
//## end module%3DD3BCC70122.epilog


#endif
