//## begin module%3B87B9CC0371.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B87B9CC0371.cm

//## begin module%3B87B9CC0371.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3B87B9CC0371.cp

//## Module: cOptions%3B87B9CC0371; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cOptions.h

#ifndef cOptions_h
#define cOptions_h 1

//## begin module%3B87B9CC0371.includes preserve=yes
//## end module%3B87B9CC0371.includes

// cTokenizer
#include "System/cTokenizer.h"
//## begin module%3B87B9CC0371.additionalDeclarations preserve=yes

typedef std::map<STRING_T,STRING_T> OPTION_MAP_T;
typedef std::list<STRING_T> OPTION_LIST_T;

class InvalidOption
{
public:
   InvalidOption(CONST_STRING_T option) {_Option = option;};
   CONST_STRING_T GetOption() {return _Option.c_str();};
private:
   STRING_T _Option;
};

//## end module%3B87B9CC0371.additionalDeclarations


//## begin cOptions%3B87B9CC0371.preface preserve=yes
//## end cOptions%3B87B9CC0371.preface

//## Class: cOptions%3B87B9CC0371
//## Category: System::Process%3D3FFF4B0086
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3B87C9D400D3;cTokenizer { -> }

class __DLL_EXPORT__ cOptions 
{
  //## begin cOptions%3B87B9CC0371.initialDeclarations preserve=yes
public:
  //## end cOptions%3B87B9CC0371.initialDeclarations

    //## Constructors (generated)
      cOptions();

      cOptions(const cOptions &right);

    //## Constructors (specified)
      //## Operation: cOptions%998750937
      cOptions (CONST_STRING_T options, CONST_STRING_T command_line);

      //## Operation: cOptions%998750938
      cOptions (CONST_STRING_T options, INT_T argc, CHAR_T **argv);

    //## Destructor (generated)
      virtual ~cOptions();


    //## Other Operations (specified)
      //## Operation: Option%998750939
      STRING_T Option (CONST_STRING_T option);

      //## Operation: OptionSet%998750940
      BOOL_T OptionSet (CONST_STRING_T option);

  public:
    // Additional Public Declarations
      //## begin cOptions%3B87B9CC0371.public preserve=yes
      //## end cOptions%3B87B9CC0371.public

  protected:
    // Additional Protected Declarations
      //## begin cOptions%3B87B9CC0371.protected preserve=yes
      //## end cOptions%3B87B9CC0371.protected

  private:
    // Additional Private Declarations
      //## begin cOptions%3B87B9CC0371.private preserve=yes
      //## end cOptions%3B87B9CC0371.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: OptionValid%998750942
      BOOL_T OptionValid (CONST_STRING_T option);

      //## Operation: OptionSpec%998750944
      STRING_T OptionSpec (CONST_STRING_T option);

      //## Operation: Scan%998750941
      void Scan ();

      //## Operation: LoadDescription%998750943
      void LoadDescription ();

    // Data Members for Class Attributes

      //## Attribute: OptionList%3B87C6710176
      //## begin cOptions::OptionList%3B87C6710176.attr preserve=no  implementation: OPTION_LIST_T {U} 
      OPTION_LIST_T _OptionList;
      //## end cOptions::OptionList%3B87C6710176.attr

      //## Attribute: OptionMap%3B87BC620124
      //## begin cOptions::OptionMap%3B87BC620124.attr preserve=no  implementation: OPTION_MAP_T {U} 
      OPTION_MAP_T _OptionMap;
      //## end cOptions::OptionMap%3B87BC620124.attr

      //## Attribute: OptionString%3B87BD060115
      //## begin cOptions::OptionString%3B87BD060115.attr preserve=no  implementation: STRING_T {U} 
      STRING_T _OptionString;
      //## end cOptions::OptionString%3B87BD060115.attr

      //## Attribute: Application%3B87BD22024C
      //## begin cOptions::Application%3B87BD22024C.attr preserve=no  implementation: STRING_T {U} 
      STRING_T _Application;
      //## end cOptions::Application%3B87BD22024C.attr

      //## Attribute: Args%3B87BF4903C1
      //## begin cOptions::Args%3B87BF4903C1.attr preserve=no  implementation: STRING_T {U} 
      STRING_T _Args;
      //## end cOptions::Args%3B87BF4903C1.attr

    // Additional Implementation Declarations
      //## begin cOptions%3B87B9CC0371.implementation preserve=yes
      //## end cOptions%3B87B9CC0371.implementation

};

//## begin cOptions%3B87B9CC0371.postscript preserve=yes
//## end cOptions%3B87B9CC0371.postscript

// Class cOptions 

//## begin module%3B87B9CC0371.epilog preserve=yes
//## end module%3B87B9CC0371.epilog


#endif
