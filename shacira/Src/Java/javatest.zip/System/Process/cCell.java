//## begin module%3EDDAD4C02CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EDDAD4C02CE.cm

//## begin module%3EDDAD4C02CE.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3EDDAD4C02CE.cp

//## Module: cCell%3EDDAD4C02CE; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Process\cCell.cpp

//## begin module%3EDDAD4C02CE.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3EDDAD4C02CE.additionalIncludes

//## begin module%3EDDAD4C02CE.includes preserve=yes
//## end module%3EDDAD4C02CE.includes

// cCell
#include "System/Process/cCell.h"
//## begin module%3EDDAD4C02CE.additionalDeclarations preserve=yes
//## end module%3EDDAD4C02CE.additionalDeclarations


// Class cCell 


cCell::cCell()
  //## begin cCell::cCell%.hasinit preserve=no
  //## end cCell::cCell%.hasinit
  //## begin cCell::cCell%.initialization preserve=yes
  //## end cCell::cCell%.initialization
{
  //## begin cCell::cCell%.body preserve=yes
  //## end cCell::cCell%.body
}

cCell::cCell(const cCell &right)
  //## begin cCell::cCell%copy.hasinit preserve=no
  //## end cCell::cCell%copy.hasinit
  //## begin cCell::cCell%copy.initialization preserve=yes
  //## end cCell::cCell%copy.initialization
{
  //## begin cCell::cCell%copy.body preserve=yes
  //## end cCell::cCell%copy.body
}


cCell::~cCell()
{
  //## begin cCell::~cCell%.body preserve=yes
  //## end cCell::~cCell%.body
}


// Additional Declarations
  //## begin cCell%3EDDAD4C02CE.declarations preserve=yes
  //## end cCell%3EDDAD4C02CE.declarations

//## begin module%3EDDAD4C02CE.epilog preserve=yes
//## end module%3EDDAD4C02CE.epilog
