//## begin module%3AA342FA00A3.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AA342FA00A3.cm

//## begin module%3AA342FA00A3.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3AA342FA00A3.cp

//## Module: cControlThread%3AA342FA00A3; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Threads\cControlThread.h

#ifndef cControlThread_h
#define cControlThread_h 1

//## begin module%3AA342FA00A3.includes preserve=yes
//## end module%3AA342FA00A3.includes

// eb_thread
#include "base/eb_thread.hpp"

class __DLL_EXPORT__ cObjectLock;

//## begin module%3AA342FA00A3.additionalDeclarations preserve=yes

class cControlThread;
typedef std::map<unsigned long, cControlThread*> THREAD_MAP_T;

//## end module%3AA342FA00A3.additionalDeclarations


//## begin cControlThread%3AA342FA00A3.preface preserve=yes
//## end cControlThread%3AA342FA00A3.preface

//## Class: cControlThread%3AA342FA00A3
//## Category: System::Threads%3DC7FCF00004
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C68EC78000C;cObjectLock { -> F}

class __DLL_EXPORT__ cControlThread : public cThread  //## Inherits: <unnamed>%3AA343220303
{
  //## begin cControlThread%3AA342FA00A3.initialDeclarations preserve=yes
public:
  //## end cControlThread%3AA342FA00A3.initialDeclarations

    //## Constructors (generated)
      cControlThread();

      cControlThread(const cControlThread &right);

    //## Destructor (generated)
      virtual ~cControlThread();


    //## Other Operations (specified)
      //## Operation: Terminated%983778353
      BOOL_T Terminated ();

      //## Operation: StartUp%987504143
      virtual BOOL_T StartUp ();

      //## Operation: ShutDown%987504144
      virtual BOOL_T ShutDown ();

      //## Operation: onEnter%983778320
      virtual BOOL_T onEnter (void *extra);

      //## Operation: onMain%983778321
      virtual INT_T onMain (void *extra);

      //## Operation: onLeave%983778322
      virtual void onLeave (INT_T rc);

      //## Operation: MainFunc%1012414868
      virtual INT_T MainFunc (void *extra);

      //## Operation: ControlFunc%983778325
      virtual INT_T ControlFunc ();

      //## Operation: GetThreadById%997883622
      static cControlThread * GetThreadById (ULONG_T thread_id);

      //## Operation: GetThreadByName%1036575935
      static cControlThread * GetThreadByName (CONST_STRING_T thread_name);

      //## Operation: GetCurrentThreadID%1036575936
      static ULONG_T GetCurrentThreadID ();

      //## Operation: GetCurrentThread%1036575937
      static cControlThread * GetCurrentThread ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Threads%3B7AA2690231
      static THREAD_MAP_T get_Threads ();

      //## Attribute: ThreadName%3FBF5FA701D4
      STRING_T get_ThreadName () const;
      void set_ThreadName (STRING_T value);

      //## Attribute: ThreadId%3B7AAA810118
      ULONG_T get_ThreadId () const;

      //## Attribute: IdleTime%3AA3436D03E7
      ULONG_T get_IdleTime () const;
      void set_IdleTime (ULONG_T value);

      //## Attribute: Terminated%3AA344490357
      BOOL_T get_Terminated () const;

      //## Attribute: Started%3AC1B433030C
      BOOL_T get_Started () const;

  public:
    // Additional Public Declarations
      //## begin cControlThread%3AA342FA00A3.public preserve=yes
      //## end cControlThread%3AA342FA00A3.public

  protected:
    // Data Members for Class Attributes

      //## begin cControlThread::Threads%3B7AA2690231.attr preserve=no  public: static THREAD_MAP_T {U} 
      static THREAD_MAP_T _Threads;
      //## end cControlThread::Threads%3B7AA2690231.attr

      //## begin cControlThread::ThreadName%3FBF5FA701D4.attr preserve=no  public: STRING_T {U} 
      STRING_T _ThreadName;
      //## end cControlThread::ThreadName%3FBF5FA701D4.attr

      //## begin cControlThread::ThreadId%3B7AAA810118.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _ThreadId;
      //## end cControlThread::ThreadId%3B7AAA810118.attr

      //## begin cControlThread::IdleTime%3AA3436D03E7.attr preserve=no  public: ULONG_T {U} 1000
      ULONG_T _IdleTime;
      //## end cControlThread::IdleTime%3AA3436D03E7.attr

      //## begin cControlThread::Terminated%3AA344490357.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _Terminated;
      //## end cControlThread::Terminated%3AA344490357.attr

      //## begin cControlThread::Started%3AC1B433030C.attr preserve=no  public: BOOL_T {U} false
      BOOL_T _Started;
      //## end cControlThread::Started%3AC1B433030C.attr

    // Additional Protected Declarations
      //## begin cControlThread%3AA342FA00A3.protected preserve=yes
      //## end cControlThread%3AA342FA00A3.protected

  private:
    // Additional Private Declarations
      //## begin cControlThread%3AA342FA00A3.private preserve=yes
      //## end cControlThread%3AA342FA00A3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ThreadMutex%3C68EC8C01A6
      //## begin cControlThread::ThreadMutex%3C68EC8C01A6.attr preserve=no  implementation: cMutexSem {U} 
      cMutexSem _ThreadMutex;
      //## end cControlThread::ThreadMutex%3C68EC8C01A6.attr

    // Additional Implementation Declarations
      //## begin cControlThread%3AA342FA00A3.implementation preserve=yes
      //## end cControlThread%3AA342FA00A3.implementation

};

//## begin cControlThread%3AA342FA00A3.postscript preserve=yes
//## end cControlThread%3AA342FA00A3.postscript

// Class cControlThread 

//## begin module%3AA342FA00A3.epilog preserve=yes
//## end module%3AA342FA00A3.epilog


#endif
