//## begin module%3AA342FA00A3.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AA342FA00A3.cm

//## begin module%3AA342FA00A3.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3AA342FA00A3.cp

//## Module: cControlThread%3AA342FA00A3; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Threads\cControlThread.cpp

//## begin module%3AA342FA00A3.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3AA342FA00A3.additionalIncludes

//## begin module%3AA342FA00A3.includes preserve=yes
//## end module%3AA342FA00A3.includes

// cObjectLock
#include "System/Objects/cObjectLock.h"
// cControlThread
#include "System/Threads/cControlThread.h"
//## begin module%3AA342FA00A3.additionalDeclarations preserve=yes
//## end module%3AA342FA00A3.additionalDeclarations


// Class cControlThread 

//## begin cControlThread::Threads%3B7AA2690231.attr preserve=no  public: static THREAD_MAP_T {U} 
THREAD_MAP_T cControlThread::_Threads;
//## end cControlThread::Threads%3B7AA2690231.attr







cControlThread::cControlThread()
  //## begin cControlThread::cControlThread%.hasinit preserve=no
      : _ThreadId(0), _IdleTime(1000), _Terminated(false), _Started(false)
  //## end cControlThread::cControlThread%.hasinit
  //## begin cControlThread::cControlThread%.initialization preserve=yes
  //## end cControlThread::cControlThread%.initialization
{
  //## begin cControlThread::cControlThread%.body preserve=yes
  //## end cControlThread::cControlThread%.body
}

cControlThread::cControlThread(const cControlThread &right)
  //## begin cControlThread::cControlThread%copy.hasinit preserve=no
      : _ThreadId(0), _IdleTime(1000), _Terminated(false), _Started(false)
  //## end cControlThread::cControlThread%copy.hasinit
  //## begin cControlThread::cControlThread%copy.initialization preserve=yes
  //## end cControlThread::cControlThread%copy.initialization
{
  //## begin cControlThread::cControlThread%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cControlThread::cControlThread%copy.body
}


cControlThread::~cControlThread()
{
  //## begin cControlThread::~cControlThread%.body preserve=yes
   ShutDown();
  //## end cControlThread::~cControlThread%.body
}



//## Other Operations (implementation)
BOOL_T cControlThread::Terminated ()
{
  //## begin cControlThread::Terminated%983778353.body preserve=yes
   return _Terminated;
  //## end cControlThread::Terminated%983778353.body
}

BOOL_T cControlThread::StartUp ()
{
  //## begin cControlThread::StartUp%987504143.body preserve=yes
   cObjectLock __Lock__ (&_ThreadMutex);
   if (_Started) return true;
   _Started = true;
   STRING_T starter_name = "unknown";
   cControlThread * starter = GetCurrentThread();
   if (starter != NULL) starter_name = starter->get_ThreadName().c_str();
   BOOL_T success = start(teStart);
   if (success) {
      _ThreadId = getThreadId();
      _Threads[_ThreadId] = this;
      InfoPrintf("%s started by %s\n", _ThreadName.c_str(), starter_name.c_str());
   } else {
      ErrorPrintf("Failed to start %s by %s\n", _ThreadName.c_str(), starter_name.c_str());
   }
   waitFor(teStart);
   return success;
  //## end cControlThread::StartUp%987504143.body
}

BOOL_T cControlThread::ShutDown ()
{
  //## begin cControlThread::ShutDown%987504144.body preserve=yes
   cObjectLock __Lock__ (&_ThreadMutex);
   if (!_Started) return true;
   if (_Terminated) return true;
   _Started = false;
   _Terminated = true;
   STRING_T stopper_name = "unknown";
   cControlThread * stopper = GetCurrentThread();
   if (stopper != NULL) stopper_name = stopper->get_ThreadName().c_str();
   waitFor(teEnd);
   InfoPrintf("%s stopped by %s\n", _ThreadName.c_str(), stopper_name.c_str());
   _Threads.erase(_ThreadId);
   return true;
  //## end cControlThread::ShutDown%987504144.body
}

BOOL_T cControlThread::onEnter (void *extra)
{
  //## begin cControlThread::onEnter%983778320.body preserve=yes
   return true;
  //## end cControlThread::onEnter%983778320.body
}

INT_T cControlThread::onMain (void *extra)
{
  //## begin cControlThread::onMain%983778321.body preserve=yes
   __try {
      int rc = 0;
      rc = MainFunc(extra);
      if (rc != 0) ErrorPrintf("Thread %s abnormal termination rc=%d\n", _ThreadName.c_str(), rc);
      _Terminated = true;
      return 0;
   } __except(ExceptionFilter(GetExceptionInformation())) {
      ErrorPrintf("Unhandled structured exception in thread %s\n", _ThreadName.c_str());
      ExitProcess(-2);
      return -2;
   }
  //## end cControlThread::onMain%983778321.body
}

void cControlThread::onLeave (INT_T rc)
{
  //## begin cControlThread::onLeave%983778322.body preserve=yes
   if (rc != 0) {
      GenerateConsoleCtrlEvent(CTRL_C_EVENT, NULL);
   }
  //## end cControlThread::onLeave%983778322.body
}

INT_T cControlThread::MainFunc (void *extra)
{
  //## begin cControlThread::MainFunc%1012414868.body preserve=yes
MAINFUNC_PROLOG(_ThreadName.c_str())
   while (!_Terminated) {
MAINFUNC_LOOP_PROLOG(_ThreadName.c_str())
      ControlFunc();
MAINFUNC_LOOP_EPILOG
		if (!_Terminated) cSystemUtils::Suspend(_IdleTime);
   }
   return 0;
MAINFUNC_EPILOG
  //## end cControlThread::MainFunc%1012414868.body
}

INT_T cControlThread::ControlFunc ()
{
  //## begin cControlThread::ControlFunc%983778325.body preserve=yes
   return 0;
  //## end cControlThread::ControlFunc%983778325.body
}

cControlThread * cControlThread::GetThreadById (ULONG_T thread_id)
{
  //## begin cControlThread::GetThreadById%997883622.body preserve=yes
   cControlThread * control_thread = NULL;
   THREAD_MAP_T::const_iterator thread = _Threads.find(thread_id);
   if (thread != _Threads.end()) {
      control_thread = (*thread).second;
   }
   return control_thread;
  //## end cControlThread::GetThreadById%997883622.body
}

cControlThread * cControlThread::GetThreadByName (CONST_STRING_T thread_name)
{
  //## begin cControlThread::GetThreadByName%1036575935.body preserve=yes
   cControlThread * control_thread = NULL;
   THREAD_MAP_T::const_iterator thread = _Threads.begin();
   while (thread != _Threads.end()) {
      if (strcmp((*thread).second->get_ThreadName().c_str(), thread_name) == 0) {
         control_thread = (*thread).second;
         break;
      }
      thread++;
   }
   return control_thread;
  //## end cControlThread::GetThreadByName%1036575935.body
}

ULONG_T cControlThread::GetCurrentThreadID ()
{
  //## begin cControlThread::GetCurrentThreadID%1036575936.body preserve=yes
   unsigned long thread_id = GetCurrentThreadId();
   return thread_id;
  //## end cControlThread::GetCurrentThreadID%1036575936.body
}

cControlThread * cControlThread::GetCurrentThread ()
{
  //## begin cControlThread::GetCurrentThread%1036575937.body preserve=yes
   unsigned long thread_id = GetCurrentThreadId();
   return GetThreadById(thread_id);
  //## end cControlThread::GetCurrentThread%1036575937.body
}

//## Get and Set Operations for Class Attributes (implementation)

THREAD_MAP_T cControlThread::get_Threads ()
{
  //## begin cControlThread::get_Threads%3B7AA2690231.get preserve=no
  return _Threads;
  //## end cControlThread::get_Threads%3B7AA2690231.get
}

STRING_T cControlThread::get_ThreadName () const
{
  //## begin cControlThread::get_ThreadName%3FBF5FA701D4.get preserve=no
  return _ThreadName;
  //## end cControlThread::get_ThreadName%3FBF5FA701D4.get
}

void cControlThread::set_ThreadName (STRING_T value)
{
  //## begin cControlThread::set_ThreadName%3FBF5FA701D4.set preserve=no
  _ThreadName = value;
  //## end cControlThread::set_ThreadName%3FBF5FA701D4.set
}

ULONG_T cControlThread::get_ThreadId () const
{
  //## begin cControlThread::get_ThreadId%3B7AAA810118.get preserve=no
  return _ThreadId;
  //## end cControlThread::get_ThreadId%3B7AAA810118.get
}

ULONG_T cControlThread::get_IdleTime () const
{
  //## begin cControlThread::get_IdleTime%3AA3436D03E7.get preserve=no
  return _IdleTime;
  //## end cControlThread::get_IdleTime%3AA3436D03E7.get
}

void cControlThread::set_IdleTime (ULONG_T value)
{
  //## begin cControlThread::set_IdleTime%3AA3436D03E7.set preserve=no
  _IdleTime = value;
  //## end cControlThread::set_IdleTime%3AA3436D03E7.set
}

BOOL_T cControlThread::get_Terminated () const
{
  //## begin cControlThread::get_Terminated%3AA344490357.get preserve=no
  return _Terminated;
  //## end cControlThread::get_Terminated%3AA344490357.get
}

BOOL_T cControlThread::get_Started () const
{
  //## begin cControlThread::get_Started%3AC1B433030C.get preserve=no
  return _Started;
  //## end cControlThread::get_Started%3AC1B433030C.get
}

// Additional Declarations
  //## begin cControlThread%3AA342FA00A3.declarations preserve=yes
  //## end cControlThread%3AA342FA00A3.declarations

//## begin module%3AA342FA00A3.epilog preserve=yes
//## end module%3AA342FA00A3.epilog
