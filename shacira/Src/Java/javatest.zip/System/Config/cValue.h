//## begin module%3A542EFA03A0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A542EFA03A0.cm

//## begin module%3A542EFA03A0.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3A542EFA03A0.cp

//## Module: cValue%3A542EFA03A0; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Config\cValue.h

#ifndef cValue_h
#define cValue_h 1

//## begin module%3A542EFA03A0.includes preserve=yes
//## end module%3A542EFA03A0.includes


class __DLL_EXPORT__ cTypeDef;
class __DLL_EXPORT__ cConvUtils;

//## begin module%3A542EFA03A0.additionalDeclarations preserve=yes
//## end module%3A542EFA03A0.additionalDeclarations


//## begin cValue%3A542EFA03A0.preface preserve=yes
//## end cValue%3A542EFA03A0.preface

//## Class: cValue%3A542EFA03A0
//## Category: System::Config%3A5307460270
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3DCA4DD101B8;cConvUtils { -> F}

class __DLL_EXPORT__ cValue 
{
  //## begin cValue%3A542EFA03A0.initialDeclarations preserve=yes
  //## end cValue%3A542EFA03A0.initialDeclarations

    //## Constructors (generated)
      cValue();

      cValue(const cValue &right);

    //## Constructors (specified)
      //## Operation: cValue%978694293
      cValue (cTypeDef *type_def);

    //## Destructor (generated)
      virtual ~cValue();


    //## Other Operations (specified)
      //## Operation: Value%1011276251
      //	This method returns the value of the virtual item
      //	specified by item_name. The value of the virtual item is
      //	returned using an object of type STRING_T &. If the item
      //	is not contained in virtual data, false will be returned
      //	otherwise true.
      BOOL_T Value (STRING_T &item_value);

      //## Operation: Value%1011276252
      //	This method returns the value of the virtual item
      //	specified by item_name. The value of the virtual item is
      //	returned using an object of type STRING_T &. If the item
      //	is not contained in virtual data, false will be returned
      //	otherwise true.
      BOOL_T Value (LONG_T &item_value);

      //## Operation: Value%1011276253
      //	This method returns the value of the virtual item
      //	specified by item_name. The value of the virtual item is
      //	returned using an object of type STRING_T &. If the item
      //	is not contained in virtual data, false will be returned
      //	otherwise true.
      BOOL_T Value (ULONG_T &item_value);

      //## Operation: Value%1011276254
      //	This method returns the value of the virtual item
      //	specified by item_name. The value of the virtual item is
      //	returned using an object of type STRING_T &. If the item
      //	is not contained in virtual data, false will be returned
      //	otherwise true.
      BOOL_T Value (DOUBLE_T &item_value);

      //## Operation: SetValue%1011276255
      //	Sets the value of a virtual item specified by item_name.
      //	The value is passed using an object of type CONST_STRING_
      //	T. If the item is not contained in virtual data, false
      //	will be returned otherwise true.
      BOOL_T SetValue (CONST_STRING_T item_value);

      //## Operation: SetValue%1011276256
      //	Sets the value of a virtual item specified by item_name.
      //	The value is passed using an object of type CONST_STRING_
      //	T. If the item is not contained in virtual data, false
      //	will be returned otherwise true.
      BOOL_T SetValue (LONG_T item_value);

      //## Operation: SetValue%1011276257
      //	Sets the value of a virtual item specified by item_name.
      //	The value is passed using an object of type CONST_STRING_
      //	T. If the item is not contained in virtual data, false
      //	will be returned otherwise true.
      BOOL_T SetValue (ULONG_T item_value);

      //## Operation: SetValue%1011276258
      //	Sets the value of a virtual item specified by item_name.
      //	The value is passed using an object of type CONST_STRING_
      //	T. If the item is not contained in virtual data, false
      //	will be returned otherwise true.
      BOOL_T SetValue (DOUBLE_T item_value);

      //## Operation: TypeDef%1011276259
      cTypeDef * TypeDef ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%3C4728560365
      STRING_T get_Name () const;
      void set_Name (STRING_T value);

  public:
    // Additional Public Declarations
      //## begin cValue%3A542EFA03A0.public preserve=yes
      //## end cValue%3A542EFA03A0.public

  protected:
    // Data Members for Class Attributes

      //## begin cValue::Name%3C4728560365.attr preserve=no  public: STRING_T {U} 
      STRING_T _Name;
      //## end cValue::Name%3C4728560365.attr

    // Data Members for Associations

      //## Association: Control::Driver::<unnamed>%3C471A4E007B
      //## Role: cValue::TypeDef%3C471A4E03D9
      //## begin cValue::TypeDef%3C471A4E03D9.role preserve=no  public: cTypeDef { -> 1RFHN}
      cTypeDef *_TypeDef;
      //## end cValue::TypeDef%3C471A4E03D9.role

    // Additional Protected Declarations
      //## begin cValue%3A542EFA03A0.protected preserve=yes
      //## end cValue%3A542EFA03A0.protected

  private:
    // Additional Private Declarations
      //## begin cValue%3A542EFA03A0.private preserve=yes
      //## end cValue%3A542EFA03A0.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: NumericValue%3A54317A020F
      //## begin cValue::NumericValue%3A54317A020F.attr preserve=no  implementation: DOUBLE_T {U} 0
      DOUBLE_T _NumericValue;
      //## end cValue::NumericValue%3A54317A020F.attr

      //## Attribute: StringValue%3A542F4F0012
      //## begin cValue::StringValue%3A542F4F0012.attr preserve=no  implementation: STRING_T {U} 
      STRING_T _StringValue;
      //## end cValue::StringValue%3A542F4F0012.attr

    // Additional Implementation Declarations
      //## begin cValue%3A542EFA03A0.implementation preserve=yes
      //## end cValue%3A542EFA03A0.implementation

};

//## begin cValue%3A542EFA03A0.postscript preserve=yes
//## end cValue%3A542EFA03A0.postscript

// Class cValue 

//## begin module%3A542EFA03A0.epilog preserve=yes
//## end module%3A542EFA03A0.epilog


#endif
