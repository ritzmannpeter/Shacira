//## begin module%3A542EFA03A0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3A542EFA03A0.cm

//## begin module%3A542EFA03A0.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3A542EFA03A0.cp

//## Module: cValue%3A542EFA03A0; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Config\cValue.cpp

//## begin module%3A542EFA03A0.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3A542EFA03A0.additionalIncludes

//## begin module%3A542EFA03A0.includes preserve=yes
//## end module%3A542EFA03A0.includes

// cValue
#include "System/Config/cValue.h"
// cTypeDef
#include "System/Config/cTypeDef.h"
// cConvUtils
#include "System/Sys/cConvUtils.h"
//## begin module%3A542EFA03A0.additionalDeclarations preserve=yes
//## end module%3A542EFA03A0.additionalDeclarations


// Class cValue 





cValue::cValue()
  //## begin cValue::cValue%.hasinit preserve=no
      : _NumericValue(0), _TypeDef(NULL)
  //## end cValue::cValue%.hasinit
  //## begin cValue::cValue%.initialization preserve=yes
  //## end cValue::cValue%.initialization
{
  //## begin cValue::cValue%.body preserve=yes
  //## end cValue::cValue%.body
}

cValue::cValue(const cValue &right)
  //## begin cValue::cValue%copy.hasinit preserve=no
      : _NumericValue(0), _TypeDef(NULL)
  //## end cValue::cValue%copy.hasinit
  //## begin cValue::cValue%copy.initialization preserve=yes
  //## end cValue::cValue%copy.initialization
{
  //## begin cValue::cValue%copy.body preserve=yes
   _TypeDef = right._TypeDef;
   _NumericValue = right._NumericValue;
   _StringValue = right._StringValue;
  //## end cValue::cValue%copy.body
}

cValue::cValue (cTypeDef *type_def)
  //## begin cValue::cValue%978694293.hasinit preserve=no
      : _NumericValue(0), _TypeDef(NULL)
  //## end cValue::cValue%978694293.hasinit
  //## begin cValue::cValue%978694293.initialization preserve=yes
  //## end cValue::cValue%978694293.initialization
{
  //## begin cValue::cValue%978694293.body preserve=yes
   _TypeDef = type_def;
  //## end cValue::cValue%978694293.body
}


cValue::~cValue()
{
  //## begin cValue::~cValue%.body preserve=yes
  //## end cValue::~cValue%.body
}



//## Other Operations (implementation)
BOOL_T cValue::Value (STRING_T &item_value)
{
  //## begin cValue::Value%1011276251.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      item_value = _StringValue.c_str();
      return true;
   } else if (base_type == Numeric) {
      item_value = cConvUtils::StringValue(_NumericValue);
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::Value%1011276251.body
}

BOOL_T cValue::Value (LONG_T &item_value)
{
  //## begin cValue::Value%1011276252.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   } else if (base_type == Numeric) {
      item_value = (long)_NumericValue;
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::Value%1011276252.body
}

BOOL_T cValue::Value (ULONG_T &item_value)
{
  //## begin cValue::Value%1011276253.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   } else if (base_type == Numeric) {
      item_value = (unsigned long)_NumericValue;
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::Value%1011276253.body
}

BOOL_T cValue::Value (DOUBLE_T &item_value)
{
  //## begin cValue::Value%1011276254.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   } else if (base_type == Numeric) {
      item_value = _NumericValue;
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::Value%1011276254.body
}

BOOL_T cValue::SetValue (CONST_STRING_T item_value)
{
  //## begin cValue::SetValue%1011276255.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      _StringValue = item_value;
      return true;
   } else if (base_type == Numeric) {
      _NumericValue = atof(item_value);
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::SetValue%1011276255.body
}

BOOL_T cValue::SetValue (LONG_T item_value)
{
  //## begin cValue::SetValue%1011276256.body preserve=yes
   return SetValue((double)item_value);
  //## end cValue::SetValue%1011276256.body
}

BOOL_T cValue::SetValue (ULONG_T item_value)
{
  //## begin cValue::SetValue%1011276257.body preserve=yes
   return SetValue((double)item_value);
  //## end cValue::SetValue%1011276257.body
}

BOOL_T cValue::SetValue (DOUBLE_T item_value)
{
  //## begin cValue::SetValue%1011276258.body preserve=yes
   if (_TypeDef == NULL) throw cError(VALUE_NO_TYPEDEF, 0, _Name.c_str());
   BaseTypes base_type = _TypeDef->get_BaseType();
   if (base_type == String) {
      _StringValue = cConvUtils::StringValue((double)item_value).c_str();
      return true;
   } else if (base_type == Numeric) {
      _NumericValue = item_value;
      return true;
   } else {
      throw cError(VALUE_INVALID_TYPE, 0, _Name.c_str(), cConvUtils::StringValue(base_type).c_str());
   }
  //## end cValue::SetValue%1011276258.body
}

cTypeDef * cValue::TypeDef ()
{
  //## begin cValue::TypeDef%1011276259.body preserve=yes
   return _TypeDef;
  //## end cValue::TypeDef%1011276259.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cValue::get_Name () const
{
  //## begin cValue::get_Name%3C4728560365.get preserve=no
  return _Name;
  //## end cValue::get_Name%3C4728560365.get
}

void cValue::set_Name (STRING_T value)
{
  //## begin cValue::set_Name%3C4728560365.set preserve=no
  _Name = value;
  //## end cValue::set_Name%3C4728560365.set
}

// Additional Declarations
  //## begin cValue%3A542EFA03A0.declarations preserve=yes
  //## end cValue%3A542EFA03A0.declarations

//## begin module%3A542EFA03A0.epilog preserve=yes
//## end module%3A542EFA03A0.epilog
