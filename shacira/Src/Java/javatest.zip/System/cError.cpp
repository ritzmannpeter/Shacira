//## begin module%39AB9829007C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%39AB9829007C.cm

//## begin module%39AB9829007C.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%39AB9829007C.cp

//## Module: cError%39AB9829007C; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\cError.cpp

//## begin module%39AB9829007C.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%39AB9829007C.additionalIncludes

//## begin module%39AB9829007C.includes preserve=yes
//## end module%39AB9829007C.includes

// cStringUtils
#include "System/cStringUtils.h"
// cError
#include "System/cError.h"
// cConvUtils
#include "System/Sys/cConvUtils.h"
//## begin module%39AB9829007C.additionalDeclarations preserve=yes

#define ERR(symbol,code,text) \
   {symbol,text},
typedef struct {
   int errcode;
   const char * errmsg;
}  ERROR_ENTRY_T;
const ERROR_ENTRY_T _ErrorTable[] =
{
#include "Errors.msg"
};
#define ERROR_COUNT sizeof(_ErrorTable)/sizeof(ERROR_ENTRY_T)
#undef ERR(symbol,code,text)

static const char * ErrorText(long errcode)
{
   for (long i=0; i<ERROR_COUNT; i++) {
      if (_ErrorTable[i].errcode == errcode) return _ErrorTable[i].errmsg;
   }
   return "";
}

//## end module%39AB9829007C.additionalDeclarations


// Class cError 









cError::cError()
  //## begin cError::cError%.hasinit preserve=no
  //## end cError::cError%.hasinit
  //## begin cError::cError%.initialization preserve=yes
  //## end cError::cError%.initialization
{
  //## begin cError::cError%.body preserve=yes
  //## end cError::cError%.body
}

cError::cError(const cError &right)
  //## begin cError::cError%copy.hasinit preserve=no
  //## end cError::cError%copy.hasinit
  //## begin cError::cError%copy.initialization preserve=yes
  //## end cError::cError%copy.initialization
{
  //## begin cError::cError%copy.body preserve=yes
   _ErrCode = right._ErrCode;
   _NativeCode = right._NativeCode;
   _Param1 = right._Param1;
   _Param2 = right._Param2;
   _Param3 = right._Param3;
   _Param4 = right._Param4;
  //## end cError::cError%copy.body
}

cError::cError (INT_T err_code, LONG_T native_code, CONST_STRING_T param1, CONST_STRING_T param2, CONST_STRING_T param3, CONST_STRING_T param4)
  //## begin cError::cError%967547765.hasinit preserve=no
  //## end cError::cError%967547765.hasinit
  //## begin cError::cError%967547765.initialization preserve=yes
  //## end cError::cError%967547765.initialization
{
  //## begin cError::cError%967547765.body preserve=yes
   _ErrCode = err_code;
   _NativeCode = native_code;
   if (param1 != NULL) _Param1 = param1;
   if (param2 != NULL) _Param2 = param2;
   if (param3 != NULL) _Param3 = param3;
   if (param4 != NULL) _Param4 = param4;
  //## end cError::cError%967547765.body
}


cError::~cError()
{
  //## begin cError::~cError%.body preserve=yes
  //## end cError::~cError%.body
}



//## Other Operations (implementation)
cError::operator CONST_STRING_T ()
{
  //## begin cError::operator CONST_STRING_T%989323343.body preserve=yes
   _Text = ErrMsg();
   if (_Text.size() == 0 || strcmp(_Text.c_str(), "?") == 0) {
      char buf[512] = {0};
      sprintf(buf, "Error (%d,%d,%s,%s,%s,%s)", _ErrCode, _NativeCode,
                                                _Param1.c_str(),
                                                _Param2.c_str(),
                                                _Param3.c_str(),
                                                _Param4.c_str());
      _Text = buf;
   }
   return _Text.c_str();
  //## end cError::operator CONST_STRING_T%989323343.body
}

STRING_T cError::ErrMsg ()
{
  //## begin cError::ErrMsg%1014996956.body preserve=yes
   STRING_T msg = ErrorText(_ErrCode);
   msg = SubstParams(msg.c_str());
   _Text = msg.c_str();
   _Text += " (";
   _Text += cConvUtils::StringValue(_ErrCode).c_str();
   _Text += ",";
   _Text += cConvUtils::StringValue(_NativeCode).c_str();
   _Text += ")";
   return _Text.c_str();
  //## end cError::ErrMsg%1014996956.body
}

void cError::PrintErrors (CONST_STRING_T file_name)
{
  //## begin cError::PrintErrors%1043401582.body preserve=yes
   FILE * stream = fopen(file_name, "w");
   if (stream != NULL) {
      ULONG_T count = ERROR_COUNT;
      for (ULONG_T i=0; i<count; i++) {
         fprintf(stream, "%d=%s\n",_ErrorTable[i].errcode, _ErrorTable[i].errmsg);
      }
      fclose(stream);
   }
  //## end cError::PrintErrors%1043401582.body
}

STRING_T cError::SubstParams (CONST_STRING_T text)
{
  //## begin cError::SubstParams%1014996957.body preserve=yes
   STRING_T new_text = text;
   char native_code[32] = {0};
   ltoa(_NativeCode, native_code, 10);
   new_text = cStringUtils::Replace(new_text, "#0", native_code);
   new_text = cStringUtils::Replace(new_text, "#1", _Param1.c_str());
   new_text = cStringUtils::Replace(new_text, "#2", _Param2.c_str());
   new_text = cStringUtils::Replace(new_text, "#3", _Param3.c_str());
   new_text = cStringUtils::Replace(new_text, "#4", _Param4.c_str());
   return new_text;
  //## end cError::SubstParams%1014996957.body
}

//## Get and Set Operations for Class Attributes (implementation)

INT_T cError::get_ErrCode () const
{
  //## begin cError::get_ErrCode%39ABB5A40088.get preserve=no
  return _ErrCode;
  //## end cError::get_ErrCode%39ABB5A40088.get
}

void cError::set_ErrCode (INT_T value)
{
  //## begin cError::set_ErrCode%39ABB5A40088.set preserve=no
  _ErrCode = value;
  //## end cError::set_ErrCode%39ABB5A40088.set
}

LONG_T cError::get_NativeCode () const
{
  //## begin cError::get_NativeCode%3A914EC7003F.get preserve=no
  return _NativeCode;
  //## end cError::get_NativeCode%3A914EC7003F.get
}

void cError::set_NativeCode (LONG_T value)
{
  //## begin cError::set_NativeCode%3A914EC7003F.set preserve=no
  _NativeCode = value;
  //## end cError::set_NativeCode%3A914EC7003F.set
}

ULONG_T cError::get_Params () const
{
  //## begin cError::get_Params%3A922DBF0094.get preserve=no
  return _Params;
  //## end cError::get_Params%3A922DBF0094.get
}

STRING_T cError::get_Param1 () const
{
  //## begin cError::get_Param1%39ABB5DF001F.get preserve=no
  return _Param1;
  //## end cError::get_Param1%39ABB5DF001F.get
}

void cError::set_Param1 (STRING_T value)
{
  //## begin cError::set_Param1%39ABB5DF001F.set preserve=no
  _Param1 = value;
  //## end cError::set_Param1%39ABB5DF001F.set
}

STRING_T cError::get_Param2 () const
{
  //## begin cError::get_Param2%3A914EFE00CA.get preserve=no
  return _Param2;
  //## end cError::get_Param2%3A914EFE00CA.get
}

void cError::set_Param2 (STRING_T value)
{
  //## begin cError::set_Param2%3A914EFE00CA.set preserve=no
  _Param2 = value;
  //## end cError::set_Param2%3A914EFE00CA.set
}

STRING_T cError::get_Param3 () const
{
  //## begin cError::get_Param3%3A914EFF0343.get preserve=no
  return _Param3;
  //## end cError::get_Param3%3A914EFF0343.get
}

void cError::set_Param3 (STRING_T value)
{
  //## begin cError::set_Param3%3A914EFF0343.set preserve=no
  _Param3 = value;
  //## end cError::set_Param3%3A914EFF0343.set
}

STRING_T cError::get_Param4 () const
{
  //## begin cError::get_Param4%3A914F010219.get preserve=no
  return _Param4;
  //## end cError::get_Param4%3A914F010219.get
}

void cError::set_Param4 (STRING_T value)
{
  //## begin cError::set_Param4%3A914F010219.set preserve=no
  _Param4 = value;
  //## end cError::set_Param4%3A914F010219.set
}

// Additional Declarations
  //## begin cError%39AB9829007C.declarations preserve=yes
  //## end cError%39AB9829007C.declarations

//## begin module%39AB9829007C.epilog preserve=yes
//## end module%39AB9829007C.epilog
