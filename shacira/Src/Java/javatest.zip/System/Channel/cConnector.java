//## begin module%3F85177902CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F85177902CE.cm

//## begin module%3F85177902CE.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F85177902CE.cp

//## Module: cConnector%3F85177902CE; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cConnector.cpp

//## begin module%3F85177902CE.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3F85177902CE.additionalIncludes

//## begin module%3F85177902CE.includes preserve=yes
//## end module%3F85177902CE.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"
// cChannel
#include "System/Channel/cChannel.h"
// cConnector
#include "System/Channel/cConnector.h"
//## begin module%3F85177902CE.additionalDeclarations preserve=yes
//## end module%3F85177902CE.additionalDeclarations


// Class cConnector 


cConnector::cConnector()
  //## begin cConnector::cConnector%.hasinit preserve=no
      : _Channel(NULL)
  //## end cConnector::cConnector%.hasinit
  //## begin cConnector::cConnector%.initialization preserve=yes
  //## end cConnector::cConnector%.initialization
{
  //## begin cConnector::cConnector%.body preserve=yes
_ASSERT_UNCOND
  //## end cConnector::cConnector%.body
}

cConnector::cConnector(const cConnector &right)
  //## begin cConnector::cConnector%copy.hasinit preserve=no
      : _Channel(NULL)
  //## end cConnector::cConnector%copy.hasinit
  //## begin cConnector::cConnector%copy.initialization preserve=yes
  //## end cConnector::cConnector%copy.initialization
{
  //## begin cConnector::cConnector%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cConnector::cConnector%copy.body
}

cConnector::cConnector (cChannel *channel)
  //## begin cConnector::cConnector%1065687230.hasinit preserve=no
      : _Channel(NULL)
  //## end cConnector::cConnector%1065687230.hasinit
  //## begin cConnector::cConnector%1065687230.initialization preserve=yes
  //## end cConnector::cConnector%1065687230.initialization
{
  //## begin cConnector::cConnector%1065687230.body preserve=yes
   _Channel = channel;
  //## end cConnector::cConnector%1065687230.body
}


cConnector::~cConnector()
{
  //## begin cConnector::~cConnector%.body preserve=yes
  //## end cConnector::~cConnector%.body
}



//## Other Operations (implementation)
void cConnector::Object (cTransientObject *object)
{
  //## begin cConnector::Object%1065687231.body preserve=yes
printf("sending object to %s\n", _Channel->get_ChannelName().c_str());
   _Channel->Send(object);
  //## end cConnector::Object%1065687231.body
}

// Additional Declarations
  //## begin cConnector%3F85177902CE.declarations preserve=yes
  //## end cConnector%3F85177902CE.declarations

//## begin module%3F85177902CE.epilog preserve=yes
//## end module%3F85177902CE.epilog
