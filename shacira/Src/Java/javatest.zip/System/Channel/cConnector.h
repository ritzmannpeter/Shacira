//## begin module%3F85177902CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F85177902CE.cm

//## begin module%3F85177902CE.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F85177902CE.cp

//## Module: cConnector%3F85177902CE; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cConnector.h

#ifndef cConnector_h
#define cConnector_h 1

//## begin module%3F85177902CE.includes preserve=yes
//## end module%3F85177902CE.includes

// cAdapter
#include "System/Channel/cAdapter.h"

class __DLL_EXPORT__ cTransientObject;
class __DLL_EXPORT__ cChannel;

//## begin module%3F85177902CE.additionalDeclarations preserve=yes
//## end module%3F85177902CE.additionalDeclarations


//## begin cConnector%3F85177902CE.preface preserve=yes
//## end cConnector%3F85177902CE.preface

//## Class: cConnector%3F85177902CE
//## Category: System::Channel%3F82F2E2001F
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3F85195E009C;cTransientObject { -> F}

class __DLL_EXPORT__ cConnector : public cAdapter  //## Inherits: <unnamed>%3F85179D038A
{
  //## begin cConnector%3F85177902CE.initialDeclarations preserve=yes
public:
  //## end cConnector%3F85177902CE.initialDeclarations

    //## Constructors (generated)
      cConnector();

      cConnector(const cConnector &right);

    //## Constructors (specified)
      //## Operation: cConnector%1065687230
      cConnector (cChannel *channel);

    //## Destructor (generated)
      virtual ~cConnector();


    //## Other Operations (specified)
      //## Operation: Object%1065687231
      //	Method that is called when an incoming object arrives at
      //	the back end of the associated channel.
      virtual void Object (cTransientObject *object);

  public:
    // Additional Public Declarations
      //## begin cConnector%3F85177902CE.public preserve=yes
      //## end cConnector%3F85177902CE.public

  protected:
    // Data Members for Associations

      //## Association: System::Channel::<unnamed>%3F85180B0203
      //## Role: cConnector::Channel%3F85180C01E4
      //## begin cConnector::Channel%3F85180C01E4.role preserve=no  public: cChannel { -> 1RFHN}
      cChannel *_Channel;
      //## end cConnector::Channel%3F85180C01E4.role

    // Additional Protected Declarations
      //## begin cConnector%3F85177902CE.protected preserve=yes
      //## end cConnector%3F85177902CE.protected

  private:
    // Additional Private Declarations
      //## begin cConnector%3F85177902CE.private preserve=yes
      //## end cConnector%3F85177902CE.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cConnector%3F85177902CE.implementation preserve=yes
      //## end cConnector%3F85177902CE.implementation

};

//## begin cConnector%3F85177902CE.postscript preserve=yes
//## end cConnector%3F85177902CE.postscript

// Class cConnector 

//## begin module%3F85177902CE.epilog preserve=yes
//## end module%3F85177902CE.epilog


#endif
