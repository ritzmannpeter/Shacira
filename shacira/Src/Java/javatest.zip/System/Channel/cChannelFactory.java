//## begin module%3FBA3CF100DA.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3FBA3CF100DA.cm

//## begin module%3FBA3CF100DA.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3FBA3CF100DA.cp

//## Module: cChannelFactory%3FBA3CF100DA; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cChannelFactory.cpp

//## begin module%3FBA3CF100DA.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3FBA3CF100DA.additionalIncludes

//## begin module%3FBA3CF100DA.includes preserve=yes
//## end module%3FBA3CF100DA.includes

// cSHProcess
#include "System/Process/cSHProcess.h"
// cConfigurationObject
#include "System/Config/cConfigurationObject.h"
// cChannel
#include "System/Channel/cChannel.h"
// cChannelFactory
#include "System/Channel/cChannelFactory.h"
// cRemoteBridge
#include "System/Channel/cRemoteBridge.h"
// cCOSChannel
#include "System/Channel/cCOSChannel.h"
// cLocalChannel
#include "System/Channel/cLocalChannel.h"
//## begin module%3FBA3CF100DA.additionalDeclarations preserve=yes
//## end module%3FBA3CF100DA.additionalDeclarations


// Class cChannelFactory 

cChannelFactory::cChannelFactory()
  //## begin cChannelFactory::cChannelFactory%.hasinit preserve=no
  //## end cChannelFactory::cChannelFactory%.hasinit
  //## begin cChannelFactory::cChannelFactory%.initialization preserve=yes
  //## end cChannelFactory::cChannelFactory%.initialization
{
  //## begin cChannelFactory::cChannelFactory%.body preserve=yes
  //## end cChannelFactory::cChannelFactory%.body
}

cChannelFactory::cChannelFactory(const cChannelFactory &right)
  //## begin cChannelFactory::cChannelFactory%copy.hasinit preserve=no
  //## end cChannelFactory::cChannelFactory%copy.hasinit
  //## begin cChannelFactory::cChannelFactory%copy.initialization preserve=yes
  //## end cChannelFactory::cChannelFactory%copy.initialization
{
  //## begin cChannelFactory::cChannelFactory%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cChannelFactory::cChannelFactory%copy.body
}


cChannelFactory::~cChannelFactory()
{
  //## begin cChannelFactory::~cChannelFactory%.body preserve=yes
  //## end cChannelFactory::~cChannelFactory%.body
}



//## Other Operations (implementation)
cChannel * cChannelFactory::CreateChannel (cConfigurationObject *config_obj, CONST_STRING_T cell_name, cSHProcess *process)
{
  //## begin cChannelFactory::CreateChannel%1069152411.body preserve=yes
_ASSERT_COND(config_obj != NULL)
   STRING_T channel_name;
   if (cell_name != NULL && *cell_name != 0) {
      channel_name += cell_name;
      channel_name += ".";
   }
   channel_name += config_obj->get_Name();
   STRING_T type_name = config_obj->PropertyValue("ChannelType", "", true);
   int type = TypeCode(type_name.c_str());
   cChannel * channel = NULL;
   switch (type) {
   case LOCAL_CHANNEL:
      channel = new cLocalChannel(channel_name.c_str());
      break;
   case REMOTE_BRIDGE:
_ASSERT_COND(process != NULL)
      channel_name = config_obj->PropertyValue("RemoteChannelName", channel_name.c_str());
      channel = new cRemoteBridge(channel_name.c_str(), process);
      break;
   default:
      throw cError(FACTORY_INVALID_VALUE, 0, type_name.c_str(), "cChannel");
   }
   return channel;
  //## end cChannelFactory::CreateChannel%1069152411.body
}

INT_T cChannelFactory::TypeCode (CONST_STRING_T type_name)
{
  //## begin cChannelFactory::TypeCode%1069241192.body preserve=yes
   TYPE_CODE(type_name,LOCAL_CHANNEL)
   TYPE_CODE(type_name,REMOTE_BRIDGE)
   throw cError(FACTORY_INVALID_VALUE, 0, type_name, "cChannelFactory");
  //## end cChannelFactory::TypeCode%1069241192.body
}

CONST_STRING_T cChannelFactory::TypeName (INT_T type_code)
{
  //## begin cChannelFactory::TypeName%1069241193.body preserve=yes
   TYPE_NAME(type_code,LOCAL_CHANNEL)
   TYPE_NAME(type_code,REMOTE_BRIDGE)
   throw cError(FACTORY_INVALID_VALUE, 0, cConvUtils::StringValue(type_code).c_str(), "cChannelFactory");
  //## end cChannelFactory::TypeName%1069241193.body
}

// Additional Declarations
  //## begin cChannelFactory%3FBA3CF100DA.declarations preserve=yes
  //## end cChannelFactory%3FBA3CF100DA.declarations

//## begin module%3FBA3CF100DA.epilog preserve=yes
//## end module%3FBA3CF100DA.epilog
