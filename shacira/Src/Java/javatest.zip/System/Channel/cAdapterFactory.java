//## begin module%3FBA3D9F03A9.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3FBA3D9F03A9.cm

//## begin module%3FBA3D9F03A9.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3FBA3D9F03A9.cp

//## Module: cAdapterFactory%3FBA3D9F03A9; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cAdapterFactory.cpp

//## begin module%3FBA3D9F03A9.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3FBA3D9F03A9.additionalIncludes

//## begin module%3FBA3D9F03A9.includes preserve=yes
//## end module%3FBA3D9F03A9.includes

// cConfigurationObject
#include "System/Config/cConfigurationObject.h"
// cChannel
#include "System/Channel/cChannel.h"
// cAdapterFactory
#include "System/Channel/cAdapterFactory.h"
// cConnector
#include "System/Channel/cConnector.h"
// cAdapter
#include "System/Channel/cAdapter.h"
//## begin module%3FBA3D9F03A9.additionalDeclarations preserve=yes
//## end module%3FBA3D9F03A9.additionalDeclarations


// Class cAdapterFactory 

cAdapterFactory::cAdapterFactory()
  //## begin cAdapterFactory::cAdapterFactory%.hasinit preserve=no
  //## end cAdapterFactory::cAdapterFactory%.hasinit
  //## begin cAdapterFactory::cAdapterFactory%.initialization preserve=yes
  //## end cAdapterFactory::cAdapterFactory%.initialization
{
  //## begin cAdapterFactory::cAdapterFactory%.body preserve=yes
  //## end cAdapterFactory::cAdapterFactory%.body
}

cAdapterFactory::cAdapterFactory(const cAdapterFactory &right)
  //## begin cAdapterFactory::cAdapterFactory%copy.hasinit preserve=no
  //## end cAdapterFactory::cAdapterFactory%copy.hasinit
  //## begin cAdapterFactory::cAdapterFactory%copy.initialization preserve=yes
  //## end cAdapterFactory::cAdapterFactory%copy.initialization
{
  //## begin cAdapterFactory::cAdapterFactory%copy.body preserve=yes
  //## end cAdapterFactory::cAdapterFactory%copy.body
}


cAdapterFactory::~cAdapterFactory()
{
  //## begin cAdapterFactory::~cAdapterFactory%.body preserve=yes
  //## end cAdapterFactory::~cAdapterFactory%.body
}



//## Other Operations (implementation)
cAdapter * cAdapterFactory::CreateAdapter (cConfigurationObject *config_obj, cChannel *front_end)
{
  //## begin cAdapterFactory::CreateAdapter%1069152410.body preserve=yes
_ASSERT_COND(config_obj != NULL)
   STRING_T adapter_name = config_obj->get_Name();
   STRING_T type_name = config_obj->PropertyValue("AdapterType", "", true);
   int type = TypeCode(type_name.c_str());
   cAdapter * adapter = NULL;
   switch (type) {
   case CONNECTOR:
_ASSERT_COND(front_end != NULL)
      adapter = new cConnector(front_end);
      break;
   default:
      throw cError(FACTORY_INVALID_VALUE, 0, type_name.c_str(), "cAdapter");
   }
   return adapter;
  //## end cAdapterFactory::CreateAdapter%1069152410.body
}

INT_T cAdapterFactory::TypeCode (CONST_STRING_T type_name)
{
  //## begin cAdapterFactory::TypeCode%1069241190.body preserve=yes
   TYPE_CODE(type_name,CONNECTOR)
   throw cError(FACTORY_INVALID_VALUE, 0, type_name, "cAdapterFactory");
  //## end cAdapterFactory::TypeCode%1069241190.body
}

CONST_STRING_T cAdapterFactory::TypeName (INT_T type_code)
{
  //## begin cAdapterFactory::TypeName%1069241191.body preserve=yes
   TYPE_NAME(type_code,CONNECTOR)
   throw cError(FACTORY_INVALID_VALUE, 0, cConvUtils::StringValue(type_code).c_str(), "cAdapterFactory");
  //## end cAdapterFactory::TypeName%1069241191.body
}

// Additional Declarations
  //## begin cAdapterFactory%3FBA3D9F03A9.declarations preserve=yes
  //## end cAdapterFactory%3FBA3D9F03A9.declarations

//## begin module%3FBA3D9F03A9.epilog preserve=yes
//## end module%3FBA3D9F03A9.epilog
