//## begin module%3F82FE2F0157.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F82FE2F0157.cm

//## begin module%3F82FE2F0157.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F82FE2F0157.cp

//## Module: cLocalChannel%3F82FE2F0157; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cLocalChannel.cpp

//## begin module%3F82FE2F0157.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3F82FE2F0157.additionalIncludes

//## begin module%3F82FE2F0157.includes preserve=yes
//## end module%3F82FE2F0157.includes

// eb_msg
#include "base/eb_msg.hpp"
// cTransientObject
#include "System/Objects/cTransientObject.h"
// cLocalChannel
#include "System/Channel/cLocalChannel.h"
// cAdapter
#include "System/Channel/cAdapter.h"
//## begin module%3F82FE2F0157.additionalDeclarations preserve=yes

#define CHANNEL_QUEUE_SIZE	10000

typedef struct
{
	INT_T msg_id;
	cTransientObject * object;
}	AsyncMessage;

#define MSG_ID_TERMINATE		-1
#define MSG_ID_OBJECT			1

//## end module%3F82FE2F0157.additionalDeclarations


// Class cLocalChannel 





cLocalChannel::cLocalChannel()
  //## begin cLocalChannel::cLocalChannel%.hasinit preserve=no
      : _MsgBox(NULL)
  //## end cLocalChannel::cLocalChannel%.hasinit
  //## begin cLocalChannel::cLocalChannel%.initialization preserve=yes
  //## end cLocalChannel::cLocalChannel%.initialization
{
  //## begin cLocalChannel::cLocalChannel%.body preserve=yes
   _MsgBox = new cMsgBox(CHANNEL_QUEUE_SIZE, sizeof(AsyncMessage));
  //## end cLocalChannel::cLocalChannel%.body
}

cLocalChannel::cLocalChannel(const cLocalChannel &right)
  //## begin cLocalChannel::cLocalChannel%copy.hasinit preserve=no
      : _MsgBox(NULL)
  //## end cLocalChannel::cLocalChannel%copy.hasinit
  //## begin cLocalChannel::cLocalChannel%copy.initialization preserve=yes
  //## end cLocalChannel::cLocalChannel%copy.initialization
{
  //## begin cLocalChannel::cLocalChannel%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cLocalChannel::cLocalChannel%copy.body
}

cLocalChannel::cLocalChannel (CONST_STRING_T channel_name)
  //## begin cLocalChannel::cLocalChannel%1065547486.hasinit preserve=no
      : _MsgBox(NULL)
  //## end cLocalChannel::cLocalChannel%1065547486.hasinit
  //## begin cLocalChannel::cLocalChannel%1065547486.initialization preserve=yes
  , cChannel(channel_name)
  //## end cLocalChannel::cLocalChannel%1065547486.initialization
{
  //## begin cLocalChannel::cLocalChannel%1065547486.body preserve=yes
   _MsgBox = new cMsgBox(CHANNEL_QUEUE_SIZE, sizeof(AsyncMessage));
   _Name = channel_name;
   _ThreadName = channel_name;
  //## end cLocalChannel::cLocalChannel%1065547486.body
}


cLocalChannel::~cLocalChannel()
{
  //## begin cLocalChannel::~cLocalChannel%.body preserve=yes
   StopListen();
   DELETE_OBJECT(cMsgBox, _MsgBox);
  //## end cLocalChannel::~cLocalChannel%.body
}



//## Other Operations (implementation)
INT_T cLocalChannel::MainFunc (void *extra)
{
  //## begin cLocalChannel::MainFunc%1065547489.body preserve=yes
MAINFUNC_PROLOG(_ThreadName.c_str())
   cMsg msg;
   while (true) {
MAINFUNC_LOOP_PROLOG(_ThreadName.c_str())
      msg = _MsgBox->receive();
      int msg_id = msg.getMsgId();
      if (msg_id == MSG_ID_TERMINATE) {
			break;
      } else if (msg_id == MSG_ID_OBJECT) {
			AsyncMessage * msg_data = (AsyncMessage*)msg.getData();
			cTransientObject * object = msg_data->object;
         if (object == NULL) {
            throw cError(ASYNC_CHANNEL_NULL_OBJECT, 0, _ThreadName.c_str());
			} else if (object->IsInvalid()) {
				throw cError(ASYNC_CHANNEL_INVALID_OBJECT, 0, _ThreadName.c_str());
			} else {
            Emit(object);
printf("releasing object in %s\n", _ChannelName.c_str());
            object->Release();
			}
      } else {
			throw cError(ASYNC_CHANNEL_UNKNOWN_MSG_ID, 0, _ThreadName.c_str(),
				          cConvUtils::StringValue(msg_id).c_str());
      }
MAINFUNC_LOOP_EPILOG
   }
   return 0;
MAINFUNC_EPILOG
  //## end cLocalChannel::MainFunc%1065547489.body
}

void cLocalChannel::Listen ()
{
  //## begin cLocalChannel::Listen%1065703995.body preserve=yes
   cControlThread::StartUp();
  //## end cLocalChannel::Listen%1065703995.body
}

void cLocalChannel::StopListen ()
{
  //## begin cLocalChannel::StopListen%1065629499.body preserve=yes
   AsyncMessage msg_data = {0};
   msg_data.msg_id = MSG_ID_TERMINATE;
   msg_data.object = NULL;
   _MsgBox->send(cMsg(MSG_ID_TERMINATE, sizeof(msg_data), &msg_data));
   cControlThread::ShutDown();
  //## end cLocalChannel::StopListen%1065629499.body
}

void cLocalChannel::Send (cTransientObject *object)
{
  //## begin cLocalChannel::Send%1065547487.body preserve=yes
	object->AddRef();
   AsyncMessage msg_data = {0};
   msg_data.msg_id = MSG_ID_OBJECT;
   msg_data.object = object;
   _MsgBox->send(cMsg(MSG_ID_OBJECT, sizeof(msg_data), &msg_data));
  //## end cLocalChannel::Send%1065547487.body
}

// Additional Declarations
  //## begin cLocalChannel%3F82FE2F0157.declarations preserve=yes
  //## end cLocalChannel%3F82FE2F0157.declarations

//## begin module%3F82FE2F0157.epilog preserve=yes
//## end module%3F82FE2F0157.epilog
