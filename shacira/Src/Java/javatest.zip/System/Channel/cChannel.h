//## begin module%3F82F311037A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F82F311037A.cm

//## begin module%3F82F311037A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F82F311037A.cp

//## Module: cChannel%3F82F311037A; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cChannel.h

#ifndef cChannel_h
#define cChannel_h 1

//## begin module%3F82F311037A.includes preserve=yes
//## end module%3F82F311037A.includes

// cStaticObject
#include "System/Objects/cStaticObject.h"

class __DLL_EXPORT__ cTransientObject;
class __DLL_EXPORT__ cConnector;
class __DLL_EXPORT__ cAdapter;

//## begin module%3F82F311037A.additionalDeclarations preserve=yes

typedef std::map<cAdapter*,cAdapter*> CHANNEL_ADAPTER_MAP_T;

//## end module%3F82F311037A.additionalDeclarations


//## begin cChannel%3F82F311037A.preface preserve=yes
//## end cChannel%3F82F311037A.preface

//## Class: cChannel%3F82F311037A
//	Base class for channels.
//	A channel is a software object that receives transient
//	objects at the front end and transfers the object to the
//	back end of the channel.
//	A channel realizes an async m:n communication between
//	software objects that potentially crosses (but must not)
//	process or network borders.
//## Category: System::Channel%3F82F2E2001F
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3F82F473030D;cAdapter { -> F}
//## Uses: <unnamed>%3F82F5F9033C;cTransientObject { -> F}
//## Uses: <unnamed>%3F8518350251;cConnector { -> F}

class __DLL_EXPORT__ cChannel : public cStaticObject  //## Inherits: <unnamed>%3FBF532C00FA
{
  //## begin cChannel%3F82F311037A.initialDeclarations preserve=yes
public:
  //## end cChannel%3F82F311037A.initialDeclarations

    //## Constructors (generated)
      cChannel();

      cChannel(const cChannel &right);

    //## Constructors (specified)
      //## Operation: cChannel%1065547488
      cChannel (CONST_STRING_T channel_name);

    //## Destructor (generated)
      virtual ~cChannel();


    //## Other Operations (specified)
      //## Operation: Connect%1065547480
      //	Connects an adapter to the back end of the channel
      virtual void Connect (cAdapter *adapter);

      //## Operation: Connect%1065687232
      //	Connects the back end of the channel to the front end of
      //	"front_end"
      void Connect (cChannel *front_end);

      //## Operation: Connect%1065687229
      //	Connects two channels. The back end of "back_end" is
      //	connected to the front end of "front_end".
      void Connect (cChannel *back_end, cChannel *front_end);

      //## Operation: Disconnect%1065547481
      //	Disconnects an adapter from the back end of the channel
      void Disconnect (cAdapter *adapter);

      //## Operation: Listen%1065703996
      //	Enables listening to incoming objects at the back end of
      //	the channel.
      virtual void Listen ();

      //## Operation: StopListen%1065629500
      //	Stop listening to the back end of the channel. Incoming
      //	objects are no more processed.
      virtual void StopListen ();

      //## Operation: Send%1065547482
      //	Method to send an object to (into) the front end of the
      //	channel
      virtual void Send (cTransientObject *object) = 0;

      //## Operation: Object%1065547485
      //	Back end object method of the channel. Is called when an
      //	object arrives at the back end of the channel.
      void Object (cTransientObject *object);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ChannelName%3F82FF6E02DE
      STRING_T get_ChannelName () const;

  public:
    // Additional Public Declarations
      //## begin cChannel%3F82F311037A.public preserve=yes
      //## end cChannel%3F82F311037A.public

  protected:

    //## Other Operations (specified)
      //## Operation: Emit%1069152409
      //	Emit emits an object.
      void Emit (cTransientObject *object);

    // Data Members for Class Attributes

      //## begin cChannel::ChannelName%3F82FF6E02DE.attr preserve=no  public: STRING_T {U} 
      STRING_T _ChannelName;
      //## end cChannel::ChannelName%3F82FF6E02DE.attr

      //## Attribute: Adapters%3F82F5B103D8
      //## begin cChannel::Adapters%3F82F5B103D8.attr preserve=no  protected: CHANNEL_ADAPTER_MAP_T {U} 
      CHANNEL_ADAPTER_MAP_T _Adapters;
      //## end cChannel::Adapters%3F82F5B103D8.attr

      //## Attribute: Listening%3F856409038A
      //## begin cChannel::Listening%3F856409038A.attr preserve=no  protected: BOOL_T {U} false
      BOOL_T _Listening;
      //## end cChannel::Listening%3F856409038A.attr

    // Additional Protected Declarations
      //## begin cChannel%3F82F311037A.protected preserve=yes
      //## end cChannel%3F82F311037A.protected

  private:
    // Additional Private Declarations
      //## begin cChannel%3F82F311037A.private preserve=yes
      //## end cChannel%3F82F311037A.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: Encode%1065547483
      //	Serializes a transient object to a string
      STRING_T Encode (cTransientObject *object);

      //## Operation: Decode%1065547484
      //	Deserializes an object from his string representation
      cTransientObject * Decode (CONST_STRING_T serialzed_object);

    // Additional Implementation Declarations
      //## begin cChannel%3F82F311037A.implementation preserve=yes
      //## end cChannel%3F82F311037A.implementation

};

//## begin cChannel%3F82F311037A.postscript preserve=yes
//## end cChannel%3F82F311037A.postscript

// Class cChannel 

//## begin module%3F82F311037A.epilog preserve=yes
//## end module%3F82F311037A.epilog


#endif
