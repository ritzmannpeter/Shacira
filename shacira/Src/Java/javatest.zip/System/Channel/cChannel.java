//## begin module%3F82F311037A.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F82F311037A.cm

//## begin module%3F82F311037A.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F82F311037A.cp

//## Module: cChannel%3F82F311037A; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cChannel.cpp

//## begin module%3F82F311037A.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3F82F311037A.additionalIncludes

//## begin module%3F82F311037A.includes preserve=yes
//## end module%3F82F311037A.includes

// cTransientObject
#include "System/Objects/cTransientObject.h"
// cConnector
#include "System/Channel/cConnector.h"
// cAdapter
#include "System/Channel/cAdapter.h"
// cChannel
#include "System/Channel/cChannel.h"
//## begin module%3F82F311037A.additionalDeclarations preserve=yes
//## end module%3F82F311037A.additionalDeclarations


// Class cChannel 









cChannel::cChannel()
  //## begin cChannel::cChannel%.hasinit preserve=no
      : _Listening(false)
  //## end cChannel::cChannel%.hasinit
  //## begin cChannel::cChannel%.initialization preserve=yes
  //## end cChannel::cChannel%.initialization
{
  //## begin cChannel::cChannel%.body preserve=yes
_ASSERT_UNCOND
  //## end cChannel::cChannel%.body
}

cChannel::cChannel(const cChannel &right)
  //## begin cChannel::cChannel%copy.hasinit preserve=no
      : _Listening(false)
  //## end cChannel::cChannel%copy.hasinit
  //## begin cChannel::cChannel%copy.initialization preserve=yes
  //## end cChannel::cChannel%copy.initialization
{
  //## begin cChannel::cChannel%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cChannel::cChannel%copy.body
}

cChannel::cChannel (CONST_STRING_T channel_name)
  //## begin cChannel::cChannel%1065547488.hasinit preserve=no
      : _Listening(false)
  //## end cChannel::cChannel%1065547488.hasinit
  //## begin cChannel::cChannel%1065547488.initialization preserve=yes
  //## end cChannel::cChannel%1065547488.initialization
{
  //## begin cChannel::cChannel%1065547488.body preserve=yes
   _ChannelName = channel_name;
  //## end cChannel::cChannel%1065547488.body
}


cChannel::~cChannel()
{
  //## begin cChannel::~cChannel%.body preserve=yes
  //## end cChannel::~cChannel%.body
}



//## Other Operations (implementation)
void cChannel::Connect (cAdapter *adapter)
{
  //## begin cChannel::Connect%1065547480.body preserve=yes
   if (!_Listening) Listen();
   _Adapters[adapter] = adapter;
  //## end cChannel::Connect%1065547480.body
}

void cChannel::Connect (cChannel *front_end)
{
  //## begin cChannel::Connect%1065687232.body preserve=yes
   cConnector * connector = new cConnector(front_end);
   Connect(connector);
  //## end cChannel::Connect%1065687232.body
}

void cChannel::Connect (cChannel *back_end, cChannel *front_end)
{
  //## begin cChannel::Connect%1065687229.body preserve=yes
   cConnector * connector = new cConnector(front_end);
   back_end->Connect(connector);
  //## end cChannel::Connect%1065687229.body
}

void cChannel::Disconnect (cAdapter *adapter)
{
  //## begin cChannel::Disconnect%1065547481.body preserve=yes
   _Adapters.erase(adapter);
  //## end cChannel::Disconnect%1065547481.body
}

void cChannel::Listen ()
{
  //## begin cChannel::Listen%1065703996.body preserve=yes
  //## end cChannel::Listen%1065703996.body
}

void cChannel::StopListen ()
{
  //## begin cChannel::StopListen%1065629500.body preserve=yes
  //## end cChannel::StopListen%1065629500.body
}

void cChannel::Object (cTransientObject *object)
{
  //## begin cChannel::Object%1065547485.body preserve=yes
   CHANNEL_ADAPTER_MAP_T::const_iterator i = _Adapters.begin();
   while (i != _Adapters.end()) {
      cAdapter * adapter = (*i).second;
      adapter->Object(object);
      i++;
   }
  //## end cChannel::Object%1065547485.body
}

void cChannel::Emit (cTransientObject *object)
{
  //## begin cChannel::Emit%1069152409.body preserve=yes
   CHANNEL_ADAPTER_MAP_T::const_iterator i = _Adapters.begin();
   while (i != _Adapters.end()) {
      cAdapter * adapter = (*i).second;
      adapter->Object(object);
      i++;
   }
  //## end cChannel::Emit%1069152409.body
}

STRING_T cChannel::Encode (cTransientObject *object)
{
  //## begin cChannel::Encode%1065547483.body preserve=yes
return "";
  //## end cChannel::Encode%1065547483.body
}

cTransientObject * cChannel::Decode (CONST_STRING_T serialzed_object)
{
  //## begin cChannel::Decode%1065547484.body preserve=yes
return NULL;
  //## end cChannel::Decode%1065547484.body
}

//## Get and Set Operations for Class Attributes (implementation)

STRING_T cChannel::get_ChannelName () const
{
  //## begin cChannel::get_ChannelName%3F82FF6E02DE.get preserve=no
  return _ChannelName;
  //## end cChannel::get_ChannelName%3F82FF6E02DE.get
}

// Additional Declarations
  //## begin cChannel%3F82F311037A.declarations preserve=yes
  //## end cChannel%3F82F311037A.declarations

//## begin module%3F82F311037A.epilog preserve=yes
//## end module%3F82F311037A.epilog
