//## begin module%3AF294560295.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AF294560295.cm

//## begin module%3AF294560295.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3AF294560295.cp

//## Module: cChannelProxy%3AF294560295; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Channel\cChannelProxy.cpp

//## begin module%3AF294560295.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3AF294560295.additionalIncludes

//## begin module%3AF294560295.includes preserve=yes
//## end module%3AF294560295.includes

// cChannel
#include "System/Channel/cChannel.h"
// cChannelProxy
#include "System/Channel/cChannelProxy.h"
//## begin module%3AF294560295.additionalDeclarations preserve=yes
//## end module%3AF294560295.additionalDeclarations


// Class cChannelProxy 



cChannelProxy::cChannelProxy()
  //## begin cChannelProxy::cChannelProxy%.hasinit preserve=no
  //## end cChannelProxy::cChannelProxy%.hasinit
  //## begin cChannelProxy::cChannelProxy%.initialization preserve=yes
  //## end cChannelProxy::cChannelProxy%.initialization
{
  //## begin cChannelProxy::cChannelProxy%.body preserve=yes
  //## end cChannelProxy::cChannelProxy%.body
}

cChannelProxy::cChannelProxy(const cChannelProxy &right)
  //## begin cChannelProxy::cChannelProxy%copy.hasinit preserve=no
  //## end cChannelProxy::cChannelProxy%copy.hasinit
  //## begin cChannelProxy::cChannelProxy%copy.initialization preserve=yes
  //## end cChannelProxy::cChannelProxy%copy.initialization
{
  //## begin cChannelProxy::cChannelProxy%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cChannelProxy::cChannelProxy%copy.body
}


cChannelProxy::~cChannelProxy()
{
  //## begin cChannelProxy::~cChannelProxy%.body preserve=yes
  //## end cChannelProxy::~cChannelProxy%.body
}



//## Other Operations (implementation)
void cChannelProxy::Object (cTransientObject *object)
{
  //## begin cChannelProxy::Object%1054547845.body preserve=yes
   CHANNEL_LIST_T::const_iterator j = _Channels.begin();
   while (j != _Channels.end()) {
      cChannel * channel = (*j);
      channel->Object(object);
      j++;
   }
  //## end cChannelProxy::Object%1054547845.body
}

void cChannelProxy::RegisterChannel (cChannel *channel)
{
  //## begin cChannelProxy::RegisterChannel%1065773702.body preserve=yes
   _Channels.push_back(channel);
  //## end cChannelProxy::RegisterChannel%1065773702.body
}

// Additional Declarations
  //## begin cChannelProxy%3AF294560295.declarations preserve=yes
  //## end cChannelProxy%3AF294560295.declarations

//## begin module%3AF294560295.epilog preserve=yes
//## end module%3AF294560295.epilog
