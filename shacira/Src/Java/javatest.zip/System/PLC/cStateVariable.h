//## begin module%3F39224B03B9.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F39224B03B9.cm

//## begin module%3F39224B03B9.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F39224B03B9.cp

//## Module: cStateVariable%3F39224B03B9; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\PLC\cStateVariable.h

#ifndef cStateVariable_h
#define cStateVariable_h 1

//## begin module%3F39224B03B9.includes preserve=yes
//## end module%3F39224B03B9.includes

// cVariable
#include "System/Database/cVariable.h"

class __DLL_EXPORT__ cControlState;

//## begin module%3F39224B03B9.additionalDeclarations preserve=yes
//## end module%3F39224B03B9.additionalDeclarations


//## begin cStateVariable%3F39224B03B9.preface preserve=yes
//## end cStateVariable%3F39224B03B9.preface

//## Class: cStateVariable%3F39224B03B9
//## Category: System::PLC%3F38BB400109
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class __DLL_EXPORT__ cStateVariable : public cVariable  //## Inherits: <unnamed>%3F392279029F
{
  //## begin cStateVariable%3F39224B03B9.initialDeclarations preserve=yes
public:
  //## end cStateVariable%3F39224B03B9.initialDeclarations

    //## Constructors (generated)
      cStateVariable();

      cStateVariable(const cStateVariable &right);

    //## Constructors (specified)
      //## Operation: cStateVariable%1060709190
      cStateVariable (cVarDef *var_def, cControlState *state);

    //## Destructor (generated)
      virtual ~cStateVariable();


    //## Other Operations (specified)
      //## Operation: GetValue%1060709191
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (CHAR_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709192
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (UCHAR_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709193
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (SHORT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709194
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (USHORT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709195
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (LONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709196
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (ULONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709197
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (FLOAT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709198
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (DOUBLE_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709199
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (UCHAR_T *buf, ULONG_T buf_len, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709200
      //	Retrieves the value of a variable specified by name and
      //	indices into a string.
      virtual void GetValue (STRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: GetValue%1060709201
      //	Retrieves the value of a variable specified by name and
      //	indices into a string.
      virtual void GetValue (WSTRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709202
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (CHAR_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709203
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (UCHAR_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709204
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (SHORT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709205
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (USHORT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709206
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a signed long value.
      virtual void SetValue (LONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709207
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (ULONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709208
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (FLOAT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709209
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (DOUBLE_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709210
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (UCHAR_T *value, ULONG_T len, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709211
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (CHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709212
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (const CHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709213
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (WCHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

      //## Operation: SetValue%1060709214
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (const WCHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0);

  public:
    // Additional Public Declarations
      //## begin cStateVariable%3F39224B03B9.public preserve=yes
      //## end cStateVariable%3F39224B03B9.public

  protected:
    // Data Members for Associations

      //## Association: System::PLC::<unnamed>%3F392513002E
      //## Role: cStateVariable::State%3F392514029F
      //## begin cStateVariable::State%3F392514029F.role preserve=no  public: cControlState { -> 1RFHN}
      cControlState *_State;
      //## end cStateVariable::State%3F392514029F.role

    // Additional Protected Declarations
      //## begin cStateVariable%3F39224B03B9.protected preserve=yes
      //## end cStateVariable%3F39224B03B9.protected

  private:
    // Additional Private Declarations
      //## begin cStateVariable%3F39224B03B9.private preserve=yes
      //## end cStateVariable%3F39224B03B9.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cStateVariable%3F39224B03B9.implementation preserve=yes
      //## end cStateVariable%3F39224B03B9.implementation

};

//## begin cStateVariable%3F39224B03B9.postscript preserve=yes
//## end cStateVariable%3F39224B03B9.postscript

// Class cStateVariable 

//## begin module%3F39224B03B9.epilog preserve=yes
//## end module%3F39224B03B9.epilog


#endif
