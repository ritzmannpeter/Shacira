//## begin module%3F38BC3A0232.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F38BC3A0232.cm

//## begin module%3F38BC3A0232.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F38BC3A0232.cp

//## Module: cControlStartCondition%3F38BC3A0232; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\PLC\cControlStartCondition.cpp

//## begin module%3F38BC3A0232.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3F38BC3A0232.additionalIncludes

//## begin module%3F38BC3A0232.includes preserve=yes
//## end module%3F38BC3A0232.includes

// cContext
#include "System/Database/cContext.h"
// cControlStartCondition
#include "System/PLC/cControlStartCondition.h"
//## begin module%3F38BC3A0232.additionalDeclarations preserve=yes
//## end module%3F38BC3A0232.additionalDeclarations


// Class cControlStartCondition 



cControlStartCondition::cControlStartCondition()
  //## begin cControlStartCondition::cControlStartCondition%.hasinit preserve=no
  //## end cControlStartCondition::cControlStartCondition%.hasinit
  //## begin cControlStartCondition::cControlStartCondition%.initialization preserve=yes
  //## end cControlStartCondition::cControlStartCondition%.initialization
{
  //## begin cControlStartCondition::cControlStartCondition%.body preserve=yes
  //## end cControlStartCondition::cControlStartCondition%.body
}

cControlStartCondition::cControlStartCondition(const cControlStartCondition &right)
  //## begin cControlStartCondition::cControlStartCondition%copy.hasinit preserve=no
  //## end cControlStartCondition::cControlStartCondition%copy.hasinit
  //## begin cControlStartCondition::cControlStartCondition%copy.initialization preserve=yes
  //## end cControlStartCondition::cControlStartCondition%copy.initialization
{
  //## begin cControlStartCondition::cControlStartCondition%copy.body preserve=yes
  //## end cControlStartCondition::cControlStartCondition%copy.body
}


cControlStartCondition::~cControlStartCondition()
{
  //## begin cControlStartCondition::~cControlStartCondition%.body preserve=yes
  //## end cControlStartCondition::~cControlStartCondition%.body
}


// Additional Declarations
  //## begin cControlStartCondition%3F38BC3A0232.declarations preserve=yes
  //## end cControlStartCondition%3F38BC3A0232.declarations

//## begin module%3F38BC3A0232.epilog preserve=yes
//## end module%3F38BC3A0232.epilog
