//## begin module%3F39224B03B9.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F39224B03B9.cm

//## begin module%3F39224B03B9.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3F39224B03B9.cp

//## Module: cStateVariable%3F39224B03B9; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\PLC\cStateVariable.cpp

//## begin module%3F39224B03B9.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3F39224B03B9.additionalIncludes

//## begin module%3F39224B03B9.includes preserve=yes
//## end module%3F39224B03B9.includes

// cStateVariable
#include "System/PLC/cStateVariable.h"
// cControlState
#include "System/PLC/cControlState.h"
//## begin module%3F39224B03B9.additionalDeclarations preserve=yes
//## end module%3F39224B03B9.additionalDeclarations


// Class cStateVariable 


cStateVariable::cStateVariable()
  //## begin cStateVariable::cStateVariable%.hasinit preserve=no
      : _State(NULL)
  //## end cStateVariable::cStateVariable%.hasinit
  //## begin cStateVariable::cStateVariable%.initialization preserve=yes
  //## end cStateVariable::cStateVariable%.initialization
{
  //## begin cStateVariable::cStateVariable%.body preserve=yes
_ASSERT_UNCOND
  //## end cStateVariable::cStateVariable%.body
}

cStateVariable::cStateVariable(const cStateVariable &right)
  //## begin cStateVariable::cStateVariable%copy.hasinit preserve=no
      : _State(NULL)
  //## end cStateVariable::cStateVariable%copy.hasinit
  //## begin cStateVariable::cStateVariable%copy.initialization preserve=yes
  //## end cStateVariable::cStateVariable%copy.initialization
{
  //## begin cStateVariable::cStateVariable%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cStateVariable::cStateVariable%copy.body
}

cStateVariable::cStateVariable (cVarDef *var_def, cControlState *state)
  //## begin cStateVariable::cStateVariable%1060709190.hasinit preserve=no
      : _State(NULL)
  //## end cStateVariable::cStateVariable%1060709190.hasinit
  //## begin cStateVariable::cStateVariable%1060709190.initialization preserve=yes
  , cVariable(var_def)
  //## end cStateVariable::cStateVariable%1060709190.initialization
{
  //## begin cStateVariable::cStateVariable%1060709190.body preserve=yes
   _State = state;
  //## end cStateVariable::cStateVariable%1060709190.body
}


cStateVariable::~cStateVariable()
{
  //## begin cStateVariable::~cStateVariable%.body preserve=yes
  //## end cStateVariable::~cStateVariable%.body
}



//## Other Operations (implementation)
void cStateVariable::GetValue (CHAR_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709191.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709191.body
}

void cStateVariable::GetValue (UCHAR_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709192.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709192.body
}

void cStateVariable::GetValue (SHORT_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709193.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709193.body
}

void cStateVariable::GetValue (USHORT_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709194.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709194.body
}

void cStateVariable::GetValue (LONG_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709195.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709195.body
}

void cStateVariable::GetValue (ULONG_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709196.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709196.body
}

void cStateVariable::GetValue (FLOAT_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709197.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709197.body
}

void cStateVariable::GetValue (DOUBLE_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709198.body preserve=yes
   if (_State->Eval()) {
      value = 1;
   } else {
      value = 0;
   }
  //## end cStateVariable::GetValue%1060709198.body
}

void cStateVariable::GetValue (UCHAR_T *buf, ULONG_T buf_len, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709199.body preserve=yes
  //## end cStateVariable::GetValue%1060709199.body
}

void cStateVariable::GetValue (STRING_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709200.body preserve=yes
   if (_State->Eval()) {
      value = "1";
   } else {
      value = "0";
   }
  //## end cStateVariable::GetValue%1060709200.body
}

void cStateVariable::GetValue (WSTRING_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::GetValue%1060709201.body preserve=yes
  //## end cStateVariable::GetValue%1060709201.body
}

void cStateVariable::SetValue (CHAR_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709202.body preserve=yes
  //## end cStateVariable::SetValue%1060709202.body
}

void cStateVariable::SetValue (UCHAR_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709203.body preserve=yes
  //## end cStateVariable::SetValue%1060709203.body
}

void cStateVariable::SetValue (SHORT_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709204.body preserve=yes
  //## end cStateVariable::SetValue%1060709204.body
}

void cStateVariable::SetValue (USHORT_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709205.body preserve=yes
  //## end cStateVariable::SetValue%1060709205.body
}

void cStateVariable::SetValue (LONG_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709206.body preserve=yes
  //## end cStateVariable::SetValue%1060709206.body
}

void cStateVariable::SetValue (ULONG_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709207.body preserve=yes
  //## end cStateVariable::SetValue%1060709207.body
}

void cStateVariable::SetValue (FLOAT_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709208.body preserve=yes
  //## end cStateVariable::SetValue%1060709208.body
}

void cStateVariable::SetValue (DOUBLE_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709209.body preserve=yes
  //## end cStateVariable::SetValue%1060709209.body
}

void cStateVariable::SetValue (UCHAR_T *value, ULONG_T len, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709210.body preserve=yes
  //## end cStateVariable::SetValue%1060709210.body
}

void cStateVariable::SetValue (CHAR_T *value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709211.body preserve=yes
  //## end cStateVariable::SetValue%1060709211.body
}

void cStateVariable::SetValue (const CHAR_T *value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709212.body preserve=yes
  //## end cStateVariable::SetValue%1060709212.body
}

void cStateVariable::SetValue (WCHAR_T *value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709213.body preserve=yes
  //## end cStateVariable::SetValue%1060709213.body
}

void cStateVariable::SetValue (const WCHAR_T *value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4, ULONG_T flags)
{
  //## begin cStateVariable::SetValue%1060709214.body preserve=yes
  //## end cStateVariable::SetValue%1060709214.body
}

// Additional Declarations
  //## begin cStateVariable%3F39224B03B9.declarations preserve=yes
  //## end cStateVariable%3F39224B03B9.declarations

//## begin module%3F39224B03B9.epilog preserve=yes
//## end module%3F39224B03B9.epilog
