//## begin module%3E0032230357.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E0032230357.cm

//## begin module%3E0032230357.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E0032230357.cp

//## Module: cVarDef%3E0032230357; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cVarDef.cpp

//## begin module%3E0032230357.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E0032230357.additionalIncludes

//## begin module%3E0032230357.includes preserve=yes
//## end module%3E0032230357.includes

// cFuncRef
#include "System/Database/cFuncRef.h"
// cVarDef
#include "System/Database/cVarDef.h"
// cContext
#include "System/Database/cContext.h"
// cVariable
#include "System/Database/cVariable.h"
// cSHVariant
#include "System/Database/cSHVariant.h"
// cMapping
#include "System/Database/cMapping.h"
//## begin module%3E0032230357.additionalDeclarations preserve=yes

#define RELPOS_1(i1)                            (i1)
#define RELPOS_2(i1,d2,i2)                      ((i1 * d2) + i2)
#define RELPOS_3(i1,d2,i2,d3,i3)                ((i1 * (d2*d3)) + RELPOS_2(i2,d3,i3))
#define RELPOS_4(i1,d2,i2,d3,i3,d4,i4)          ((i1 * (d2*d3*d4)) + RELPOS_3(i2,d3,i3,d4,i4))
#define RELPOS_5(i1,d2,i2,d3,i3,d4,i4,d5,i5)    ((i1 * (d2*d3*d4*d5)) + RELPOS_4(i2,d3,i3,d4,i4,d5,i5))

#define GET_INDICES_1(pos,i1,d1)                          {i1=pos;}
#define GET_INDICES_2(pos,i1,i2,d1,d2)                    {i1=(pos/d2)%d1;i2=pos%d2;}
#define GET_INDICES_3(pos,i1,i2,i3,d1,d2,d3)              {i1=(pos/(d2*d3))%d1;i2=(pos/d3)%d2;i3=pos%d3;}
#define GET_INDICES_4(pos,i1,i2,i3,i4,d1,d2,d3,d4)        {i1=(pos/(d2*d3*d4))%d1;i2=(pos/(d3*d4))%d2;i3=(pos/d4)%d3;i4=pos%d4;}
#define GET_INDICES_5(pos,i1,i2,i3,i4,i5,d1,d2,d3,d4,d5)  {i1=(pos/(d2*d3*d4*d5))%d1;i2=(pos/(d3*d4*d5))%d2;i3=(pos/(d4*d5))%d3;i4=(pos/d5)%d4;i5=pos%d5;}

#define POSITION_1(i1)                                (i1)
#define POSITION_2(i1,d2,i2,el_size)                  (RELPOS_2(i1,d2,i2) * el_size)
#define POSITION_3(i1,d2,i2,d3,i3,el_size)            (RELPOS_3(i1,d2,i2,d3,i3) * el_size)
#define POSITION_4(i1,d2,i2,d3,i3,d4,i4,el_size)      (RELPOS_4(i1,d2,i2,d3,i3,d4,i4) * el_size)
#define POSITION_5(i1,d2,i2,d3,i3,d4,i4,d5,i5el_size) (RELPOS_5(i1,d2,i2,d3,i3,d4,i4,d5,i5) * el_size)

//## end module%3E0032230357.additionalDeclarations


// Class cVarDef 




















cVarDef::cVarDef()
  //## begin cVarDef::cVarDef%.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _Precision(0), _VarType(UNDEFINED), _PersistenceType(UNDEFINED), _FileType(UNDEFINED), _RefreshType(UNDEFINED), _RefreshValue(-1), _Variable(NULL), _Context(NULL), _Filter(NULL), _Mapping(NULL)
  //## end cVarDef::cVarDef%.hasinit
  //## begin cVarDef::cVarDef%.initialization preserve=yes
  //## end cVarDef::cVarDef%.initialization
{
  //## begin cVarDef::cVarDef%.body preserve=yes
  //## end cVarDef::cVarDef%.body
}

cVarDef::cVarDef(const cVarDef &right)
  //## begin cVarDef::cVarDef%copy.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _Precision(0), _VarType(UNDEFINED), _PersistenceType(UNDEFINED), _FileType(UNDEFINED), _RefreshType(UNDEFINED), _RefreshValue(-1), _Variable(NULL), _Context(NULL), _Filter(NULL), _Mapping(NULL)
  //## end cVarDef::cVarDef%copy.hasinit
  //## begin cVarDef::cVarDef%copy.initialization preserve=yes
  //## end cVarDef::cVarDef%copy.initialization
{
  //## begin cVarDef::cVarDef%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cVarDef::cVarDef%copy.body
}

cVarDef::cVarDef (CONST_STRING_T var_name, UCHAR_T data_type, ULONG_T length, UCHAR_T precision)
  //## begin cVarDef::cVarDef%1040992373.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _Precision(0), _VarType(UNDEFINED), _PersistenceType(UNDEFINED), _FileType(UNDEFINED), _RefreshType(UNDEFINED), _RefreshValue(-1), _Variable(NULL), _Context(NULL), _Filter(NULL), _Mapping(NULL)
  //## end cVarDef::cVarDef%1040992373.hasinit
  //## begin cVarDef::cVarDef%1040992373.initialization preserve=yes
  //## end cVarDef::cVarDef%1040992373.initialization
{
  //## begin cVarDef::cVarDef%1040992373.body preserve=yes
   _VarName = var_name;
   _DataType = data_type;
   _Length = length;
   _Precision = precision;
  //## end cVarDef::cVarDef%1040992373.body
}


cVarDef::~cVarDef()
{
  //## begin cVarDef::~cVarDef%.body preserve=yes
  //## end cVarDef::~cVarDef%.body
}



//## Other Operations (implementation)
UCHAR_T cVarDef::DataType ()
{
  //## begin cVarDef::DataType%1061805340.body preserve=yes
   return _DataType;
  //## end cVarDef::DataType%1061805340.body
}

ULONG_T cVarDef::GetPos (LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cVarDef::GetPos%1040202763.body preserve=yes
   unsigned element_pos = 0;
   switch (_Dims.size()) {
   case 0: break;
   case 1:
      if (i1 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i1 >= (long)_Dims[0]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      element_pos = RELPOS_1(i1);
      break;
   case 2:
      if (i1 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      if (i1 >= (long)_Dims[0]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 >= (long)_Dims[1]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      element_pos = RELPOS_2(i1,_Dims[1],i2);
      break;
   case 3:
      if (i1 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      if (i3 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i3).c_str(),
                      cConvUtils::StringValue(_Dims[2]-1).c_str());
      }
      if (i1 >= (long)_Dims[0]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 >= (long)_Dims[1]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      if (i3 >= (long)_Dims[2]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i3).c_str(),
                      cConvUtils::StringValue(_Dims[2]-1).c_str());
      }
      element_pos = RELPOS_3(i1,_Dims[1],i2,_Dims[2],i3);
      break;
   case 4:
      if (i1 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      if (i3 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i3).c_str(),
                      cConvUtils::StringValue(_Dims[2]-1).c_str());
      }
      if (i4 < 0) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i4).c_str(),
                      cConvUtils::StringValue(_Dims[3]-1).c_str());
      }
      if (i1 >= (long)_Dims[0]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i1).c_str(),
                      cConvUtils::StringValue(_Dims[0]-1).c_str());
      }
      if (i2 >= (long)_Dims[1]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i2).c_str(),
                      cConvUtils::StringValue(_Dims[1]-1).c_str());
      }
      if (i3 >= (long)_Dims[2]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i3).c_str(),
                      cConvUtils::StringValue(_Dims[2]-1).c_str());
      }
      if (i4 >= (long)_Dims[3]) {
         throw cError(VARIABLE_INVALID_INDEX, 0, _VarName.c_str(),
                      cConvUtils::StringValue(i4).c_str(),
                      cConvUtils::StringValue(_Dims[3]-1).c_str());
      }
      element_pos = RELPOS_4(i1,_Dims[1],i2,_Dims[2],i3,_Dims[3],i4);
      break;
   default: _ASSERT_UNCOND;
   }
   return element_pos;
  //## end cVarDef::GetPos%1040202763.body
}

void cVarDef::GetIndices (ULONG_T pos, LONG_T &i1, LONG_T &i2, LONG_T &i3, LONG_T &i4)
{
  //## begin cVarDef::GetIndices%1040202764.body preserve=yes
   i1 = i2 = i3 = i4 = -1;
   switch (_Dims.size()) {
   case 0: break;
   case 1:
      GET_INDICES_1(pos,i1,_Dims[0])
      break;
   case 2:
      GET_INDICES_2(pos,i1,i2,_Dims[0],_Dims[1])
      break;
   case 3:
      GET_INDICES_3(pos,i1,i2,i3,_Dims[0],_Dims[1],_Dims[2])
      break;
   case 4:
      GET_INDICES_4(pos,i1,i2,i3,i4,_Dims[0],_Dims[1],_Dims[2],_Dims[3])
      break;
   default:
_ASSERT_UNCOND
   }
  //## end cVarDef::GetIndices%1040202764.body
}

void cVarDef::AddDim (ULONG_T pos, ULONG_T dim_size)
{
  //## begin cVarDef::AddDim%1040209222.body preserve=yes
   ULONG_T size = _Dims.size();
   if (pos >= size) _Dims.resize(pos+1);
   _Dims[pos] = dim_size;
  //## end cVarDef::AddDim%1040209222.body
}

void cVarDef::SetFilter (cFuncRef *filter_func)
{
  //## begin cVarDef::SetFilter%1040209223.body preserve=yes
   _Filter = filter_func;
  //## end cVarDef::SetFilter%1040209223.body
}

void cVarDef::SetMapping (cMapping *mapping)
{
  //## begin cVarDef::SetMapping%1040209224.body preserve=yes
   _Mapping = mapping;
  //## end cVarDef::SetMapping%1040209224.body
}

ULONG_T cVarDef::Dims ()
{
  //## begin cVarDef::Dims%1040209225.body preserve=yes
   return _Dims.size();
  //## end cVarDef::Dims%1040209225.body
}

ULONG_T cVarDef::DimSize (ULONG_T pos)
{
  //## begin cVarDef::DimSize%1040209226.body preserve=yes
   ULONG_T size = _Dims.size();
   if (pos >= size) {
      throw cError(VARIABLE_INVALID_DIM, 0, _VarName.c_str(),
                   cConvUtils::StringValue(pos).c_str(),
                   cConvUtils::StringValue(size).c_str());
   }
   return _Dims[pos];
  //## end cVarDef::DimSize%1040209226.body
}

ULONG_T cVarDef::Elements ()
{
  //## begin cVarDef::Elements%1040209227.body preserve=yes
   ULONG_T elements = 1;
   ULONG_T size = _Dims.size();
   for (ULONG_T i=0; i<size; i++) {
      elements = elements * _Dims[i];
   }
   return elements;
  //## end cVarDef::Elements%1040209227.body
}

ULONG_T cVarDef::ElementSize ()
{
  //## begin cVarDef::ElementSize%1042559818.body preserve=yes
   return _Length * cSHVariant::TypeSize(_DataType);
  //## end cVarDef::ElementSize%1042559818.body
}

STRING_T cVarDef::Serialize ()
{
  //## begin cVarDef::Serialize%1049277232.body preserve=yes
	char buf[1024] = {0};
	ULONG_T dim[4] = {0};
	ULONG_T dims = _Dims.size();
	if (dims > 4) dims = 4;
	for (ULONG_T i=0; i<dims; i++) {
		dim[i] = _Dims[i];
	}
	sprintf(buf, "VAR(%s,%d,%d,%d,%d,%d,%d,%d,%d,%d)",
		     _VarName.c_str(),
		     dim[0],dim[1],dim[2],dim[3],
			  _DataType,
			  _Length,
			  _Precision,
			  _VarType,
			  _FileType);
	STRING_T serialized_obj = buf;
	return serialized_obj;
  //## end cVarDef::Serialize%1049277232.body
}

void cVarDef::Construct (CONST_STRING_T serialized_obj)
{
  //## begin cVarDef::Construct%1049277233.body preserve=yes
	char var_name[512] = {0};
	ULONG_T dim[4] = {0};
	int params = 0;
/*
	params = scanf(serialized_obj,
		     "VAR(%[^,],%d,%d,%d,%d,%d,%d,%d,%d,%d)",
		     var_name,
		     &dim[0],&dim[1],&dim[2],&dim[3],
			  &_DataType,
			  &_Length,
			  &_Precision,
			  &_VarType,
			  &_FileType);
*/
	params = sscanf(serialized_obj,
		     "VAR(%[^,],%d,%d,%d,%d,%d,%d,%d,%d,%d)",
		     var_name,
		     &dim[0],&dim[1],&dim[2],&dim[3],
			  &_DataType,
			  &_Length,
			  &_Precision,
			  &_VarType,
			  &_FileType);
	if (params == 10) {
		_VarName = var_name;
		for (ULONG_T i=0; i<4; i++) {
			if (dim[i] == 0) break;
			_Dims.resize(i+1);
			_Dims[i] = dim[i];
		}
	}
  //## end cVarDef::Construct%1049277233.body
}

// Additional Declarations
  //## begin cVarDef%3E0032230357.declarations preserve=yes
  //## end cVarDef%3E0032230357.declarations

//## begin module%3E0032230357.epilog preserve=yes
//## end module%3E0032230357.epilog
