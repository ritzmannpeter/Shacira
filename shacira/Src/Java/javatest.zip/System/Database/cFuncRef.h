//## begin module%3C7E428400AB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C7E428400AB.cm

//## begin module%3C7E428400AB.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C7E428400AB.cp

//## Module: cFuncRef%3C7E428400AB; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cFuncRef.h

#ifndef cFuncRef_h
#define cFuncRef_h 1

//## begin module%3C7E428400AB.includes preserve=yes
//## end module%3C7E428400AB.includes

// cArgument
#include "System/Database/cArgument.h"

class __DLL_EXPORT__ cBlockBuffer;
class __DLL_EXPORT__ cFuncDecl;
class __DLL_EXPORT__ cContext;
class __DLL_EXPORT__ cSHVariant;

//## begin module%3C7E428400AB.additionalDeclarations preserve=yes
//## end module%3C7E428400AB.additionalDeclarations


//## begin cFuncRef%3C7E428400AB.preface preserve=yes
//## end cFuncRef%3C7E428400AB.preface

//## Class: cFuncRef%3C7E428400AB
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E073B3701E3;cArgument { -> }
//## Uses: <unnamed>%3E9EAA8803C8;cBlockBuffer { -> F}
//## Uses: <unnamed>%3EF4523B0128;cSHVariant { -> F}

class __DLL_EXPORT__ cFuncRef 
{
  //## begin cFuncRef%3C7E428400AB.initialDeclarations preserve=yes
public:
  //## end cFuncRef%3C7E428400AB.initialDeclarations

    //## Constructors (generated)
      cFuncRef();

      cFuncRef(const cFuncRef &right);

    //## Constructors (specified)
      //## Operation: cFuncRef%1040202772
      cFuncRef (cFuncDecl *func_decl, cContext *context);

    //## Destructor (generated)
      virtual ~cFuncRef();


    //## Other Operations (specified)
      //## Operation: FuncDecl%1061797998
      cFuncDecl * FuncDecl ();

      //## Operation: DataType%1061798000
      UCHAR_T DataType ();

      //## Operation: SetParam%1040202773
      void SetParam (ULONG_T pos, cArgument *param);

      //## Operation: Params%1040202774
      ULONG_T Params ();

      //## Operation: GetValue%1040202778
      //	Retrieves the value of a function specified by name and
      //	args into a string.
      virtual void GetValue (STRING_T &value, CONST_STRING_T input = NULL);

      //## Operation: GetValue%1040202779
      //	Retrieves the value of a function specified by name and
      //	args into a long.
      virtual void GetValue (LONG_T &value, CONST_STRING_T input = NULL);

      //## Operation: GetValue%1040202780
      //	Retrieves the value of a function specified by name and
      //	args into a double.
      virtual void GetValue (DOUBLE_T &value, CONST_STRING_T input = NULL);

    // Data Members for Class Attributes

      //## Attribute: Name%3E00465B016F
      //## begin cFuncRef::Name%3E00465B016F.attr preserve=no  public: STRING_T {U} 
      STRING_T _Name;
      //## end cFuncRef::Name%3E00465B016F.attr

    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E2595A4032B
      //## Role: cFuncRef::Context%3E2595A502DC
      //## begin cFuncRef::Context%3E2595A502DC.role preserve=no  public: cContext { -> 1RFHN}
      cContext *_Context;
      //## end cFuncRef::Context%3E2595A502DC.role

  public:
    // Additional Public Declarations
      //## begin cFuncRef%3C7E428400AB.public preserve=yes
      //## end cFuncRef%3C7E428400AB.public

  protected:
    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E9D8D4E0399
      //## Role: cFuncRef::FuncDecl%3E9D8D4F031C
      //## begin cFuncRef::FuncDecl%3E9D8D4F031C.role preserve=no  public: cFuncDecl { -> 1RFHN}
      cFuncDecl *_FuncDecl;
      //## end cFuncRef::FuncDecl%3E9D8D4F031C.role

    // Additional Protected Declarations
      //## begin cFuncRef%3C7E428400AB.protected preserve=yes
      //## end cFuncRef%3C7E428400AB.protected

  private:
    // Additional Private Declarations
      //## begin cFuncRef%3C7E428400AB.private preserve=yes
      //## end cFuncRef%3C7E428400AB.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: CallVoidFunc%1050565120
      void CallVoidFunc (CONST_STRING_T input);

      //## Operation: CallLongFunc%1050565121
      LONG_T CallLongFunc (CONST_STRING_T input);

      //## Operation: CallFloatFunc%1050565122
      FLOAT_T CallFloatFunc (CONST_STRING_T input);

      //## Operation: CallDoubleFunc%1050565123
      DOUBLE_T CallDoubleFunc (CONST_STRING_T input);

      //## Operation: CallStringFunc%1050565124
      STRING_T CallStringFunc (CONST_STRING_T input);

      //## Operation: CallWStringFunc%1050565125
      WSTRING_T CallWStringFunc (CONST_STRING_T input);

    // Data Members for Class Attributes

      //## Attribute: ParamVec%3E0046A202BC
      //## begin cFuncRef::ParamVec%3E0046A202BC.attr preserve=no  implementation: ARG_VECTOR_T {U} 
      ARG_VECTOR_T _ParamVec;
      //## end cFuncRef::ParamVec%3E0046A202BC.attr

    // Additional Implementation Declarations
      //## begin cFuncRef%3C7E428400AB.implementation preserve=yes
      //## end cFuncRef%3C7E428400AB.implementation

};

//## begin cFuncRef%3C7E428400AB.postscript preserve=yes
//## end cFuncRef%3C7E428400AB.postscript

// Class cFuncRef 

//## begin module%3C7E428400AB.epilog preserve=yes
//## end module%3C7E428400AB.epilog


#endif
