
#include "FirstHeader.h"
#include "System/Database/FuncSpecs.h"
#include "System/Database/cContext.h"
#include "System/Database/cVarRef.h"
#include "System/cTokenizer.h"
#include "Language/cStyxParser.h"

#ifdef __cplusplus
extern "C" {
#endif

LONG_T TestFunc(cContext * context, LONG_T p)
{
   cStyxParser parser;
   parser.ParseDatabaseFromFile(context, "Ventilus.mdl");
   cVarRef * var_ref = parser.VarRef(context, "S001IATS");
   if (var_ref != NULL) {
      STRING_T value;
      DOUBLE_T dval = 55;
      var_ref->SetValue(dval);
      var_ref->GetValue(value);
   }
   STRING_T name = "is bins; nun mal";
   cTokenizer t(name.c_str(), name.size());
   CONST_STRING_T token = NULL;
   while ((token = t.GetToken(";")) != NULL) {
      printf("token %s\n", token);
   }
   return 0;
}

LONG_T fact(cContext * context, LONG_T p)
{
   if (p == 0) {
      return 0;
   } else if (p == 1) {
      return 1;
   } else {
      return p + fact(context, p-1);
   }
}

FUNC_T __DLL_EXPORT__ GetClientFuncAddr(CONST_STRING_T func_name)
{
   if (strcmp(func_name, "fact") == 0) {
      return (FUNC_T)fact;
   } else if (strcmp(func_name, "TestFunc") == 0) {
      return (FUNC_T)TestFunc;
   } else {
      return NULL;
   }
}

#ifdef __cplusplus
}
#endif
