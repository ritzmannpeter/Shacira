//## begin module%3E00548802D6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E00548802D6.cm

//## begin module%3E00548802D6.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E00548802D6.cp

//## Module: cMapping%3E00548802D6; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cMapping.cpp

//## begin module%3E00548802D6.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E00548802D6.additionalIncludes

//## begin module%3E00548802D6.includes preserve=yes
//## end module%3E00548802D6.includes

// cFuncRef
#include "System/Database/cFuncRef.h"
// cMapping
#include "System/Database/cMapping.h"
//## begin module%3E00548802D6.additionalDeclarations preserve=yes
//## end module%3E00548802D6.additionalDeclarations


// Class cMapping 







cMapping::cMapping()
  //## begin cMapping::cMapping%.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _ConvFunc(NULL)
  //## end cMapping::cMapping%.hasinit
  //## begin cMapping::cMapping%.initialization preserve=yes
  //## end cMapping::cMapping%.initialization
{
  //## begin cMapping::cMapping%.body preserve=yes
  //## end cMapping::cMapping%.body
}

cMapping::cMapping(const cMapping &right)
  //## begin cMapping::cMapping%copy.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _ConvFunc(NULL)
  //## end cMapping::cMapping%copy.hasinit
  //## begin cMapping::cMapping%copy.initialization preserve=yes
  //## end cMapping::cMapping%copy.initialization
{
  //## begin cMapping::cMapping%copy.body preserve=yes
  //## end cMapping::cMapping%copy.body
}


cMapping::~cMapping()
{
  //## begin cMapping::~cMapping%.body preserve=yes
  //## end cMapping::~cMapping%.body
}



//## Other Operations (implementation)
void cMapping::SetConvFunc (cFuncRef *conv_func)
{
  //## begin cMapping::SetConvFunc%1041236870.body preserve=yes
   _ConvFunc = conv_func;
  //## end cMapping::SetConvFunc%1041236870.body
}

void cMapping::SetItem (ULONG_T pos, cMapItem *item)
{
  //## begin cMapping::SetItem%1041236877.body preserve=yes
   if (pos >= _ItemVec.size()) _ItemVec.resize(pos+1);
   _ItemVec[pos] = item;
  //## end cMapping::SetItem%1041236877.body
}

cMapItem * cMapping::MapItem (ULONG_T pos)
{
  //## begin cMapping::MapItem%1042459999.body preserve=yes
   if (pos >= _ItemVec.size()) {
_ASSERT_UNCOND
   }
   return _ItemVec[pos];
  //## end cMapping::MapItem%1042459999.body
}

// Additional Declarations
  //## begin cMapping%3E00548802D6.declarations preserve=yes
  //## end cMapping%3E00548802D6.declarations

//## begin module%3E00548802D6.epilog preserve=yes
//## end module%3E00548802D6.epilog
