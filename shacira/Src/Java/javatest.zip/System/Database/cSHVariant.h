//## begin module%3EF2E1D8008C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EF2E1D8008C.cm

//## begin module%3EF2E1D8008C.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3EF2E1D8008C.cp

//## Module: cSHVariant%3EF2E1D8008C; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cSHVariant.h

#ifndef cSHVariant_h
#define cSHVariant_h 1

//## begin module%3EF2E1D8008C.includes preserve=yes
//## end module%3EF2E1D8008C.includes

//## begin module%3EF2E1D8008C.additionalDeclarations preserve=yes
//## end module%3EF2E1D8008C.additionalDeclarations


//## begin cSHVariant%3EF2E1D8008C.preface preserve=yes
//## end cSHVariant%3EF2E1D8008C.preface

//## Class: cSHVariant%3EF2E1D8008C
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class __DLL_EXPORT__ cSHVariant 
{
  //## begin cSHVariant%3EF2E1D8008C.initialDeclarations preserve=yes
public:
  //## end cSHVariant%3EF2E1D8008C.initialDeclarations

    //## Constructors (generated)
      cSHVariant();

      cSHVariant(const cSHVariant &right);

    //## Destructor (generated)
      virtual ~cSHVariant();


    //## Other Operations (specified)
      //## Operation: Set%1056115080
      void Set (CHAR_T value);

      //## Operation: Set%1056115081
      void Set (UCHAR_T value);

      //## Operation: Set%1056115083
      void Set (SHORT_T value);

      //## Operation: Set%1056115084
      void Set (USHORT_T value);

      //## Operation: Set%1056115086
      void Set (LONG_T value);

      //## Operation: Set%1056115087
      void Set (ULONG_T value);

      //## Operation: Set%1056115088
      void Set (FLOAT_T value);

      //## Operation: Set%1056115089
      void Set (DOUBLE_T value);

      //## Operation: Set%1056375591
      void Set (UCHAR_T *value, ULONG_T length);

      //## Operation: Set%1056115082
      void Set (CHAR_T *value, CHAR_T data_type = SH_STRING);

      //## Operation: Set%1056375590
      void Set (const CHAR_T *value, CHAR_T data_type = SH_SYM_STRING);

      //## Operation: Set%1056375589
      void Set (WCHAR_T *value, CHAR_T data_type = SH_WSTRING);

      //## Operation: Set%1056115085
      void Set (const WCHAR_T *value, CHAR_T data_type = SH_SYM_WSTRING);

      //## Operation: Get_CHAR%1056195543
      CHAR_T Get_CHAR ();

      //## Operation: Get_UCHAR%1056195544
      UCHAR_T Get_UCHAR ();

      //## Operation: Get_SHORT%1056195545
      SHORT_T Get_SHORT ();

      //## Operation: Get_USHORT%1056195546
      USHORT_T Get_USHORT ();

      //## Operation: Get_LONG%1056195547
      LONG_T Get_LONG ();

      //## Operation: Get_ULONG%1056195548
      ULONG_T Get_ULONG ();

      //## Operation: Get_FLOAT%1056195549
      FLOAT_T Get_FLOAT ();

      //## Operation: Get_DOUBLE%1056195550
      DOUBLE_T Get_DOUBLE ();

      //## Operation: Get%1056375602
      void Get (const UCHAR_T *buf, ULONG_T buf_len);

      //## Operation: Get%1056195553
      void Get (STRING_T &value, CHAR_T radix = 10);

      //## Operation: Get%1056195554
      void Get (WSTRING_T &value, CHAR_T radix = 10);

      //## Operation: Get%1056375601
      void Get (const CHAR_T *buf, ULONG_T buf_len);

      //## Operation: Get%1056375603
      void Get (const WCHAR_T *buf, ULONG_T buf_len);

      //## Operation: TypeName%1056195555
      static STRING_T TypeName (UCHAR_T data_type);

      //## Operation: String2Wide%1056375604
      static WSTRING_T String2Wide (CONST_STRING_T str);

      //## Operation: Wide2String%1056195556
      static STRING_T Wide2String (CONST_WSTRING_T str);

      //## Operation: Real2Double%1056195557
      static DOUBLE_T Real2Double (CONST_STRING_T str);

      //## Operation: Real2Double%1056375592
      static DOUBLE_T Real2Double (CONST_WSTRING_T str);

      //## Operation: Real2Float%1056375594
      static FLOAT_T Real2Float (CONST_STRING_T str);

      //## Operation: Real2Float%1056375593
      static FLOAT_T Real2Float (CONST_WSTRING_T str);

      //## Operation: Hex2Ulong%1056375595
      static ULONG_T Hex2Ulong (CONST_STRING_T str);

      //## Operation: Hex2Ulong%1056375596
      static ULONG_T Hex2Ulong (CONST_WSTRING_T str);

      //## Operation: Dec2Long%1056375599
      static LONG_T Dec2Long (CONST_STRING_T str);

      //## Operation: Dec2Long%1056375600
      static LONG_T Dec2Long (CONST_WSTRING_T str);

      //## Operation: BCD2Long%1056375605
      static LONG_T BCD2Long (CONST_STRING_T str);

      //## Operation: BCD2Long%1056375606
      static LONG_T BCD2Long (CONST_WSTRING_T str);

      //## Operation: KMBCD2Long%1056375607
      static LONG_T KMBCD2Long (CONST_STRING_T str);

      //## Operation: KMBCD2Long%1056375608
      static LONG_T KMBCD2Long (CONST_WSTRING_T str);

      //## Operation: Long2String%1056447736
      static void Long2String (STRING_T &str, LONG_T value, UCHAR_T radix = 10);

      //## Operation: Long2String%1056447737
      static void Long2String (WSTRING_T &str, LONG_T value, UCHAR_T radix = 10);

      //## Operation: Float2String%1056447738
      static void Float2String (STRING_T &str, FLOAT_T value, UCHAR_T precision = 0);

      //## Operation: Float2String%1056447739
      static void Float2String (WSTRING_T &str, FLOAT_T value, UCHAR_T precision = 0);

      //## Operation: Double2String%1056447740
      static void Double2String (STRING_T &str, DOUBLE_T value, UCHAR_T precision = 0);

      //## Operation: Double2String%1056447741
      static void Double2String (WSTRING_T &str, DOUBLE_T value, UCHAR_T precision = 0);

      //## Operation: StrLen%1056195558
      static ULONG_T StrLen (CONST_STRING_T str);

      //## Operation: StrLen%1056195559
      static ULONG_T StrLen (CONST_WSTRING_T str);

      //## Operation: StrCmp%1056621170
      static INT_T StrCmp (CONST_STRING_T str1, CONST_STRING_T str2);

      //## Operation: StrCmp%1056621171
      static INT_T StrCmp (CONST_WSTRING_T str1, CONST_WSTRING_T str2);

      //## Operation: MemSize%1056478821
      static ULONG_T MemSize (CONST_STRING_T str);

      //## Operation: MemSize%1056478822
      static ULONG_T MemSize (CONST_WSTRING_T str);

      //## Operation: TypeSize%1056478823
      static ULONG_T TypeSize (UCHAR_T data_type);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DataType%3EF32B4F032C
      UCHAR_T get_DataType () const;
      void set_DataType (UCHAR_T value);

  public:
    // Additional Public Declarations
      //## begin cSHVariant%3EF2E1D8008C.public preserve=yes
      //## end cSHVariant%3EF2E1D8008C.public

  protected:
    // Data Members for Class Attributes

      //## begin cSHVariant::DataType%3EF32B4F032C.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _DataType;
      //## end cSHVariant::DataType%3EF32B4F032C.attr

    // Additional Protected Declarations
      //## begin cSHVariant%3EF2E1D8008C.protected preserve=yes
      //## end cSHVariant%3EF2E1D8008C.protected

  private:
    // Additional Private Declarations
      //## begin cSHVariant%3EF2E1D8008C.private preserve=yes
      //## end cSHVariant%3EF2E1D8008C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Length%3EF32BF6032C
      //## begin cSHVariant::Length%3EF32BF6032C.attr preserve=no  implementation: ULONG_T {U} 0
      ULONG_T _Length;
      //## end cSHVariant::Length%3EF32BF6032C.attr

      //## Attribute: Radix%3EF724680251
      //## begin cSHVariant::Radix%3EF724680251.attr preserve=no  implementation: UCHAR_T {U} 10
      UCHAR_T _Radix;
      //## end cSHVariant::Radix%3EF724680251.attr

      //## Attribute: CHAR_Value%3EF32C860000
      //## begin cSHVariant::CHAR_Value%3EF32C860000.attr preserve=no  implementation: CHAR_T {U} 0
      CHAR_T _CHAR_Value;
      //## end cSHVariant::CHAR_Value%3EF32C860000.attr

      //## Attribute: UCHAR_Value%3EF32CAD0251
      //## begin cSHVariant::UCHAR_Value%3EF32CAD0251.attr preserve=no  implementation: UCHAR_T {U} 0
      UCHAR_T _UCHAR_Value;
      //## end cSHVariant::UCHAR_Value%3EF32CAD0251.attr

      //## Attribute: SHORT_Value%3EF32CCE01D4
      //## begin cSHVariant::SHORT_Value%3EF32CCE01D4.attr preserve=no  implementation: USHORT_T {U} 0
      USHORT_T _SHORT_Value;
      //## end cSHVariant::SHORT_Value%3EF32CCE01D4.attr

      //## Attribute: USHORT_Value%3EF32CCE01D5
      //## begin cSHVariant::USHORT_Value%3EF32CCE01D5.attr preserve=no  implementation: USHORT_T {U} 0
      USHORT_T _USHORT_Value;
      //## end cSHVariant::USHORT_Value%3EF32CCE01D5.attr

      //## Attribute: LONG_Value%3EF32CDE033C
      //## begin cSHVariant::LONG_Value%3EF32CDE033C.attr preserve=no  implementation: LONG_T {U} 0
      LONG_T _LONG_Value;
      //## end cSHVariant::LONG_Value%3EF32CDE033C.attr

      //## Attribute: ULONG_Value%3EF32CDE034B
      //## begin cSHVariant::ULONG_Value%3EF32CDE034B.attr preserve=no  implementation: ULONG_T {U} 0
      ULONG_T _ULONG_Value;
      //## end cSHVariant::ULONG_Value%3EF32CDE034B.attr

      //## Attribute: FLOAT_Value%3EF32D1C0251
      //## begin cSHVariant::FLOAT_Value%3EF32D1C0251.attr preserve=no  implementation: FLOAT_T {U} 0
      FLOAT_T _FLOAT_Value;
      //## end cSHVariant::FLOAT_Value%3EF32D1C0251.attr

      //## Attribute: DOUBLE_Value%3EF32D1C0252
      //## begin cSHVariant::DOUBLE_Value%3EF32D1C0252.attr preserve=no  implementation: DOUBLE_T {U} 0
      DOUBLE_T _DOUBLE_Value;
      //## end cSHVariant::DOUBLE_Value%3EF32D1C0252.attr

      //## Attribute: STRING_PtrValue%3EF32D440280
      //## begin cSHVariant::STRING_PtrValue%3EF32D440280.attr preserve=no  implementation: CHAR_T * {U} NULL
      CHAR_T *_STRING_PtrValue;
      //## end cSHVariant::STRING_PtrValue%3EF32D440280.attr

      //## Attribute: WSTRING_PtrValue%3EF32D440290
      //## begin cSHVariant::WSTRING_PtrValue%3EF32D440290.attr preserve=no  implementation: WCHAR_T * {U} NULL
      WCHAR_T *_WSTRING_PtrValue;
      //## end cSHVariant::WSTRING_PtrValue%3EF32D440290.attr

      //## Attribute: BYTE_PtrValue%3EF442E70177
      //## begin cSHVariant::BYTE_PtrValue%3EF442E70177.attr preserve=no  implementation: UCHAR_T * {U} NULL
      UCHAR_T *_BYTE_PtrValue;
      //## end cSHVariant::BYTE_PtrValue%3EF442E70177.attr

      //## Attribute: STRING_Value%3EF4434B0119
      //## begin cSHVariant::STRING_Value%3EF4434B0119.attr preserve=no  implementation: STRING_T {U} 
      STRING_T _STRING_Value;
      //## end cSHVariant::STRING_Value%3EF4434B0119.attr

      //## Attribute: WSTRING_Value%3EF4438403B9
      //## begin cSHVariant::WSTRING_Value%3EF4438403B9.attr preserve=no  implementation: WSTRING_T {U} 
      WSTRING_T _WSTRING_Value;
      //## end cSHVariant::WSTRING_Value%3EF4438403B9.attr

    // Additional Implementation Declarations
      //## begin cSHVariant%3EF2E1D8008C.implementation preserve=yes
      //## end cSHVariant%3EF2E1D8008C.implementation

};

//## begin cSHVariant%3EF2E1D8008C.postscript preserve=yes
//## end cSHVariant%3EF2E1D8008C.postscript

// Class cSHVariant 

//## begin module%3EF2E1D8008C.epilog preserve=yes
//## end module%3EF2E1D8008C.epilog


#endif
