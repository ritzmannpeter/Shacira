//## begin module%3C6A7BFD0121.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6A7BFD0121.cm

//## begin module%3C6A7BFD0121.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C6A7BFD0121.cp

//## Module: cVariable%3C6A7BFD0121; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cVariable.h

#ifndef cVariable_h
#define cVariable_h 1

//## begin module%3C6A7BFD0121.includes preserve=yes
//## end module%3C6A7BFD0121.includes

// cLocalContext
#include "Control/LocalDatabase/cLocalContext.h"

class __DLL_EXPORT__ cDataChange;
class __DLL_EXPORT__ cVarDef;
class __DLL_EXPORT__ cContext;

//## begin module%3C6A7BFD0121.additionalDeclarations preserve=yes
//## end module%3C6A7BFD0121.additionalDeclarations


//## begin cVariable%3C6A7BFD0121.preface preserve=yes
//## end cVariable%3C6A7BFD0121.preface

//## Class: cVariable%3C6A7BFD0121
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3CFE3367010A;cDataChange { -> F}
//## Uses: <unnamed>%3E0749D903D4;cContext { -> F}
//## Uses: <unnamed>%3EDDE1FD029F;cLocalContext { -> }

class __DLL_EXPORT__ cVariable 
{
  //## begin cVariable%3C6A7BFD0121.initialDeclarations preserve=yes
public:
  //## end cVariable%3C6A7BFD0121.initialDeclarations

    //## Constructors (generated)
      cVariable();

      cVariable(const cVariable &right);

    //## Constructors (specified)
      //## Operation: cVariable%1015079155
      cVariable (cVarDef *var_def);

    //## Destructor (generated)
      virtual ~cVariable();


    //## Other Operations (specified)
      //## Operation: GetValue%1056550355
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (CHAR_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550356
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (UCHAR_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550357
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (SHORT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550358
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (USHORT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1015505622
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (LONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550359
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      virtual void GetValue (ULONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1015505624
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (FLOAT_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550360
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (DOUBLE_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550361
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      virtual void GetValue (UCHAR_T *buf, ULONG_T buf_len, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1013778191
      //	Retrieves the value of a variable specified by name and
      //	indices into a string.
      virtual void GetValue (STRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: GetValue%1056550351
      //	Retrieves the value of a variable specified by name and
      //	indices into a string.
      virtual void GetValue (WSTRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550362
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (CHAR_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550363
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (UCHAR_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550364
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (SHORT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550365
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (USHORT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1015505623
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a signed long value.
      virtual void SetValue (LONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1015505625
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      virtual void SetValue (ULONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1013778192
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (FLOAT_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550352
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (DOUBLE_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550366
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (UCHAR_T *value, ULONG_T len, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550354
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (CHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550353
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (const CHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550367
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (WCHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

      //## Operation: SetValue%1056550368
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      virtual void SetValue (const WCHAR_T *value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1, ULONG_T flags = 0) = 0;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: VarId%3D085CD7007A
      LONG_T get_VarId () const;
      void set_VarId (LONG_T value);

    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E0032500226
      //## Role: cVariable::VarDef%3E003251008D
      //## begin cVariable::VarDef%3E003251008D.role preserve=no  public: cVarDef {1 -> 1RFHN}
      cVarDef *_VarDef;
      //## end cVariable::VarDef%3E003251008D.role

  public:
    // Additional Public Declarations
      //## begin cVariable%3C6A7BFD0121.public preserve=yes
      //## end cVariable%3C6A7BFD0121.public

  protected:
    // Data Members for Class Attributes

      //## begin cVariable::VarId%3D085CD7007A.attr preserve=no  public: LONG_T {U} -1
      LONG_T _VarId;
      //## end cVariable::VarId%3D085CD7007A.attr

    // Additional Protected Declarations
      //## begin cVariable%3C6A7BFD0121.protected preserve=yes
      //## end cVariable%3C6A7BFD0121.protected

  private:
    // Additional Private Declarations
      //## begin cVariable%3C6A7BFD0121.private preserve=yes
      //## end cVariable%3C6A7BFD0121.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cVariable%3C6A7BFD0121.implementation preserve=yes
      //## end cVariable%3C6A7BFD0121.implementation

};

//## begin cVariable%3C6A7BFD0121.postscript preserve=yes
//## end cVariable%3C6A7BFD0121.postscript

// Class cVariable 

//## begin module%3C6A7BFD0121.epilog preserve=yes
//## end module%3C6A7BFD0121.epilog


#endif
