//## begin module%3E00548802D6.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E00548802D6.cm

//## begin module%3E00548802D6.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E00548802D6.cp

//## Module: cMapping%3E00548802D6; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cMapping.h

#ifndef cMapping_h
#define cMapping_h 1

//## begin module%3E00548802D6.includes preserve=yes
//## end module%3E00548802D6.includes

// cMapItem
#include "System/Database/cMapItem.h"

class __DLL_EXPORT__ cFuncRef;

//## begin module%3E00548802D6.additionalDeclarations preserve=yes

typedef std::vector<cMapItem*> MAP_ITEM_VECTOR_T;

//## end module%3E00548802D6.additionalDeclarations


//## begin cMapping%3E00548802D6.preface preserve=yes
//## end cMapping%3E00548802D6.preface

//## Class: cMapping%3E00548802D6
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E101EBD00A4;cMapItem { -> }

class __DLL_EXPORT__ cMapping 
{
  //## begin cMapping%3E00548802D6.initialDeclarations preserve=yes
public:
  //## end cMapping%3E00548802D6.initialDeclarations

    //## Constructors (generated)
      cMapping();

      cMapping(const cMapping &right);

    //## Destructor (generated)
      virtual ~cMapping();


    //## Other Operations (specified)
      //## Operation: SetConvFunc%1041236870
      void SetConvFunc (cFuncRef *conv_func);

      //## Operation: SetItem%1041236877
      void SetItem (ULONG_T pos, cMapItem *item);

      //## Operation: MapItem%1042459999
      cMapItem * MapItem (ULONG_T pos);

    // Data Members for Class Attributes

      //## Attribute: PhysSpec%3E22ED590002
      //## begin cMapping::PhysSpec%3E22ED590002.attr preserve=no  public: STRING_T {U} 
      STRING_T _PhysSpec;
      //## end cMapping::PhysSpec%3E22ED590002.attr

      //## Attribute: DataType%3E22AE4903C0
      //## begin cMapping::DataType%3E22AE4903C0.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _DataType;
      //## end cMapping::DataType%3E22AE4903C0.attr

      //## Attribute: Length%3E22AE4903CA
      //## begin cMapping::Length%3E22AE4903CA.attr preserve=no  public: ULONG_T {U} 1
      ULONG_T _Length;
      //## end cMapping::Length%3E22AE4903CA.attr

  public:
    // Additional Public Declarations
      //## begin cMapping%3E00548802D6.public preserve=yes
      //## end cMapping%3E00548802D6.public

  protected:
    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E14047B0224
      //## Role: cMapping::ConvFunc%3E14047C01A3
      //## begin cMapping::ConvFunc%3E14047C01A3.role preserve=no  public: cFuncRef { -> 0..1RFHN}
      cFuncRef *_ConvFunc;
      //## end cMapping::ConvFunc%3E14047C01A3.role

    // Additional Protected Declarations
      //## begin cMapping%3E00548802D6.protected preserve=yes
      //## end cMapping%3E00548802D6.protected

  private:
    // Additional Private Declarations
      //## begin cMapping%3E00548802D6.private preserve=yes
      //## end cMapping%3E00548802D6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ItemVec%3E101C250063
      //## begin cMapping::ItemVec%3E101C250063.attr preserve=no  private: MAP_ITEM_VECTOR_T {U} 
      MAP_ITEM_VECTOR_T _ItemVec;
      //## end cMapping::ItemVec%3E101C250063.attr

    // Additional Implementation Declarations
      //## begin cMapping%3E00548802D6.implementation preserve=yes
      //## end cMapping%3E00548802D6.implementation

};

//## begin cMapping%3E00548802D6.postscript preserve=yes
//## end cMapping%3E00548802D6.postscript

// Class cMapping 

//## begin module%3E00548802D6.epilog preserve=yes
//## end module%3E00548802D6.epilog


#endif
