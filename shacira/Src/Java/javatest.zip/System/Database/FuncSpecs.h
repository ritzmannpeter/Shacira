
#ifndef __FuncSpecs_h__
#define __FuncSpecs_h__

#include "FirstHeader.h"

#define MAX_STACK_LENGTH   256

typedef struct _inner {
   char fill[MAX_STACK_LENGTH];
}  inner;
    
typedef struct {
   int start_of_struct;
   inner stack;
}  PARAMS;

typedef void (*FUNC_T)(inner stack);
typedef void (*VOID_FUNC_T)(inner stack);
typedef LONG_T (*LONG_FUNC_T)(inner stack);
typedef FLOAT_T (*FLOAT_FUNC_T)(inner stack);
typedef DOUBLE_T (*DOUBLE_FUNC_T)(inner stack);
typedef STRING_T (*STRING_FUNC_T)(inner stack);
typedef WSTRING_T (*WSTRING_FUNC_T)(inner stack);

#define FUNC_NAME_SIZE     256

typedef struct {
   const char * func_name;
   FUNC_T func_ptr;
   int func_type;
}  FUNC_ENTRY_T;

#ifdef __cplusplus
extern "C" {
#endif

FUNC_T __DLL_EXPORT__ GetClientFuncAddr(CONST_STRING_T func_name);

#ifdef __cplusplus
}
#endif

#endif

