//## begin module%3EF2E1D8008C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3EF2E1D8008C.cm

//## begin module%3EF2E1D8008C.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3EF2E1D8008C.cp

//## Module: cSHVariant%3EF2E1D8008C; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cSHVariant.cpp

//## begin module%3EF2E1D8008C.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3EF2E1D8008C.additionalIncludes

//## begin module%3EF2E1D8008C.includes preserve=yes
//## end module%3EF2E1D8008C.includes

// cSHVariant
#include "System/Database/cSHVariant.h"
//## begin module%3EF2E1D8008C.additionalDeclarations preserve=yes
//## end module%3EF2E1D8008C.additionalDeclarations


// Class cSHVariant 

















cSHVariant::cSHVariant()
  //## begin cSHVariant::cSHVariant%.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(0), _Radix(10), _CHAR_Value(0), _UCHAR_Value(0), _SHORT_Value(0), _USHORT_Value(0), _LONG_Value(0), _ULONG_Value(0), _FLOAT_Value(0), _DOUBLE_Value(0), _STRING_PtrValue(NULL), _WSTRING_PtrValue(NULL), _BYTE_PtrValue(NULL)
  //## end cSHVariant::cSHVariant%.hasinit
  //## begin cSHVariant::cSHVariant%.initialization preserve=yes
  //## end cSHVariant::cSHVariant%.initialization
{
  //## begin cSHVariant::cSHVariant%.body preserve=yes
  //## end cSHVariant::cSHVariant%.body
}

cSHVariant::cSHVariant(const cSHVariant &right)
  //## begin cSHVariant::cSHVariant%copy.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(0), _Radix(10), _CHAR_Value(0), _UCHAR_Value(0), _SHORT_Value(0), _USHORT_Value(0), _LONG_Value(0), _ULONG_Value(0), _FLOAT_Value(0), _DOUBLE_Value(0), _STRING_PtrValue(NULL), _WSTRING_PtrValue(NULL), _BYTE_PtrValue(NULL)
  //## end cSHVariant::cSHVariant%copy.hasinit
  //## begin cSHVariant::cSHVariant%copy.initialization preserve=yes
  //## end cSHVariant::cSHVariant%copy.initialization
{
  //## begin cSHVariant::cSHVariant%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cSHVariant::cSHVariant%copy.body
}


cSHVariant::~cSHVariant()
{
  //## begin cSHVariant::~cSHVariant%.body preserve=yes
  //## end cSHVariant::~cSHVariant%.body
}



//## Other Operations (implementation)
void cSHVariant::Set (CHAR_T value)
{
  //## begin cSHVariant::Set%1056115080.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_CHAR).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115080.body
}

void cSHVariant::Set (UCHAR_T value)
{
  //## begin cSHVariant::Set%1056115081.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_UCHAR).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115081.body
}

void cSHVariant::Set (SHORT_T value)
{
  //## begin cSHVariant::Set%1056115083.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_SHORT).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115083.body
}

void cSHVariant::Set (USHORT_T value)
{
  //## begin cSHVariant::Set%1056115084.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_USHORT).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115084.body
}

void cSHVariant::Set (LONG_T value)
{
  //## begin cSHVariant::Set%1056115086.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_LONG).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115086.body
}

void cSHVariant::Set (ULONG_T value)
{
  //## begin cSHVariant::Set%1056115087.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_ULONG).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115087.body
}

void cSHVariant::Set (FLOAT_T value)
{
  //## begin cSHVariant::Set%1056115088.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_FLOAT).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115088.body
}

void cSHVariant::Set (DOUBLE_T value)
{
  //## begin cSHVariant::Set%1056115089.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)value;
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)value;
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)value;
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)value;
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)value;
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)value;
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)value;
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)value;
      return;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_DOUBLE).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115089.body
}

void cSHVariant::Set (UCHAR_T *value, ULONG_T length)
{
  //## begin cSHVariant::Set%1056375591.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      break;
   case SH_UCHAR:
      break;
   case SH_SHORT:
      break;
   case SH_USHORT:
      break;
   case SH_LONG:
      break;
   case SH_ULONG:
      break;
   case SH_FLOAT:
      break;
   case SH_DOUBLE:
      break;
   case SH_STRING:
      break;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      _Length = length;
      _BYTE_PtrValue = value;
      return;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_BYTE).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056375591.body
}

void cSHVariant::Set (CHAR_T *value, CHAR_T data_type)
{
  //## begin cSHVariant::Set%1056115082.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      break;
   case SH_UCHAR:
      break;
   case SH_SHORT:
      break;
   case SH_USHORT:
      break;
   case SH_LONG:
      break;
   case SH_ULONG:
      break;
   case SH_FLOAT:
      break;
   case SH_DOUBLE:
      break;
   case SH_STRING:
      _STRING_PtrValue = value;
      _STRING_Value = "";
      return;
   case SH_WSTRING:
      break;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_STRING).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115082.body
}

void cSHVariant::Set (const CHAR_T *value, CHAR_T data_type)
{
  //## begin cSHVariant::Set%1056375590.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)Dec2Long(value);
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)Dec2Long(value);
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)Dec2Long(value);
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)Dec2Long(value);
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)Dec2Long(value);
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)Dec2Long(value);
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)Real2Float(value);
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)Real2Double(value);
      return;
   case SH_STRING:
      _STRING_Value = value;
      _STRING_PtrValue = NULL;
      return;
   case SH_WSTRING:
      _WSTRING_Value = String2Wide(value);
      _WSTRING_PtrValue = NULL;
      return;
   case SH_BYTE: break;
      _STRING_Value = value;
      return;
   case SH_SYM_DEC:
      _STRING_Value = value;
      return;
   case SH_SYM_HEX:
      _STRING_Value = value;
      return;
   case SH_SYM_REAL:
      _STRING_Value = value;
      return;
   case SH_SYM_STRING:
      _STRING_Value = value;
      return;
   case SH_SYM_WSTRING:
      _WSTRING_Value = String2Wide(value);
      return;
   case SH_SYM_BCD:
      _STRING_Value = value;
      return;
   case SH_SYM_KMBCD:
      _STRING_Value = value;
      return;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_STRING).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056375590.body
}

void cSHVariant::Set (WCHAR_T *value, CHAR_T data_type)
{
  //## begin cSHVariant::Set%1056375589.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      break;
   case SH_UCHAR:
      break;
   case SH_SHORT:
      break;
   case SH_USHORT:
      break;
   case SH_LONG:
      break;
   case SH_ULONG:
      break;
   case SH_FLOAT:
      break;
   case SH_DOUBLE:
      break;
   case SH_STRING:
      break;
   case SH_WSTRING:
      _WSTRING_PtrValue = value;
      _WSTRING_Value = L"";
      return;
   case SH_BYTE: break;
      break;
   case SH_SYM_DEC:
      break;
   case SH_SYM_HEX:
      break;
   case SH_SYM_REAL:
      break;
   case SH_SYM_STRING:
      break;
   case SH_SYM_WSTRING:
      break;
   case SH_SYM_BCD:
      break;
   case SH_SYM_KMBCD:
      break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_WSTRING).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056375589.body
}

void cSHVariant::Set (const WCHAR_T *value, CHAR_T data_type)
{
  //## begin cSHVariant::Set%1056115085.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      _CHAR_Value = (CHAR_T)Dec2Long(value);
      return;
   case SH_UCHAR:
      _UCHAR_Value = (UCHAR_T)Dec2Long(value);
      return;
   case SH_SHORT:
      _SHORT_Value = (SHORT_T)Dec2Long(value);
      return;
   case SH_USHORT:
      _USHORT_Value = (USHORT_T)Dec2Long(value);
      return;
   case SH_LONG:
      _LONG_Value = (LONG_T)Dec2Long(value);
      return;
   case SH_ULONG:
      _ULONG_Value = (ULONG_T)Dec2Long(value);
      return;
   case SH_FLOAT:
      _FLOAT_Value = (FLOAT_T)Real2Float(value);
      return;
   case SH_DOUBLE:
      _DOUBLE_Value = (DOUBLE_T)Real2Double(value);
      return;
   case SH_STRING:
      _STRING_Value = Wide2String(value);
      _STRING_PtrValue = NULL;
      return;
   case SH_WSTRING:
      _WSTRING_Value = value;
      _WSTRING_PtrValue = NULL;
      return;
   case SH_BYTE: break;
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_DEC:
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_HEX:
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_REAL:
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_STRING:
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_WSTRING:
      _WSTRING_Value = value;
      return;
   case SH_SYM_BCD:
      _STRING_Value = Wide2String(value);
      return;
   case SH_SYM_KMBCD:
      _STRING_Value = Wide2String(value);
      return;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(SH_WSTRING).c_str(), TypeName(_DataType).c_str());
  //## end cSHVariant::Set%1056115085.body
}

CHAR_T cSHVariant::Get_CHAR ()
{
  //## begin cSHVariant::Get_CHAR%1056195543.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (CHAR_T)_CHAR_Value;
   case SH_UCHAR:
      return (CHAR_T)_UCHAR_Value;
   case SH_SHORT:
      return (CHAR_T)_SHORT_Value;
   case SH_USHORT:
      return (CHAR_T)_USHORT_Value;
   case SH_LONG:
      return (CHAR_T)_LONG_Value;
   case SH_ULONG:
      return (CHAR_T)_ULONG_Value;
   case SH_FLOAT:
      return (CHAR_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (CHAR_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (CHAR_T)Dec2Long(_STRING_Value.c_str()) :
         (CHAR_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (CHAR_T)Dec2Long(_WSTRING_Value.c_str()) :
         (CHAR_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE: break;
   case SH_SYM_DEC:
      return (CHAR_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (CHAR_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (CHAR_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (CHAR_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (CHAR_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (CHAR_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (CHAR_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_CHAR).c_str());
  //## end cSHVariant::Get_CHAR%1056195543.body
}

UCHAR_T cSHVariant::Get_UCHAR ()
{
  //## begin cSHVariant::Get_UCHAR%1056195544.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (UCHAR_T)_CHAR_Value;
   case SH_UCHAR:
      return (UCHAR_T)_UCHAR_Value;
   case SH_SHORT:
      return (UCHAR_T)_SHORT_Value;
   case SH_USHORT:
      return (UCHAR_T)_USHORT_Value;
   case SH_LONG:
      return (UCHAR_T)_LONG_Value;
   case SH_ULONG:
      return (UCHAR_T)_ULONG_Value;
   case SH_FLOAT:
      return (UCHAR_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (UCHAR_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (UCHAR_T)Dec2Long(_STRING_Value.c_str()) :
         (UCHAR_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (UCHAR_T)Dec2Long(_WSTRING_Value.c_str()) :
         (UCHAR_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (UCHAR_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (UCHAR_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (UCHAR_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (UCHAR_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (UCHAR_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (UCHAR_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (UCHAR_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_UCHAR).c_str());
  //## end cSHVariant::Get_UCHAR%1056195544.body
}

SHORT_T cSHVariant::Get_SHORT ()
{
  //## begin cSHVariant::Get_SHORT%1056195545.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (SHORT_T)_CHAR_Value;
   case SH_UCHAR:
      return (SHORT_T)_UCHAR_Value;
   case SH_SHORT:
      return (SHORT_T)_SHORT_Value;
   case SH_USHORT:
      return (SHORT_T)_USHORT_Value;
   case SH_LONG:
      return (SHORT_T)_LONG_Value;
   case SH_ULONG:
      return (SHORT_T)_ULONG_Value;
   case SH_FLOAT:
      return (SHORT_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (SHORT_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (SHORT_T)Dec2Long(_STRING_Value.c_str()) :
         (SHORT_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (SHORT_T)Dec2Long(_WSTRING_Value.c_str()) :
         (SHORT_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE: break;
   case SH_SYM_DEC:
      return (SHORT_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (SHORT_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (SHORT_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (SHORT_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (SHORT_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (SHORT_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (SHORT_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_SHORT).c_str());
  //## end cSHVariant::Get_SHORT%1056195545.body
}

USHORT_T cSHVariant::Get_USHORT ()
{
  //## begin cSHVariant::Get_USHORT%1056195546.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (USHORT_T)_CHAR_Value;
   case SH_UCHAR:
      return (USHORT_T)_UCHAR_Value;
   case SH_SHORT:
      return (USHORT_T)_SHORT_Value;
   case SH_USHORT:
      return (USHORT_T)_USHORT_Value;
   case SH_LONG:
      return (USHORT_T)_LONG_Value;
   case SH_ULONG:
      return (USHORT_T)_ULONG_Value;
   case SH_FLOAT:
      return (USHORT_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (USHORT_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (USHORT_T)Dec2Long(_STRING_Value.c_str()) :
         (USHORT_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (USHORT_T)Dec2Long(_WSTRING_Value.c_str()) :
         (USHORT_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (USHORT_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (USHORT_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (USHORT_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (USHORT_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (USHORT_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (USHORT_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (USHORT_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_USHORT).c_str());
  //## end cSHVariant::Get_USHORT%1056195546.body
}

LONG_T cSHVariant::Get_LONG ()
{
  //## begin cSHVariant::Get_LONG%1056195547.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (LONG_T)_CHAR_Value;
   case SH_UCHAR:
      return (LONG_T)_UCHAR_Value;
   case SH_SHORT:
      return (LONG_T)_SHORT_Value;
   case SH_USHORT:
      return (LONG_T)_USHORT_Value;
   case SH_LONG:
      return (LONG_T)_LONG_Value;
   case SH_ULONG:
      return (LONG_T)_ULONG_Value;
   case SH_FLOAT:
      return (LONG_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (LONG_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (LONG_T)Dec2Long(_STRING_Value.c_str()) :
         (LONG_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (LONG_T)Dec2Long(_WSTRING_Value.c_str()) :
         (LONG_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (LONG_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (LONG_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (LONG_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (LONG_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (LONG_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (LONG_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (LONG_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_LONG).c_str());
  //## end cSHVariant::Get_LONG%1056195547.body
}

ULONG_T cSHVariant::Get_ULONG ()
{
  //## begin cSHVariant::Get_ULONG%1056195548.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (ULONG_T)_CHAR_Value;
   case SH_UCHAR:
      return (ULONG_T)_UCHAR_Value;
   case SH_SHORT:
      return (ULONG_T)_SHORT_Value;
   case SH_USHORT:
      return (ULONG_T)_USHORT_Value;
   case SH_LONG:
      return (ULONG_T)_LONG_Value;
   case SH_ULONG:
      return (ULONG_T)_ULONG_Value;
   case SH_FLOAT:
      return (ULONG_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (ULONG_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (ULONG_T)Dec2Long(_STRING_Value.c_str()) :
         (ULONG_T)Dec2Long(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (ULONG_T)Dec2Long(_WSTRING_Value.c_str()) :
         (ULONG_T)Dec2Long(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (ULONG_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (ULONG_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (ULONG_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (ULONG_T)Dec2Long(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (ULONG_T)Dec2Long(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (ULONG_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (ULONG_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_ULONG).c_str());
  //## end cSHVariant::Get_ULONG%1056195548.body
}

FLOAT_T cSHVariant::Get_FLOAT ()
{
  //## begin cSHVariant::Get_FLOAT%1056195549.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (FLOAT_T)_CHAR_Value;
   case SH_UCHAR:
      return (FLOAT_T)_UCHAR_Value;
   case SH_SHORT:
      return (FLOAT_T)_SHORT_Value;
   case SH_USHORT:
      return (FLOAT_T)_USHORT_Value;
   case SH_LONG:
      return (FLOAT_T)_LONG_Value;
   case SH_ULONG:
      return (FLOAT_T)_ULONG_Value;
   case SH_FLOAT:
      return (FLOAT_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (FLOAT_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (FLOAT_T)Real2Float(_STRING_Value.c_str()) :
         (FLOAT_T)Real2Float(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (FLOAT_T)Real2Float(_WSTRING_Value.c_str()) :
         (FLOAT_T)Real2Float(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (FLOAT_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (FLOAT_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (FLOAT_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (FLOAT_T)Real2Float(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (FLOAT_T)Real2Float(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (FLOAT_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (FLOAT_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_FLOAT).c_str());
  //## end cSHVariant::Get_FLOAT%1056195549.body
}

DOUBLE_T cSHVariant::Get_DOUBLE ()
{
  //## begin cSHVariant::Get_DOUBLE%1056195550.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      return (DOUBLE_T)_CHAR_Value;
   case SH_UCHAR:
      return (DOUBLE_T)_UCHAR_Value;
   case SH_SHORT:
      return (DOUBLE_T)_SHORT_Value;
   case SH_USHORT:
      return (DOUBLE_T)_USHORT_Value;
   case SH_LONG:
      return (DOUBLE_T)_LONG_Value;
   case SH_ULONG:
      return (DOUBLE_T)_ULONG_Value;
   case SH_FLOAT:
      return (DOUBLE_T)_FLOAT_Value;
   case SH_DOUBLE:
      return (DOUBLE_T)_DOUBLE_Value;
   case SH_STRING:
      return (_STRING_PtrValue == NULL) ?
         (DOUBLE_T)Real2Double(_STRING_Value.c_str()) :
         (DOUBLE_T)Real2Double(_STRING_PtrValue);
   case SH_WSTRING:
      return (_WSTRING_PtrValue == NULL) ?
         (DOUBLE_T)Real2Double(_WSTRING_Value.c_str()) :
         (DOUBLE_T)Real2Double(_WSTRING_PtrValue);
   case SH_BYTE:
      break;
   case SH_SYM_DEC:
      return (DOUBLE_T)Real2Double(_STRING_Value.c_str());
   case SH_SYM_HEX:
      return (DOUBLE_T)Hex2Ulong(_STRING_Value.c_str());
   case SH_SYM_REAL: break;
      return (DOUBLE_T)Real2Double(_STRING_Value.c_str());
   case SH_SYM_STRING:
      return (DOUBLE_T)Real2Double(_STRING_Value.c_str());
   case SH_SYM_WSTRING: break;
      return (DOUBLE_T)Real2Double(_WSTRING_Value.c_str());
   case SH_SYM_BCD: break;
      return (DOUBLE_T)BCD2Long(_STRING_Value.c_str());
   case SH_SYM_KMBCD: break;
      return (DOUBLE_T)KMBCD2Long(_STRING_Value.c_str());
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_DOUBLE).c_str());
  //## end cSHVariant::Get_DOUBLE%1056195550.body
}

void cSHVariant::Get (const UCHAR_T *buf, ULONG_T buf_len)
{
  //## begin cSHVariant::Get%1056375602.body preserve=yes
   LONG_T len = 0;
   LONG_T fill = 0;
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR: break;
   case SH_UCHAR: break;
   case SH_SHORT: break;
   case SH_USHORT: break;
   case SH_LONG: break;
   case SH_ULONG: break;
   case SH_FLOAT: break;
   case SH_DOUBLE: break;
   case SH_STRING: break;
   case SH_WSTRING: break;
   case SH_BYTE:
      len = MIN(_Length, buf_len);
      memcpy((void*)buf, _BYTE_PtrValue, len);
      fill = buf_len - len;
      if (fill > 0) memset((void*)(buf+len), 0, fill);
      return;
   case SH_SYM_DEC: break;
   case SH_SYM_HEX: break;
   case SH_SYM_REAL: break;
   case SH_SYM_STRING: break;
   case SH_SYM_WSTRING: break;
   case SH_SYM_BCD: break;
   case SH_SYM_KMBCD: break;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_BYTE).c_str());
  //## end cSHVariant::Get%1056375602.body
}

void cSHVariant::Get (STRING_T &value, CHAR_T radix)
{
  //## begin cSHVariant::Get%1056195553.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      Long2String(value, (LONG_T)_CHAR_Value);
      return;
   case SH_UCHAR:
      Long2String(value, (LONG_T)_UCHAR_Value);
      return;
   case SH_SHORT:
      Long2String(value, (LONG_T)_SHORT_Value);
      return;
   case SH_USHORT:
      Long2String(value, (LONG_T)_USHORT_Value);
      return;
   case SH_LONG:
      Long2String(value, (LONG_T)_LONG_Value);
      return;
   case SH_ULONG:
      Long2String(value, (LONG_T)_ULONG_Value);
      return;
   case SH_FLOAT:
      Float2String(value, (FLOAT_T)_FLOAT_Value);
      return;
   case SH_DOUBLE:
      Double2String(value, (DOUBLE_T)_DOUBLE_Value);
      return;
   case SH_STRING:
      value = (_STRING_PtrValue == NULL) ? _STRING_Value : _STRING_PtrValue;
      return;
   case SH_WSTRING:
      value = (_WSTRING_PtrValue == NULL) ?
         Wide2String(_WSTRING_Value.c_str()) :
         Wide2String(_WSTRING_PtrValue);
      return;
   case SH_BYTE: break;
   case SH_SYM_DEC:
      value = _STRING_Value;
      return;
   case SH_SYM_HEX:
      value = _STRING_Value;
      return;
   case SH_SYM_REAL: break;
      value = _STRING_Value;
      return;
   case SH_SYM_STRING:
      value = _STRING_Value;
      return;
   case SH_SYM_WSTRING: break;
      value = Wide2String(_WSTRING_Value.c_str());
      return;
   case SH_SYM_BCD: break;
      value = _STRING_Value;
      return;
   case SH_SYM_KMBCD: break;
      value = _STRING_Value;
      return;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_STRING).c_str());
  //## end cSHVariant::Get%1056195553.body
}

void cSHVariant::Get (WSTRING_T &value, CHAR_T radix)
{
  //## begin cSHVariant::Get%1056195554.body preserve=yes
   switch (_DataType) {
   case SH_VOID: break;
   case SH_CHAR:
      Long2String(value, (LONG_T)_CHAR_Value);
      return;
   case SH_UCHAR:
      Long2String(value, (LONG_T)_UCHAR_Value);
      return;
   case SH_SHORT:
      Long2String(value, (LONG_T)_SHORT_Value);
      return;
   case SH_USHORT:
      Long2String(value, (LONG_T)_USHORT_Value);
      return;
   case SH_LONG:
      Long2String(value, (LONG_T)_LONG_Value);
      return;
   case SH_ULONG:
      Long2String(value, (LONG_T)_ULONG_Value);
      return;
   case SH_FLOAT:
      Float2String(value, (FLOAT_T)_FLOAT_Value);
      return;
   case SH_DOUBLE:
      Double2String(value, (DOUBLE_T)_DOUBLE_Value);
      return;
   case SH_STRING:
      value = (_STRING_PtrValue == NULL) ?
         String2Wide(_STRING_Value.c_str()) :
         String2Wide(_STRING_PtrValue);
      return;
   case SH_WSTRING:
      value = (_WSTRING_PtrValue == NULL) ? _WSTRING_Value : _WSTRING_PtrValue;
      return;
   case SH_BYTE: break;
   case SH_SYM_DEC:
      value = String2Wide(_STRING_Value.c_str());
      return;
   case SH_SYM_HEX:
      value = String2Wide(_STRING_Value.c_str());
      return;
   case SH_SYM_REAL: break;
      value = String2Wide(_STRING_Value.c_str());
      return;
   case SH_SYM_STRING:
      value = String2Wide(_STRING_Value.c_str());
      return;
   case SH_SYM_WSTRING: break;
      value = _WSTRING_Value.c_str();
      return;
   case SH_SYM_BCD: break;
      value = String2Wide(_STRING_Value.c_str());
      return;
   case SH_SYM_KMBCD: break;
      value = String2Wide(_STRING_Value.c_str());
      return;
   }
   throw cError(VARIANT_CONVERSION_ERROR, 0, TypeName(_DataType).c_str(), TypeName(SH_WSTRING).c_str());
  //## end cSHVariant::Get%1056195554.body
}

void cSHVariant::Get (const CHAR_T *buf, ULONG_T buf_len)
{
  //## begin cSHVariant::Get%1056375601.body preserve=yes
  //## end cSHVariant::Get%1056375601.body
}

void cSHVariant::Get (const WCHAR_T *buf, ULONG_T buf_len)
{
  //## begin cSHVariant::Get%1056375603.body preserve=yes
  //## end cSHVariant::Get%1056375603.body
}

STRING_T cSHVariant::TypeName (UCHAR_T data_type)
{
  //## begin cSHVariant::TypeName%1056195555.body preserve=yes
   switch (data_type) {
   case UNDEFINED: return "undefined";
   case SH_VOID: return "void";
   case SH_CHAR: return "char";
   case SH_UCHAR: return "unsigned char";
   case SH_SHORT: return "short";
   case SH_USHORT: return "unsigned short";
   case SH_LONG: return "long";
   case SH_ULONG: return "unsigned long";
   case SH_FLOAT: return "float";
   case SH_DOUBLE: return "double";
   case SH_STRING: return "string";
   case SH_WSTRING: return "wstring";
   case SH_BYTE: return "byte";
   case SH_SYM_DEC: return "decimal";
   case SH_SYM_HEX: return "hexadecinmal";
   case SH_SYM_REAL: return "real";
   case SH_SYM_STRING: return "variable string";
   case SH_SYM_WSTRING: return "variable wstring";
   case SH_SYM_BCD: return "binary coded decimal";
   case SH_SYM_KMBCD: return "km binary coded decimal";
   }
   char type_name[64] = {0};
   return type_name;
  //## end cSHVariant::TypeName%1056195555.body
}

WSTRING_T cSHVariant::String2Wide (CONST_STRING_T str)
{
  //## begin cSHVariant::String2Wide%1056375604.body preserve=yes
   ULONG_T len = StrLen(str);
   WCHAR_T * buf = (WCHAR_T*)cSystemUtils::Alloc((len+1) * sizeof(WCHAR_T));
   for (ULONG_T i = 0; i<len; i++) {
      buf[i] = str[i];
   }
   buf[i] = 0;
   WSTRING_T value = (CONST_WSTRING_T)buf;
   cSystemUtils::Free(buf);
   return value;
  //## end cSHVariant::String2Wide%1056375604.body
}

STRING_T cSHVariant::Wide2String (CONST_WSTRING_T str)
{
  //## begin cSHVariant::Wide2String%1056195556.body preserve=yes
   ULONG_T len = StrLen(str);
   CHAR_T * buf = (CHAR_T*)cSystemUtils::Alloc(len+1);
   for (ULONG_T i = 0; i<len; i++) {
      buf[i] = (CHAR_T)str[i];
   }
   buf[i] = 0;
   STRING_T value = (const char*)buf;
   cSystemUtils::Free(buf);
   return value;
  //## end cSHVariant::Wide2String%1056195556.body
}

DOUBLE_T cSHVariant::Real2Double (CONST_STRING_T str)
{
  //## begin cSHVariant::Real2Double%1056195557.body preserve=yes
   DOUBLE_T value = 0;
   sscanf(str, "%f", &value);
   return (DOUBLE_T)value;
  //## end cSHVariant::Real2Double%1056195557.body
}

DOUBLE_T cSHVariant::Real2Double (CONST_WSTRING_T str)
{
  //## begin cSHVariant::Real2Double%1056375592.body preserve=yes
   DOUBLE_T value = 0;
   STRING_T temp_str = Wide2String(str);
   sscanf(temp_str.c_str(), "%f", &value);
   return value;
  //## end cSHVariant::Real2Double%1056375592.body
}

FLOAT_T cSHVariant::Real2Float (CONST_STRING_T str)
{
  //## begin cSHVariant::Real2Float%1056375594.body preserve=yes
   FLOAT_T value = 0;
   sscanf(str, "%f", &value);
   return value;
  //## end cSHVariant::Real2Float%1056375594.body
}

FLOAT_T cSHVariant::Real2Float (CONST_WSTRING_T str)
{
  //## begin cSHVariant::Real2Float%1056375593.body preserve=yes
   FLOAT_T value = 0;
   STRING_T temp_str = Wide2String(str);
   sscanf(temp_str.c_str(), "%f", &value);
   return value;
  //## end cSHVariant::Real2Float%1056375593.body
}

ULONG_T cSHVariant::Hex2Ulong (CONST_STRING_T str)
{
  //## begin cSHVariant::Hex2Ulong%1056375595.body preserve=yes
   ULONG_T value = 0;
   sscanf(str, "%x", &value);
   return value;
  //## end cSHVariant::Hex2Ulong%1056375595.body
}

ULONG_T cSHVariant::Hex2Ulong (CONST_WSTRING_T str)
{
  //## begin cSHVariant::Hex2Ulong%1056375596.body preserve=yes
   ULONG_T value = 0;
   STRING_T temp_str = Wide2String(str);
   sscanf(temp_str.c_str(), "%x", &value);
   return value;
  //## end cSHVariant::Hex2Ulong%1056375596.body
}

LONG_T cSHVariant::Dec2Long (CONST_STRING_T str)
{
  //## begin cSHVariant::Dec2Long%1056375599.body preserve=yes
   LONG_T value = 0;
   sscanf(str, "%d", &value);
   return value;
  //## end cSHVariant::Dec2Long%1056375599.body
}

LONG_T cSHVariant::Dec2Long (CONST_WSTRING_T str)
{
  //## begin cSHVariant::Dec2Long%1056375600.body preserve=yes
   LONG_T value = 0;
   STRING_T temp_str = Wide2String(str);
   sscanf(temp_str.c_str(), "%d", &value);
   return value;
  //## end cSHVariant::Dec2Long%1056375600.body
}

LONG_T cSHVariant::BCD2Long (CONST_STRING_T str)
{
  //## begin cSHVariant::BCD2Long%1056375605.body preserve=yes
_ASSERT_UNCOND
return 0;
  //## end cSHVariant::BCD2Long%1056375605.body
}

LONG_T cSHVariant::BCD2Long (CONST_WSTRING_T str)
{
  //## begin cSHVariant::BCD2Long%1056375606.body preserve=yes
_ASSERT_UNCOND
return 0;
  //## end cSHVariant::BCD2Long%1056375606.body
}

LONG_T cSHVariant::KMBCD2Long (CONST_STRING_T str)
{
  //## begin cSHVariant::KMBCD2Long%1056375607.body preserve=yes
_ASSERT_UNCOND
return 0;
  //## end cSHVariant::KMBCD2Long%1056375607.body
}

LONG_T cSHVariant::KMBCD2Long (CONST_WSTRING_T str)
{
  //## begin cSHVariant::KMBCD2Long%1056375608.body preserve=yes
_ASSERT_UNCOND
return 0;
  //## end cSHVariant::KMBCD2Long%1056375608.body
}

void cSHVariant::Long2String (STRING_T &str, LONG_T value, UCHAR_T radix)
{
  //## begin cSHVariant::Long2String%1056447736.body preserve=yes
   char buf[64] = {0};
   str = ltoa(value, buf, radix);
  //## end cSHVariant::Long2String%1056447736.body
}

void cSHVariant::Long2String (WSTRING_T &str, LONG_T value, UCHAR_T radix)
{
  //## begin cSHVariant::Long2String%1056447737.body preserve=yes
   char buf[64] = {0};
   str = String2Wide(ltoa(value, buf, radix));
  //## end cSHVariant::Long2String%1056447737.body
}

void cSHVariant::Float2String (STRING_T &str, FLOAT_T value, UCHAR_T precision)
{
  //## begin cSHVariant::Float2String%1056447738.body preserve=yes
   char buf[64] = {0};
   sprintf(buf, "%f", value);
   str = buf;
  //## end cSHVariant::Float2String%1056447738.body
}

void cSHVariant::Float2String (WSTRING_T &str, FLOAT_T value, UCHAR_T precision)
{
  //## begin cSHVariant::Float2String%1056447739.body preserve=yes
   char buf[64] = {0};
   sprintf(buf, "%f", value);
   str = String2Wide(buf);
  //## end cSHVariant::Float2String%1056447739.body
}

void cSHVariant::Double2String (STRING_T &str, DOUBLE_T value, UCHAR_T precision)
{
  //## begin cSHVariant::Double2String%1056447740.body preserve=yes
   char buf[64] = {0};
   sprintf(buf, "%f", value);
   str = buf;
  //## end cSHVariant::Double2String%1056447740.body
}

void cSHVariant::Double2String (WSTRING_T &str, DOUBLE_T value, UCHAR_T precision)
{
  //## begin cSHVariant::Double2String%1056447741.body preserve=yes
   char buf[64] = {0};
   sprintf(buf, "%f", value);
   str = String2Wide(buf);
  //## end cSHVariant::Double2String%1056447741.body
}

ULONG_T cSHVariant::StrLen (CONST_STRING_T str)
{
  //## begin cSHVariant::StrLen%1056195558.body preserve=yes
   return strlen(str);
  //## end cSHVariant::StrLen%1056195558.body
}

ULONG_T cSHVariant::StrLen (CONST_WSTRING_T str)
{
  //## begin cSHVariant::StrLen%1056195559.body preserve=yes
   ULONG_T i = 0;
   while (true) {
      if (str[i] == 0) return i + 1;
      i++;
   }
  //## end cSHVariant::StrLen%1056195559.body
}

INT_T cSHVariant::StrCmp (CONST_STRING_T str1, CONST_STRING_T str2)
{
  //## begin cSHVariant::StrCmp%1056621170.body preserve=yes
   return strcmp(str1, str2);
  //## end cSHVariant::StrCmp%1056621170.body
}

INT_T cSHVariant::StrCmp (CONST_WSTRING_T str1, CONST_WSTRING_T str2)
{
  //## begin cSHVariant::StrCmp%1056621171.body preserve=yes
   ULONG_T len = StrLen(str1);
   if (len != StrLen(str2)) return -1;
   for (ULONG_T i=0; i<len; i++) {
      if (str1[i] != str2[i]) return false;
   }
   return true;
  //## end cSHVariant::StrCmp%1056621171.body
}

ULONG_T cSHVariant::MemSize (CONST_STRING_T str)
{
  //## begin cSHVariant::MemSize%1056478821.body preserve=yes
   return StrLen(str) * sizeof(CHAR_T);
  //## end cSHVariant::MemSize%1056478821.body
}

ULONG_T cSHVariant::MemSize (CONST_WSTRING_T str)
{
  //## begin cSHVariant::MemSize%1056478822.body preserve=yes
   return StrLen(str) * sizeof(WCHAR_T);
  //## end cSHVariant::MemSize%1056478822.body
}

ULONG_T cSHVariant::TypeSize (UCHAR_T data_type)
{
  //## begin cSHVariant::TypeSize%1056478823.body preserve=yes
   switch (data_type) {
   case SH_VOID: return 0;
   case SH_CHAR: return sizeof(CHAR_T);
   case SH_UCHAR: return sizeof(UCHAR_T);
   case SH_SHORT: return sizeof(SHORT_T);
   case SH_USHORT: return sizeof(USHORT_T);
   case SH_LONG: return sizeof(LONG_T);
   case SH_ULONG: return sizeof(ULONG_T);
   case SH_FLOAT: return sizeof(FLOAT_T);
   case SH_DOUBLE: return sizeof(DOUBLE_T);
   case SH_STRING: return sizeof(CHAR_T);
   case SH_WSTRING: return sizeof(WCHAR_T);
   case SH_SYM_BCD:
   case SH_SYM_KMBCD:
   case SH_SYM_HEX:
_ASSERT_UNCOND
   default:
_ASSERT_UNCOND
   }
  //## end cSHVariant::TypeSize%1056478823.body
}

//## Get and Set Operations for Class Attributes (implementation)

UCHAR_T cSHVariant::get_DataType () const
{
  //## begin cSHVariant::get_DataType%3EF32B4F032C.get preserve=no
  return _DataType;
  //## end cSHVariant::get_DataType%3EF32B4F032C.get
}

void cSHVariant::set_DataType (UCHAR_T value)
{
  //## begin cSHVariant::set_DataType%3EF32B4F032C.set preserve=no
  _DataType = value;
  //## end cSHVariant::set_DataType%3EF32B4F032C.set
}

// Additional Declarations
  //## begin cSHVariant%3EF2E1D8008C.declarations preserve=yes
  //## end cSHVariant%3EF2E1D8008C.declarations

//## begin module%3EF2E1D8008C.epilog preserve=yes
//## end module%3EF2E1D8008C.epilog
