//## begin module%3C6A7BFD0121.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6A7BFD0121.cm

//## begin module%3C6A7BFD0121.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C6A7BFD0121.cp

//## Module: cVariable%3C6A7BFD0121; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cVariable.cpp

//## begin module%3C6A7BFD0121.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C6A7BFD0121.additionalIncludes

//## begin module%3C6A7BFD0121.includes preserve=yes
//## end module%3C6A7BFD0121.includes

// cDataChange
#include "System/Objects/cDataChange.h"
// cVarDef
#include "System/Database/cVarDef.h"
// cContext
#include "System/Database/cContext.h"
// cVariable
#include "System/Database/cVariable.h"
//## begin module%3C6A7BFD0121.additionalDeclarations preserve=yes
//## end module%3C6A7BFD0121.additionalDeclarations


// Class cVariable 





cVariable::cVariable()
  //## begin cVariable::cVariable%.hasinit preserve=no
      : _VarId(-1), _VarDef(NULL)
  //## end cVariable::cVariable%.hasinit
  //## begin cVariable::cVariable%.initialization preserve=yes
  //## end cVariable::cVariable%.initialization
{
  //## begin cVariable::cVariable%.body preserve=yes
_ASSERT_UNCOND
  //## end cVariable::cVariable%.body
}

cVariable::cVariable(const cVariable &right)
  //## begin cVariable::cVariable%copy.hasinit preserve=no
      : _VarId(-1), _VarDef(NULL)
  //## end cVariable::cVariable%copy.hasinit
  //## begin cVariable::cVariable%copy.initialization preserve=yes
  //## end cVariable::cVariable%copy.initialization
{
  //## begin cVariable::cVariable%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cVariable::cVariable%copy.body
}

cVariable::cVariable (cVarDef *var_def)
  //## begin cVariable::cVariable%1015079155.hasinit preserve=no
      : _VarId(-1), _VarDef(NULL)
  //## end cVariable::cVariable%1015079155.hasinit
  //## begin cVariable::cVariable%1015079155.initialization preserve=yes
  //## end cVariable::cVariable%1015079155.initialization
{
  //## begin cVariable::cVariable%1015079155.body preserve=yes
_ASSERT_COND(var_def != NULL)
   _VarDef = var_def;
  //## end cVariable::cVariable%1015079155.body
}


cVariable::~cVariable()
{
  //## begin cVariable::~cVariable%.body preserve=yes
  //## end cVariable::~cVariable%.body
}


//## Get and Set Operations for Class Attributes (implementation)

LONG_T cVariable::get_VarId () const
{
  //## begin cVariable::get_VarId%3D085CD7007A.get preserve=no
  return _VarId;
  //## end cVariable::get_VarId%3D085CD7007A.get
}

void cVariable::set_VarId (LONG_T value)
{
  //## begin cVariable::set_VarId%3D085CD7007A.set preserve=no
  _VarId = value;
  //## end cVariable::set_VarId%3D085CD7007A.set
}

// Additional Declarations
  //## begin cVariable%3C6A7BFD0121.declarations preserve=yes
  //## end cVariable%3C6A7BFD0121.declarations

//## begin module%3C6A7BFD0121.epilog preserve=yes
//## end module%3C6A7BFD0121.epilog
