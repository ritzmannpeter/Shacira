//## begin module%3E0032230357.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E0032230357.cm

//## begin module%3E0032230357.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E0032230357.cp

//## Module: cVarDef%3E0032230357; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cVarDef.h

#ifndef cVarDef_h
#define cVarDef_h 1

//## begin module%3E0032230357.includes preserve=yes
//## end module%3E0032230357.includes


class __DLL_EXPORT__ cFuncRef;
class __DLL_EXPORT__ cContext;
class __DLL_EXPORT__ cVariable;
class __DLL_EXPORT__ cSHVariant;
class __DLL_EXPORT__ cMapping;

//## begin module%3E0032230357.additionalDeclarations preserve=yes
//## end module%3E0032230357.additionalDeclarations


//## begin cVarDef%3E0032230357.preface preserve=yes
//## end cVarDef%3E0032230357.preface

//## Class: cVarDef%3E0032230357
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3EF8987F0000;cSHVariant { -> F}

class __DLL_EXPORT__ cVarDef 
{
  //## begin cVarDef%3E0032230357.initialDeclarations preserve=yes
public:
  //## end cVarDef%3E0032230357.initialDeclarations

    //## Constructors (generated)
      cVarDef();

      cVarDef(const cVarDef &right);

    //## Constructors (specified)
      //## Operation: cVarDef%1040992373
      cVarDef (CONST_STRING_T var_name, UCHAR_T data_type, ULONG_T length = 1, UCHAR_T precision = 0);

    //## Destructor (generated)
      virtual ~cVarDef();


    //## Other Operations (specified)
      //## Operation: DataType%1061805340
      UCHAR_T DataType ();

      //## Operation: GetPos%1040202763
      //	This method check the indices against the variable
      //	declaration and returns the position in the element
      //	array.
      ULONG_T GetPos (LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4);

      //## Operation: GetIndices%1040202764
      void GetIndices (ULONG_T pos, LONG_T &i1, LONG_T &i2, LONG_T &i3, LONG_T &i4);

      //## Operation: AddDim%1040209222
      void AddDim (ULONG_T pos, ULONG_T dim_size);

      //## Operation: SetFilter%1040209223
      void SetFilter (cFuncRef *filter_func);

      //## Operation: SetMapping%1040209224
      void SetMapping (cMapping *mapping);

      //## Operation: Dims%1040209225
      ULONG_T Dims ();

      //## Operation: DimSize%1040209226
      ULONG_T DimSize (ULONG_T pos);

      //## Operation: Elements%1040209227
      ULONG_T Elements ();

      //## Operation: ElementSize%1042559818
      ULONG_T ElementSize ();

      //## Operation: Serialize%1049277232
      STRING_T Serialize ();

      //## Operation: Construct%1049277233
      void Construct (CONST_STRING_T serialized_obj);

    // Data Members for Class Attributes

      //## Attribute: DriverName%3E22C9220065
      //## begin cVarDef::DriverName%3E22C9220065.attr preserve=no  public: STRING_T {U} 
      STRING_T _DriverName;
      //## end cVarDef::DriverName%3E22C9220065.attr

      //## Attribute: VarName%3E00545502FB
      //## begin cVarDef::VarName%3E00545502FB.attr preserve=no  public: STRING_T {U} 
      STRING_T _VarName;
      //## end cVarDef::VarName%3E00545502FB.attr

      //## Attribute: DataType%3E00540B01BE
      //## begin cVarDef::DataType%3E00540B01BE.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _DataType;
      //## end cVarDef::DataType%3E00540B01BE.attr

      //## Attribute: Length%3E0CA3FC0070
      //## begin cVarDef::Length%3E0CA3FC0070.attr preserve=no  public: ULONG_T {U} 1
      ULONG_T _Length;
      //## end cVarDef::Length%3E0CA3FC0070.attr

      //## Attribute: Precision%3E0CA4180175
      //## begin cVarDef::Precision%3E0CA4180175.attr preserve=no  public: UCHAR_T {U} 0
      UCHAR_T _Precision;
      //## end cVarDef::Precision%3E0CA4180175.attr

      //## Attribute: VarType%3E101AFC0034
      //## begin cVarDef::VarType%3E101AFC0034.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _VarType;
      //## end cVarDef::VarType%3E101AFC0034.attr

      //## Attribute: PersistenceType%3EAFEBA30261
      //## begin cVarDef::PersistenceType%3EAFEBA30261.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _PersistenceType;
      //## end cVarDef::PersistenceType%3EAFEBA30261.attr

      //## Attribute: FileType%3E101B1901DA
      //## begin cVarDef::FileType%3E101B1901DA.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _FileType;
      //## end cVarDef::FileType%3E101B1901DA.attr

      //## Attribute: Description%3EAFEB8B006D
      //## begin cVarDef::Description%3EAFEB8B006D.attr preserve=no  public: STRING_T {U} 
      STRING_T _Description;
      //## end cVarDef::Description%3EAFEB8B006D.attr

      //## Attribute: RefreshType%3EAFF030009C
      //## begin cVarDef::RefreshType%3EAFF030009C.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _RefreshType;
      //## end cVarDef::RefreshType%3EAFF030009C.attr

      //## Attribute: RefreshValue%3EAFF0440222
      //## begin cVarDef::RefreshValue%3EAFF0440222.attr preserve=no  public: LONG_T {U} -1
      LONG_T _RefreshValue;
      //## end cVarDef::RefreshValue%3EAFF0440222.attr

    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E0032500226
      //## Role: cVarDef::Variable%3E0032510083
      //## begin cVarDef::Variable%3E0032510083.role preserve=no  public: cVariable {1 -> 1RFHN}
      cVariable *_Variable;
      //## end cVarDef::Variable%3E0032510083.role

      //## Association: System::Database::<unnamed>%3E07379A01A6
      //## Role: cVarDef::Context%3E07379B0144
      //## begin cVarDef::Context%3E07379B0144.role preserve=no  public: cContext {0..n -> 1RFHN}
      cContext *_Context;
      //## end cVarDef::Context%3E07379B0144.role

      //## Association: System::Database::<unnamed>%3E0054F60049
      //## Role: cVarDef::Mapping%3E0054F6032E
      //## begin cVarDef::Mapping%3E0054F6032E.role preserve=no  public: cMapping { -> 0..1RFHN}
      cMapping *_Mapping;
      //## end cVarDef::Mapping%3E0054F6032E.role

  public:
    // Additional Public Declarations
      //## begin cVarDef%3E0032230357.public preserve=yes
      //## end cVarDef%3E0032230357.public

  protected:
    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E0054EC02E4
      //## Role: cVarDef::Filter%3E0054ED0322
      //## begin cVarDef::Filter%3E0054ED0322.role preserve=no  public: cFuncRef { -> 0..1RFHN}
      cFuncRef *_Filter;
      //## end cVarDef::Filter%3E0054ED0322.role

    // Additional Protected Declarations
      //## begin cVarDef%3E0032230357.protected preserve=yes
      //## end cVarDef%3E0032230357.protected

  private:
    // Additional Private Declarations
      //## begin cVarDef%3E0032230357.private preserve=yes
      //## end cVarDef%3E0032230357.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Dims%3E005437029E
      //## begin cVarDef::Dims%3E005437029E.attr preserve=no  implementation: ULONG_VECTOR_T {U} 
      ULONG_VECTOR_T _Dims;
      //## end cVarDef::Dims%3E005437029E.attr

    // Additional Implementation Declarations
      //## begin cVarDef%3E0032230357.implementation preserve=yes
      //## end cVarDef%3E0032230357.implementation

};

//## begin cVarDef%3E0032230357.postscript preserve=yes
//## end cVarDef%3E0032230357.postscript

// Class cVarDef 

//## begin module%3E0032230357.epilog preserve=yes
//## end module%3E0032230357.epilog


#endif
