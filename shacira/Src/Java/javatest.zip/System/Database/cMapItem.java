//## begin module%3E101DEA0119.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E101DEA0119.cm

//## begin module%3E101DEA0119.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E101DEA0119.cp

//## Module: cMapItem%3E101DEA0119; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cMapItem.cpp

//## begin module%3E101DEA0119.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E101DEA0119.additionalIncludes

//## begin module%3E101DEA0119.includes preserve=yes
//## end module%3E101DEA0119.includes

// cVarDef
#include "System/Database/cVarDef.h"
// cMapItem
#include "System/Database/cMapItem.h"
// cDataObject
#include "Control/LocalDatabase/cDataObject.h"
//## begin module%3E101DEA0119.additionalDeclarations preserve=yes
//## end module%3E101DEA0119.additionalDeclarations


// Class cMapItem 











cMapItem::cMapItem()
  //## begin cMapItem::cMapItem%.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _Address(0), _BitPos(-1), _VarPos(-1), _ObjectSize(4), _IsAddressMapped(true), _VarDef(NULL), _DataObject(NULL)
  //## end cMapItem::cMapItem%.hasinit
  //## begin cMapItem::cMapItem%.initialization preserve=yes
  //## end cMapItem::cMapItem%.initialization
{
  //## begin cMapItem::cMapItem%.body preserve=yes
  //## end cMapItem::cMapItem%.body
}

cMapItem::cMapItem(const cMapItem &right)
  //## begin cMapItem::cMapItem%copy.hasinit preserve=no
      : _DataType(UNDEFINED), _Length(1), _Address(0), _BitPos(-1), _VarPos(-1), _ObjectSize(4), _IsAddressMapped(true), _VarDef(NULL), _DataObject(NULL)
  //## end cMapItem::cMapItem%copy.hasinit
  //## begin cMapItem::cMapItem%copy.initialization preserve=yes
  //## end cMapItem::cMapItem%copy.initialization
{
  //## begin cMapItem::cMapItem%copy.body preserve=yes
   _DataType = right._DataType;
   _Address = right._Address;
   _BitPos = right._BitPos;
   _VarPos = right._VarPos;
   _VarDef = right._VarDef;
   _ObjectSize = right._ObjectSize;
   _DataObject = NULL;
  //## end cMapItem::cMapItem%copy.body
}


cMapItem::~cMapItem()
{
  //## begin cMapItem::~cMapItem%.body preserve=yes
  //## end cMapItem::~cMapItem%.body
}


// Additional Declarations
  //## begin cMapItem%3E101DEA0119.declarations preserve=yes
  //## end cMapItem%3E101DEA0119.declarations

//## begin module%3E101DEA0119.epilog preserve=yes
//## end module%3E101DEA0119.epilog
