//## begin module%3E101DEA0119.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E101DEA0119.cm

//## begin module%3E101DEA0119.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E101DEA0119.cp

//## Module: cMapItem%3E101DEA0119; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cMapItem.h

#ifndef cMapItem_h
#define cMapItem_h 1

//## begin module%3E101DEA0119.includes preserve=yes
//## end module%3E101DEA0119.includes


class __DLL_EXPORT__ cVarDef;
class __DLL_EXPORT__ cDataObject;

//## begin module%3E101DEA0119.additionalDeclarations preserve=yes
//## end module%3E101DEA0119.additionalDeclarations


//## begin cMapItem%3E101DEA0119.preface preserve=yes
//## end cMapItem%3E101DEA0119.preface

//## Class: cMapItem%3E101DEA0119
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class __DLL_EXPORT__ cMapItem 
{
  //## begin cMapItem%3E101DEA0119.initialDeclarations preserve=yes
public:
  //## end cMapItem%3E101DEA0119.initialDeclarations

    //## Constructors (generated)
      cMapItem();

      cMapItem(const cMapItem &right);

    //## Destructor (generated)
      virtual ~cMapItem();

    // Data Members for Class Attributes

      //## Attribute: DataType%3E101E1E02EA
      //## begin cMapItem::DataType%3E101E1E02EA.attr preserve=no  public: UCHAR_T {U} UNDEFINED
      UCHAR_T _DataType;
      //## end cMapItem::DataType%3E101E1E02EA.attr

      //## Attribute: Length%3E22AE0D01F7
      //## begin cMapItem::Length%3E22AE0D01F7.attr preserve=no  public: ULONG_T {U} 1
      ULONG_T _Length;
      //## end cMapItem::Length%3E22AE0D01F7.attr

      //## Attribute: Name%3E101E5F02B1
      //## begin cMapItem::Name%3E101E5F02B1.attr preserve=no  public: STRING_T {U} 
      STRING_T _Name;
      //## end cMapItem::Name%3E101E5F02B1.attr

      //## Attribute: Address%3E101E960170
      //## begin cMapItem::Address%3E101E960170.attr preserve=no  public: ULONG_T {U} 0
      ULONG_T _Address;
      //## end cMapItem::Address%3E101E960170.attr

      //## Attribute: BitPos%3E104C7800C6
      //## begin cMapItem::BitPos%3E104C7800C6.attr preserve=no  public: CHAR_T {U} -1
      CHAR_T _BitPos;
      //## end cMapItem::BitPos%3E104C7800C6.attr

      //## Attribute: VarPos%3E1EF13E015B
      //## begin cMapItem::VarPos%3E1EF13E015B.attr preserve=no  public: LONG_T {U} -1
      LONG_T _VarPos;
      //## end cMapItem::VarPos%3E1EF13E015B.attr

      //## Attribute: ObjectSize%3E23021A00F2
      //## begin cMapItem::ObjectSize%3E23021A00F2.attr preserve=no  public: ULONG_T {U} 4
      ULONG_T _ObjectSize;
      //## end cMapItem::ObjectSize%3E23021A00F2.attr

      //## Attribute: IsAddressMapped%3E23C68800FD
      //## begin cMapItem::IsAddressMapped%3E23C68800FD.attr preserve=no  public: BOOL_T {U} true
      BOOL_T _IsAddressMapped;
      //## end cMapItem::IsAddressMapped%3E23C68800FD.attr

    // Data Members for Associations

      //## Association: Control::LocalDatabase::<unnamed>%3E1EFE9100E8
      //## Role: cMapItem::VarDef%3E1EFE9502D8
      //## begin cMapItem::VarDef%3E1EFE9502D8.role preserve=no  public: cVarDef { -> 1RFHN}
      cVarDef *_VarDef;
      //## end cMapItem::VarDef%3E1EFE9502D8.role

      //## Association: Control::LocalDatabase::<unnamed>%3E1EFCDB01A6
      //## Role: cMapItem::DataObject%3E1EFCDC0040
      //## begin cMapItem::DataObject%3E1EFCDC0040.role preserve=no  public: cDataObject {1 -> 1RFHN}
      cDataObject *_DataObject;
      //## end cMapItem::DataObject%3E1EFCDC0040.role

  public:
    // Additional Public Declarations
      //## begin cMapItem%3E101DEA0119.public preserve=yes
      //## end cMapItem%3E101DEA0119.public

  protected:
    // Additional Protected Declarations
      //## begin cMapItem%3E101DEA0119.protected preserve=yes
      //## end cMapItem%3E101DEA0119.protected

  private:
    // Additional Private Declarations
      //## begin cMapItem%3E101DEA0119.private preserve=yes
      //## end cMapItem%3E101DEA0119.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin cMapItem%3E101DEA0119.implementation preserve=yes
      //## end cMapItem%3E101DEA0119.implementation

};

//## begin cMapItem%3E101DEA0119.postscript preserve=yes
//## end cMapItem%3E101DEA0119.postscript

// Class cMapItem 

//## begin module%3E101DEA0119.epilog preserve=yes
//## end module%3E101DEA0119.epilog


#endif
