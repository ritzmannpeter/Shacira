//## begin module%3C7E428400AB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C7E428400AB.cm

//## begin module%3C7E428400AB.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C7E428400AB.cp

//## Module: cFuncRef%3C7E428400AB; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cFuncRef.cpp

//## begin module%3C7E428400AB.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C7E428400AB.additionalIncludes

//## begin module%3C7E428400AB.includes preserve=yes
#include "System/Database/FuncSpecs.h"
//## end module%3C7E428400AB.includes

// cBlockBuffer
#include "System/Memory/cBlockBuffer.h"
// cFuncDecl
#include "System/Database/cFuncDecl.h"
// cFuncRef
#include "System/Database/cFuncRef.h"
// cContext
#include "System/Database/cContext.h"
// cSHVariant
#include "System/Database/cSHVariant.h"
//## begin module%3C7E428400AB.additionalDeclarations preserve=yes

#define PUSH_PARAMS(ap) \
LONG_T lvalue = 0; \
FLOAT_T fvalue = 0; \
DOUBLE_T dvalue = 0; \
CONST_STRING_T svalue = ""; \
STRING_T _svalue = ""; \
CONST_WSTRING_T wvalue = L""; \
WSTRING_T _wvalue = L""; \
cBlockBuffer buf; \
for (unsigned long i=0; i<_FuncDecl->Params(); i++) { \
	int type = _FuncDecl->ParamType(i); \
   switch (type) { \
   case SH_CHAR: \
   case SH_UCHAR: \
   case SH_SHORT: \
   case SH_USHORT: \
   case SH_LONG: \
   case SH_ULONG: \
      _ParamVec[i]->GetValue(lvalue); \
      va_arg(ap, LONG_T) = lvalue; \
      break; \
   case SH_FLOAT: \
      _ParamVec[i]->GetValue(dvalue); \
		fvalue = dvalue; \
      va_arg(ap, FLOAT_T) = fvalue; \
      break; \
   case SH_DOUBLE: \
      _ParamVec[i]->GetValue(dvalue); \
      va_arg(ap, DOUBLE_T) = dvalue; \
      break; \
   case SH_STRING: \
      _ParamVec[i]->GetValue(_svalue); \
      svalue = (CONST_STRING_T)buf.AllocString(_svalue.c_str()); \
      va_arg(ap, CONST_STRING_T) = svalue; \
      break; \
   default: \
      throw cError(FUNCREF_PARAMETER_TYPE_NOT_SUPPORTED, 0, cSHVariant::TypeName(type).c_str()); \
      break; \
   } \
}

//## end module%3C7E428400AB.additionalDeclarations


// Class cFuncRef 









cFuncRef::cFuncRef()
  //## begin cFuncRef::cFuncRef%.hasinit preserve=no
      : _FuncDecl(NULL), _Context(NULL)
  //## end cFuncRef::cFuncRef%.hasinit
  //## begin cFuncRef::cFuncRef%.initialization preserve=yes
  //## end cFuncRef::cFuncRef%.initialization
{
  //## begin cFuncRef::cFuncRef%.body preserve=yes
  //## end cFuncRef::cFuncRef%.body
}

cFuncRef::cFuncRef(const cFuncRef &right)
  //## begin cFuncRef::cFuncRef%copy.hasinit preserve=no
      : _FuncDecl(NULL), _Context(NULL)
  //## end cFuncRef::cFuncRef%copy.hasinit
  //## begin cFuncRef::cFuncRef%copy.initialization preserve=yes
  //## end cFuncRef::cFuncRef%copy.initialization
{
  //## begin cFuncRef::cFuncRef%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cFuncRef::cFuncRef%copy.body
}

cFuncRef::cFuncRef (cFuncDecl *func_decl, cContext *context)
  //## begin cFuncRef::cFuncRef%1040202772.hasinit preserve=no
      : _FuncDecl(NULL), _Context(NULL)
  //## end cFuncRef::cFuncRef%1040202772.hasinit
  //## begin cFuncRef::cFuncRef%1040202772.initialization preserve=yes
  //## end cFuncRef::cFuncRef%1040202772.initialization
{
  //## begin cFuncRef::cFuncRef%1040202772.body preserve=yes
_ASSERT_COND(context != NULL)
	_Context = context;
	_FuncDecl = func_decl;
   _Name = _FuncDecl->_FuncName;
  //## end cFuncRef::cFuncRef%1040202772.body
}


cFuncRef::~cFuncRef()
{
  //## begin cFuncRef::~cFuncRef%.body preserve=yes
  //## end cFuncRef::~cFuncRef%.body
}



//## Other Operations (implementation)
cFuncDecl * cFuncRef::FuncDecl ()
{
  //## begin cFuncRef::FuncDecl%1061797998.body preserve=yes
   return _FuncDecl;
  //## end cFuncRef::FuncDecl%1061797998.body
}

UCHAR_T cFuncRef::DataType ()
{
  //## begin cFuncRef::DataType%1061798000.body preserve=yes
   return _FuncDecl->DataType();
  //## end cFuncRef::DataType%1061798000.body
}

void cFuncRef::SetParam (ULONG_T pos, cArgument *param)
{
  //## begin cFuncRef::SetParam%1040202773.body preserve=yes
   if (pos >= _ParamVec.size()) _ParamVec.resize(pos+1);
   _ParamVec[pos] = param;
  //## end cFuncRef::SetParam%1040202773.body
}

ULONG_T cFuncRef::Params ()
{
  //## begin cFuncRef::Params%1040202774.body preserve=yes
   return _ParamVec.size();
  //## end cFuncRef::Params%1040202774.body
}

void cFuncRef::GetValue (STRING_T &value, CONST_STRING_T input)
{
  //## begin cFuncRef::GetValue%1040202778.body preserve=yes
	value = "";
	char temp_buf[256] = {0};
	LONG_T lvalue = 0;
	FLOAT_T fvalue = 0;
   DOUBLE_T dvalue = 0;
   STRING_T svalue;
   WSTRING_T wsvalue;
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   UCHAR_T value_type = _FuncDecl->_DataType;
   switch (value_type) {
	case SH_VOID: CallVoidFunc(input); break;
   case SH_CHAR:
   case SH_UCHAR:
   case SH_SHORT:
   case SH_USHORT:
   case SH_LONG:
   case SH_ULONG:
		lvalue = CallLongFunc(input);
		sprintf(temp_buf, "%d", lvalue);
		value = temp_buf;
		break;
   case SH_FLOAT:
		fvalue = CallFloatFunc(input);
		sprintf(temp_buf, "%f", fvalue);
		value = temp_buf;
		break;
   case SH_DOUBLE:
		dvalue = CallDoubleFunc(input);
		sprintf(temp_buf, "%f", fvalue);
		value = temp_buf;
		break;
   case SH_STRING:
		svalue = CallStringFunc(input);
		value = svalue;
		break;
   case SH_WSTRING:
		wsvalue = CallWStringFunc(input);
      value = cSHVariant::Wide2String(wsvalue.c_str());
		break;
	}
  //## end cFuncRef::GetValue%1040202778.body
}

void cFuncRef::GetValue (LONG_T &value, CONST_STRING_T input)
{
  //## begin cFuncRef::GetValue%1040202779.body preserve=yes
	value = 0;
	LONG_T lvalue = 0;
	FLOAT_T fvalue = 0;
   DOUBLE_T dvalue = 0;
   STRING_T svalue;
   WSTRING_T wsvalue;
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   UCHAR_T value_type = _FuncDecl->_DataType;
   switch (value_type) {
	case SH_VOID: CallVoidFunc(input); break;
   case SH_CHAR:
   case SH_UCHAR:
   case SH_SHORT:
   case SH_USHORT:
   case SH_LONG:
   case SH_ULONG:
		lvalue = CallLongFunc(input);
		value = lvalue;
		break;
   case SH_FLOAT:
		fvalue = CallFloatFunc(input);
		value = fvalue;
		break;
   case SH_DOUBLE:
		dvalue = CallDoubleFunc(input);
		value = dvalue;
		break;
   case SH_STRING:
		svalue = CallStringFunc(input);
		value = atol(svalue.c_str());
		break;
   case SH_WSTRING:
		wsvalue = CallWStringFunc(input);
		// ??
		break;
	}
  //## end cFuncRef::GetValue%1040202779.body
}

void cFuncRef::GetValue (DOUBLE_T &value, CONST_STRING_T input)
{
  //## begin cFuncRef::GetValue%1040202780.body preserve=yes
	value = 0;
	LONG_T lvalue = 0;
	FLOAT_T fvalue = 0;
   DOUBLE_T dvalue = 0;
   STRING_T svalue;
   WSTRING_T wsvalue;
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   UCHAR_T value_type = _FuncDecl->_DataType;
   switch (value_type) {
	case SH_VOID: CallVoidFunc(input); break;
   case SH_CHAR:
   case SH_UCHAR:
   case SH_SHORT:
   case SH_USHORT:
   case SH_LONG:
   case SH_ULONG:
		lvalue = CallLongFunc(input);
		value = lvalue;
		break;
   case SH_FLOAT:
		fvalue = CallFloatFunc(input);
		value = fvalue;
		break;
   case SH_DOUBLE:
		dvalue = CallDoubleFunc(input);
		value = dvalue;
		break;
   case SH_STRING:
		svalue = CallStringFunc(input);
		value = atol(svalue.c_str());
		break;
   case SH_WSTRING:
		wsvalue = CallWStringFunc(input);
		// ??
		break;
	}
  //## end cFuncRef::GetValue%1040202780.body
}

void cFuncRef::CallVoidFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallVoidFunc%1050565120.body preserve=yes
   VOID_FUNC_T func = (VOID_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
   PUSH_PARAMS(ap)
   func(params.stack);
  //## end cFuncRef::CallVoidFunc%1050565120.body
}

LONG_T cFuncRef::CallLongFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallLongFunc%1050565121.body preserve=yes
   LONG_FUNC_T func = (LONG_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
   PUSH_PARAMS(ap)
   LONG_T value = func(params.stack);
	return value;
  //## end cFuncRef::CallLongFunc%1050565121.body
}

FLOAT_T cFuncRef::CallFloatFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallFloatFunc%1050565122.body preserve=yes
   FLOAT_FUNC_T func = (FLOAT_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
   PUSH_PARAMS(ap)
   FLOAT_T value = func(params.stack);
	return value;
  //## end cFuncRef::CallFloatFunc%1050565122.body
}

DOUBLE_T cFuncRef::CallDoubleFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallDoubleFunc%1050565123.body preserve=yes
   DOUBLE_FUNC_T func = (DOUBLE_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
   PUSH_PARAMS(ap)
   DOUBLE_T value = func(params.stack);
	return value;
  //## end cFuncRef::CallDoubleFunc%1050565123.body
}

STRING_T cFuncRef::CallStringFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallStringFunc%1050565124.body preserve=yes
   STRING_FUNC_T func = (STRING_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
	PUSH_PARAMS(ap)
   STRING_T value = func(params.stack);
	return value;
  //## end cFuncRef::CallStringFunc%1050565124.body
}

WSTRING_T cFuncRef::CallWStringFunc (CONST_STRING_T input)
{
  //## begin cFuncRef::CallWStringFunc%1050565125.body preserve=yes
   WSTRING_FUNC_T func = (WSTRING_FUNC_T)GetClientFuncAddr(_Name.c_str());
	if (func == NULL) throw cError(FUNCREF_FUNCTION_NOT_RESOLVED, 0, _Name.c_str());
	UCHAR_T func_class = _FuncDecl->_FuncClass;
   PARAMS params;
   va_list ap;
   va_start(ap,params.start_of_struct);
   va_arg(ap, cContext*) = _Context;
	if (input != NULL) {
      va_arg(ap, const char *) = input;
	}
   PUSH_PARAMS(ap)
   WSTRING_T value = func(params.stack);
	return value;
  //## end cFuncRef::CallWStringFunc%1050565125.body
}

// Additional Declarations
  //## begin cFuncRef%3C7E428400AB.declarations preserve=yes
  //## end cFuncRef%3C7E428400AB.declarations

//## begin module%3C7E428400AB.epilog preserve=yes
//## end module%3C7E428400AB.epilog
