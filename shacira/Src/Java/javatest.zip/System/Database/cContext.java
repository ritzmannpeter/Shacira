//## begin module%3E0031DC0265.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E0031DC0265.cm

//## begin module%3E0031DC0265.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E0031DC0265.cp

//## Module: cContext%3E0031DC0265; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cContext.cpp

//## begin module%3E0031DC0265.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E0031DC0265.additionalIncludes

//## begin module%3E0031DC0265.includes preserve=yes
//## end module%3E0031DC0265.includes

// cSHProcess
#include "System/Process/cSHProcess.h"
// cConfigurationObject
#include "System/Config/cConfigurationObject.h"
// cFuncDecl
#include "System/Database/cFuncDecl.h"
// cFuncRef
#include "System/Database/cFuncRef.h"
// cVarRef
#include "System/Database/cVarRef.h"
// cVarDef
#include "System/Database/cVarDef.h"
// cContext
#include "System/Database/cContext.h"
// cVariable
#include "System/Database/cVariable.h"
// cFile
#include "System/Sys/cFile.h"
// cFileSystemUtils
#include "System/Sys/cFileSystemUtils.h"
// cControlStartCondition
#include "System/PLC/cControlStartCondition.h"
// cControlProcedure
#include "System/PLC/cControlProcedure.h"
// cControlProgram
#include "System/PLC/cControlProgram.h"
// cControlState
#include "System/PLC/cControlState.h"
// cAdapter
#include "System/Channel/cAdapter.h"
// cStyxParser
#include "Language/cStyxParser.h"
//## begin module%3E0031DC0265.additionalDeclarations preserve=yes
//## end module%3E0031DC0265.additionalDeclarations


// Class cContext 




















cContext::cContext()
  //## begin cContext::cContext%.hasinit preserve=no
      : _Created(false), _Process(NULL)
  //## end cContext::cContext%.hasinit
  //## begin cContext::cContext%.initialization preserve=yes
  //## end cContext::cContext%.initialization
{
  //## begin cContext::cContext%.body preserve=yes
  //## end cContext::cContext%.body
}

cContext::cContext(const cContext &right)
  //## begin cContext::cContext%copy.hasinit preserve=no
      : _Created(false), _Process(NULL)
  //## end cContext::cContext%copy.hasinit
  //## begin cContext::cContext%copy.initialization preserve=yes
  //## end cContext::cContext%copy.initialization
{
  //## begin cContext::cContext%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cContext::cContext%copy.body
}

cContext::cContext (cSHProcess *process)
  //## begin cContext::cContext%1054890583.hasinit preserve=no
      : _Created(false), _Process(NULL)
  //## end cContext::cContext%1054890583.hasinit
  //## begin cContext::cContext%1054890583.initialization preserve=yes
  //## end cContext::cContext%1054890583.initialization
{
  //## begin cContext::cContext%1054890583.body preserve=yes
   _Process = process;
  //## end cContext::cContext%1054890583.body
}


cContext::~cContext()
{
  //## begin cContext::~cContext%.body preserve=yes
  //## end cContext::~cContext%.body
}



//## Other Operations (implementation)
void cContext::Search (cContext *context)
{
  //## begin cContext::Search%1050753126.body preserve=yes
	_SearchContexts[context->_Name.c_str()] = context;
  //## end cContext::Search%1050753126.body
}

void cContext::Parse (CONST_STRING_T source)
{
  //## begin cContext::Parse%1042447636.body preserve=yes
   STRING_T file = cFileSystemUtils::FullPath(source);
   if (!cFileSystemUtils::FileExists(file.c_str())) {
      throw cError(CONFIG_FILE_NOT_FOUND, 0, file.c_str());
   }
   cStyxParser parser;
   parser.ParseDatabaseFromFile(this, file.c_str());
  //## end cContext::Parse%1042447636.body
}

void cContext::LoadSymbols (CONST_STRING_T symbol_file)
{
  //## begin cContext::LoadSymbols%1054726255.body preserve=yes
   cFile file(symbol_file);
   if (!file.Exists()) throw cError(FILE_NOT_FOUND, 0, symbol_file);
   file.Open(ACCESS_READ_ONLY);
   STRING_T line;
   char symbol[512];
   LONG_T definition = 0;
   while (file.ReadLine(line)) {
      if (line.size() > 0) {
         memset(symbol, 0, sizeof(symbol));
         int params = sscanf(line.c_str(), "#define %s %x", symbol, &definition);
         if (params == 2) {
            AddSymbolValue(symbol, definition);
         } else {
            params = sscanf(line.c_str(), "#define %s %d", symbol, &definition);
            if (params == 2) {
               AddSymbolValue(symbol, definition);
            }
         }
      }
   }
  //## end cContext::LoadSymbols%1054726255.body
}

void cContext::AddSymbolValue (CONST_STRING_T symbol, LONG_T symbol_value)
{
  //## begin cContext::AddSymbolValue%1050432222.body preserve=yes
	_Symbols[symbol] = symbol_value;
  //## end cContext::AddSymbolValue%1050432222.body
}

LONG_T cContext::SymbolValue (CONST_STRING_T symbol)
{
  //## begin cContext::SymbolValue%1041261887.body preserve=yes
	LONG_MAP_T::const_iterator i = _Symbols.find(symbol);
	if (i == _Symbols.end()) {
		return UNDEFINED_SYMBOL_VALUE;
	} else {
		return (*i).second;
	}
  //## end cContext::SymbolValue%1041261887.body
}

cVarRef * cContext::VarRef (CONST_STRING_T spec)
{
  //## begin cContext::VarRef%1050417247.body preserve=yes
   cStyxParser parser;
   cVarRef * var_ref = parser.VarRef(this, spec);
	return var_ref;
  //## end cContext::VarRef%1050417247.body
}

cFuncRef * cContext::FuncRef (CONST_STRING_T spec)
{
  //## begin cContext::FuncRef%1050417248.body preserve=yes
   cStyxParser parser;
   cFuncRef * func_ref = parser.FuncRef(this, spec);
	return func_ref;
  //## end cContext::FuncRef%1050417248.body
}

void cContext::AddFuncDecl (CONST_STRING_T func_name, cFuncDecl *func_decl)
{
  //## begin cContext::AddFuncDecl%1040992370.body preserve=yes
   _FuncDecls[func_name] = func_decl;
  //## end cContext::AddFuncDecl%1040992370.body
}

void cContext::AddVarDef (CONST_STRING_T var_name, cVarDef *var_def)
{
  //## begin cContext::AddVarDef%1040992371.body preserve=yes
   _VarDefs[var_name] = var_def;
  //## end cContext::AddVarDef%1040992371.body
}

void cContext::AddControlState (CONST_STRING_T state_name, cControlState *state)
{
  //## begin cContext::AddControlState%1060682986.body preserve=yes
   _States[state_name] = state;
   cVarDef * var_def = state->VarDef();
   if (var_def != NULL) {
      AddVarDef(state_name, var_def);
   }
  //## end cContext::AddControlState%1060682986.body
}

void cContext::AddControlProgram (CONST_STRING_T program_name, cControlProgram *program)
{
  //## begin cContext::AddControlProgram%1060682987.body preserve=yes
   _Programs[program_name] = program;
  //## end cContext::AddControlProgram%1060682987.body
}

void cContext::AddControlProcedure (CONST_STRING_T procedure_name, cControlProcedure *proc)
{
  //## begin cContext::AddControlProcedure%1060682988.body preserve=yes
   _Procedures[procedure_name] = proc;
  //## end cContext::AddControlProcedure%1060682988.body
}

void cContext::AddControlStartCondition (CONST_STRING_T condition_name, cControlStartCondition *cond)
{
  //## begin cContext::AddControlStartCondition%1060682989.body preserve=yes
   _StartConditions[condition_name] = cond;
  //## end cContext::AddControlStartCondition%1060682989.body
}

void cContext::AddAdapter (CONST_STRING_T name, cAdapter *adapter)
{
  //## begin cContext::AddAdapter%1052744775.body preserve=yes
   _Adapters[name] = adapter;
  //## end cContext::AddAdapter%1052744775.body
}

cAdapter * cContext::Adapter (CONST_STRING_T name)
{
  //## begin cContext::Adapter%1052744776.body preserve=yes
   ADAPTER_MAP_T::const_iterator i = _Adapters.find(name);
   if (i == _Adapters.end()) {
      return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::Adapter%1052744776.body
}

void cContext::FuncDecls (STRING_LIST_T &func_names)
{
  //## begin cContext::FuncDecls%1042459997.body preserve=yes
   std::map<STRING_T, cFuncDecl*>::const_iterator i = _FuncDecls.begin();
   while (i != _FuncDecls.end()) {
      cFuncDecl * func_decl = (*i).second;
      func_names.push_back(func_decl->_FuncName.c_str());
      i++;
   }
  //## end cContext::FuncDecls%1042459997.body
}

cFuncDecl * cContext::FuncDecl (CONST_STRING_T func_name)
{
  //## begin cContext::FuncDecl%1040992359.body preserve=yes
   std::map<STRING_T, cFuncDecl*>::const_iterator i = _FuncDecls.find(func_name);
   if (i == _FuncDecls.end()) {
      return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::FuncDecl%1040992359.body
}

void cContext::VarDefs (STRING_LIST_T &var_names)
{
  //## begin cContext::VarDefs%1042459998.body preserve=yes
   std::map<STRING_T, cVarDef*>::const_iterator i = _VarDefs.begin();
   while (i != _VarDefs.end()) {
      cVarDef * var_def = (*i).second;
      var_names.push_back(var_def->_VarName.c_str());
      i++;
   }
  //## end cContext::VarDefs%1042459998.body
}

cVarDef * cContext::VarDef (CONST_STRING_T var_name)
{
  //## begin cContext::VarDef%1040992360.body preserve=yes
   std::map<STRING_T, cVarDef*>::const_iterator i = _VarDefs.find(var_name);
   if (i == _VarDefs.end()) {
	   std::map<STRING_T, cContext*>::const_iterator j = _SearchContexts.begin();
		while (j != _SearchContexts.end()) {
			cVarDef * var_def = (*j).second->VarDef(var_name);
			if (var_def != NULL) return var_def;
			j++;
		}
		return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::VarDef%1040992360.body
}

cVariable * cContext::Variable (CONST_STRING_T var_name)
{
  //## begin cContext::Variable%1042648651.body preserve=yes
   cVarDef * var_def = VarDef(var_name);
   if (var_def == NULL) return NULL;
   return var_def->_Variable;;
  //## end cContext::Variable%1042648651.body
}

void cContext::GetValue (CONST_STRING_T var_name, STRING_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::GetValue%1041514715.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) {
      throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   } else {
      variable->GetValue(value, i1, i2, i3, i4);
   }
  //## end cContext::GetValue%1041514715.body
}

void cContext::GetValue (CONST_STRING_T var_name, LONG_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::GetValue%1041514716.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   variable->GetValue(value, i1, i2, i3, i4);
  //## end cContext::GetValue%1041514716.body
}

void cContext::GetValue (CONST_STRING_T var_name, DOUBLE_T &value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::GetValue%1041514717.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   variable->GetValue(value, i1, i2, i3, i4);
  //## end cContext::GetValue%1041514717.body
}

void cContext::SetValue (CONST_STRING_T var_name, CONST_STRING_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::SetValue%1041514718.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   variable->SetValue(value, i1, i2, i3, i4);
  //## end cContext::SetValue%1041514718.body
}

void cContext::SetValue (CONST_STRING_T var_name, LONG_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::SetValue%1041514719.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   variable->SetValue(value, i1, i2, i3, i4);
  //## end cContext::SetValue%1041514719.body
}

void cContext::SetValue (CONST_STRING_T var_name, DOUBLE_T value, LONG_T i1, LONG_T i2, LONG_T i3, LONG_T i4)
{
  //## begin cContext::SetValue%1041514720.body preserve=yes
   cVariable * variable = Variable(var_name);
   if (variable == NULL) throw cError(VARIABLE_NOT_FOUND, 0, var_name);
   variable->SetValue(value, i1, i2, i3, i4);
  //## end cContext::SetValue%1041514720.body
}

void cContext::States (STRING_LIST_T &state_names)
{
  //## begin cContext::States%1060691311.body preserve=yes
   std::map<STRING_T, cControlState*>::const_iterator i = _States.begin();
   while (i != _States.end()) {
      cControlState * state = (*i).second;
      state_names.push_back(state->_StateName.c_str());
      i++;
   }
  //## end cContext::States%1060691311.body
}

cControlState * cContext::State (CONST_STRING_T state_name)
{
  //## begin cContext::State%1060691312.body preserve=yes
   std::map<STRING_T, cControlState*>::const_iterator i = _States.find(state_name);
   if (i == _States.end()) {
		return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::State%1060691312.body
}

void cContext::Programs (STRING_LIST_T &program_names)
{
  //## begin cContext::Programs%1060691313.body preserve=yes
   std::map<STRING_T, cControlProgram*>::const_iterator i = _Programs.begin();
   while (i != _Programs.end()) {
      cControlProgram * program = (*i).second;
      program_names.push_back(program->Name().c_str());
      i++;
   }
  //## end cContext::Programs%1060691313.body
}

cControlProgram * cContext::Program (CONST_STRING_T prog_name)
{
  //## begin cContext::Program%1060691314.body preserve=yes
   std::map<STRING_T, cControlProgram*>::const_iterator i = _Programs.find(prog_name);
   if (i == _Programs.end()) {
		return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::Program%1060691314.body
}

void cContext::Procedures (STRING_LIST_T &proc_names)
{
  //## begin cContext::Procedures%1060691315.body preserve=yes
   std::map<STRING_T, cControlProcedure*>::const_iterator i = _Procedures.begin();
   while (i != _Procedures.end()) {
      cControlProcedure * proc = (*i).second;
      proc_names.push_back(proc->Name().c_str());
      i++;
   }
  //## end cContext::Procedures%1060691315.body
}

cControlProcedure * cContext::Procedure (CONST_STRING_T proc_name)
{
  //## begin cContext::Procedure%1060691316.body preserve=yes
   std::map<STRING_T, cControlProcedure*>::const_iterator i = _Procedures.find(proc_name);
   if (i == _Procedures.end()) {
		return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::Procedure%1060691316.body
}

void cContext::StartConditions (STRING_LIST_T &cond_names)
{
  //## begin cContext::StartConditions%1060691317.body preserve=yes
   std::map<STRING_T, cControlStartCondition*>::const_iterator i = _StartConditions.begin();
   while (i != _StartConditions.end()) {
      cControlStartCondition * start_cond = (*i).second;
      cond_names.push_back(start_cond->_ConditionName.c_str());
      i++;
   }
  //## end cContext::StartConditions%1060691317.body
}

cControlStartCondition * cContext::StartCondition (CONST_STRING_T cond_name)
{
  //## begin cContext::StartCondition%1060691318.body preserve=yes
   std::map<STRING_T, cControlStartCondition*>::const_iterator i = _StartConditions.find(cond_name);
   if (i == _StartConditions.end()) {
		return NULL;
   } else {
      return (*i).second;
   }
  //## end cContext::StartCondition%1060691318.body
}

// Additional Declarations
  //## begin cContext%3E0031DC0265.declarations preserve=yes
  //## end cContext%3E0031DC0265.declarations

//## begin module%3E0031DC0265.epilog preserve=yes
//## end module%3E0031DC0265.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin cContext::SlowChannel%1049277229.body preserve=no
   return _SlowChannel;
//## end cContext::SlowChannel%1049277229.body

//## begin cContext::FastChannel%1049277230.body preserve=no
   return _FastChannel;
//## end cContext::FastChannel%1049277230.body

#endif
