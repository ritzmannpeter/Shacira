//## begin module%3E0031DC0265.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E0031DC0265.cm

//## begin module%3E0031DC0265.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E0031DC0265.cp

//## Module: cContext%3E0031DC0265; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cContext.h

#ifndef cContext_h
#define cContext_h 1

//## begin module%3E0031DC0265.includes preserve=yes
//## end module%3E0031DC0265.includes


class __DLL_EXPORT__ cSHProcess;
class __DLL_EXPORT__ cConfigurationObject;
class __DLL_EXPORT__ cFuncDecl;
class __DLL_EXPORT__ cFuncRef;
class __DLL_EXPORT__ cVarRef;
class __DLL_EXPORT__ cVarDef;
class __DLL_EXPORT__ cVariable;
class __DLL_EXPORT__ cFile;
class __DLL_EXPORT__ cFileSystemUtils;
class __DLL_EXPORT__ cControlStartCondition;
class __DLL_EXPORT__ cControlProcedure;
class __DLL_EXPORT__ cControlProgram;
class __DLL_EXPORT__ cControlState;
class __DLL_EXPORT__ cAdapter;
class __DLL_EXPORT__ cStyxParser;

//## begin module%3E0031DC0265.additionalDeclarations preserve=yes

#define UNDEFINED_SYMBOL_VALUE	-1

typedef std::map<STRING_T,cAdapter*> ADAPTER_MAP_T;

//## end module%3E0031DC0265.additionalDeclarations


//## begin cContext%3E0031DC0265.preface preserve=yes
//## end cContext%3E0031DC0265.preface

//## Class: cContext%3E0031DC0265
//## Category: System::Database%3E0030DC0267
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E259F98023E;cVariable { -> F}
//## Uses: <unnamed>%3E9C189402AF;cVarRef { -> F}
//## Uses: <unnamed>%3E9C18A60242;cFuncRef { -> F}
//## Uses: <unnamed>%3E9C2654034B;cStyxParser { -> F}
//## Uses: <unnamed>%3EA9350300DA;cFileSystemUtils { -> F}
//## Uses: <unnamed>%3EDDC42301F4;cConfigurationObject { -> F}
//## Uses: <unnamed>%3EE062330000;cFile { -> F}
//## Uses: <unnamed>%3F86C60401B5;cAdapter { -> F}

class __DLL_EXPORT__ cContext 
{
  //## begin cContext%3E0031DC0265.initialDeclarations preserve=yes
public:
  //## end cContext%3E0031DC0265.initialDeclarations

    //## Constructors (generated)
      cContext();

      cContext(const cContext &right);

    //## Constructors (specified)
      //## Operation: cContext%1054890583
      cContext (cSHProcess *process);

    //## Destructor (generated)
      virtual ~cContext();


    //## Other Operations (specified)
      //## Operation: IsRemote%1042447642
      //	Is this Context a remote context ?
      virtual BOOL_T IsRemote () = 0;

      //## Operation: Connect%1050753125
      virtual void Connect (ULONG_T wait = 0) = 0;

      //## Operation: Create%1042447637
      //	Creates necessary resources.
      virtual void Create () = 0;

      //## Operation: GetVarDefs%1054726257
      //	Gets all variable definitions as a list of serialized
      //	objects.
      virtual ULONG_T GetVarDefs (STRING_LIST_T &obj_list) = 0;

      //## Operation: Search%1050753126
      void Search (cContext *context);

      //## Operation: Parse%1042447636
      //	Parses context definitions from a description source.
      virtual void Parse (CONST_STRING_T source);

      //## Operation: LoadSymbols%1054726255
      //	Loads Symbols from a symbol file.
      virtual void LoadSymbols (CONST_STRING_T symbol_file);

      //## Operation: AddSymbolValue%1050432222
      void AddSymbolValue (CONST_STRING_T symbol, LONG_T symbol_value);

      //## Operation: SymbolValue%1041261887
      LONG_T SymbolValue (CONST_STRING_T symbol);

      //## Operation: VarRef%1050417247
      cVarRef * VarRef (CONST_STRING_T spec);

      //## Operation: FuncRef%1050417248
      cFuncRef * FuncRef (CONST_STRING_T spec);

      //## Operation: AddFuncDecl%1040992370
      void AddFuncDecl (CONST_STRING_T func_name, cFuncDecl *func_decl);

      //## Operation: AddVarDef%1040992371
      void AddVarDef (CONST_STRING_T var_name, cVarDef *var_def);

      //## Operation: AddControlState%1060682986
      void AddControlState (CONST_STRING_T state_name, cControlState *state);

      //## Operation: AddControlProgram%1060682987
      void AddControlProgram (CONST_STRING_T program_name, cControlProgram *program);

      //## Operation: AddControlProcedure%1060682988
      void AddControlProcedure (CONST_STRING_T procedure_name, cControlProcedure *proc);

      //## Operation: AddControlStartCondition%1060682989
      void AddControlStartCondition (CONST_STRING_T condition_name, cControlStartCondition *cond);

      //## Operation: AddAdapter%1052744775
      void AddAdapter (CONST_STRING_T name, cAdapter *adapter);

      //## Operation: Adapter%1052744776
      cAdapter * Adapter (CONST_STRING_T name);

      //## Operation: FuncDecls%1042459997
      void FuncDecls (STRING_LIST_T &func_names);

      //## Operation: FuncDecl%1040992359
      cFuncDecl * FuncDecl (CONST_STRING_T func_name);

      //## Operation: VarDefs%1042459998
      void VarDefs (STRING_LIST_T &var_names);

      //## Operation: VarDef%1040992360
      cVarDef * VarDef (CONST_STRING_T var_name);

      //## Operation: Variable%1042648651
      cVariable * Variable (CONST_STRING_T var_name);

      //## Operation: GetValue%1041514715
      //	Retrieves the value of a variable specified by name and
      //	indices into a string.
      void GetValue (CONST_STRING_T var_name, STRING_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: GetValue%1041514716
      //	Retrieves the value of a variable specified by name and
      //	indices into a long.
      void GetValue (CONST_STRING_T var_name, LONG_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: GetValue%1041514717
      //	Retrieves the value of a variable specified by name and
      //	indices into a double.
      void GetValue (CONST_STRING_T var_name, DOUBLE_T &value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: SetValue%1041514718
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a conatant string value.
      void SetValue (CONST_STRING_T var_name, CONST_STRING_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: SetValue%1041514719
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a signed long value.
      void SetValue (CONST_STRING_T var_name, LONG_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: SetValue%1041514720
      //	Sets the value of a variable specified by name and
      //	indices. The value is passed as a double value.
      void SetValue (CONST_STRING_T var_name, DOUBLE_T value, LONG_T i1 = -1, LONG_T i2 = -1, LONG_T i3 = -1, LONG_T i4 = -1);

      //## Operation: States%1060691311
      void States (STRING_LIST_T &state_names);

      //## Operation: State%1060691312
      cControlState * State (CONST_STRING_T state_name);

      //## Operation: Programs%1060691313
      void Programs (STRING_LIST_T &program_names);

      //## Operation: Program%1060691314
      cControlProgram * Program (CONST_STRING_T prog_name);

      //## Operation: Procedures%1060691315
      void Procedures (STRING_LIST_T &proc_names);

      //## Operation: Procedure%1060691316
      cControlProcedure * Procedure (CONST_STRING_T proc_name);

      //## Operation: StartConditions%1060691317
      void StartConditions (STRING_LIST_T &cond_names);

      //## Operation: StartCondition%1060691318
      cControlStartCondition * StartCondition (CONST_STRING_T cond_name);

    // Data Members for Class Attributes

      //## Attribute: Name%3E9C2249001F
      //## begin cContext::Name%3E9C2249001F.attr preserve=no  public: STRING_T {U} 
      STRING_T _Name;
      //## end cContext::Name%3E9C2249001F.attr

      //## Attribute: ActDriverName%3E22C9E7016D
      //## begin cContext::ActDriverName%3E22C9E7016D.attr preserve=no  public: STRING_T {U} 
      STRING_T _ActDriverName;
      //## end cContext::ActDriverName%3E22C9E7016D.attr

  public:
    // Additional Public Declarations
      //## begin cContext%3E0031DC0265.public preserve=yes
      //## end cContext%3E0031DC0265.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Created%3EF84E9D033C
      //## begin cContext::Created%3EF84E9D033C.attr preserve=no  protected: BOOL_T {U} false
      BOOL_T _Created;
      //## end cContext::Created%3EF84E9D033C.attr

    // Data Members for Associations

      //## Association: System::Database::<unnamed>%3E0737AD02F8
      //## Role: cContext::FuncDecls%3E0737AE03AE
      //## Qualifier: name%3E07390303C2; STRING_T
      //## begin cContext::FuncDecls%3E0737AE03AE.role preserve=no  public: cFuncDecl {1 -> 0..nRFHN}
      std::map<STRING_T, cFuncDecl*> _FuncDecls;
      //## end cContext::FuncDecls%3E0737AE03AE.role

      //## Association: System::Database::<unnamed>%3E07379A01A6
      //## Role: cContext::VarDefs%3E07379B014E
      //## Qualifier: name%3E0738C803E5; STRING_T
      //## begin cContext::VarDefs%3E07379B014E.role preserve=no  public: cVarDef {1 -> 0..nRFHN}
      std::map<STRING_T, cVarDef*> _VarDefs;
      //## end cContext::VarDefs%3E07379B014E.role

      //## Association: System::Database::<unnamed>%3E9C21DB0157
      //## Role: cContext::SearchContexts%3E9C21E9031C
      //## Qualifier: name%3E9C2298031C; STRING_T
      //## begin cContext::SearchContexts%3E9C21E9031C.role preserve=no  public: cContext { -> 0..nRFHN}
      std::map<STRING_T, cContext*> _SearchContexts;
      //## end cContext::SearchContexts%3E9C21E9031C.role

      //## Association: System::PLC::<unnamed>%3F3902B700CB
      //## Role: cContext::States%3F3902B8035B
      //## Qualifier: name%3F3902FE0222; STRING_T
      //## begin cContext::States%3F3902B8035B.role preserve=no  public: cControlState { -> 0..nRFHN}
      std::map<STRING_T, cControlState*> _States;
      //## end cContext::States%3F3902B8035B.role

      //## Association: System::PLC::<unnamed>%3F39031F02BF
      //## Role: cContext::Programs%3F390320038B
      //## Qualifier: name%3F3903390222; STRING_T
      //## begin cContext::Programs%3F390320038B.role preserve=no  public: cControlProgram { -> 0..nRFHN}
      std::map<STRING_T, cControlProgram*> _Programs;
      //## end cContext::Programs%3F390320038B.role

      //## Association: System::PLC::<unnamed>%3F390364005D
      //## Role: cContext::StartConditions%3F390365000F
      //## Qualifier: name%3F3903DC0251; STRING_T
      //## begin cContext::StartConditions%3F390365000F.role preserve=no  public: cControlStartCondition { -> 0..nRFHN}
      std::map<STRING_T, cControlStartCondition*> _StartConditions;
      //## end cContext::StartConditions%3F390365000F.role

      //## Association: System::PLC::<unnamed>%3F390397031C
      //## Role: cContext::Procedures%3F39039A0213
      //## Qualifier: name%3F3903C501D4; STRING_T
      //## begin cContext::Procedures%3F39039A0213.role preserve=no  public: cControlProcedure { -> 0..nRFHN}
      std::map<STRING_T, cControlProcedure*> _Procedures;
      //## end cContext::Procedures%3F39039A0213.role

      //## Association: System::Process::<unnamed>%3EE063540148
      //## Role: cContext::Process%3EE063550261
      //## begin cContext::Process%3EE063550261.role preserve=no  public: cSHProcess { -> 0..1RFHN}
      cSHProcess *_Process;
      //## end cContext::Process%3EE063550261.role

    // Additional Protected Declarations
      //## begin cContext%3E0031DC0265.protected preserve=yes
      //## end cContext%3E0031DC0265.protected

  private:
    // Additional Private Declarations
      //## begin cContext%3E0031DC0265.private preserve=yes
      //## end cContext%3E0031DC0265.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Symbols%3E9C53AB0186
      //## begin cContext::Symbols%3E9C53AB0186.attr preserve=no  private: LONG_MAP_T {U} 
      LONG_MAP_T _Symbols;
      //## end cContext::Symbols%3E9C53AB0186.attr

      //## Attribute: Adapters%3EBFB5880251
      //## begin cContext::Adapters%3EBFB5880251.attr preserve=no  private: ADAPTER_MAP_T {U} 
      ADAPTER_MAP_T _Adapters;
      //## end cContext::Adapters%3EBFB5880251.attr

    // Additional Implementation Declarations
      //## begin cContext%3E0031DC0265.implementation preserve=yes
      //## end cContext%3E0031DC0265.implementation

};

//## begin cContext%3E0031DC0265.postscript preserve=yes
//## end cContext%3E0031DC0265.postscript

// Class cContext 

//## begin module%3E0031DC0265.epilog preserve=yes
//## end module%3E0031DC0265.epilog


#endif
