//## begin module%3C7E422F03C0.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C7E422F03C0.cm

//## begin module%3C7E422F03C0.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C7E422F03C0.cp

//## Module: cVarRef%3C7E422F03C0; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Database\cVarRef.cpp

//## begin module%3C7E422F03C0.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C7E422F03C0.additionalIncludes

//## begin module%3C7E422F03C0.includes preserve=yes
//## end module%3C7E422F03C0.includes

// cDataChange
#include "System/Objects/cDataChange.h"
// cVarRef
#include "System/Database/cVarRef.h"
// cVarDef
#include "System/Database/cVarDef.h"
// cContext
#include "System/Database/cContext.h"
// cVariable
#include "System/Database/cVariable.h"
// cSHVariant
#include "System/Database/cSHVariant.h"
// cDataControl
#include "Client/Adapters/cDataControl.h"
// cDataChangeAdapter
#include "Client/Adapters/cDataChangeAdapter.h"
//## begin module%3C7E422F03C0.additionalDeclarations preserve=yes
//## end module%3C7E422F03C0.additionalDeclarations


// Class cVarRef 










cVarRef::cVarRef()
  //## begin cVarRef::cVarRef%.hasinit preserve=no
      : _VarId(-1), _Variable(NULL), _Context(NULL), _VarDef(NULL), _Control(NULL)
  //## end cVarRef::cVarRef%.hasinit
  //## begin cVarRef::cVarRef%.initialization preserve=yes
  //## end cVarRef::cVarRef%.initialization
{
  //## begin cVarRef::cVarRef%.body preserve=yes
_ASSERT_UNCOND
  //## end cVarRef::cVarRef%.body
}

cVarRef::cVarRef(const cVarRef &right)
  //## begin cVarRef::cVarRef%copy.hasinit preserve=no
      : _VarId(-1), _Variable(NULL), _Context(NULL), _VarDef(NULL), _Control(NULL)
  //## end cVarRef::cVarRef%copy.hasinit
  //## begin cVarRef::cVarRef%copy.initialization preserve=yes
  //## end cVarRef::cVarRef%copy.initialization
{
  //## begin cVarRef::cVarRef%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cVarRef::cVarRef%copy.body
}

cVarRef::cVarRef (cVarDef *var_def, cContext *context)
  //## begin cVarRef::cVarRef%1040202775.hasinit preserve=no
      : _VarId(-1), _Variable(NULL), _Context(NULL), _VarDef(NULL), _Control(NULL)
  //## end cVarRef::cVarRef%1040202775.hasinit
  //## begin cVarRef::cVarRef%1040202775.initialization preserve=yes
  //## end cVarRef::cVarRef%1040202775.initialization
{
  //## begin cVarRef::cVarRef%1040202775.body preserve=yes
   _Context = context;
   _VarDef = var_def;
   _Variable = _VarDef->_Variable;
   _Name = _VarDef->_VarName;
  //## end cVarRef::cVarRef%1040202775.body
}


cVarRef::~cVarRef()
{
  //## begin cVarRef::~cVarRef%.body preserve=yes
  //## end cVarRef::~cVarRef%.body
}



//## Other Operations (implementation)
cVarDef * cVarRef::VarDef ()
{
  //## begin cVarRef::VarDef%1061797997.body preserve=yes
   return _VarDef;
  //## end cVarRef::VarDef%1061797997.body
}

UCHAR_T cVarRef::DataType ()
{
  //## begin cVarRef::DataType%1061797999.body preserve=yes
   return _VarDef->DataType();
  //## end cVarRef::DataType%1061797999.body
}

void cVarRef::SetIndex (ULONG_T pos, cArgument *index)
{
  //## begin cVarRef::SetIndex%1040202776.body preserve=yes
   if (pos >= _IndexVec.size()) _IndexVec.resize(pos+1);
   _IndexVec[pos] = index;
  //## end cVarRef::SetIndex%1040202776.body
}

ULONG_T cVarRef::Indices ()
{
  //## begin cVarRef::Indices%1040202777.body preserve=yes
   return _IndexVec.size();
  //## end cVarRef::Indices%1040202777.body
}

void cVarRef::GetValue (STRING_T &value)
{
  //## begin cVarRef::GetValue%1040202784.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->GetValue(value, i1, i2, i3, i4);
  //## end cVarRef::GetValue%1040202784.body
}

void cVarRef::GetValue (LONG_T &value)
{
  //## begin cVarRef::GetValue%1040202785.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->GetValue(value, i1, i2, i3, i4);
  //## end cVarRef::GetValue%1040202785.body
}

void cVarRef::GetValue (DOUBLE_T &value)
{
  //## begin cVarRef::GetValue%1040202786.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->GetValue(value, i1, i2, i3, i4);
  //## end cVarRef::GetValue%1040202786.body
}

void cVarRef::SetValue (CONST_STRING_T value)
{
  //## begin cVarRef::SetValue%1040202787.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->SetValue(value, i1, i2, i3, i4);
  //## end cVarRef::SetValue%1040202787.body
}

void cVarRef::SetValue (LONG_T value)
{
  //## begin cVarRef::SetValue%1040202788.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->SetValue(value, i1, i2, i3, i4);
  //## end cVarRef::SetValue%1040202788.body
}

void cVarRef::SetValue (DOUBLE_T value)
{
  //## begin cVarRef::SetValue%1040202789.body preserve=yes
   if (_Variable == NULL) _Variable = _VarDef->_Variable;
   LONG_T i1, i2, i3, i4;
   GetIndices(i1, i2, i3, i4);
   _Variable->SetValue(value, i1, i2, i3, i4);
  //## end cVarRef::SetValue%1040202789.body
}

void cVarRef::NewValue (CONST_STRING_T value)
{
  //## begin cVarRef::NewValue%1041261882.body preserve=yes
   if (_Control != NULL) _Control->NewValue(value);
  //## end cVarRef::NewValue%1041261882.body
}

void cVarRef::GetIndices (LONG_T &i1, LONG_T &i2, LONG_T &i3, LONG_T &i4)
{
  //## begin cVarRef::GetIndices%1041261885.body preserve=yes
   i1 = i2 = i3 = i4 = -1;
   int dims = _IndexVec.size();
   if (dims > 0) _IndexVec[0]->GetValue(i1);
   if (dims > 1) _IndexVec[1]->GetValue(i2);
   if (dims > 2) _IndexVec[2]->GetValue(i3);
   if (dims > 3) _IndexVec[3]->GetValue(i4);
  //## end cVarRef::GetIndices%1041261885.body
}

void cVarRef::Register (cDataChangeAdapter *adapter)
{
  //## begin cVarRef::Register%1042646893.body preserve=yes
   if (_Control != NULL) {
      STRING_T value;
      GetValue(value);
      _Control->NewValue(value.c_str());
   }
   adapter->RegisterVar(this);
  //## end cVarRef::Register%1042646893.body
}

void cVarRef::UnRegister (cDataChangeAdapter *adapter)
{
  //## begin cVarRef::UnRegister%1042646894.body preserve=yes
   adapter->UnRegisterVar(this);
  //## end cVarRef::UnRegister%1042646894.body
}

BOOL_T cVarRef::Matches (cDataChange *change)
{
  //## begin cVarRef::Matches%1042646895.body preserve=yes
   LONG_T id1 = _VarId, id2 = change->get_VarId();
   if (id1 != -1 && id2 != -1) {
      if (id1 != id2) return false;
   } else {
      const char * name1 = _Name.c_str();
      STRING_T name2 = change->get_VarName();
      const char * _name2 = name2.c_str();
      if (strcmp(name1, _name2) != 0) return false;
   }
   ULONG_T dims = _IndexVec.size();
   LONG_T i1 = -1, i2 = -1, i3 = -1, i4 = -1;
   GetIndices(i1, i2, i3, i4);
   if (i1 != change->get_Index1()) return false;
   if (i2 != change->get_Index2()) return false;
   if (i3 != change->get_Index3()) return false;
   if (i4 != change->get_Index4()) return false;
   return true;
  //## end cVarRef::Matches%1042646895.body
}

void cVarRef::SetControl (cDataControl *control)
{
  //## begin cVarRef::SetControl%1043311227.body preserve=yes
  _Control = control;
  //## end cVarRef::SetControl%1043311227.body
}

// Additional Declarations
  //## begin cVarRef%3C7E422F03C0.declarations preserve=yes
  //## end cVarRef%3C7E422F03C0.declarations

//## begin module%3C7E422F03C0.epilog preserve=yes
//## end module%3C7E422F03C0.epilog
