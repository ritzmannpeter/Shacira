//## begin module%3E9EF7DD02AF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E9EF7DD02AF.cm

//## begin module%3E9EF7DD02AF.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E9EF7DD02AF.cp

//## Module: cFile%3E9EF7DD02AF; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cFile.cpp

//## begin module%3E9EF7DD02AF.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3E9EF7DD02AF.additionalIncludes

//## begin module%3E9EF7DD02AF.includes preserve=yes
//## end module%3E9EF7DD02AF.includes

// cFile
#include "System/Sys/cFile.h"
// cFileSystemUtils
#include "System/Sys/cFileSystemUtils.h"
//## begin module%3E9EF7DD02AF.additionalDeclarations preserve=yes
//## end module%3E9EF7DD02AF.additionalDeclarations


// Class cFile 



cFile::cFile()
  //## begin cFile::cFile%.hasinit preserve=no
      : _Stream(NULL)
  //## end cFile::cFile%.hasinit
  //## begin cFile::cFile%.initialization preserve=yes
  //## end cFile::cFile%.initialization
{
  //## begin cFile::cFile%.body preserve=yes
_ASSERT_UNCOND
  //## end cFile::cFile%.body
}

cFile::cFile(const cFile &right)
  //## begin cFile::cFile%copy.hasinit preserve=no
      : _Stream(NULL)
  //## end cFile::cFile%copy.hasinit
  //## begin cFile::cFile%copy.initialization preserve=yes
  //## end cFile::cFile%copy.initialization
{
  //## begin cFile::cFile%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cFile::cFile%copy.body
}

cFile::cFile (CONST_STRING_T file_name)
  //## begin cFile::cFile%1050605979.hasinit preserve=no
      : _Stream(NULL)
  //## end cFile::cFile%1050605979.hasinit
  //## begin cFile::cFile%1050605979.initialization preserve=yes
  //## end cFile::cFile%1050605979.initialization
{
  //## begin cFile::cFile%1050605979.body preserve=yes
	_Path = cFileSystemUtils::FullPath(file_name);
  //## end cFile::cFile%1050605979.body
}


cFile::~cFile()
{
  //## begin cFile::~cFile%.body preserve=yes
	Close();
  //## end cFile::~cFile%.body
}



//## Other Operations (implementation)
BOOL_T cFile::Open (ULONG_T flags)
{
  //## begin cFile::Open%1050605980.body preserve=yes
	if (flags & ACCESS_APPEND) {
		_Stream = fopen(_Path.c_str(), "a");
	} else {
		if (flags & ACCESS_READ_ONLY) {
			if (flags & MODE_BINARY) {
				_Stream = fopen(_Path.c_str(), "rb");
			} else {
				_Stream = fopen(_Path.c_str(), "r");
			}
		} else {
			if (flags & MODE_BINARY) {
				_Stream = fopen(_Path.c_str(), "wb");
			} else {
				_Stream = fopen(_Path.c_str(), "w");
			}
		}
	}
   if (_Stream == NULL) {
      return false;
   } else {
      return true;
   }
  //## end cFile::Open%1050605980.body
}

void cFile::Close ()
{
  //## begin cFile::Close%1050605981.body preserve=yes
	UnLock();
	if (_Stream != NULL) {
		fclose(_Stream);
	}
  //## end cFile::Close%1050605981.body
}

ULONG_T cFile::Read (void *buf, ULONG_T buf_size, ULONG_T bytes)
{
  //## begin cFile::Read%1050605982.body preserve=yes
	if (_Stream != NULL) return 0;
   ULONG_T nread = fread(buf, bytes, 1, _Stream);
	return nread;
  //## end cFile::Read%1050605982.body
}

BOOL_T cFile::ReadLine (BUF_T buf, ULONG_T buf_size)
{
  //## begin cFile::ReadLine%1050605983.body preserve=yes
   if (_Stream == NULL) return false;
   ULONG_T nread = 0;
	int c = fgetc(_Stream);
	while (c != '\n' && c != EOF) {
		buf[nread] = c;
		nread++;
   	c = fgetc(_Stream);
	}
	buf[nread] = 0;
	return (c == EOF) ? false : true;
  //## end cFile::ReadLine%1050605983.body
}

BOOL_T cFile::ReadLine (STRING_T &buf)
{
  //## begin cFile::ReadLine%1051885629.body preserve=yes
   if (_Stream == NULL) return false;
   char line_buf[2048] = {0};
   if (ReadLine(line_buf, sizeof(line_buf))) {
      buf = line_buf;
      return true;
   } else {
      return false;
   }
  //## end cFile::ReadLine%1051885629.body
}

ULONG_T cFile::Write (void *buf, ULONG_T bytes)
{
  //## begin cFile::Write%1053510999.body preserve=yes
   if (_Stream == NULL) return false;
   ULONG_T nwrite = fwrite(buf, bytes, 1, _Stream);
	return nwrite;
  //## end cFile::Write%1053510999.body
}

void cFile::Printf (CONST_STRING_T fmt_str, ... )
{
  //## begin cFile::Printf%1050605984.body preserve=yes
   if (_Stream == NULL) return;
   char text[4096] = {0};
   va_list args;
   va_start(args, fmt_str);
   vsprintf(text, fmt_str, args);
   va_end(args);
   Write(text, strlen(text));
  //## end cFile::Printf%1050605984.body
}

void cFile::Lock ()
{
  //## begin cFile::Lock%1050605985.body preserve=yes
  //## end cFile::Lock%1050605985.body
}

void cFile::UnLock ()
{
  //## begin cFile::UnLock%1050605986.body preserve=yes
  //## end cFile::UnLock%1050605986.body
}

BOOL_T cFile::Exists ()
{
  //## begin cFile::Exists%1050605987.body preserve=yes
	return cFileSystemUtils::FileExists(_Path.c_str());
  //## end cFile::Exists%1050605987.body
}

void cFile::Remove ()
{
  //## begin cFile::Remove%1050605988.body preserve=yes
	if (Exists()) {
		remove(_Path.c_str());
	}
  //## end cFile::Remove%1050605988.body
}

STRING_T cFile::Path ()
{
  //## begin cFile::Path%1050605989.body preserve=yes
	return _Path;
  //## end cFile::Path%1050605989.body
}

ULONG_T cFile::Size ()
{
  //## begin cFile::Size%1053511000.body preserve=yes
   return 0;
  //## end cFile::Size%1053511000.body
}

void cFile::SetReadOnly (BOOL_T read_only)
{
  //## begin cFile::SetReadOnly%1053513442.body preserve=yes
   DWORD attributes = GetFileAttributes(_Path.c_str());
   if (read_only) {
      if (!(attributes & FILE_ATTRIBUTE_READONLY)) {
         attributes |= FILE_ATTRIBUTE_READONLY;
         SetFileAttributes(_Path.c_str(), attributes);
      }
   } else {
      if (attributes & FILE_ATTRIBUTE_READONLY) {
         attributes &= (~FILE_ATTRIBUTE_READONLY);
         SetFileAttributes(_Path.c_str(), attributes);
      }
   }
  //## end cFile::SetReadOnly%1053513442.body
}

// Additional Declarations
  //## begin cFile%3E9EF7DD02AF.declarations preserve=yes
  //## end cFile%3E9EF7DD02AF.declarations

//## begin module%3E9EF7DD02AF.epilog preserve=yes
//## end module%3E9EF7DD02AF.epilog
