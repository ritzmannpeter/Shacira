//## begin module%3B8A23E00182.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B8A23E00182.cm

//## begin module%3B8A23E00182.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3B8A23E00182.cp

//## Module: cSystemUtils%3B8A23E00182; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cSystemUtils.cpp

//## begin module%3B8A23E00182.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3B8A23E00182.additionalIncludes

//## begin module%3B8A23E00182.includes preserve=yes
//## end module%3B8A23E00182.includes

// cSystemUtils
#include "System/Sys/cSystemUtils.h"
//## begin module%3B8A23E00182.additionalDeclarations preserve=yes
//## end module%3B8A23E00182.additionalDeclarations


// Class cSystemUtils 

//## begin cSystemUtils::ComputerName%3B8A3EB802BA.attr preserve=no  implementation: static STRING_T {U} 
STRING_T cSystemUtils::_ComputerName;
//## end cSystemUtils::ComputerName%3B8A3EB802BA.attr

cSystemUtils::cSystemUtils()
  //## begin cSystemUtils::cSystemUtils%.hasinit preserve=no
  //## end cSystemUtils::cSystemUtils%.hasinit
  //## begin cSystemUtils::cSystemUtils%.initialization preserve=yes
  //## end cSystemUtils::cSystemUtils%.initialization
{
  //## begin cSystemUtils::cSystemUtils%.body preserve=yes
_ASSERT_UNCOND
  //## end cSystemUtils::cSystemUtils%.body
}

cSystemUtils::cSystemUtils(const cSystemUtils &right)
  //## begin cSystemUtils::cSystemUtils%copy.hasinit preserve=no
  //## end cSystemUtils::cSystemUtils%copy.hasinit
  //## begin cSystemUtils::cSystemUtils%copy.initialization preserve=yes
  //## end cSystemUtils::cSystemUtils%copy.initialization
{
  //## begin cSystemUtils::cSystemUtils%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cSystemUtils::cSystemUtils%copy.body
}


cSystemUtils::~cSystemUtils()
{
  //## begin cSystemUtils::~cSystemUtils%.body preserve=yes
_ASSERT_UNCOND
  //## end cSystemUtils::~cSystemUtils%.body
}



//## Other Operations (implementation)
STRING_T cSystemUtils::ComputerName ()
{
  //## begin cSystemUtils::ComputerName%998912342.body preserve=yes
   if (_ComputerName.size() == 0) _ComputerName = EnvironmentString("COMPUTERNAME");
   return _ComputerName;
  //## end cSystemUtils::ComputerName%998912342.body
}

STRING_T cSystemUtils::IPAddress ()
{
  //## begin cSystemUtils::IPAddress%1041592744.body preserve=yes
   return "?";
  //## end cSystemUtils::IPAddress%1041592744.body
}

STRING_T cSystemUtils::EnvironmentString (CONST_STRING_T variable)
{
  //## begin cSystemUtils::EnvironmentString%998912343.body preserve=yes
   const char * environment_string = NULL;
   environment_string = getenv(variable);
   return environment_string == NULL ? "" : environment_string;
  //## end cSystemUtils::EnvironmentString%998912343.body
}

ULONG_T cSystemUtils::ProcessId ()
{
  //## begin cSystemUtils::ProcessId%1036748524.body preserve=yes
   return GetCurrentProcessId(); 
  //## end cSystemUtils::ProcessId%1036748524.body
}

ULONG_T cSystemUtils::ThreadId ()
{
  //## begin cSystemUtils::ThreadId%1036748525.body preserve=yes
   return GetCurrentThreadId(); 
  //## end cSystemUtils::ThreadId%1036748525.body
}

void cSystemUtils::Suspend (ULONG_T msecs)
{
  //## begin cSystemUtils::Suspend%1036748526.body preserve=yes
   Sleep(msecs);
  //## end cSystemUtils::Suspend%1036748526.body
}

void * cSystemUtils::Alloc (ULONG_T size)
{
  //## begin cSystemUtils::Alloc%1050584916.body preserve=yes
	return calloc(1, size);
  //## end cSystemUtils::Alloc%1050584916.body
}

void cSystemUtils::Free (void *memory)
{
  //## begin cSystemUtils::Free%1050584917.body preserve=yes
	free(memory);
  //## end cSystemUtils::Free%1050584917.body
}

ULONG_T cSystemUtils::Milliseconds ()
{
  //## begin cSystemUtils::Milliseconds%1054305357.body preserve=yes

#ifdef for_doc

// winmm.lib / dll used

void SetResolution()
{
   #define TARGET_RESOLUTION 1         // 1-millisecond target resolution
   TIMECAPS tc;
   UINT wTimerRes;
   if (timeGetDevCaps(&tc, sizeof(TIMECAPS)) != TIMERR_NOERROR) 
   {
      // Error; application can't continue.
   }
   wTimerRes = MIN(MAX(tc.wPeriodMin, TARGET_RESOLUTION), tc.wPeriodMax);
   timeBeginPeriod(wTimerRes); 
}

//typedef DWORD * DWORD_PTR;
typedef unsigned long DWORD_PTR;
#define RESOLUTION 1

void __stdcall Expired(UINT uTimerID, UINT uMsg, DWORD_PTR dwUser, DWORD_PTR dw1, DWORD_PTR dw2)
{
   SYSTEMTIME after = {0};
   DWORD ticks = GetTickCount();
   GetLocalTime(&after);
   printf("%d,%d\n", after.wMilliseconds, ticks);
   MMRESULT rc = timeSetEvent(RESOLUTION, 1, Expired, TIME_ONESHOT, TIME_CALLBACK_FUNCTION);
}

void SetTimer()
{
   MMRESULT rc = timeSetEvent(RESOLUTION, 1, Expired, TIME_ONESHOT, TIME_CALLBACK_FUNCTION);
}


#endif
   
   
   ULONG_T ticks = GetTickCount();
   return ticks;
  //## end cSystemUtils::Milliseconds%1054305357.body
}

// Additional Declarations
  //## begin cSystemUtils%3B8A23E00182.declarations preserve=yes
  //## end cSystemUtils%3B8A23E00182.declarations

//## begin module%3B8A23E00182.epilog preserve=yes
//## end module%3B8A23E00182.epilog


// Detached code regions:
// WARNING: this code will be lost if code is regenerated.
#if 0
//## begin cSystemUtils::TypeSize%1042559819.body preserve=no
   switch (data_type) {
   case SH_VOID: return 0;
   case SH_CHAR: return 1;
   case SH_UCHAR: return 1;
   case SH_SHORT: return 2;
   case SH_USHORT: return 2;
   case SH_LONG: return 4;
   case SH_ULONG: return 4;
   case SH_FLOAT: return 4;
   case SH_DOUBLE: return 8;
   case SH_STRING: return 1;
   case SH_WSTRING: return 2;
   case SH_SYM_BCD:
   case SH_SYM_KMBCD:
   case SH_SYM_HEX:
_ASSERT_UNCOND
   default:
_ASSERT_UNCOND
   }
//## end cSystemUtils::TypeSize%1042559819.body

#endif
