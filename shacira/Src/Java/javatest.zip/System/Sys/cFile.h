//## begin module%3E9EF7DD02AF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3E9EF7DD02AF.cm

//## begin module%3E9EF7DD02AF.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3E9EF7DD02AF.cp

//## Module: cFile%3E9EF7DD02AF; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cFile.h

#ifndef cFile_h
#define cFile_h 1

//## begin module%3E9EF7DD02AF.includes preserve=yes
//## end module%3E9EF7DD02AF.includes


class __DLL_EXPORT__ cFileSystemUtils;

//## begin module%3E9EF7DD02AF.additionalDeclarations preserve=yes

#define ACCESS_APPEND		0x00000001
#define ACCESS_READ_ONLY	0x00000002
#define MODE_BINARY			0x00000004

//## end module%3E9EF7DD02AF.additionalDeclarations


//## begin cFile%3E9EF7DD02AF.preface preserve=yes
//## end cFile%3E9EF7DD02AF.preface

//## Class: cFile%3E9EF7DD02AF
//## Category: System::Sys%3E5A1D1800A3
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3E9EF8590271;cFileSystemUtils { -> F}

class __DLL_EXPORT__ cFile 
{
  //## begin cFile%3E9EF7DD02AF.initialDeclarations preserve=yes
public:
  //## end cFile%3E9EF7DD02AF.initialDeclarations

    //## Constructors (generated)
      cFile();

      cFile(const cFile &right);

    //## Constructors (specified)
      //## Operation: cFile%1050605979
      cFile (CONST_STRING_T file_name);

    //## Destructor (generated)
      virtual ~cFile();


    //## Other Operations (specified)
      //## Operation: Open%1050605980
      BOOL_T Open (ULONG_T flags = 0);

      //## Operation: Close%1050605981
      void Close ();

      //## Operation: Read%1050605982
      ULONG_T Read (void *buf, ULONG_T buf_size, ULONG_T bytes);

      //## Operation: ReadLine%1050605983
      BOOL_T ReadLine (BUF_T buf, ULONG_T buf_size);

      //## Operation: ReadLine%1051885629
      BOOL_T ReadLine (STRING_T &buf);

      //## Operation: Write%1053510999
      ULONG_T Write (void *buf, ULONG_T bytes);

      //## Operation: Printf%1050605984
      void Printf (CONST_STRING_T fmt_str, ... );

      //## Operation: Lock%1050605985
      void Lock ();

      //## Operation: UnLock%1050605986
      void UnLock ();

      //## Operation: Exists%1050605987
      BOOL_T Exists ();

      //## Operation: Remove%1050605988
      void Remove ();

      //## Operation: Path%1050605989
      STRING_T Path ();

      //## Operation: Size%1053511000
      ULONG_T Size ();

      //## Operation: SetReadOnly%1053513442
      void SetReadOnly (BOOL_T read_only);

  public:
    // Additional Public Declarations
      //## begin cFile%3E9EF7DD02AF.public preserve=yes
      //## end cFile%3E9EF7DD02AF.public

  protected:
    // Additional Protected Declarations
      //## begin cFile%3E9EF7DD02AF.protected preserve=yes
      //## end cFile%3E9EF7DD02AF.protected

  private:
    // Additional Private Declarations
      //## begin cFile%3E9EF7DD02AF.private preserve=yes
      //## end cFile%3E9EF7DD02AF.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Path%3E9EF83700CB
      //## begin cFile::Path%3E9EF83700CB.attr preserve=no  private: STRING_T {U} 
      STRING_T _Path;
      //## end cFile::Path%3E9EF83700CB.attr

      //## Attribute: Stream%3E9EFB4503B9
      //## begin cFile::Stream%3E9EFB4503B9.attr preserve=no  private: FILE * {U} NULL
      FILE *_Stream;
      //## end cFile::Stream%3E9EFB4503B9.attr

    // Additional Implementation Declarations
      //## begin cFile%3E9EF7DD02AF.implementation preserve=yes
      //## end cFile%3E9EF7DD02AF.implementation

};

//## begin cFile%3E9EF7DD02AF.postscript preserve=yes
//## end cFile%3E9EF7DD02AF.postscript

// Class cFile 

//## begin module%3E9EF7DD02AF.epilog preserve=yes
//## end module%3E9EF7DD02AF.epilog


#endif
