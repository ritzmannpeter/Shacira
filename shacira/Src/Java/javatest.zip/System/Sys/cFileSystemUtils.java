//## begin module%3B8A315401D5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B8A315401D5.cm

//## begin module%3B8A315401D5.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3B8A315401D5.cp

//## Module: cFileSystemUtils%3B8A315401D5; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cFileSystemUtils.cpp

//## begin module%3B8A315401D5.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3B8A315401D5.additionalIncludes

//## begin module%3B8A315401D5.includes preserve=yes
//## end module%3B8A315401D5.includes

// cFileSystemUtils
#include "System/Sys/cFileSystemUtils.h"
//## begin module%3B8A315401D5.additionalDeclarations preserve=yes
//## end module%3B8A315401D5.additionalDeclarations


// Class cFileSystemUtils 

//## begin cFileSystemUtils::Type%3B8A340400E4.attr preserve=no  public: static FileSystemTypes {U} FSYS_WINDOWS
FileSystemTypes cFileSystemUtils::_Type = FSYS_WINDOWS;
//## end cFileSystemUtils::Type%3B8A340400E4.attr

//## begin cFileSystemUtils::StartupDirectory%3B8A5B5A0292.attr preserve=no  implementation: static STRING_T {U} 
STRING_T cFileSystemUtils::_StartupDirectory;
//## end cFileSystemUtils::StartupDirectory%3B8A5B5A0292.attr

cFileSystemUtils::cFileSystemUtils()
  //## begin cFileSystemUtils::cFileSystemUtils%.hasinit preserve=no
  //## end cFileSystemUtils::cFileSystemUtils%.hasinit
  //## begin cFileSystemUtils::cFileSystemUtils%.initialization preserve=yes
  //## end cFileSystemUtils::cFileSystemUtils%.initialization
{
  //## begin cFileSystemUtils::cFileSystemUtils%.body preserve=yes
_ASSERT_UNCOND
  //## end cFileSystemUtils::cFileSystemUtils%.body
}

cFileSystemUtils::cFileSystemUtils(const cFileSystemUtils &right)
  //## begin cFileSystemUtils::cFileSystemUtils%copy.hasinit preserve=no
  //## end cFileSystemUtils::cFileSystemUtils%copy.hasinit
  //## begin cFileSystemUtils::cFileSystemUtils%copy.initialization preserve=yes
  //## end cFileSystemUtils::cFileSystemUtils%copy.initialization
{
  //## begin cFileSystemUtils::cFileSystemUtils%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cFileSystemUtils::cFileSystemUtils%copy.body
}


cFileSystemUtils::~cFileSystemUtils()
{
  //## begin cFileSystemUtils::~cFileSystemUtils%.body preserve=yes
_ASSERT_UNCOND
  //## end cFileSystemUtils::~cFileSystemUtils%.body
}



//## Other Operations (implementation)
BOOL_T cFileSystemUtils::CreateDir (CONST_STRING_T directory)
{
  //## begin cFileSystemUtils::CreateDir%998912344.body preserve=yes
   STRING_T path = FullPath(directory);
   STRING_T temp_path;
   STRING_T head, tail;
   LeftSplit(path.c_str(), head, tail);
   while (head.size() > 0) {
      temp_path = AppendPath(temp_path.c_str(), head.c_str());
      if (!IsDrive(temp_path.c_str())) {
         if (!DirExists(temp_path.c_str())) {
            BOOL_T success = (BOOL_T)CreateDirectory(temp_path.c_str(), NULL);
            if (!success) {
               return false;
            }
         }
      }
      LeftSplit(tail.c_str(), head, tail);
   }
   return true;
  //## end cFileSystemUtils::CreateDir%998912344.body
}

BOOL_T cFileSystemUtils::RemoveFile (CONST_STRING_T file)
{
  //## begin cFileSystemUtils::RemoveFile%1037294318.body preserve=yes
   if (remove(file) == 0) {
      return true;
   } else {
      return false;
   }
  //## end cFileSystemUtils::RemoveFile%1037294318.body
}

BOOL_T cFileSystemUtils::DirExists (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::DirExists%998912345.body preserve=yes
   STRING_T full_path = FullPath(path);
   STRING_T find_spec = AppendPath(full_path.c_str(), "*");
   WIN32_FIND_DATA find_data;
   HANDLE hFind;
   hFind = FindFirstFile(find_spec.c_str(), &find_data);
   if (hFind == INVALID_HANDLE_VALUE) {
      return false;
   } else {
      FindClose(hFind);
      return true;
   }
  //## end cFileSystemUtils::DirExists%998912345.body
}

BOOL_T cFileSystemUtils::FileExists (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::FileExists%998912346.body preserve=yes
   STRING_T full_path = FullPath(path);
   WIN32_FIND_DATA find_data;
   HANDLE hFind;
   hFind = FindFirstFile(full_path.c_str(), &find_data);
   if (hFind == INVALID_HANDLE_VALUE) {
      return false;
   } else {
      FindClose(hFind);
      return true;
   }
  //## end cFileSystemUtils::FileExists%998912346.body
}

BOOL_T cFileSystemUtils::FileExistence (STRING_VECTOR_T &paths, CONST_STRING_T file_name, STRING_T &file)
{
  //## begin cFileSystemUtils::FileExistence%1044520499.body preserve=yes
   STRING_VECTOR_T::const_iterator i = paths.begin();
   while (i != paths.end()) {
      STRING_T path = (*i);
      STRING_T test_file = AppendPath(path.c_str(), file_name);
      if (FileExists(test_file.c_str())) {
         file = test_file;
         return true;
      }
      i++;
   }
   return false;
  //## end cFileSystemUtils::FileExistence%1044520499.body
}

ULONG_T cFileSystemUtils::FileSize (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::FileSize%1013674760.body preserve=yes
   HANDLE handle = CreateFile(path,
                              GENERIC_READ,
                              0, NULL,
                              OPEN_EXISTING,
                              FILE_ATTRIBUTE_NORMAL,
                              NULL);
   if (handle != INVALID_HANDLE_VALUE) {
      unsigned long file_size = GetFileSize(handle, NULL);
      if (file_size == 0xFFFFFFFF) {
         file_size = 0;
      }
      CloseHandle(handle);
      return file_size;
   } else {
      return 0;
   }
  //## end cFileSystemUtils::FileSize%1013674760.body
}

BOOL_T cFileSystemUtils::FileList (STRING_LIST_T &file_names, CONST_STRING_T path, CONST_STRING_T pattern)
{
  //## begin cFileSystemUtils::FileList%1000386745.body preserve=yes
   STRING_T full_path = FullPath(path);
   if (!DirExists(full_path.c_str())) return false;
   STRING_T find_spec = AppendPath(full_path.c_str(), pattern);
   WIN32_FIND_DATA find_data;
   HANDLE hFind;
   hFind = FindFirstFile(find_spec.c_str(), &find_data);
   if (hFind != INVALID_HANDLE_VALUE) {
      BOOL_T found = true;
      while (found) {
         STRING_T file_name = find_data.cFileName;
         file_names.push_back(file_name);
         found = (BOOL_T)FindNextFile(hFind, &find_data);
      }
   }
   DWORD last_error = GetLastError();
   if (hFind != INVALID_HANDLE_VALUE) FindClose(hFind);
   if (last_error == ERROR_NO_MORE_FILES) {
      return true;
   } else {
      return false;
   }
  //## end cFileSystemUtils::FileList%1000386745.body
}

STRING_T cFileSystemUtils::FullPath (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::FullPath%998912347.body preserve=yes
   if (IsRelativePath(path)) {
      return AppendPath(CurrentDir().c_str(), path);
   } else if (IsUNCPath(path)) {
      return path;
   } else if (IsAbsolutePath(path)) {
      STRING_T drive_name = DriveName(path);
      if (drive_name.size() == 0) {
         STRING_T full_path = drive_name.c_str();
         full_path += CurrentDrive().c_str();
         return full_path;
      } else {
         return path;
      }
   } else {
      STRING_T full_path = "\\\\\\\\\\invalid path specification::";
      full_path += path;
      return full_path;
   }
  //## end cFileSystemUtils::FullPath%998912347.body
}

void cFileSystemUtils::LeftSplit (CONST_STRING_T path, STRING_T &head, STRING_T &tail)
{
  //## begin cFileSystemUtils::LeftSplit%998912348.body preserve=yes
   int pos = cStringUtils::FindFirstOf(path, PATH_DELIMITERS);
   if (pos < 0) {
      head = path;
      tail = "";
   } else {
      head = cStringUtils::Left(path, pos);
      tail = cStringUtils::Right(path, strlen(path) - (pos + 1));
   }
  //## end cFileSystemUtils::LeftSplit%998912348.body
}

void cFileSystemUtils::RightSplit (CONST_STRING_T path, STRING_T &head, STRING_T &tail)
{
  //## begin cFileSystemUtils::RightSplit%998912349.body preserve=yes
   int pos = cStringUtils::FindLastOf(path, PATH_DELIMITERS);
   if (pos < 0) {
      head = path;
      tail = "";
   } else {
      head = cStringUtils::Left(path, pos);
      tail = cStringUtils::Right(path, strlen(path) - (pos + 1));
   }
  //## end cFileSystemUtils::RightSplit%998912349.body
}

STRING_T cFileSystemUtils::AppendPath (CONST_STRING_T head, CONST_STRING_T tail, CONST_STRING_T delimiter)
{
  //## begin cFileSystemUtils::AppendPath%998912355.body preserve=yes
   if (strlen(head) == 0) return tail;
   if (strlen(tail) == 0) return head;
   if (IsAbsolutePath(tail) || IsUNCPath(tail)) return tail;
   STRING_T new_head = cStringUtils::RTrim(head, SLASH);
   new_head = cStringUtils::RTrim(new_head.c_str(), BACK_SLASH);
   STRING_T new_tail = cStringUtils::LTrim(tail, SLASH);
   new_tail = cStringUtils::LTrim(new_tail.c_str(), BACK_SLASH);
   STRING_T new_path = new_head;
   new_path += delimiter;
   new_path += new_tail.c_str();
   return new_path;
  //## end cFileSystemUtils::AppendPath%998912355.body
}

STRING_T cFileSystemUtils::FileName (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::FileName%998912350.body preserve=yes
   STRING_T file_name;
   STRING_T directory;
   RightSplit(path, directory, file_name);
   if (directory.size() > 0 && file_name.size() == 0) file_name = directory;
   return file_name;
  //## end cFileSystemUtils::FileName%998912350.body
}

STRING_T cFileSystemUtils::DirName (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::DirName%998912351.body preserve=yes
   STRING_T file_name;
   STRING_T directory;
   RightSplit(path, directory, file_name);
   return directory;
  //## end cFileSystemUtils::DirName%998912351.body
}

STRING_T cFileSystemUtils::DriveName (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::DriveName%998912359.body preserve=yes
   if (IsUNCPath(path)) return "";
   if (IsRelativePath(path)) {
      return DriveName(CurrentDir().c_str());
   }
   STRING_T drive_name = cStringUtils::Left(path, 2);
   return drive_name;
  //## end cFileSystemUtils::DriveName%998912359.body
}

STRING_T cFileSystemUtils::FileExtension (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::FileExtension%998912352.body preserve=yes
   int pos = cStringUtils::FindLastOf(path, ".");
   STRING_T file_extension = cStringUtils::Right(path, strlen(path) - pos);
   return file_extension;
  //## end cFileSystemUtils::FileExtension%998912352.body
}

STRING_T cFileSystemUtils::CurrentDir ()
{
  //## begin cFileSystemUtils::CurrentDir%998912356.body preserve=yes
   char current_directory[1024] = {0};
   DWORD len = GetCurrentDirectory(sizeof(current_directory), current_directory);
   if (len > 0) {
      return current_directory;
   } else {
      return "Current directory unknown";
   }
  //## end cFileSystemUtils::CurrentDir%998912356.body
}

STRING_T cFileSystemUtils::CurrentDrive ()
{
  //## begin cFileSystemUtils::CurrentDrive%998912363.body preserve=yes
   STRING_T current_directory = CurrentDir();
   STRING_T current_drive = cStringUtils::Left(current_directory, 2);
   return current_drive;
  //## end cFileSystemUtils::CurrentDrive%998912363.body
}

STRING_T cFileSystemUtils::StartupDir ()
{
  //## begin cFileSystemUtils::StartupDir%998912357.body preserve=yes
   if (_StartupDirectory.size() == 0) {
      _StartupDirectory = CurrentDir();
   }
   return _StartupDirectory.c_str();
  //## end cFileSystemUtils::StartupDir%998912357.body
}

BOOL_T cFileSystemUtils::IsRelativePath (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::IsRelativePath%998912360.body preserve=yes
   int len = strlen(path);
   if (len == 0) return true;
   if (IsPathDelimiter(path[0])) {
      return false;
   } else if (len > 1 && IsDriveChar(path[1])) {
      return false;
   } else {
      return true;
   }
  //## end cFileSystemUtils::IsRelativePath%998912360.body
}

BOOL_T cFileSystemUtils::IsAbsolutePath (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::IsAbsolutePath%998912361.body preserve=yes
   return !IsRelativePath(path);
  //## end cFileSystemUtils::IsAbsolutePath%998912361.body
}

BOOL_T cFileSystemUtils::IsUNCPath (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::IsUNCPath%998912365.body preserve=yes
   if (path[0] == BACK_SLASH && path[1] == BACK_SLASH) {
      return true;
   } else {
      return false;
   }
  //## end cFileSystemUtils::IsUNCPath%998912365.body
}

BOOL_T cFileSystemUtils::IsPathDelimiter (CHAR_T c)
{
  //## begin cFileSystemUtils::IsPathDelimiter%998912362.body preserve=yes
   return (c == BACK_SLASH || c == SLASH);
  //## end cFileSystemUtils::IsPathDelimiter%998912362.body
}

BOOL_T cFileSystemUtils::IsDrive (CONST_STRING_T path)
{
  //## begin cFileSystemUtils::IsDrive%998912364.body preserve=yes
   if (strlen(path) == 2 && IsDriveChar(path[1])) {
      return true;
   } else {
      return false;
   }
  //## end cFileSystemUtils::IsDrive%998912364.body
}

BOOL_T cFileSystemUtils::IsDriveChar (CHAR_T c)
{
  //## begin cFileSystemUtils::IsDriveChar%998912366.body preserve=yes
   return (c == ':');
  //## end cFileSystemUtils::IsDriveChar%998912366.body
}

INT_T cFileSystemUtils::WriteProfileString (CONST_STRING_T chapter, CONST_STRING_T key, CONST_STRING_T value, CONST_STRING_T file)
{
  //## begin cFileSystemUtils::WriteProfileString%1046178221.body preserve=yes
   BOOL success = WritePrivateProfileString(chapter, key, value, file);
   if (!success) {
      return GetLastError();
   }
   return 0;
  //## end cFileSystemUtils::WriteProfileString%1046178221.body
}

STRING_T cFileSystemUtils::GetProfileString (CONST_STRING_T chapter, CONST_STRING_T key, CONST_STRING_T default_value, CONST_STRING_T file)
{
  //## begin cFileSystemUtils::GetProfileString%1053266946.body preserve=yes
   char buffer[1024] = {0};
   DWORD nread = GetPrivateProfileString(chapter, key, default_value, buffer, sizeof(buffer), file);
   return buffer;
  //## end cFileSystemUtils::GetProfileString%1053266946.body
}

//## Get and Set Operations for Class Attributes (implementation)

FileSystemTypes cFileSystemUtils::get_Type ()
{
  //## begin cFileSystemUtils::get_Type%3B8A340400E4.get preserve=no
  return _Type;
  //## end cFileSystemUtils::get_Type%3B8A340400E4.get
}

void cFileSystemUtils::set_Type (FileSystemTypes value)
{
  //## begin cFileSystemUtils::set_Type%3B8A340400E4.set preserve=no
  _Type = value;
  //## end cFileSystemUtils::set_Type%3B8A340400E4.set
}

// Additional Declarations
  //## begin cFileSystemUtils%3B8A315401D5.declarations preserve=yes
  //## end cFileSystemUtils%3B8A315401D5.declarations

//## begin module%3B8A315401D5.epilog preserve=yes
//## end module%3B8A315401D5.epilog
