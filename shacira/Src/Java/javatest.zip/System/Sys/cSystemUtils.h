//## begin module%3B8A23E00182.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3B8A23E00182.cm

//## begin module%3B8A23E00182.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3B8A23E00182.cp

//## Module: cSystemUtils%3B8A23E00182; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cSystemUtils.h

#ifndef cSystemUtils_h
#define cSystemUtils_h 1

//## begin module%3B8A23E00182.includes preserve=yes
//## end module%3B8A23E00182.includes

//## begin module%3B8A23E00182.additionalDeclarations preserve=yes
//## end module%3B8A23E00182.additionalDeclarations


//## begin cSystemUtils%3B8A23E00182.preface preserve=yes
//## end cSystemUtils%3B8A23E00182.preface

//## Class: cSystemUtils%3B8A23E00182
//	This class offers some utility functions wrapped around
//	system functionality.
//## Category: System::Sys%3E5A1D1800A3
//## Persistence: Transient
//## Cardinality/Multiplicity: n

class __DLL_EXPORT__ cSystemUtils 
{
  //## begin cSystemUtils%3B8A23E00182.initialDeclarations preserve=yes
public:
  //## end cSystemUtils%3B8A23E00182.initialDeclarations

    //## Constructors (generated)
      cSystemUtils();

      cSystemUtils(const cSystemUtils &right);

    //## Destructor (generated)
      virtual ~cSystemUtils();


    //## Other Operations (specified)
      //## Operation: ComputerName%998912342
      //	Denotes the name of the computer the process is running
      //	on.
      static STRING_T ComputerName ();

      //## Operation: IPAddress%1041592744
      //	Denotes the ip address of the computer the process is
      //	running on.
      static STRING_T IPAddress ();

      //## Operation: EnvironmentString%998912343
      //	Delivers the substitution of an environment variable. If
      //	this variable is not defined the return value is an
      //	empty string;
      static STRING_T EnvironmentString (CONST_STRING_T variable);

      //## Operation: ProcessId%1036748524
      //	Denotes the Id of the current process.
      static ULONG_T ProcessId ();

      //## Operation: ThreadId%1036748525
      //	Denotes the Id of the current thread.
      static ULONG_T ThreadId ();

      //## Operation: Suspend%1036748526
      //	Suspends thread execution for msecs milliseconds;
      static void Suspend (ULONG_T msecs);

      //## Operation: Alloc%1050584916
      static void * Alloc (ULONG_T size);

      //## Operation: Free%1050584917
      static void Free (void *memory);

      //## Operation: Milliseconds%1054305357
      static ULONG_T Milliseconds ();

  public:
    // Additional Public Declarations
      //## begin cSystemUtils%3B8A23E00182.public preserve=yes
      //## end cSystemUtils%3B8A23E00182.public

  protected:
    // Additional Protected Declarations
      //## begin cSystemUtils%3B8A23E00182.protected preserve=yes
      //## end cSystemUtils%3B8A23E00182.protected

  private:
    // Additional Private Declarations
      //## begin cSystemUtils%3B8A23E00182.private preserve=yes
      //## end cSystemUtils%3B8A23E00182.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ComputerName%3B8A3EB802BA
      //## begin cSystemUtils::ComputerName%3B8A3EB802BA.attr preserve=no  implementation: static STRING_T {U} 
      static STRING_T _ComputerName;
      //## end cSystemUtils::ComputerName%3B8A3EB802BA.attr

    // Additional Implementation Declarations
      //## begin cSystemUtils%3B8A23E00182.implementation preserve=yes
      //## end cSystemUtils%3B8A23E00182.implementation

};

//## begin cSystemUtils%3B8A23E00182.postscript preserve=yes
//## end cSystemUtils%3B8A23E00182.postscript

// Class cSystemUtils 

//## begin module%3B8A23E00182.epilog preserve=yes
//## end module%3B8A23E00182.epilog


#endif
