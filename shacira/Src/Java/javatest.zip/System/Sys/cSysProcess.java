//## begin module%3AE83FE50190.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3AE83FE50190.cm

//## begin module%3AE83FE50190.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3AE83FE50190.cp

//## Module: cSysProcess%3AE83FE50190; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cSysProcess.cpp

//## begin module%3AE83FE50190.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3AE83FE50190.additionalIncludes

//## begin module%3AE83FE50190.includes preserve=yes
#include <process.h>
//## end module%3AE83FE50190.includes

// cSysProcess
#include "System/Sys/cSysProcess.h"
//## begin module%3AE83FE50190.additionalDeclarations preserve=yes
//## end module%3AE83FE50190.additionalDeclarations


// Class cSysProcess 






cSysProcess::cSysProcess()
  //## begin cSysProcess::cSysProcess%.hasinit preserve=no
      : _Pid(0), _Handle(NULL)
  //## end cSysProcess::cSysProcess%.hasinit
  //## begin cSysProcess::cSysProcess%.initialization preserve=yes
  //## end cSysProcess::cSysProcess%.initialization
{
  //## begin cSysProcess::cSysProcess%.body preserve=yes
  //## end cSysProcess::cSysProcess%.body
}

cSysProcess::cSysProcess(const cSysProcess &right)
  //## begin cSysProcess::cSysProcess%copy.hasinit preserve=no
      : _Pid(0), _Handle(NULL)
  //## end cSysProcess::cSysProcess%copy.hasinit
  //## begin cSysProcess::cSysProcess%copy.initialization preserve=yes
  //## end cSysProcess::cSysProcess%copy.initialization
{
  //## begin cSysProcess::cSysProcess%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cSysProcess::cSysProcess%copy.body
}


cSysProcess::~cSysProcess()
{
  //## begin cSysProcess::~cSysProcess%.body preserve=yes
   Terminate();
  //## end cSysProcess::~cSysProcess%.body
}



//## Other Operations (implementation)
BOOL_T cSysProcess::Create (CONST_STRING_T name, CONST_STRING_T args)
{
  //## begin cSysProcess::Create%988300376.body preserve=yes
   __TRY__ {
      STARTUPINFO suinfo = {0};
      PROCESS_INFORMATION pinfo = {0};
      _Name = name;
      if (args != NULL) _Args += args;
      char command[512] = {0};
      sprintf(command, "%s %s", _Name.c_str(), _Args.c_str());
      suinfo.cb = sizeof(suinfo);
      int err = 0;
      BOOL_T success = (BOOL_T)CreateProcess(_Name.c_str(),
                                             command,
                                             NULL,
                                             NULL,
                                             false,
                                             0,
                                             NULL,
                                             NULL,
                                             &suinfo,
                                             &pinfo);
      if (success) {
         _Pid = pinfo.dwProcessId;
         _Handle = pinfo.hProcess;
         return true;
      } else {
         err = GetLastError();
         InfoPrintf("Failed to create process %s %d\n", name, err);
         return false;
      }
   } __EXCEPT__(EXCEPTION_EXECUTE_HANDLER) {
      InfoPrintf("Failed to create process%s fatal\n", name);
      return false;
   }
  //## end cSysProcess::Create%988300376.body
}

BOOL_T cSysProcess::Spawn (CONST_STRING_T name, CONST_STRING_T args)
{
  //## begin cSysProcess::Spawn%988306473.body preserve=yes
   __TRY__ {
      int pid = -1;
      _Name = name;
      if (args != NULL) _Args += args;
      try {
         pid = spawnlp(P_NOWAIT, name, name, args, NULL);
         if (pid > 0) {
            _Pid = pid;
            return true;
         } else {
            InfoPrintf("Failed to start process %s %d\n", name, errno);
            return false;
         }
      } catch (...) {
         InfoPrintf("Failed to spawn process %s exception\n", name);
         return false;
      }
   } __EXCEPT__(EXCEPTION_EXECUTE_HANDLER) {
      InfoPrintf("Failed to spawn process %s fatal\n", name);
      return false;
   }
  //## end cSysProcess::Spawn%988306473.body
}

BOOL_T cSysProcess::Terminate ()
{
  //## begin cSysProcess::Terminate%988300377.body preserve=yes
   __TRY__ {
      BOOL_T success = true;
      int err = 0;
      if (_Handle != NULL) {
         success = (BOOL_T)TerminateProcess(_Handle, 0);
         if (success) {
            _Handle = NULL;
            return true;
         } else {
            err = GetLastError();
            InfoPrintf("Failed to terminate process %p %d\n", _Handle, err);
            return false;
         }
      }
      return success;
   } __EXCEPT__(EXCEPTION_EXECUTE_HANDLER) {
      InfoPrintf("Failed to terminate process %p fatal\n", _Handle);
      return false;
   }
  //## end cSysProcess::Terminate%988300377.body
}

//## Get and Set Operations for Class Attributes (implementation)

INT_T cSysProcess::get_Pid () const
{
  //## begin cSysProcess::get_Pid%3AE8408B03D4.get preserve=no
  return _Pid;
  //## end cSysProcess::get_Pid%3AE8408B03D4.get
}

// Additional Declarations
  //## begin cSysProcess%3AE83FE50190.declarations preserve=yes
  //## end cSysProcess%3AE83FE50190.declarations

//## begin module%3AE83FE50190.epilog preserve=yes
//## end module%3AE83FE50190.epilog
