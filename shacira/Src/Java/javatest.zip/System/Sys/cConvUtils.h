//## begin module%3C7FAFB50192.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C7FAFB50192.cm

//## begin module%3C7FAFB50192.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C7FAFB50192.cp

//## Module: cConvUtils%3C7FAFB50192; Pseudo Package specification
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cConvUtils.h

#ifndef cConvUtils_h
#define cConvUtils_h 1

//## begin module%3C7FAFB50192.includes preserve=yes
//## end module%3C7FAFB50192.includes


class __DLL_EXPORT__ cStringUtils;

//## begin module%3C7FAFB50192.additionalDeclarations preserve=yes
//## end module%3C7FAFB50192.additionalDeclarations


//## begin cConvUtils%3C7FAFB50192.preface preserve=yes
//## end cConvUtils%3C7FAFB50192.preface

//## Class: cConvUtils%3C7FAFB50192
//## Category: System::Sys%3E5A1D1800A3
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C7FB3C3039D;cStringUtils { -> F}

class __DLL_EXPORT__ cConvUtils 
{
  //## begin cConvUtils%3C7FAFB50192.initialDeclarations preserve=yes
public:
  //## end cConvUtils%3C7FAFB50192.initialDeclarations

    //## Constructors (generated)
      cConvUtils();

      cConvUtils(const cConvUtils &right);

    //## Destructor (generated)
      virtual ~cConvUtils();


    //## Other Operations (specified)
      //## Operation: CharBuf2LPWSTR%1014996958
      //	Conversion function from character buffer to windows
      //	LPWSTR.
      static LPWSTR CharBuf2LPWSTR (CONST_STRING_T buf);

      //## Operation: LPWSTR2CharBuf%1014996959
      //	Conversion function from character buffer to windows
      //	LPWSTR.
      static CONST_STRING_T LPWSTR2CharBuf (LPWSTR wide_string, CHAR_T *buf, INT_T buf_size);

      //## Operation: StringValue%1014996960
      static STRING_T StringValue (DOUBLE_T value);

      //## Operation: StringValue%1014996962
      static STRING_T StringValue (FLOAT_T value);

      //## Operation: StringValue%1014996961
      static STRING_T StringValue (LONG_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996963
      static STRING_T StringValue (ULONG_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996964
      static STRING_T StringValue (INT_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996965
      static STRING_T StringValue (UINT_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996966
      static STRING_T StringValue (SHORT_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996967
      static STRING_T StringValue (USHORT_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996968
      static STRING_T StringValue (CHAR_T value, INT_T radix = 10);

      //## Operation: StringValue%1014996969
      static STRING_T StringValue (UCHAR_T value, INT_T radix = 10);

      //## Operation: IsNumeric%1037360042
      static BOOL_T IsNumeric (CONST_STRING_T value);

      //## Operation: DataTypeFromString%1038418270
      static void DataTypeFromString (CONST_STRING_T value, CHAR_T &data_type, USHORT_T &length, UCHAR_T &precision);

      //## Operation: FormatValue%1038473727
      static STRING_T FormatValue (CONST_STRING_T value, CHAR_T data_type = UNDEFINED, USHORT_T length = 0, UCHAR_T precision = 0);

  public:
    // Additional Public Declarations
      //## begin cConvUtils%3C7FAFB50192.public preserve=yes
      //## end cConvUtils%3C7FAFB50192.public

  protected:
    // Additional Protected Declarations
      //## begin cConvUtils%3C7FAFB50192.protected preserve=yes
      //## end cConvUtils%3C7FAFB50192.protected

  private:
    // Additional Private Declarations
      //## begin cConvUtils%3C7FAFB50192.private preserve=yes
      //## end cConvUtils%3C7FAFB50192.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: FormatReal%1038473728
      static void FormatReal (BUF_T value, UCHAR_T precision);

    // Additional Implementation Declarations
      //## begin cConvUtils%3C7FAFB50192.implementation preserve=yes
      //## end cConvUtils%3C7FAFB50192.implementation

};

//## begin cConvUtils%3C7FAFB50192.postscript preserve=yes
//## end cConvUtils%3C7FAFB50192.postscript

// Class cConvUtils 

//## begin module%3C7FAFB50192.epilog preserve=yes
//## end module%3C7FAFB50192.epilog


#endif
