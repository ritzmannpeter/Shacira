//## begin module%3C7FAFB50192.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C7FAFB50192.cm

//## begin module%3C7FAFB50192.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C7FAFB50192.cp

//## Module: cConvUtils%3C7FAFB50192; Pseudo Package body
//## Source file: e:\usr\prj\Shacira\Src\System\Sys\cConvUtils.cpp

//## begin module%3C7FAFB50192.additionalIncludes preserve=no
#include "FirstHeader.h"
//## end module%3C7FAFB50192.additionalIncludes

//## begin module%3C7FAFB50192.includes preserve=yes
//## end module%3C7FAFB50192.includes

// cStringUtils
#include "System/cStringUtils.h"
// cConvUtils
#include "System/Sys/cConvUtils.h"
//## begin module%3C7FAFB50192.additionalDeclarations preserve=yes
//## end module%3C7FAFB50192.additionalDeclarations


// Class cConvUtils 

cConvUtils::cConvUtils()
  //## begin cConvUtils::cConvUtils%.hasinit preserve=no
  //## end cConvUtils::cConvUtils%.hasinit
  //## begin cConvUtils::cConvUtils%.initialization preserve=yes
  //## end cConvUtils::cConvUtils%.initialization
{
  //## begin cConvUtils::cConvUtils%.body preserve=yes
  //## end cConvUtils::cConvUtils%.body
}

cConvUtils::cConvUtils(const cConvUtils &right)
  //## begin cConvUtils::cConvUtils%copy.hasinit preserve=no
  //## end cConvUtils::cConvUtils%copy.hasinit
  //## begin cConvUtils::cConvUtils%copy.initialization preserve=yes
  //## end cConvUtils::cConvUtils%copy.initialization
{
  //## begin cConvUtils::cConvUtils%copy.body preserve=yes
  //## end cConvUtils::cConvUtils%copy.body
}


cConvUtils::~cConvUtils()
{
  //## begin cConvUtils::~cConvUtils%.body preserve=yes
  //## end cConvUtils::~cConvUtils%.body
}



//## Other Operations (implementation)
LPWSTR cConvUtils::CharBuf2LPWSTR (CONST_STRING_T buf)
{
  //## begin cConvUtils::CharBuf2LPWSTR%1014996958.body preserve=yes
   int len = strlen(buf);
   WCHAR* wide_buf = new WCHAR[len+1];
   MultiByteToWideChar(CP_ACP, 0, buf, -1, wide_buf, len+1);
   LPWSTR wide_string = SysAllocString(wide_buf);
   delete wide_buf;
   return wide_string;
  //## end cConvUtils::CharBuf2LPWSTR%1014996958.body
}

CONST_STRING_T cConvUtils::LPWSTR2CharBuf (LPWSTR wide_string, CHAR_T *buf, INT_T buf_size)
{
  //## begin cConvUtils::LPWSTR2CharBuf%1014996959.body preserve=yes
   WideCharToMultiByte(CP_ACP, 0, wide_string, -1, buf, buf_size, NULL, NULL);
   return buf;
  //## end cConvUtils::LPWSTR2CharBuf%1014996959.body
}

STRING_T cConvUtils::StringValue (DOUBLE_T value)
{
  //## begin cConvUtils::StringValue%1014996960.body preserve=yes
   char cval[64] = {0};
   sprintf(cval, "%f", value);
   STRING_T sval = cStringUtils::RTrim(cval, '0');
   sval = cStringUtils::RTrim(sval.c_str(), '.');
   return sval;
  //## end cConvUtils::StringValue%1014996960.body
}

STRING_T cConvUtils::StringValue (FLOAT_T value)
{
  //## begin cConvUtils::StringValue%1014996962.body preserve=yes
   char cval[64] = {0};
   sprintf(cval, "%f", value);
   STRING_T sval = cStringUtils::RTrim(cval, '0');
   sval = cStringUtils::RTrim(sval.c_str(), '.');
   return sval;
  //## end cConvUtils::StringValue%1014996962.body
}

STRING_T cConvUtils::StringValue (LONG_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996961.body preserve=yes
   char cval[32] = {0};
   ltoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996961.body
}

STRING_T cConvUtils::StringValue (ULONG_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996963.body preserve=yes
   char cval[32] = {0};
   ltoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996963.body
}

STRING_T cConvUtils::StringValue (INT_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996964.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996964.body
}

STRING_T cConvUtils::StringValue (UINT_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996965.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996965.body
}

STRING_T cConvUtils::StringValue (SHORT_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996966.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996966.body
}

STRING_T cConvUtils::StringValue (USHORT_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996967.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996967.body
}

STRING_T cConvUtils::StringValue (CHAR_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996968.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996968.body
}

STRING_T cConvUtils::StringValue (UCHAR_T value, INT_T radix)
{
  //## begin cConvUtils::StringValue%1014996969.body preserve=yes
   char cval[32] = {0};
   itoa(value, cval, radix);
   return cval;
  //## end cConvUtils::StringValue%1014996969.body
}

BOOL_T cConvUtils::IsNumeric (CONST_STRING_T value)
{
  //## begin cConvUtils::IsNumeric%1037360042.body preserve=yes
   int size = strlen(value);
   if (size == 0) return false;
   int decimal_points = 0;
   for (int i=0; i<size; i++) {
      int c = value[i];
      if (c == '.') {
         if (decimal_points == 0) {
            decimal_points++;
         } else {
            return false;
         }
      } else if (!isdigit(c)) {
         return false;
      }
   }
   return true;
  //## end cConvUtils::IsNumeric%1037360042.body
}

void cConvUtils::DataTypeFromString (CONST_STRING_T value, CHAR_T &data_type, USHORT_T &length, UCHAR_T &precision)
{
  //## begin cConvUtils::DataTypeFromString%1038418270.body preserve=yes
   int size = strlen(value);
   if (size == 0) return;
   int decimal_points = 0;
   for (int i=0; i<size; i++) {
      int c = value[i];
      if (c == '.') {
         if (decimal_points == 0) {
            decimal_points++;
            data_type = SH_DOUBLE;
         } else {
            data_type = SH_STRING;
            return;
         }
      } else if (isdigit(c)) {
         if (decimal_points == 1) precision++;
      } else {
         data_type = SH_STRING;
         return;
      }
   }
   if (decimal_points == 0) {
      data_type = SH_LONG;
   } else {
      data_type = SH_DOUBLE;
   }
  //## end cConvUtils::DataTypeFromString%1038418270.body
}

STRING_T cConvUtils::FormatValue (CONST_STRING_T value, CHAR_T data_type, USHORT_T length, UCHAR_T precision)
{
  //## begin cConvUtils::FormatValue%1038473727.body preserve=yes
   char buf[128] = {0};
   BOOL_T not_null = (strlen(value) > 0);
   LONG_T slong = 0;
   ULONG_T ulong = 0;
   float real = 0;
   switch (data_type) {
   case SH_CHAR:
   case SH_SHORT:
   case SH_LONG:
      if (not_null) slong = atol(value); 
      sprintf(buf, "%d", slong);
      break;
   case SH_UCHAR:
   case SH_USHORT:
   case SH_ULONG:
      if (not_null) ulong = atol(value); 
      sprintf(buf, "%d", ulong);
      break;
   case SH_FLOAT:
   case SH_DOUBLE:
      if (not_null) sscanf(value, "%f", &real);
      sprintf(buf, "%f", real);
      FormatReal(buf, precision);
      break;
/*
      switch (precision) {
      case 0: sprintf(buf, "%.0f"); break;
      case 1: sprintf(buf, "%.1f"); break;
      case 2: sprintf(buf, "%.2f"); break;
      case 3: sprintf(buf, "%.3f"); break;
      case 4: sprintf(buf, "%.4f"); break;
      case 5: sprintf(buf, "%.5f"); break;
      default: sprintf(buf, "%f"); break;
      }
*/
   case SH_STRING:
   case SH_WSTRING:
      return value;
   case SH_SYM_BCD:
      if (not_null) ulong = atol(value);
      switch (length) {
      case 0: sprintf(buf, "%d", ulong); break;
      case 1: sprintf(buf, "%1.1d", ulong); break;
      case 2: sprintf(buf, "%2.2d", ulong); break;
      case 3: sprintf(buf, "%3.3d", ulong); break;
      case 4: sprintf(buf, "%4.4d", ulong); break;
      case 5: sprintf(buf, "%5.5d", ulong); break;
      case 6: sprintf(buf, "%6.6d", ulong); break;
      case 7: sprintf(buf, "%7.7d", ulong); break;
      case 8: sprintf(buf, "%8.8d", ulong); break;
      case 9: sprintf(buf, "%9.9d", ulong); break;
      case 10: sprintf(buf, "%10.10d", ulong); break;
      case 11: sprintf(buf, "%11.11d", ulong); break;
      case 12: sprintf(buf, "%12.12d", ulong); break;
      default: sprintf(buf, "%d", ulong); break;
      }
      break;
   case SH_SYM_KMBCD:
      if (not_null) ulong = atol(value);
      switch (length) {
      case 0: sprintf(buf, "%d", ulong); break;
      case 1: sprintf(buf, "%1.1d", ulong); break;
      case 2: sprintf(buf, "%2.2d", ulong); break;
      case 3: sprintf(buf, "%3.3d", ulong); break;
      case 4: sprintf(buf, "%4.4d", ulong); break;
      case 5: sprintf(buf, "%5.5d", ulong); break;
      case 6: sprintf(buf, "%6.6d", ulong); break;
      case 7: sprintf(buf, "%7.7d", ulong); break;
      case 8: sprintf(buf, "%8.8d", ulong); break;
      case 9: sprintf(buf, "%9.9d", ulong); break;
      case 10: sprintf(buf, "%10.10d", ulong); break;
      case 11: sprintf(buf, "%11.11d", ulong); break;
      case 12: sprintf(buf, "%12.12d", ulong); break;
      default: sprintf(buf, "%d", ulong); break;
      }
      break;
   case SH_SYM_HEX:
      if (not_null) {
         int params = sscanf(value, "%d", &ulong);
      }
      switch (length) {
      case 0: sprintf(buf, "%X", ulong); break;
      case 1: sprintf(buf, "%1.1X", ulong); break;
      case 2: sprintf(buf, "%2.2X", ulong); break;
      case 3: sprintf(buf, "%3.3X", ulong); break;
      case 4: sprintf(buf, "%4.4X", ulong); break;
      case 5: sprintf(buf, "%5.5X", ulong); break;
      case 6: sprintf(buf, "%6.6X", ulong); break;
      case 7: sprintf(buf, "%7.7X", ulong); break;
      case 8: sprintf(buf, "%8.8X", ulong); break;
      case 9: sprintf(buf, "%9.9X", ulong); break;
      case 10: sprintf(buf, "%10.10X", ulong); break;
      case 11: sprintf(buf, "%11.11X", ulong); break;
      case 12: sprintf(buf, "%12.12X", ulong); break;
      default: sprintf(buf, "%X", ulong); break;
      }
      break;
   default: return "?";
   }
   return buf;
  //## end cConvUtils::FormatValue%1038473727.body
}

void cConvUtils::FormatReal (BUF_T value, UCHAR_T precision)
{
  //## begin cConvUtils::FormatReal%1038473728.body preserve=yes
   if (precision == 0) return;
   unsigned int len = strlen(value);
   BOOL_T decimal_point = false;
   for (unsigned int i=0; i<len; i++) {
      if (decimal_point && precision == 0) {
         value[i] = '\0';
         return;
      }
      if (decimal_point) precision--;
      if (value[i] == '.') decimal_point = true;
   }
  //## end cConvUtils::FormatReal%1038473728.body
}

// Additional Declarations
  //## begin cConvUtils%3C7FAFB50192.declarations preserve=yes
  //## end cConvUtils%3C7FAFB50192.declarations

//## begin module%3C7FAFB50192.epilog preserve=yes
//## end module%3C7FAFB50192.epilog
