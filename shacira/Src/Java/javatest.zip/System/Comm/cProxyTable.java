//## begin module%3C4EE4B900CF.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C4EE4B900CF.cm

//## begin module%3C4EE4B900CF.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C4EE4B900CF.cp

//## Module: cProxyTable%3C4EE4B900CF; Pseudo Package body
//## Source file: e:/usr/prj/Shacira/Src/System/Comm/cProxyTable.cpp

//## begin module%3C4EE4B900CF.additionalIncludes preserve=no
//## end module%3C4EE4B900CF.additionalIncludes

//## begin module%3C4EE4B900CF.includes preserve=yes
//## end module%3C4EE4B900CF.includes

// cCellProxy
import cCellProxy.*;
// cObjectLock
import cObjectLock.*;
// cProxy
import cProxy.*;
// cConvUtils
import cConvUtils.*;
// cChannelProxy
import System.Channel.cChannelProxy.*;
//## begin module%3C4EE4B900CF.additionalDeclarations preserve=yes
//## end module%3C4EE4B900CF.additionalDeclarations


// Class cProxyTable 




class cProxyTable {

cProxyTable()
  //## begin cProxyTable%.hasinit preserve=no
  //## end cProxyTable%.hasinit
  //## begin cProxyTable%.initialization preserve=yes
  //## end cProxyTable%.initialization
{
  //## begin cProxyTable%.body preserve=yes
  //## end cProxyTable%.body
}

//## Other Operations (implementation)
cProxy Proxy (String name)
{
  //## begin Proxy%1011794629.body preserve=yes
  //## end Proxy%1011794629.body
}

cCellProxy CellProxy (String name)
{
  //## begin CellProxy%1011861108.body preserve=yes
  //## end CellProxy%1011861108.body
}

cChannelProxy ChannelProxy (String name)
{
  //## begin ChannelProxy%1011948773.body preserve=yes
  //## end ChannelProxy%1011948773.body
}

void SetProxy (cProxy proxy)
{
  //## begin SetProxy%1011794627.body preserve=yes
  //## end SetProxy%1011794627.body
}

}

// Additional Declarations
  //## begin cProxyTable%3C4EE4B900CF.declarations preserve=yes
  //## end cProxyTable%3C4EE4B900CF.declarations

//## begin module%3C4EE4B900CF.epilog preserve=yes
//## end module%3C4EE4B900CF.epilog
