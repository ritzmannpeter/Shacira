//## begin module%3C552714024C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C552714024C.cm

//## begin module%3C552714024C.cp preserve=no
//	Copyright � 2002 by
//	2i Industrial Informatics GmbH
//## end module%3C552714024C.cp

//## Module: cProxyReceiver%3C552714024C; Pseudo Package body
//## Source file: e:/usr/prj/Shacira/Src/System/Comm/cProxyReceiver.cpp

//## begin module%3C552714024C.additionalIncludes preserve=no
//## end module%3C552714024C.additionalIncludes

//## begin module%3C552714024C.includes preserve=yes
//## end module%3C552714024C.includes

// cCellProxy
import System/Process/cCellProxy.*
// cSHProcess
import System/Process/cSHProcess.*
// cProxy
import System/Objects/cProxy.*
// cConfigurationObject
import System/Config/cConfigurationObject.*
// cProxyReceiver
import System/Comm/cProxyReceiver.*
// cProxyTable
import System/Comm/cProxyTable.*
// cConvUtils
import System/Sys/cConvUtils.*
// cChannelProxy
import System/Channel/cChannelProxy.*
// cCosEventChannelProxy
import Orb/cCosEventChannelProxy.*
// cCorbaCellProxy
import Orb/cCorbaCellProxy.*
//## begin module%3C552714024C.additionalDeclarations preserve=yes

#define RECEIVER_TIMEOUT   1000
#define INBUF_SIZE         1024

//## end module%3C552714024C.additionalDeclarations


// Class cProxyReceiver 







cProxyReceiver::cProxyReceiver()
  //## begin cProxyReceiver::cProxyReceiver%.hasinit preserve=no
      : _IPAddress("127.0.0.1"), _Port(0), _Socket(INVALID_SOCKET), _Process(NULL), _ProxyTable(NULL)
  //## end cProxyReceiver::cProxyReceiver%.hasinit
  //## begin cProxyReceiver::cProxyReceiver%.initialization preserve=yes
  //## end cProxyReceiver::cProxyReceiver%.initialization
{
  //## begin cProxyReceiver::cProxyReceiver%.body preserve=yes
   _InBuf.Size(INBUF_SIZE);
   _ProxyTable = new cProxyTable;
  //## end cProxyReceiver::cProxyReceiver%.body
}

cProxyReceiver::cProxyReceiver(const cProxyReceiver &right)
  //## begin cProxyReceiver::cProxyReceiver%copy.hasinit preserve=no
      : _IPAddress("127.0.0.1"), _Port(0), _Socket(INVALID_SOCKET), _Process(NULL), _ProxyTable(NULL)
  //## end cProxyReceiver::cProxyReceiver%copy.hasinit
  //## begin cProxyReceiver::cProxyReceiver%copy.initialization preserve=yes
  //## end cProxyReceiver::cProxyReceiver%copy.initialization
{
  //## begin cProxyReceiver::cProxyReceiver%copy.body preserve=yes
_ASSERT_UNCOND
  //## end cProxyReceiver::cProxyReceiver%copy.body
}

cProxyReceiver::cProxyReceiver (ULONG_T port, CONST_STRING_T ip_addr, cSHProcess *process)
  //## begin cProxyReceiver::cProxyReceiver%1012207924.hasinit preserve=no
      : _IPAddress("127.0.0.1"), _Port(0), _Socket(INVALID_SOCKET), _Process(NULL), _ProxyTable(NULL)
  //## end cProxyReceiver::cProxyReceiver%1012207924.hasinit
  //## begin cProxyReceiver::cProxyReceiver%1012207924.initialization preserve=yes
  //## end cProxyReceiver::cProxyReceiver%1012207924.initialization
{
  //## begin cProxyReceiver::cProxyReceiver%1012207924.body preserve=yes
   _InBuf.Size(INBUF_SIZE);
   _Port = port;
   if (ip_addr != NULL) _IPAddress = ip_addr;
   SetSockets();
   _ProxyTable = new cProxyTable;
   _Process = process;
  //## end cProxyReceiver::cProxyReceiver%1012207924.body
}

cProxyReceiver::cProxyReceiver (cConfigurationObject *config_obj, cSHProcess *process)
  //## begin cProxyReceiver::cProxyReceiver%1012207925.hasinit preserve=no
      : _IPAddress("127.0.0.1"), _Port(0), _Socket(INVALID_SOCKET), _Process(NULL), _ProxyTable(NULL)
  //## end cProxyReceiver::cProxyReceiver%1012207925.hasinit
  //## begin cProxyReceiver::cProxyReceiver%1012207925.initialization preserve=yes
  //## end cProxyReceiver::cProxyReceiver%1012207925.initialization
{
  //## begin cProxyReceiver::cProxyReceiver%1012207925.body preserve=yes
_ASSERT_COND(config_obj != NULL)
   _InBuf.Size(INBUF_SIZE);
   _ThreadName = config_obj->get_Name().c_str();
   _Port = config_obj->PropertyValue("ReceivePort", _Port);
   _IPAddress = config_obj->PropertyValue("IPAddress", _IPAddress.c_str());
   SetSockets();
   _ProxyTable = new cProxyTable;
   _Process = process;
  //## end cProxyReceiver::cProxyReceiver%1012207925.body
}


cProxyReceiver::~cProxyReceiver()
{
  //## begin cProxyReceiver::~cProxyReceiver%.body preserve=yes
   ShutDown();
   CloseSockets();
   DELETE_OBJECT(cProxyTable, _ProxyTable)
  //## end cProxyReceiver::~cProxyReceiver%.body
}



//## Other Operations (implementation)
cProxy * cProxyReceiver::Proxy (CONST_STRING_T name)
{
  //## begin cProxyReceiver::Proxy%1012295717.body preserve=yes
   return _ProxyTable->Proxy(name);
  //## end cProxyReceiver::Proxy%1012295717.body
}

cCellProxy * cProxyReceiver::CellProxy (CONST_STRING_T name)
{
  //## begin cProxyReceiver::CellProxy%1012295719.body preserve=yes
   return _ProxyTable->CellProxy(name);
  //## end cProxyReceiver::CellProxy%1012295719.body
}

cChannelProxy * cProxyReceiver::ChannelProxy (CONST_STRING_T name)
{
  //## begin cProxyReceiver::ChannelProxy%1012295720.body preserve=yes
   return _ProxyTable->ChannelProxy(name);
  //## end cProxyReceiver::ChannelProxy%1012295720.body
}

INT_T cProxyReceiver::MainFunc (void *extra)
{
  //## begin cProxyReceiver::MainFunc%1012207938.body preserve=yes
MAINFUNC_PROLOG(_ThreadName.c_str())
   while (!Terminated()) {
MAINFUNC_LOOP_PROLOG(_ThreadName.c_str())
      long size = Receive(_InBuf, _InBuf.Size(), RECEIVER_TIMEOUT);
      if (size > 0 && !Terminated()) {
         ((char*)_InBuf)[size] = 0;
         const char * serialized_obj = (const char *)_InBuf;
         int object_type = cTransferObject::ObjectType(serialized_obj);
         cProxy * proxy = NULL;
         if (object_type == OT_CORBA_CELL_PROXY) {
#ifdef __BLCPP__
            throw cError(PROXY_RECEIVER_UNKNOWN_POT, 0,
                         cConvUtils::StringValue(object_type).c_str(),
                         _ThreadName.c_str(), serialized_obj);
#else
            proxy = new cCorbaCellProxy;
#endif
         } else if (object_type == OT_COS_EVENTCHANNEL_PROXY) {
            proxy = new cCosEventChannelProxy;
         } else {
            throw cError(PROXY_RECEIVER_UNKNOWN_POT, 0,
                         cConvUtils::StringValue(object_type).c_str(),
                         _ThreadName.c_str(), serialized_obj);
         }
         if (proxy != NULL) {
            if (proxy->Construct(serialized_obj)) {
                _ProxyTable->SetProxy(proxy);
                if (_Process != NULL) _Process->NewProxy(proxy);
					RELEASE_OBJECT(proxy)
            } else {
					RELEASE_OBJECT(proxy)
               throw cError(PROXY_RECEIVER_FAILED_TO_CONSTRUCT, 0,
                            _ThreadName.c_str(), serialized_obj);
            }
         }
      }
MAINFUNC_LOOP_EPILOG
   }
   return 0;
MAINFUNC_EPILOG
  //## end cProxyReceiver::MainFunc%1012207938.body
}

ULONG_T cProxyReceiver::Receive (CONST_STRING_T buf, ULONG_T buf_size, ULONG_T timeout)
{
  //## begin cProxyReceiver::Receive%1054547834.body preserve=yes
   if (_Socket == INVALID_SOCKET) {
      cSystemUtils::Suspend(100);
      return 0;
   }
   if (setsockopt(_Socket, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout)) < 0) {
      throw cError(SOCKET_SETSOCKOPT, WSAGetLastError(), _IPAddress.c_str(),
                   cConvUtils::StringValue(_Port).c_str(), "SO_RCVTIMEO");
   }
   struct sockaddr addr = {0};
   int addr_size = sizeof(addr);
   int flags = 0;
   int nreceive = recvfrom(_Socket, _InBuf, _InBuf.Size(), flags, &addr, &addr_size);
   if (nreceive < 0) {
      int err_code = WSAGetLastError();
      if (err_code != WSAETIMEDOUT) {
         throw cError(SOCKET_RECVFROM, WSAGetLastError(), _IPAddress.c_str(),
                      cConvUtils::StringValue(_Port).c_str());
      }
      return 0;
   } else {
      if ((long)buf_size >= nreceive) {
         memcpy((void*)buf, _InBuf, nreceive);
         return nreceive;
      } else {
         throw cError(SOCKET_BUF_TOO_SMALL, 0, _IPAddress.c_str(),
                      cConvUtils::StringValue(_Port).c_str(),
                      cConvUtils::StringValue(nreceive).c_str(),
                      cConvUtils::StringValue(buf_size).c_str());
      }
   }
  //## end cProxyReceiver::Receive%1054547834.body
}

void cProxyReceiver::SetSockets ()
{
  //## begin cProxyReceiver::SetSockets%1054547835.body preserve=yes
   int on = 1;
   if (_Port != 0) {
   	struct sockaddr_in client_addr;
      if ((_Socket = socket(AF_INET, SOCK_DGRAM, 0)) != INVALID_SOCKET) {
         if (setsockopt(_Socket, SOL_SOCKET, SO_REUSEADDR, (const char*)&on, sizeof(on)) < 0) {
            throw cError(SOCKET_SETSOCKOPT, WSAGetLastError(), _IPAddress.c_str(),
                         cConvUtils::StringValue(_Port).c_str(), "SO_REUSEADDR");
         }
         client_addr.sin_family = AF_INET;
         client_addr.sin_addr.s_addr = INADDR_ANY;
         client_addr.sin_port = htons((unsigned short)_Port);
         if (!bind(_Socket, (struct sockaddr *)&client_addr, sizeof(client_addr)) == 0) {
            throw cError(SOCKET_BIND, WSAGetLastError(), _IPAddress.c_str(),
                         cConvUtils::StringValue(_Port).c_str());
         }
      } else {
         throw cError(SOCKET_CREATE, WSAGetLastError(), _IPAddress.c_str(),
                      cConvUtils::StringValue(_Port).c_str());
      }
   }
  //## end cProxyReceiver::SetSockets%1054547835.body
}

void cProxyReceiver::CloseSockets ()
{
  //## begin cProxyReceiver::CloseSockets%1054547836.body preserve=yes
   if (_Socket != INVALID_SOCKET) closesocket(_Socket); 
  //## end cProxyReceiver::CloseSockets%1054547836.body
}

// Additional Declarations
  //## begin cProxyReceiver%3C552714024C.declarations preserve=yes
  //## end cProxyReceiver%3C552714024C.declarations

//## begin module%3C552714024C.epilog preserve=yes
//## end module%3C552714024C.epilog
