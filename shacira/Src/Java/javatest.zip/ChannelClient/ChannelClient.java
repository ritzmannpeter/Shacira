import Control.*;
import org.omg.CORBA.*;
import CosEventComm.*;
import CosEventChannelAdmin.*;
import java.io.*;
import java.lang.*;
import Utility.*;

public class ChannelClient{
    public static void main(String[] args){
        try{
            String pfadIOR = "S:\\user\\sw\\Receiver\\channel.ior";
            ORB orb = ORB.init(args, null);
            CorbaUtility ut = new CorbaUtility(orb, pfadIOR);
            org.omg.CORBA.Object obj =ut.ReadIORFromFile();
            EventChannel e = EventChannelHelper.narrow(obj);

            ConsumerAdmin consumer = e.for_consumers();  //ConsumerObjekt geben lassen
            ProxyPullSupplier supplier = consumer.obtain_pull_supplier(); //Proxyobjekt aufbauen
            supplier.connect_pull_consumer(null); //consumer macht sich beim Proxy bekannt
            while(true){
                Any any = null;
                any = supplier.pull();   //Ereignis wird aus dem Ereigniskanal abgeholt
                String s = any.extract_string();
                System.out.println(s);
            }
        }catch(org.omg.CORBA.SystemException ex){
            System.err.println(ex);
        }catch(NullPointerException np){
            System.err.println(np + ": Objekt nicht gefunden!");
        }catch(AlreadyConnected ac){
            System.err.println(ac);
        }catch(Disconnected dis){
            System.err.println(dis);
        }
    }
}