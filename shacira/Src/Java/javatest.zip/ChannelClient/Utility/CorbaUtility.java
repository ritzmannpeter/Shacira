package Utility;
import java.io.*;
import java.util.*;
import org.omg.CORBA.*;

/** Diese Klasse stellt Funktionen zur Verf�gung mit Hilfe derer IORs
   publiziert und gelesen werden k�nnen
*/

public class CorbaUtility{
//Eigenschaften
    private org.omg.CORBA.ORB _Orb;
    private String _Path;
    private org.omg.CORBA.Object _Obj;
    private String _IOR;

//Konstruktoren
    public CorbaUtility(){
           _Orb = null;
           _Path = null;
           _Obj = null;
           _IOR = null;
    }
    public CorbaUtility(org.omg.CORBA.ORB orb,String path){
           _Orb = orb;
           _Path = path;
           _Obj = null;
           _IOR = null;
    }
    public CorbaUtility(org.omg.CORBA.ORB orb,org.omg.CORBA.Object obj, String path){
           _Orb = orb;
           _Path = path;
           _Obj = obj;
           _IOR = null;
    }

//Methoden
    public org.omg.CORBA.Object ReadIORFromFile(){
        //String IOR= null;
        try{
            //IOR aus Datei lesen
            FileInputStream file = new FileInputStream(_Path);
            BufferedReader in = new BufferedReader (new InputStreamReader(file));
            _IOR = in.readLine();
            file.close();
        }catch(IOException ex){
            System.err.println(ex);
            return null;
        }
        //IOR in Object umwandeln
        org.omg.CORBA.Object _Obj = _Orb.string_to_object (_IOR);
        if(_Obj == null){
            System.err.println("Kein Objekt gefunden!");
            return null;
        }
        return _Obj;
    }
    public boolean WriteIORToFile(){
        try{
            //IOR des Objektes in String umwandeln
            String IOR = _Orb.object_to_string(_Obj);
            //IOR in Datei publizieren
            FileOutputStream file = new FileOutputStream(_Path);
            PrintWriter out = new PrintWriter(file);
            out.println(_IOR);
            out.flush();
            return true;
        }catch(IOException ex){
            System.err.println(ex);
            return false;
        }
    }
}