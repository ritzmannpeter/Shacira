import java.net.*;
import java.io.*;
import java.lang.*;


public class DatagramReceiver{
	static boolean empfange(int port) throws IOException{
	    try{
    		byte[] msg = new byte[1024];
    		DatagramPacket dp = new DatagramPacket(msg, msg.length);
		    DatagramSocket ds = new DatagramSocket(port);
            ds.receive(dp);

            String s = new String(dp.getData(), 0, dp.getLength());
    		System.out.println(s);
    		ds.close();
    		return true;

	    }catch(InterruptedIOException i){
	     	System.out.println(i.getMessage());
		    return false;
	    }
	    catch(BindException b){
		    System.out.println(b.getMessage());
		    return false;
	    }
	}

 	public static void main ( String[] args ) throws Exception {
 	    try{
 	        if (args.length != 1)
            throw new IllegalArgumentException
                            ("Als Parameter muss der port angegeben werden");
            int port = Integer.parseInt(args[0]);
 	        String meldung = new String();
 	        meldung = "Empfangen auf Port ";
 	        meldung += args[0];
 	        meldung += ":";
 	        System.out.println(meldung);

 	        while(true){
 	            empfange(port);
	        }
        }catch(IllegalArgumentException i){
            System.err.println(i);
        }
 	}

}