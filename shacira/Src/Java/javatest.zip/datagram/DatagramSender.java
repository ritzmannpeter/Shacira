import java.net.*;
import java.io.*;
import java.lang.*;


public class DatagramSender{
    public static void main ( String[] args ) throws Exception {
        try{
            if (args.length != 3)
                throw new IllegalArgumentException
                            ("Als Parameter muessen Host, Nachrichtentext und Port angegeben werden");
    		String adresse = new String();
    		adresse = args[0];

    		InetAddress adr = InetAddress.getByName(adresse);
    		String message = new String(args[1]);
            byte[] msg = message.getBytes();

            Integer portObj = new Integer(args[2]);
 	        int port = portObj.intValue();

            DatagramSocket ds = new DatagramSocket();
            DatagramPacket dp = new DatagramPacket(msg,msg.length,adr,port);
            ds.send(dp);
            System.out.println("Message gesendet");
            ds.close();
        }catch(IllegalArgumentException i){
            System.err.println(i);
        }

    }
}