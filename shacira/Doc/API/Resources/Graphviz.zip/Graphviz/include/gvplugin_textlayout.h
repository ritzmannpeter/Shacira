/* $Id: gvplugin_textlayout.h,v 1.3 2005/06/23 12:15:50 ellson Exp $ $Revision: 1.3 $ */
/* vim:set shiftwidth=4 ts=8: */

/**********************************************************
*      This software is part of the graphviz package      *
*                http://www.graphviz.org/                 *
*                                                         *
*            Copyright (c) 1994-2004 AT&T Corp.           *
*                and is licensed under the                *
*            Common Public License, Version 1.0           *
*                      by AT&T Corp.                      *
*                                                         *
*        Information and Software Systems Research        *
*              AT&T Research, Florham Park NJ             *
**********************************************************/

#ifndef GVTEXTLAYOUT_PLUGIN_H
#define GVTEXTLAYOUT_PLUGIN_H

#include "gvplugin.h"
#include "gvcint.h"

#ifdef __cplusplus
extern "C" {
#endif

    struct gvtextlayout_engine_s {
	void (*width) (textline_t *textline, char *fontname, double fontsize, char* fontpath);
    };

#ifdef __cplusplus
}
#endif
#endif				/* GVTEXTLAYOUT_PLUGIN_H */
