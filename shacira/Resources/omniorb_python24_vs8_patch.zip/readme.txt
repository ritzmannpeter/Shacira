
   for use with omniORB-4.0.7 vstudio 8

   copy to <orb>\bin\win32_x86,
   where omniidl.exe is located

   files:

   18.10.2006  08:35         1.871.872 python24.dll
   03.04.2006  14:06             6.929 copy_reg.py
   28.10.2005  20:16             7.527 getopt.py
   24.07.2006  14:03            17.161 ntpath.py
   28.10.2005  20:16            24.983 os.py
   28.10.2005  20:16               186 re.py
   03.01.2008  19:39               111 readme.txt
   28.10.2005  20:16            12.439 sre.py
   28.10.2005  20:16            16.807 sre_compile.py
   28.10.2005  20:16             7.398 sre_constants.py
   28.10.2005  20:16            27.461 sre_parse.py
   28.10.2005  20:16             1.753 stat.py
   28.10.2005  20:16            17.274 string.py
   28.10.2005  20:16             2.243 types.py
   28.10.2005  20:16             5.742 UserDict.py
