/****************************************************************************
** QwtPlotCanvas meta object code from reading C++ file 'qwt_plot_canvas.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_plot_canvas.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtPlotCanvas::className() const
{
    return "QwtPlotCanvas";
}

QMetaObject *QwtPlotCanvas::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtPlotCanvas( "QwtPlotCanvas", &QwtPlotCanvas::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtPlotCanvas::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtPlotCanvas", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtPlotCanvas::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtPlotCanvas", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtPlotCanvas::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_0 = {"mousePressed", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_1 = {"mouseReleased", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_2 = {"mouseMoved", 1, param_signal_2 };
    static const QMetaData signal_tbl[] = {
	{ "mousePressed(const QMouseEvent&)", &signal_0, QMetaData::Public },
	{ "mouseReleased(const QMouseEvent&)", &signal_1, QMetaData::Public },
	{ "mouseMoved(const QMouseEvent&)", &signal_2, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QwtPlotCanvas", parentObject,
	0, 0,
	signal_tbl, 3,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtPlotCanvas.setMetaObject( metaObj );
    return metaObj;
}

void* QwtPlotCanvas::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtPlotCanvas" ) )
	return this;
    return QFrame::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL mousePressed
void QwtPlotCanvas::mousePressed( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL mouseReleased
void QwtPlotCanvas::mouseReleased( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL mouseMoved
void QwtPlotCanvas::mouseMoved( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 2 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

bool QwtPlotCanvas::qt_invoke( int _id, QUObject* _o )
{
    return QFrame::qt_invoke(_id,_o);
}

bool QwtPlotCanvas::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: mousePressed((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 1: mouseReleased((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 2: mouseMoved((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    default:
	return QFrame::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool QwtPlotCanvas::qt_property( int id, int f, QVariant* v)
{
    return QFrame::qt_property( id, f, v);
}

bool QwtPlotCanvas::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
