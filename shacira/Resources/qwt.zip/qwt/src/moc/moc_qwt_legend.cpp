/****************************************************************************
** QwtLegend meta object code from reading C++ file 'qwt_legend.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_legend.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtLegend::className() const
{
    return "QwtLegend";
}

QMetaObject *QwtLegend::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtLegend( "QwtLegend", &QwtLegend::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtLegend::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtLegend", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtLegend::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtLegend", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtLegend::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QwtTable::staticMetaObject();
    static const QUParameter param_signal_0[] = {
	{ "index", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"pressed", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "index", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_1 = {"clicked", 1, param_signal_1 };
    static const QMetaData signal_tbl[] = {
	{ "pressed(int)", &signal_0, QMetaData::Public },
	{ "clicked(int)", &signal_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QwtLegend", parentObject,
	0, 0,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtLegend.setMetaObject( metaObj );
    return metaObj;
}

void* QwtLegend::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtLegend" ) )
	return this;
    return QwtTable::qt_cast( clname );
}

// SIGNAL pressed
void QwtLegend::pressed( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

// SIGNAL clicked
void QwtLegend::clicked( int t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 1, t0 );
}

bool QwtLegend::qt_invoke( int _id, QUObject* _o )
{
    return QwtTable::qt_invoke(_id,_o);
}

bool QwtLegend::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: pressed((int)static_QUType_int.get(_o+1)); break;
    case 1: clicked((int)static_QUType_int.get(_o+1)); break;
    default:
	return QwtTable::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool QwtLegend::qt_property( int id, int f, QVariant* v)
{
    return QwtTable::qt_property( id, f, v);
}

bool QwtLegend::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
