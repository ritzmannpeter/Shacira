/****************************************************************************
** QwtWheel meta object code from reading C++ file 'qwt_wheel.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_wheel.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtWheel::className() const
{
    return "QwtWheel";
}

QMetaObject *QwtWheel::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtWheel( "QwtWheel", &QwtWheel::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtWheel::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtWheel", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtWheel::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtWheel", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtWheel::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QwtSliderBase::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"QwtWheel", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtWheel.setMetaObject( metaObj );
    return metaObj;
}

void* QwtWheel::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtWheel" ) )
	return this;
    return QwtSliderBase::qt_cast( clname );
}

bool QwtWheel::qt_invoke( int _id, QUObject* _o )
{
    return QwtSliderBase::qt_invoke(_id,_o);
}

bool QwtWheel::qt_emit( int _id, QUObject* _o )
{
    return QwtSliderBase::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool QwtWheel::qt_property( int id, int f, QVariant* v)
{
    return QwtSliderBase::qt_property( id, f, v);
}

bool QwtWheel::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
