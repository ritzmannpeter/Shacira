/****************************************************************************
** QwtPlot meta object code from reading C++ file 'qwt_plot.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_plot.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtPlot::className() const
{
    return "QwtPlot";
}

QMetaObject *QwtPlot::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtPlot( "QwtPlot", &QwtPlot::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtPlot::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtPlot", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtPlot::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtPlot", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtPlot::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    static const QUMethod slot_0 = {"replot", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ "index", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"lgdClicked", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "replot()", &slot_0, QMetaData::Public },
	{ "lgdClicked(int)", &slot_1, QMetaData::Private }
    };
    static const QUParameter param_signal_0[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_0 = {"plotMousePressed", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_1 = {"plotMouseReleased", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod signal_2 = {"plotMouseMoved", 1, param_signal_2 };
    static const QUParameter param_signal_3[] = {
	{ "key", &static_QUType_ptr, "long", QUParameter::In }
    };
    static const QUMethod signal_3 = {"legendClicked", 1, param_signal_3 };
    static const QMetaData signal_tbl[] = {
	{ "plotMousePressed(const QMouseEvent&)", &signal_0, QMetaData::Public },
	{ "plotMouseReleased(const QMouseEvent&)", &signal_1, QMetaData::Public },
	{ "plotMouseMoved(const QMouseEvent&)", &signal_2, QMetaData::Public },
	{ "legendClicked(long)", &signal_3, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QwtPlot", parentObject,
	slot_tbl, 2,
	signal_tbl, 4,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtPlot.setMetaObject( metaObj );
    return metaObj;
}

void* QwtPlot::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtPlot" ) )
	return this;
    return QFrame::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL plotMousePressed
void QwtPlot::plotMousePressed( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL plotMouseReleased
void QwtPlot::plotMouseReleased( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL plotMouseMoved
void QwtPlot::plotMouseMoved( const QMouseEvent& t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 2 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL legendClicked
void QwtPlot::legendClicked( long t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

bool QwtPlot::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: replot(); break;
    case 1: lgdClicked((int)static_QUType_int.get(_o+1)); break;
    default:
	return QFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool QwtPlot::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: plotMousePressed((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 1: plotMouseReleased((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 2: plotMouseMoved((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 3: legendClicked((long)(*((long*)static_QUType_ptr.get(_o+1)))); break;
    default:
	return QFrame::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool QwtPlot::qt_property( int id, int f, QVariant* v)
{
    return QFrame::qt_property( id, f, v);
}

bool QwtPlot::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
