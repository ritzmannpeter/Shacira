/****************************************************************************
** QwtThermo meta object code from reading C++ file 'qwt_thermo.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_thermo.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtThermo::className() const
{
    return "QwtThermo";
}

QMetaObject *QwtThermo::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtThermo( "QwtThermo", &QwtThermo::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtThermo::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtThermo", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtThermo::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtThermo", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtThermo::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "val", &static_QUType_double, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setValue", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "setValue(double)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QwtThermo", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtThermo.setMetaObject( metaObj );
    return metaObj;
}

void* QwtThermo::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtThermo" ) )
	return this;
    if ( !qstrcmp( clname, "QwtScaleIf" ) )
	return (QwtScaleIf*)this;
    return QWidget::qt_cast( clname );
}

bool QwtThermo::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setValue((double)static_QUType_double.get(_o+1)); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool QwtThermo::qt_emit( int _id, QUObject* _o )
{
    return QWidget::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool QwtThermo::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool QwtThermo::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
