/****************************************************************************
** QwtCounter meta object code from reading C++ file 'qwt_counter.h'
**
** Created: Fr 13. Feb 08:08:45 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../../include/qwt_counter.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *QwtCounter::className() const
{
    return "QwtCounter";
}

QMetaObject *QwtCounter::metaObj = 0;
static QMetaObjectCleanUp cleanUp_QwtCounter( "QwtCounter", &QwtCounter::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString QwtCounter::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtCounter", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString QwtCounter::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "QwtCounter", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* QwtCounter::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUMethod slot_0 = {"btnReleased", 0, 0 };
    static const QUMethod slot_1 = {"btnClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "btnReleased()", &slot_0, QMetaData::Private },
	{ "btnClicked()", &slot_1, QMetaData::Private }
    };
    static const QUParameter param_signal_0[] = {
	{ "value", &static_QUType_double, 0, QUParameter::In }
    };
    static const QUMethod signal_0 = {"buttonReleased", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ "value", &static_QUType_double, 0, QUParameter::In }
    };
    static const QUMethod signal_1 = {"valueChanged", 1, param_signal_1 };
    static const QMetaData signal_tbl[] = {
	{ "buttonReleased(double)", &signal_0, QMetaData::Public },
	{ "valueChanged(double)", &signal_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"QwtCounter", parentObject,
	slot_tbl, 2,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_QwtCounter.setMetaObject( metaObj );
    return metaObj;
}

void* QwtCounter::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "QwtCounter" ) )
	return this;
    if ( !qstrcmp( clname, "QwtDblRange" ) )
	return (QwtDblRange*)this;
    return QWidget::qt_cast( clname );
}

// SIGNAL buttonReleased
void QwtCounter::buttonReleased( double t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 0, t0 );
}

// SIGNAL valueChanged
void QwtCounter::valueChanged( double t0 )
{
    activate_signal( staticMetaObject()->signalOffset() + 1, t0 );
}

bool QwtCounter::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: btnReleased(); break;
    case 1: btnClicked(); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool QwtCounter::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: buttonReleased((double)static_QUType_double.get(_o+1)); break;
    case 1: valueChanged((double)static_QUType_double.get(_o+1)); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool QwtCounter::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool QwtCounter::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
