/*-*- c++ -*-******************************************************************
 * Qwt Widget Library 
 * Copyright (C) 1997   Josef Wilgen
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *****************************************************************************/

#ifndef QWT_PLOT_DICT
#define QWT_PLOT_DICT

#include "qwt_global.h"
#include "qwt_plot_classes.h"
#include <qintdict.h>

//
//   Template classes used by QwtPlot
//

class QWT_EXPORT QwtCurveDict : public QIntDict<QwtPlotCurve> 
{
public:
    QwtCurveDict() { setAutoDelete(TRUE); }
    ~QwtCurveDict() { clear(); }
};

class QWT_EXPORT QwtMarkerDict : public QIntDict<QwtPlotMarker>
{
public:
    QwtMarkerDict() { setAutoDelete(TRUE); }
    ~QwtMarkerDict() { clear(); }
};

#endif
