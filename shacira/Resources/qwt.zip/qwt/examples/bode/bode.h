#include <qmainwindow.h>

class QLabel;
class BodePlot;

class MainWin : public QMainWindow
{
    Q_OBJECT

public:
    MainWin(QWidget *p = 0, const char *name = 0);

private slots:
    void plotMousePressed(const QMouseEvent &e);
    void plotMouseReleased(const QMouseEvent &e);
    void plotMouseMoved(const QMouseEvent &e);
    
    void print();
    void zoom(bool);

private:
    void showInfo(const QString &);

    BodePlot *d_plot;

    QPoint d_p1;
    int d_zoom;
};
