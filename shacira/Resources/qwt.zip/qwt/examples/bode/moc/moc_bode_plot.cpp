/****************************************************************************
** BodePlot meta object code from reading C++ file 'bode_plot.h'
**
** Created: Di 24. Feb 11:26:30 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../bode_plot.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *BodePlot::className() const
{
    return "BodePlot";
}

QMetaObject *BodePlot::metaObj = 0;
static QMetaObjectCleanUp cleanUp_BodePlot( "BodePlot", &BodePlot::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString BodePlot::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "BodePlot", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString BodePlot::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "BodePlot", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* BodePlot::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QwtPlot::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "damping", &static_QUType_double, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setDamp", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "setDamp(double)", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"BodePlot", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_BodePlot.setMetaObject( metaObj );
    return metaObj;
}

void* BodePlot::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "BodePlot" ) )
	return this;
    return QwtPlot::qt_cast( clname );
}

bool BodePlot::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setDamp((double)static_QUType_double.get(_o+1)); break;
    default:
	return QwtPlot::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool BodePlot::qt_emit( int _id, QUObject* _o )
{
    return QwtPlot::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool BodePlot::qt_property( int id, int f, QVariant* v)
{
    return QwtPlot::qt_property( id, f, v);
}

bool BodePlot::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
