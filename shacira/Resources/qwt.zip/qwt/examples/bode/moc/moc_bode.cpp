/****************************************************************************
** MainWin meta object code from reading C++ file 'bode.h'
**
** Created: Di 24. Feb 11:26:30 2004
**      by: The Qt MOC ($Id: $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "../bode.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.1.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *MainWin::className() const
{
    return "MainWin";
}

QMetaObject *MainWin::metaObj = 0;
static QMetaObjectCleanUp cleanUp_MainWin( "MainWin", &MainWin::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString MainWin::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainWin", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString MainWin::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "MainWin", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* MainWin::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QMainWindow::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod slot_0 = {"plotMousePressed", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod slot_1 = {"plotMouseReleased", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "e", &static_QUType_ptr, "QMouseEvent", QUParameter::In }
    };
    static const QUMethod slot_2 = {"plotMouseMoved", 1, param_slot_2 };
    static const QUMethod slot_3 = {"print", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"zoom", 1, param_slot_4 };
    static const QMetaData slot_tbl[] = {
	{ "plotMousePressed(const QMouseEvent&)", &slot_0, QMetaData::Private },
	{ "plotMouseReleased(const QMouseEvent&)", &slot_1, QMetaData::Private },
	{ "plotMouseMoved(const QMouseEvent&)", &slot_2, QMetaData::Private },
	{ "print()", &slot_3, QMetaData::Private },
	{ "zoom(bool)", &slot_4, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"MainWin", parentObject,
	slot_tbl, 5,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_MainWin.setMetaObject( metaObj );
    return metaObj;
}

void* MainWin::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "MainWin" ) )
	return this;
    return QMainWindow::qt_cast( clname );
}

bool MainWin::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: plotMousePressed((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 1: plotMouseReleased((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 2: plotMouseMoved((const QMouseEvent&)*((const QMouseEvent*)static_QUType_ptr.get(_o+1))); break;
    case 3: print(); break;
    case 4: zoom((bool)static_QUType_bool.get(_o+1)); break;
    default:
	return QMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool MainWin::qt_emit( int _id, QUObject* _o )
{
    return QMainWindow::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool MainWin::qt_property( int id, int f, QVariant* v)
{
    return QMainWindow::qt_property( id, f, v);
}

bool MainWin::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
