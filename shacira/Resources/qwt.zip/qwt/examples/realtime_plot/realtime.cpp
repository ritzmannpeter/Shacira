#include <qapp.h>
#include "mainwindow.h"

int main(int argc, char **argv)
{
    QApplication a(argc, argv);

	MainWindow w;
	w.show();
	a.setMainWidget(&w);

	return a.exec();
}
