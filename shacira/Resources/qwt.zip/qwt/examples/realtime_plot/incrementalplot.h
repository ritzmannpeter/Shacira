#ifndef _INCREMENTALPLOT_H_
#define _INCREMENTALPLOT_H_ 1

#include <qwt_plot.h>

class IncrementalPlot : public QwtPlot
{
    Q_OBJECT

public:
	IncrementalPlot(QWidget *parent = 0, const char *name = 0);

public slots:
	void appendCurvePoint(long curveId, double x, double y);
	virtual void appendCurveData(long curveId, 
		double *x, double *y, int size) = 0;

protected:
	void drawCurveIntervall(long curveId, int from, int to);
};

#endif // _INCREMENTALPLOT_H_
