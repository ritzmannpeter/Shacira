#ifndef _MAINWINDOW_H_
#define _MAINWINDOW_H_ 1

#include <qmainwindow.h>
#include <qtoolbutton.h>

class QSpinBox;
class QPushButton;
class RandomPlot;

class MainWindow: public QMainWindow
{
	Q_OBJECT
public:
	MainWindow();

private slots:
	void showRunning(bool);
	void appendPoints(bool);

private:
	QToolBar *toolBar();
	void initWhatsThis();

private:
	QSpinBox *_randomCount;
	QSpinBox *_timerCount;
	QToolButton *_startBtn;
	QToolButton *_clearBtn;

	RandomPlot *_plot;
};

#endif
