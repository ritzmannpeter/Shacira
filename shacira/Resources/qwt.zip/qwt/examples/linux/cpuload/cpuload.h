#include <qapp.h>
#include <qfont.h>
#include <qwt_thermo.h>
#include <qlabel.h>
#include <iostream.h>
#include <fstream.h>
#include <qwt_math.h>
#include <qwt_counter.h>
#include <qpopmenu.h>
#include <qmenubar.h>
#include <qdialog.h>
#include <qpushbt.h>

//
// A simple first-order lowpass used for averaging
//
class Lowpass
{
public:
    Lowpass();
    
    void setTConst(double t){tconst = t; recalc();}
    void setTSampl(double t){tsampl = t; recalc();}
    void reset(double v) { val = v; }
    double input(double v); 
    double value() {return val;}
    
private:

    void recalc();
    double val;
    double tsampl;
    double tconst;
    double c1;
    double c2;
    
};

//
//	A dialog for configuring the sampling rate and the lowpass constant
//
class ConfigDiag : public QDialog
{
    Q_OBJECT
   private:

    QwtCounter *ctSampl;
    QwtCounter *ctConst;
    QLabel *lbSampl;
    QLabel *lbConst;
    QPushButton *btDismiss;

public:

    ConfigDiag(QWidget *p = 0, const char *name = 0);
    ~ConfigDiag();
    double tSampl() {return ctSampl->value();}
    double tConst() {return ctConst->value();}

    public slots:

    void setTSampl(double);
    void setTConst(double);

    protected slots:
    void chgTSampl(double t) { emit tSamplChg(t); }
    void chgTConst(double t) { emit tConstChg(t); }
    
 signals:

    void tSamplChg(double);
    void tConstChg(double);
    
};

//
//	The main window
//
class MainWin : public QWidget 
{
    Q_OBJECT
   public:

    enum { CpuUser, CpuNice, CpuSystem, CpuIdle, ThermoCnt };
    QwtThermo *th[ThermoCnt];
    QLabel  *lb[ThermoCnt];
    ConfigDiag *cfg;
    QMenuBar *menu;
    QPopupMenu *puProg;
    QPopupMenu *puConf;
    QPopupMenu *puScale;

    Lowpass lp[ThermoCnt];

    unsigned long val[ThermoCnt];
    unsigned long old[ThermoCnt];
    
    int dynscale;
    int tmrID;
    
public:

    MainWin(QApplication &a);
    ~MainWin();
    void start();
    void update();
    void read();
    void setTimer(int ms);

protected:

    void timerEvent(QTimerEvent *e);

    public slots:

    void setTSampl(double sec);
    void setTConst(double sec);
    void setFixedScale();
    void setDynScale() { dynscale = 1; }
    void showDialog();
};

