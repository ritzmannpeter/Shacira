#include "mistdialogbase.h"


class mistDialog : public mistDialogBase
{
	Q_OBJECT
public:
	mistDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags f = 0 );
};

