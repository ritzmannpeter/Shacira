#include "mistdialog.h"


mistDialog::mistDialog( QWidget* parent, const char* name, bool modal, WFlags f )
	: mistDialogBase( parent, name, modal, f )
{

	// Add your code

}
