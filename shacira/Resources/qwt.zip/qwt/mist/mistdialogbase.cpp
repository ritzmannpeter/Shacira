/****************************************************************************
** Form implementation generated from reading ui file '.\mistdialogbase.ui'
**
** Created: Fr 13. Feb 08:01:04 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.2   edited Dec 19 11:45 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "mistdialogbase.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a mistDialogBase as a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
mistDialogBase::mistDialogBase( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setProperty( "name", "mistDialogBase" );
    setProperty( "sizeGripEnabled", QVariant( TRUE, 0 ) );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setProperty( "geometry", QRect( 20, 240, 476, 33 ) );
    Layout1 = new QHBoxLayout( privateLayoutWidget, 0, 6, "Layout1"); 

    buttonHelp = new QPushButton( privateLayoutWidget, "buttonHelp" );
    buttonHelp->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonHelp );
    QSpacerItem* spacer = new QSpacerItem( 0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum );
    Layout1->addItem( spacer );

    buttonApply = new QPushButton( privateLayoutWidget, "buttonApply" );
    buttonApply->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonApply );

    buttonOk = new QPushButton( privateLayoutWidget, "buttonOk" );
    buttonOk->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    buttonOk->setProperty( "default", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonOk );

    buttonCancel = new QPushButton( privateLayoutWidget, "buttonCancel" );
    buttonCancel->setProperty( "autoDefault", QVariant( TRUE, 0 ) );
    Layout1->addWidget( buttonCancel );

    TextLabel1 = new QLabel( this, "TextLabel1" );
    TextLabel1->setProperty( "geometry", QRect( 200, 120, 116, 13 ) );
    languageChange();
    resize( QSize(519, 285).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( buttonOk, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( buttonCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
mistDialogBase::~mistDialogBase()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void mistDialogBase::languageChange()
{
    setProperty( "caption", tr( "mist" ) );
    buttonHelp->setProperty( "text", tr( "&Help" ) );
    buttonApply->setProperty( "text", tr( "&Apply" ) );
    buttonOk->setProperty( "caption", QString::null );
    buttonOk->setProperty( "text", tr( "&OK" ) );
    buttonCancel->setProperty( "text", tr( "&Cancel" ) );
    TextLabel1->setProperty( "text", tr( "Place your widgets here!" ) );
}

