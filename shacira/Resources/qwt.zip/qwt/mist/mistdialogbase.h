/****************************************************************************
** Form interface generated from reading ui file '.\mistdialogbase.ui'
**
** Created: Fr 13. Feb 08:01:04 2004
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.2   edited Dec 19 11:45 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef MISTDIALOGBASE_H
#define MISTDIALOGBASE_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QPushButton;
class QLabel;

class mistDialogBase : public QDialog
{
    Q_OBJECT

public:
    mistDialogBase( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~mistDialogBase();

    QPushButton* buttonHelp;
    QPushButton* buttonApply;
    QPushButton* buttonOk;
    QPushButton* buttonCancel;
    QLabel* TextLabel1;

protected:
    QHBoxLayout* Layout1;

protected slots:
    virtual void languageChange();

};

#endif // MISTDIALOGBASE_H
