#include <qapplication.h>
#include "mistdialog.h"


int main( int argc, char** argv )
{
	QApplication app( argc, argv );

	mistDialog dialog( 0, 0, TRUE );
	app.setMainWidget(&dialog);

	dialog.exec();

	return 0;
}

