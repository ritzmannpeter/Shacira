/* -------------------------------------------------------------------------- */
/*                                                                            */
/* [stdosx.h]               Standard Definitions ( OSX / C )                  */
/*                                                                            */
/* Copyright (c) 1993 by D\olle, Manns                                        */
/* -------------------------------------------------------------------------- */

#include "sysbase0.h"
#include "memosx.h"
#include "sysbase1.h"

