/* -------------------------------------------------------------------------- */
/*                                                                            */
/* [standard.h]               Standard Definitions                            */
/*                                                                            */
/* Copyright (c) 1993 by D\olle, Manns                                        */
/* -------------------------------------------------------------------------- */

#include "sysbase0.h"
#include "mem_base.h"
#include "sysbase1.h"

