/* [pgm_popt.h]   Common parse command line options  */

#define start     CTX_EVAL(c_string,"Start")
#define xaron     CTX_EVAL(c_bool,"xaron")
#define early     CTX_EVAL(c_bool,"early")
#define shiftfun  CTX_EVAL(c_string,"shiftfun")
#define reducefun CTX_EVAL(c_string,"reducefun")
