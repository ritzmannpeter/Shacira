========================================================================
    KONSOLENANWENDUNG : StyxScannerTest-Projekt�bersicht
========================================================================

Der Anwendungs-Assistent hat diese StyxScannerTest-DLL erstellt.  
Diese Datei enth�lt eine �bersicht des Inhalts der Dateien der
 StyxScannerTest-Anwendung.


StyxScannerTest.vcproj
    Dies ist die Hauptprojektdatei f�r VC++-Projekte, die vom Anwendungs-Assistenten
    erstellt wird. Sie enth�lt Informationen �ber die Version von Visual C++, mit der 
    die Datei generiert wurde, �ber die Plattformen, Konfigurationen und Projektfeatures,
    die mit dem Anwendungs-Assistenten ausgew�hlt wurden.

StyxScannerTest.cpp
    Dies ist die wichtigste Anwendungsquelldatei.

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Mit diesen Dateien werden vorkompilierte Headerdateien (PCH)
    mit der Bezeichnung StyxScannerTest.pch und eine vorkompilierte Typdatei mit der Bezeichnung StdAfx.obj erstellt.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "TODO:"-Kommentare, um Teile des Quellcodes anzuzeigen, die hinzugef�gt oder angepasst werden m�ssen.

/////////////////////////////////////////////////////////////////////////////
