========================================================================
    KONSOLENANWENDUNG : StyxParseTreeTest-Projekt�bersicht
========================================================================

Der Anwendungs-Assistent hat diese StyxParseTreeTest-DLL erstellt.  
Diese Datei enth�lt eine �bersicht des Inhalts der Dateien der
 StyxParseTreeTest-Anwendung.


StyxParseTreeTest.vcproj
    Dies ist die Hauptprojektdatei f�r VC++-Projekte, die vom Anwendungs-Assistenten
    erstellt wird. Sie enth�lt Informationen �ber die Version von Visual C++, mit der 
    die Datei generiert wurde, �ber die Plattformen, Konfigurationen und Projektfeatures,
    die mit dem Anwendungs-Assistenten ausgew�hlt wurden.

StyxParseTreeTest.cpp
    Dies ist die wichtigste Anwendungsquelldatei.

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Mit diesen Dateien werden vorkompilierte Headerdateien (PCH)
    mit der Bezeichnung StyxParseTreeTest.pch und eine vorkompilierte Typdatei mit der Bezeichnung StdAfx.obj erstellt.

/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "TODO:"-Kommentare, um Teile des Quellcodes anzuzeigen, die hinzugef�gt oder angepasst werden m�ssen.

/////////////////////////////////////////////////////////////////////////////
