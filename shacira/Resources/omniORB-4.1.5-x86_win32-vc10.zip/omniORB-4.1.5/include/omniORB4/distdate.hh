// distdate.hh -- Automatically generated file

#define OMNIORB_DIST_DATE "Wed Dec 22 15:59:17 GMT 2010 dgrisby"
