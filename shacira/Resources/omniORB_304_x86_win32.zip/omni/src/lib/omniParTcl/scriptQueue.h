//
// Simple FIFO queue for Tcl/Tk scripts awaiting evaluation.
//
// $Id: scriptQueue.h,v 1.1 1995/08/21 13:22:51 krw Exp $ $Author: krw $
//

#ifndef _scriptQueue_h
#define _scriptQueue_h

struct scriptcondpair {
  char *script;
  omni_condition *cond;
};

class scriptQueue {
  private:

    struct sqe {
      scriptcondpair scp;
      sqe *next;
    };

    sqe  *head;
    sqe  *tail;

  public:
    scriptQueue() {head = tail = 0;}

    void enq(char *script, omni_condition *cond);
    scriptcondpair deq();
};

#endif
