The "alone" GK allow accesses to the client that are on the
same host only.
