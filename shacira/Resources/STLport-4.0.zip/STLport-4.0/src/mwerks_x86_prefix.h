// #define __BUILDING_STLPORT 1
#define __SGI_STL_OWN_IOSTREAMS 1
// #define _DLL
#define _WIN32
