using __STL_NEW_IO_NAMESPACE::strstreambuf;
using __STL_NEW_IO_NAMESPACE::istrstream;
using __STL_NEW_IO_NAMESPACE::ostrstream;
using __STL_NEW_IO_NAMESPACE::strstream;
