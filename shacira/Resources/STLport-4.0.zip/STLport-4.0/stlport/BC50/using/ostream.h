using __STL_NEW_IO_NAMESPACE::basic_ostream;
using __STL_NEW_IO_NAMESPACE::ostream;

# ifndef __STL_NO_WIDE_STREAMS
using __STL_NEW_IO_NAMESPACE::wostream;
# endif

using __STL_NEW_IO_NAMESPACE::endl;
using __STL_NEW_IO_NAMESPACE::ends;
using __STL_NEW_IO_NAMESPACE::flush;
