using __STL_VENDOR_STD::cin;
using __STL_VENDOR_STD::cout;
using __STL_VENDOR_STD::cerr;
using __STL_VENDOR_STD::clog;

# if ! defined (__STL_NO_WIDE_STREAMS)
using __STL_VENDOR_STD::wcin;
using __STL_VENDOR_STD::wcout;
using __STL_VENDOR_STD::wcerr;
using __STL_VENDOR_STD::wclog;
# endif
