# if defined (__STL_USE_NEW_IOSTREAMS)
using __STL_NEW_IO_NAMESPACE::char_traits;
using __STL_NEW_IO_NAMESPACE::basic_ios;
using __STL_NEW_IO_NAMESPACE::basic_streambuf;
using __STL_NEW_IO_NAMESPACE::basic_istream;
using __STL_NEW_IO_NAMESPACE::basic_ostream;
using __STL_NEW_IO_NAMESPACE::basic_iostream;
using __STL_NEW_IO_NAMESPACE::basic_stringbuf;
using __STL_NEW_IO_NAMESPACE::basic_istringstream;
using __STL_NEW_IO_NAMESPACE::basic_ostringstream;
using __STL_NEW_IO_NAMESPACE::basic_stringstream;
using __STL_NEW_IO_NAMESPACE::basic_filebuf;
using __STL_NEW_IO_NAMESPACE::basic_ifstream;
using __STL_NEW_IO_NAMESPACE::basic_ofstream;
using __STL_NEW_IO_NAMESPACE::basic_fstream;
using __STL_NEW_IO_NAMESPACE::fpos;
using __STL_NEW_IO_NAMESPACE::istreambuf_iterator;
using __STL_NEW_IO_NAMESPACE::ostreambuf_iterator;
using __STL_NEW_IO_NAMESPACE::stringbuf;
using __STL_NEW_IO_NAMESPACE::istringstream;
using __STL_NEW_IO_NAMESPACE::ostringstream;
using __STL_NEW_IO_NAMESPACE::stringstream;
# endif

using __STL_NEW_IO_NAMESPACE::ios;
using __STL_NEW_IO_NAMESPACE::streambuf;
using __STL_NEW_IO_NAMESPACE::istream;
using __STL_NEW_IO_NAMESPACE::ostream;
using __STL_NEW_IO_NAMESPACE::iostream;

using __STL_NEW_IO_NAMESPACE::filebuf;
using __STL_NEW_IO_NAMESPACE::ifstream;
using __STL_NEW_IO_NAMESPACE::ofstream;
using __STL_NEW_IO_NAMESPACE::fstream;

using __STL_NEW_IO_NAMESPACE::streampos;
using __STL_NEW_IO_NAMESPACE::streamoff;

# if !defined (__STL_NO_WIDE_STREAMS)
using __STL_NEW_IO_NAMESPACE::wios;
using __STL_NEW_IO_NAMESPACE::wstreambuf;
using __STL_NEW_IO_NAMESPACE::wistream;
using __STL_NEW_IO_NAMESPACE::wostream;
using __STL_NEW_IO_NAMESPACE::wiostream;
using __STL_NEW_IO_NAMESPACE::wstringbuf;
using __STL_NEW_IO_NAMESPACE::wistringstream;
using __STL_NEW_IO_NAMESPACE::wostringstream;
using __STL_NEW_IO_NAMESPACE::wstringstream;
using __STL_NEW_IO_NAMESPACE::wfilebuf;
using __STL_NEW_IO_NAMESPACE::wifstream;
using __STL_NEW_IO_NAMESPACE::wofstream;
using __STL_NEW_IO_NAMESPACE::wfstream;
using __STL_NEW_IO_NAMESPACE::wstreampos;
# endif
