/*
 * Copyright (c) 1999 Boris Fomitchev
 * AUTOMATICALLY GENERATED - DO NOT EDIT !
 */

/*
 *
 *  This wrapper is needed for Borland C++ 5.0 to get STLport 
 *  header properly included
 */

#ifndef __STLPORT_BC_stack_H
#  define  __STLPORT_BC_stack_H

#  include  <..\stack.>

#endif

// Local Variables:
// mode:C++
// End:
