// STLport configuration file
// It is internal STLport header - DO NOT include it directly

#  define __STL_DLLEXPORT_NEEDS_PREDECLARATION 1

# include <config/stl_msvc.h>

// debug mode problems in <algorithm>
# define __STL_NAMESPACE_FUNCTION_AMBIGUITY_BUG 1
# define __STL_LONG_LONG 1

