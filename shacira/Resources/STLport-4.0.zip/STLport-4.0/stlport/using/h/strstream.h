using __STL_OLD_IO_NAMESPACE::strstreambuf;
using __STL_OLD_IO_NAMESPACE::istrstream;
using __STL_OLD_IO_NAMESPACE::ostrstream;
using __STL_OLD_IO_NAMESPACE::strstream;
