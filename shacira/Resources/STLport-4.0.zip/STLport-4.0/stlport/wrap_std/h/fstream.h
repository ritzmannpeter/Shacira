# include __STL_NATIVE_OLD_STREAMS_HEADER(fstream.h)
# if defined  (__STL_USE_NAMESPACES) && ! defined (__STL_BROKEN_USING_DIRECTIVE)
__STL_BEGIN_NAMESPACE
#  include <using/h/fstream.h>
__STL_END_NAMESPACE
# endif /* __STL_OWN_NAMESPACE */

