# include __STL_NATIVE_OLD_STREAMS_HEADER(iostream.h)

# if defined (__STL_USE_OWN_NAMESPACE)
__STL_BEGIN_NAMESPACE
# include <using/h/iostream.h>
__STL_END_NAMESPACE
# endif /* __STL_USE_OWN_NAMESPACE */
