/* ------------------------------------------------------------------------ */
/*                                                                          */
/* [pl0_ant.c]                Language Interface                            */
/*                                                                          */
/* ------------------------------------------------------------------------ */

#include "ptm.h"
#include "gls_abs.h"

/*I--------------------- symbol objects - init & quit --------------------- */

static symbol* CfgSyms = (symbol*)NULL;
static symbol* PrdSyms = (symbol*)NULL;

void pl0_initSymbols()
{
  GLS_init();
  CfgSyms = (symbol*)NewMem(sizeof(symbol)*33);
  PrdSyms = (symbol*)NewMem(sizeof(symbol)*32);

  CfgSyms[0] = stringToSymbol("Tok");
  CfgSyms[1] = stringToSymbol("Int");
  CfgSyms[2] = stringToSymbol("Ide");
  CfgSyms[3] = stringToSymbol("Com");
  CfgSyms[4] = stringToSymbol("fun");
  CfgSyms[5] = stringToSymbol("(");
  CfgSyms[6] = stringToSymbol(")");
  CfgSyms[7] = stringToSymbol("=");
  CfgSyms[8] = stringToSymbol("run");
  CfgSyms[9] = stringToSymbol("if");
  CfgSyms[10] = stringToSymbol("then");
  CfgSyms[11] = stringToSymbol("else");
  CfgSyms[12] = stringToSymbol("<");
  CfgSyms[13] = stringToSymbol("+");
  CfgSyms[14] = stringToSymbol("-");
  CfgSyms[15] = stringToSymbol("*");
  CfgSyms[16] = stringToSymbol("/");
  CfgSyms[17] = stringToSymbol(",");
  CfgSyms[18] = stringToSymbol("Program");
  CfgSyms[19] = stringToSymbol("Dfn");
  CfgSyms[20] = stringToSymbol("Run");
  CfgSyms[21] = stringToSymbol("Exp");
  CfgSyms[22] = stringToSymbol("Exp1");
  CfgSyms[23] = stringToSymbol("Exp2");
  CfgSyms[24] = stringToSymbol("Exp3");
  CfgSyms[25] = stringToSymbol("Exp4");
  CfgSyms[26] = stringToSymbol("Args");
  CfgSyms[27] = stringToSymbol("Args0");
  CfgSyms[28] = stringToSymbol("Exps");
  CfgSyms[29] = stringToSymbol("Exps0");
  CfgSyms[30] = stringToSymbol("Dfns");
  CfgSyms[31] = stringToSymbol("Runs");
  CfgSyms[32] = stringToSymbol("pl0");

  PrdSyms[0] = stringToSymbol("pgm");
  PrdSyms[1] = stringToSymbol("fun");
  PrdSyms[2] = stringToSymbol("run");
  PrdSyms[3] = stringToSymbol("ign0");
  PrdSyms[4] = stringToSymbol("if");
  PrdSyms[5] = stringToSymbol("ign0");
  PrdSyms[6] = stringToSymbol("les");
  PrdSyms[7] = stringToSymbol("equ");
  PrdSyms[8] = stringToSymbol("ign0");
  PrdSyms[9] = stringToSymbol("add");
  PrdSyms[10] = stringToSymbol("sub");
  PrdSyms[11] = stringToSymbol("ign0");
  PrdSyms[12] = stringToSymbol("mlt");
  PrdSyms[13] = stringToSymbol("div");
  PrdSyms[14] = stringToSymbol("neg");
  PrdSyms[15] = stringToSymbol("ign0");
  PrdSyms[16] = stringToSymbol("int");
  PrdSyms[17] = stringToSymbol("var");
  PrdSyms[18] = stringToSymbol("app");
  PrdSyms[19] = stringToSymbol("nil");
  PrdSyms[20] = stringToSymbol("cons");
  PrdSyms[21] = stringToSymbol("nil");
  PrdSyms[22] = stringToSymbol("cons");
  PrdSyms[23] = stringToSymbol("nil");
  PrdSyms[24] = stringToSymbol("cons");
  PrdSyms[25] = stringToSymbol("nil");
  PrdSyms[26] = stringToSymbol("cons");
  PrdSyms[27] = stringToSymbol("nil");
  PrdSyms[28] = stringToSymbol("cons");
  PrdSyms[29] = stringToSymbol("nil");
  PrdSyms[30] = stringToSymbol("cons");
  PrdSyms[31] = stringToSymbol("Start_Program");
}

void pl0_quitSymbols()
{
  if( CfgSyms != (symbol*)NULL ) FreeMem(CfgSyms);
  if( PrdSyms != (symbol*)NULL ) FreeMem(PrdSyms);
}

/*I-------------------------- Types & Constants --------------------------- */

AbstractHugeType( pl0 );

AbstractHugeType( pl0Program );
AbstractHugeType( pl0Dfn );
AbstractHugeType( pl0Run );
AbstractHugeType( pl0Exp );

/*I--------------------------- Access to Tokens --------------------------- */

bool Tpl0_Int(GLS_Tok x)
{
  return PT_Abs_token(x) == CfgSyms[1];
}

bool Tpl0_Ide(GLS_Tok x)
{
  return PT_Abs_token(x) == CfgSyms[2];
}

/*I--------------------------- Access to Terms ---------------------------- */

bool pl0_pl0(PT_Abs_Term x, pl0* x1)
{
  if( PT_Abs_nonterm(x) == CfgSyms[32] )
  {
    if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0)x;
    return True;
  }
  return False;
}

bool pl0_Program(PT_Abs_Term x, pl0Program* x1)
{
  if(  PT_Abs_nonterm(x) == CfgSyms[18] )
  {
    if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Program)x;
    return True;
  }
  return False;
}

bool pl0_Dfn(PT_Abs_Term x, pl0Dfn* x1)
{
  if(  PT_Abs_nonterm(x) == CfgSyms[19] )
  {
    if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Dfn)x;
    return True;
  }
  return False;
}

bool pl0_Run(PT_Abs_Term x, pl0Run* x1)
{
  if(  PT_Abs_nonterm(x) == CfgSyms[20] )
  {
    if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Run)x;
    return True;
  }
  return False;
}

bool pl0_Exp(PT_Abs_Term x, pl0Exp* x1)
{
  if(  PT_Abs_nonterm(x) == CfgSyms[22]
    || PT_Abs_nonterm(x) == CfgSyms[23]
    || PT_Abs_nonterm(x) == CfgSyms[25]
    || PT_Abs_nonterm(x) == CfgSyms[24]
    || PT_Abs_nonterm(x) == CfgSyms[21] )
  {
    if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)x;
    return True;
  }
  return False;
}

/*I--------------------------------- pl0 ---------------------------------- */

bool pl0_Start_Program(pl0 x, pl0Program* x1)
#define pl0_Start_0   pl0_Start_Program
{
  assert0( PT_Abs_nonterm(x) == CfgSyms[32], "pl0 expected" );
  if( PT_Abs_product(x) != PrdSyms[31] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL )
    *x1 = (pl0Program)PT_Abs_part(x,0);
  return True;
}

/*I------------------------------- Program -------------------------------- */

bool pl0Program_pgm(pl0Program x, GLS_Lst(pl0Dfn)* x1, GLS_Lst(pl0Run)* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[18], "Program expected" );
  if( PT_Abs_product(x) != PrdSyms[0] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (GLS_Lst(pl0Dfn))PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (GLS_Lst(pl0Run))PT_Abs_part(x,1);
  return True;
}

/*I--------------------------------- Dfn ---------------------------------- */

bool pl0Dfn_fun(pl0Dfn x, GLS_Tok* x1, GLS_Lst(GLS_Tok)* x2,
                pl0Exp* x3)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[19], "Dfn expected" );
  if( PT_Abs_product(x) != PrdSyms[1] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (GLS_Tok)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (GLS_Lst(GLS_Tok))PT_Abs_part(x,1);
  if( (HugeCPtr)x3 != (HugeCPtr)NULL ) *x3 = (pl0Exp)PT_Abs_part(x,2);
  return True;
}

/*I--------------------------------- Run ---------------------------------- */

bool pl0Run_run(pl0Run x, pl0Exp* x1)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[20], "Run expected" );
  if( PT_Abs_product(x) != PrdSyms[2] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  return True;
}

/*I--------------------------------- Exp ---------------------------------- */

bool pl0Exp_if(pl0Exp x, pl0Exp* x1, pl0Exp* x2,
               pl0Exp* x3)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[4] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  if( (HugeCPtr)x3 != (HugeCPtr)NULL ) *x3 = (pl0Exp)PT_Abs_part(x,2);
  return True;
}

bool pl0Exp_div(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[13] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_var(pl0Exp x, GLS_Tok* x1)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[17] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (GLS_Tok)PT_Abs_part(x,0);
  return True;
}

bool pl0Exp_equ(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[7] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_neg(pl0Exp x, pl0Exp* x1)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[14] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  return True;
}

bool pl0Exp_app(pl0Exp x, GLS_Tok* x1, GLS_Lst(pl0Exp)* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[18] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (GLS_Tok)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (GLS_Lst(pl0Exp))PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_mlt(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[12] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_int(pl0Exp x, GLS_Tok* x1)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[16] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (GLS_Tok)PT_Abs_part(x,0);
  return True;
}

bool pl0Exp_les(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[6] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_sub(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[10] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}

bool pl0Exp_add(pl0Exp x, pl0Exp* x1, pl0Exp* x2)
{
  assert0(  PT_Abs_nonterm(x) == CfgSyms[22]
        || PT_Abs_nonterm(x) == CfgSyms[23]
        || PT_Abs_nonterm(x) == CfgSyms[25]
        || PT_Abs_nonterm(x) == CfgSyms[24]
        || PT_Abs_nonterm(x) == CfgSyms[21], "Exp expected" );
  if( PT_Abs_product(x) != PrdSyms[9] ) return False;
  if( (HugeCPtr)x1 != (HugeCPtr)NULL ) *x1 = (pl0Exp)PT_Abs_part(x,0);
  if( (HugeCPtr)x2 != (HugeCPtr)NULL ) *x2 = (pl0Exp)PT_Abs_part(x,1);
  return True;
}
