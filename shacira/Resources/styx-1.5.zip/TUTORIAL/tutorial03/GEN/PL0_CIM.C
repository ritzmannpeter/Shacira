/* [pl0_cim.c] Context table for 'pl0'  */

#include "ctx.h"

void CTX_init_pl0(int argc, string argv[])
{ CTX_T ctx;
  ctx = CTX_new(1,"pl0");
  CTX_set(ctx, 0,"Source",CTX_ARG,CTX_STRING,"");
  CTX_ctx_set(ctx);
  CTX_interprete(argc, argv);
}
