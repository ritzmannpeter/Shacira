/* [pl0_pim.c] Parser table for 'pl0'  */



#include "prs.h"

#include "prs_imp.h"


static string pl0_SNames[] = {
  "Tok", "Int", "Ide", "Com", "fun", 
  "(", ")", "=", "run", "if", 
  "then", "else", "<", "+", "-", 
  "*", "/", ",", "Program", "Dfn", 
  "Run", "Exp", "Exp1", "Exp2", "Exp3", 
  "Exp4", "Args", "Args0", "Exps", "Exps0", 
  "Dfns", "Runs"
};

static int pl0_StartIds[] = {
  18
};

static int pl0_TokKind[] = {
  1, 1, 1, 4, 2, 2, 2, 2, 
  2, 2, 2, 2, 2, 2, 2, 2, 
  2, 2
};

static int pl0_NtClass[] = {
  0, 1, 2, 3, 3, 3, 3, 3, 
  8, 8, 10, 10, 12, 13
};

static bool pl0_ErrorNt[] = {
  0, 0, 0, 0, 0, 0, 0, 0, 
  0, 0, 0, 0, 0, 0
};

static KFGHEAD pl0_KfgHead = {
  "pl0",
  18, 14, pl0_SNames,
  1, pl0_StartIds,
  pl0_TokKind,
  pl0_NtClass,
  pl0_ErrorNt
};

static int pl0_PSymbols[] = {
  30, 31,
  4, 2, 5, 26, 6, 7, 21,
  8, 21,
  22,
  9, 22, 10, 21, 11, 21,
  23,
  23, 12, 23,
  23, 7, 23,
  24,
  23, 13, 24,
  23, 14, 24,
  25,
  24, 15, 25,
  24, 16, 25,
  14, 25,
  5, 21, 6,
  1,
  2,
  2, 5, 28, 6,
  2, 27,
  17, 2, 27,
  21, 29,
  17, 21, 29,
  19, 30,
  20, 31,
  18
};

static int pl0_PSymFrms[] = {
  0, 5,
  0, 6, 10, 14, 19, 23, 27,
  0, 6,
  0,
  0, 5, 10, 17, 21, 28,
  0,
  0, 5, 9,
  0, 5, 9,
  0,
  0, 5, 9,
  0, 5, 9,
  0,
  0, 5, 9,
  0, 5, 9,
  0, 4,
  0, 4, 8,
  0,
  0,
  0, 4, 8, 13,
  0, 4,
  0, 4, 8,
  0, 4,
  0, 4, 8,
  0, 4,
  0, 4,
  0
};

static KFGPROD pl0_KfgProds[] = {
  "pgm", 0, 18, 2, &pl0_PSymbols[0], &pl0_PSymFrms[0],
  "fun", 0, 19, 7, &pl0_PSymbols[2], &pl0_PSymFrms[2],
  "run", 0, 20, 2, &pl0_PSymbols[9], &pl0_PSymFrms[9],
  "ign0", 0, 21, 1, &pl0_PSymbols[11], &pl0_PSymFrms[11],
  "if", 0, 21, 6, &pl0_PSymbols[12], &pl0_PSymFrms[12],
  "ign0", 0, 22, 1, &pl0_PSymbols[18], &pl0_PSymFrms[18],
  "les", 0, 22, 3, &pl0_PSymbols[19], &pl0_PSymFrms[19],
  "equ", 0, 22, 3, &pl0_PSymbols[22], &pl0_PSymFrms[22],
  "ign0", 0, 23, 1, &pl0_PSymbols[25], &pl0_PSymFrms[25],
  "add", 0, 23, 3, &pl0_PSymbols[26], &pl0_PSymFrms[26],
  "sub", 0, 23, 3, &pl0_PSymbols[29], &pl0_PSymFrms[29],
  "ign0", 0, 24, 1, &pl0_PSymbols[32], &pl0_PSymFrms[32],
  "mlt", 0, 24, 3, &pl0_PSymbols[33], &pl0_PSymFrms[33],
  "div", 0, 24, 3, &pl0_PSymbols[36], &pl0_PSymFrms[36],
  "neg", 0, 25, 2, &pl0_PSymbols[39], &pl0_PSymFrms[39],
  "ign0", 0, 25, 3, &pl0_PSymbols[41], &pl0_PSymFrms[41],
  "int", 0, 25, 1, &pl0_PSymbols[44], &pl0_PSymFrms[44],
  "var", 0, 25, 1, &pl0_PSymbols[45], &pl0_PSymFrms[45],
  "app", 0, 25, 4, &pl0_PSymbols[46], &pl0_PSymFrms[46],
  "nil", 0, 26, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 26, 2, &pl0_PSymbols[50], &pl0_PSymFrms[50],
  "nil", 0, 27, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 27, 3, &pl0_PSymbols[52], &pl0_PSymFrms[52],
  "nil", 0, 28, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 28, 2, &pl0_PSymbols[55], &pl0_PSymFrms[55],
  "nil", 0, 29, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 29, 3, &pl0_PSymbols[57], &pl0_PSymFrms[57],
  "nil", 0, 30, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 30, 2, &pl0_PSymbols[60], &pl0_PSymFrms[60],
  "nil", 0, 31, 0, (int*)NULL, (int*)NULL,
  "cons", 0, 31, 2, &pl0_PSymbols[62], &pl0_PSymFrms[62],
  "Start_Program", 0, 32, 1, &pl0_PSymbols[64], &pl0_PSymFrms[64]
};

static int pl0_MstShifts[] = {
  1, 3, -1, 1, 5, 7, -1, 13, 
  5, -1, 19, -1, 21, 13, 26, 26, 
  -1, -1, 34, 40, -1, -1, 43, 45, 
  13, 47, 49, -1, 26, 26, 26, 26, 
  26, 26, 51, -1, 53, 55, 57, -1, 
  13, 60, 60, 40, 40, -1, -1, 43, 
  13, 13, -1, -1, 63, -1, -1, 55, 
  13, -1, -1
};

static int pl0_DtlShifts[] = {
  -2, 4, -6, 2, -8, 8, -11, 5, 
  -12, -13, -14, -15, -16, 14, 9, 5, 
  2, 1, -23, 2, -25, 5, -12, -13, 
  -14, -16, 14, 5, 2, 1, -29, -30, 
  -31, -32, 14, 13, 12, 7, -33, -34, 
  16, 15, -35, 17, -37, 6, -40, 6, 
  -41, 10, -48, 2, -49, 7, -50, 17, 
  -52, 6, -31, -32, 14, 13, -57, 11
};

static int pl0_GoTos[] = {
  0, 2, 5, 8, 22, 32, 45, 60, 
  79, 81, 85, 87, 91, 95
};

static int pl0_GoToDfts[] = {
  62, -1, 63, -1, -4, 68, -5, -9, 
  76, 8, 85, 14, 97, 25, 112, 41, 
  114, 49, 115, 50, 118, 57, 77, 8, 
  14, 25, 41, 49, 50, 57, 86, 15, 
  78, 8, 14, 15, 25, 41, 49, 50, 
  57, 101, 29, 102, 30, 79, 8, 14, 
  15, 25, 29, 30, 41, 49, 50, 57, 
  103, 31, 104, 32, 80, 8, 14, 15, 
  25, 29, 30, 31, 32, 41, 49, 50, 
  57, 87, 16, 105, 33, 106, 34, 83, 
  -11, 95, 23, 113, 48, 98, -25, 110, 
  38, 117, 56, 64, 1, 66, 4, 69, 
  5, 81, 9
};

static int pl0_ActDfts[] = {
  28, 33, 34, 28, 30, 33, 29, 33, 
  30, 1, 20, 17, 18, 33, 33, 33, 
  3, 4, 6, 9, 12, 31, 22, 33, 
  24, 33, 33, 15, 33, 33, 33, 33, 
  33, 33, 33, 21, 33, 26, 33, 16, 
  33, 8, 7, 10, 11, 13, 14, 22, 
  33, 33, 25, 19, 33, 23, 2, 26, 
  33, 27, 5
};


static PARSETAB pl0_ParseTab = {
  &pl0_KfgHead, 32, pl0_KfgProds,
  {
    59, pl0_MstShifts, 64, pl0_DtlShifts,
    14, pl0_GoTos, 99, pl0_GoToDfts,
    59, pl0_ActDfts, 0, (int*)NULL
  }
};

PLR_Tab PLR_get_pl0()
/* simulates a PLR_getTab */
{
  return( PLR_copyTab(&pl0_ParseTab) );
}
