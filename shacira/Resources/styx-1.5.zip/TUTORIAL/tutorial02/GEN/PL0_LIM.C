/* [pl0_lim.c] Scanner table for 'pl0'  */

#include "scn_io.h"

#include "scn_imp.h"

static short StaEdg[7] =
/* first edge per state */
{
    0,  18,  19,  22,  23,  26,  29
};

static short StaFin[6] =
/* finite token per state */
{
    0,   1,   5,   2,   3,   4
};

static byte EdgeC[29] =
/* lowest character per edge */
{ /*State*/
  /*   0 */  123,   97,   62,   60,   58,   48,   47,   46,   40,   36,
              35,   33,   32,   14,   13,   11,   10,    0,
  /*   1 */    0,
  /*   2 */  127,   32,    0,
  /*   3 */    0,
  /*   4 */   58,   48,    0,
  /*   5 */  123,   97,    0
};

static short EdgeS[29] =
/* follow (state+1) per edge */
{ /*State*/
  /*   0 */   0,   6,   0,   4,   0,   5,   4,   0,   4,   0,
              3,   0,   2,   0,   2,   0,   2,   0,
  /*   1 */   0,
  /*   2 */   0,   3,   0,
  /*   3 */   0,
  /*   4 */   0,   5,   0,
  /*   5 */   0,   6,   0
};

static string Tokens[6] =
/* token -> string */
{
  "[other]",
  "Ign",
  "Tok",
  "Int",
  "Ide",
  "Com"
};

static byte Flags[6] =
/* token -> newid */
{
  0x00, 0x01, 0x00, 0x00, 0x00, 0x00
};

static ConcreteImp(scn_t) Scanner =
/* the scanner structure */
{
  "pl0", /* Name    */
   6,    /* States  */
   6,    /* Tokens  */
  StaEdg,
  StaFin,
  EdgeC,
  EdgeS,
  Tokens,
  Flags,
};

void Scn_get_pl0(Scn_T *scn)
/* simulates a Scn_get */
{
  *scn = Scn_copy(Scn_ADT(&Scanner));
};
