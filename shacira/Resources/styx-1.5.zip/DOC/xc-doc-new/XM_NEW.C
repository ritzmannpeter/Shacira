/* ------------------------------------------------------------------------ */
/*                                                                          */
/* [xm_new.c]             A Generic Reference Memory                        */
/*                                                                          */
/* This file is part of the Xaron project                                   */
/* Copyright (c) 2000 by Lars Doelle <lars.doelle@on-line.de>               */
/* ------------------------------------------------------------------------ */

#include "standard.h"

/* ================================================================== */
/*                                                                    */
/* Core Reference Memory Layer                                        */
/*                                                                    */
/*   This section forms the ground layer of the Reference Memory,     */
/*   because non of it operations make any assumptions about the      */
/*   types and values contained in it.                                */
/*                                                                    */
/*   If the storage of the machine is large enough and generic        */
/*   services like persistence are not needed for a particular        */
/*   application, one might well do with this layer only.             */
/*                                                                    */
/*   What this layer offers is:                                       */
/*                                                                    */
/*   - TVtoN: (T,V) -> N                                              */
/*   - NtoT : N     -> T                                              */
/*   - NtoV : N     -> V                                              */
/*                                                                    */
/*   together with a few utility routines to get the memory up        */
/*   and adjusted to various needs.                                   */
/*                                                                    */
/*   Since all processing of a machine using this memory heavily      */
/*   bases on this layer, extreme performance has to be the           */
/*   central concern. Never ever even consider to put in here         */
/*   anything time consuming.                                         */
/*                                                                    */
/*   Note that the full implementation of this layer is published     */
/*   through its interface for maximum performance, but defines       */
/*   are used to provide minimal abstraction. Make sure to use        */
/*   this abstraction to allow changing the implementation without    */
/*   hassle. One should also take care to maintain the layering       */
/*   which the author considers to be constitutional for this         */
/*   product.                                                         */
/*                                                                    */
/* ================================================================== */

/*INTERFACE*/
typedef void* Type;
typedef void* Value;
typedef int   Name;
//
ConcreteType(Slot)
{
  Value val;
  Type  typ;
  int   tag;
  //
  Name  nxt;
  Name  bas;
};

//
// The following four variables form the memory
// Note that the variables can be calculated from
// the first ones and are kept only to reduce the
// complexity of some operations;
//
// It may make sense to put these variables into
// a structure to allow multible reference memories.
// Because this would lead to current cost increase
// of some operations with benefit in a questionable
// future, we don't.
//
Slot ReferenceMemory;  // external access allowed, but read-only

static int slot_count; // number of total slots in memory
static int slot_used;  // number of slots used
static Name mem_free;  // list of free slots, chained via '.nxt', terminated by MEM_NIL.

/*INTERFACE*/
// export the reference memory for efficient use.
// we should have been providing a function, but
// this is too expensive. Handle with care.
#define name_type(name)  ReferenceMemory[name].typ
#define name_value(name) ReferenceMemory[name].val
//
#define name_unroot(name) ReferenceMemory[name].tag &= (MEM_TAG_ROOT)
#define name_root(name)   ReferenceMemory[name].tag |= (MEM_TAG_ROOT)


// Bits used in Slot.tag
//
#define MEM_TAG_USED (1<<0)
#define MEM_TAG_ROOT (1<<1)

// The nihil name used to mark end of chains in the Slot.nxt field
//
#define MEM_NIL (-1)

// Find the most efficient way to calcutate a hash value of T,V.
// Perhaps we need to consult Knuth's Art.
// 
#define hashTV(T,V,C) ((((int)T)+127*((int)V))%(C))

// ------------------------------------------------------------------
//
// Reconstruct hash table and vacant slot chain
//
//   This operation is to be used after garbage collection,
//   or at any other time. It rebuilds the hash table and
//   the free slot list based on the information found in
//   the tag field of the slots.
//   
//   Note that the 'slot_used' count is not passed, since
//   it is invariant.
//
// ------------------------------------------------------------------

static void mem_rebuild_lists(void)
{ int i;
  //
  // clear free chain and bucket lists
  //
  mem_free = MEM_NIL;
  for (i = 0; i < slot_count; i++) ReferenceMemory[i].bas = MEM_NIL;
  //
  // process each slot putting it into the right chain
  //
  for (i = 0; i < slot_count; i++)
  {
    if (ReferenceMemory[i].tag & MEM_TAG_USED)
    {
      int h = hashTV(ReferenceMemory[i].typ,ReferenceMemory[i].val,slot_count);
      ReferenceMemory[i].nxt = ReferenceMemory[h].bas;
      ReferenceMemory[h].bas = i;
    }
    else
    {
      ReferenceMemory[i].nxt = mem_free; mem_free = i;
    }
  }
}

// ------------------------------------------------------------------
//
// Initialize a Reference Memory Core
//
//   All that is done here is to clear the tag (indicating an
//   unoccupied slot), to clear the hash table buckets and to
//   chain together the slots to initialize the free slot list.
//
// ------------------------------------------------------------------

static void mem_initialize(void)
{ int i;
  mem_free = MEM_NIL;
  slot_used = 0;
  for (i = 0; i < slot_count; i++)
  {
    ReferenceMemory[i].tag = 0;
    ReferenceMemory[i].bas = MEM_NIL;
    ReferenceMemory[i].nxt = mem_free;
    mem_free = i;
  }
}

// ------------------------------------------------------------------
//
// Change the size of a Reference Memory Core
//
//   This operation allows to change the size of the memory
//   preserving it's contents.
//
//   To do so, the caller has to assert that the upper (released)
//   section of the memory is not occupied by any slot when decreasing.
//   
// ------------------------------------------------------------------

static void mem_resize(int new_size)
{
  if (new_size == slot_count) return;
  if (new_size < slot_count) // decrease size
  {
  // OUTLINE
  // - assert usedSlots <= new_size
  // - for (i = new_size; i < *slot_count; i++)
  //     assert Slot[i] is unused
  }
  ReferenceMemory = realloc(ReferenceMemory, SizeOf(Slot) * new_size);
  // - assert *ReferenceMemory;
  if (new_size > slot_count) // increase size
  { int i;
    for (i = slot_count; i < new_size; i++)
      ReferenceMemory[i].tag = 0; // mark slot as unused.
  }
  mem_rebuild_lists();
  slot_count = new_size;
}

// ------------------------------------------------------------------
//
// (T,V)->N, the work horse operation of the Reference Memory
//
// ------------------------------------------------------------------

Name TVtoN(Type t, Value v)
{ Name new_slot;
  //
  // Calculate hash index for (t,v).
  //
  Name h = hashTV(t,v,slot_count);
  Name p = ReferenceMemory[h].bas;
  //
  // Following, we are going to cycle the slot in a bucket,
  // i.e. all entries with the same hashTV value. Some
  // propabalistic reasoning is indicated.
  //
  // Since we know to have a geometric distribution of the values
  // within each bucket, we can make some statistic assertions
  // of the complexity of the following loop:
  //
  // [Insert geometric formula here]
  //
  // [FIXME: there is another technically more correct
  //         term for "statistically", it is "stochastically"]
  //
  // Assuming the memory is populated to a average of NN%, we
  // have an expectation of x.xx loop passes in the case of
  // a value already present. For a value not yet in the table
  // we get an average of 0.xx loop passes with a propability
  // of xx% that the slot is empty ('p >= 0' fails instantly).
  //
  // Empirical investigations with different sort of work
  // loads show that we practically can expect the first
  // case by 0.xx and the second by 0.xx, resulting in an
  // average loop count of 0.xx.
  //
  // Note that probability demonstrates that buckets with
  // many entries are astronomically unlikely. So, if you
  // ever recognize a large bucket, the hash function is
  // to be blamed and might need adjustment to cope with
  // your application.
  //
  // [Insert table of expectation values here]
  //
  for (; p >= 0; p = ReferenceMemory[p].nxt)
    if (ReferenceMemory[p].val == v && ReferenceMemory[p].typ == t)
      return p; // == 8 machine instruction to come here (gcc -O2).
                // == 8 (rarely 12 (val == v)) for a full cycle.
  //
  // Not found, allocation indicated. Guarantee having a free slot by
  // optional increase of the table size (note this is transparent).
  //
  if (mem_free != MEM_NIL)
  {
    mem_resize(2*slot_count);   //FIXME: trigger GC?
    h = hashTV(t,v,slot_count); // readjust 'h' after resize
  }
  //
  // get new slot
  //
  new_slot = mem_free;
  mem_free = ReferenceMemory[new_slot].nxt;
  slot_used += 1;
  //
  // fill in info
  //
  ReferenceMemory[new_slot].val = v;
  ReferenceMemory[new_slot].typ = t;
  ReferenceMemory[new_slot].tag = (MEM_TAG_USED | MEM_TAG_ROOT);
  //
  // enter into hash bucket
  //
  ReferenceMemory[new_slot].nxt = ReferenceMemory[h].bas;
  ReferenceMemory[h       ].bas = new_slot;
  //
  // done new slot
  //
  return new_slot;
}

/* ================================================================== */
/*                                                                    */
/* Second Reference Memory Layer                                      */
/*                                                                    */
/*   This section is separated from the core, because it makes use    */
/*   of the type information and touches the values. The core can     */
/*   do without this, so this layer might not even be needed for      */
/*   many uses.                                                       */
/*                                                                    */
/*   What this layer offers is:                                       */
/*                                                                    */
/*   - an implementation of types                                     */
/*                                                                    */
/*   (note that the following two operations are optional by design)  */
/*   - free storage reclamation (garbage collection)                  */
/*   - compression of the memory core (to prepare size decrease)      */
/*                                                                    */
/*   - persistence                                                    */
/*                                                                    */
/* ================================================================== */

//FIXME: type stuff to come here
// we can first copy it in from xm_mem.c, (only the RefType stuff is
// needed), but it will need to be reconsidered as soon as we start
// with dynamic loading. We may want to replace the type->next list
// by a map, since we may have many types and we are using the MAP
// type anyway.

// ------------------------------------------------------------------
//
// Collect unreacheable slot
//
//   This is the "garbage collector".
//
//   It is an expensive operation, since all references in all
//   values have to be enumerated.
//
// ------------------------------------------------------------------

static void mem_collect(void)
{
  // Outline
  // - adjoin a 'todo' array (and a MEM_TAG_VISITED)
  // - todo_head = MEM_NIL;
  // - enter all roots to the todo list.
  // - process entries in the todo list until it is empty.
  //   - call NtoT(entry)->forAllReferenes(enter_into_todo_&_mark_visited).
  //     all references (names & pointers) need to be considered and
  //     optionally converted to names. (They need to be known to the
  //     object memory already, so we block slot creation here).
  // - release adjoined 'todo'.
  // - pass all used slots and 'NtoT(slot)->freeValue(NtoV(slot)) them
  //   if not visited. Mark these slots to be unused, clear the visited
  //   flag of all others.
  // - mem_rebuild_lists
}

// ------------------------------------------------------------------
//
// Compress the memory.
//
//   This eventually prepares a decrease of the memory size to the
//   expense, that all application of the names have to be renamed.
//   This is a rather expensive operation since all references in
//   all values have to be modified, which can be very costy for
//   some data types.
//
//   A later version of the memory might attempt to get rid of this
//   costs by changing the implementation of the memory core to do
//   hashing in both directions, thereby removing the need of renaming
//   during compression by the expense of the hashing.
//
// ------------------------------------------------------------------

static void mem_compress(void)
{
  // Outline
  // - adjoin and fill a translation table (N->N) with the new
  //   locations of the used slots.
  // - pass through the used slots applying the translation
  //   table: NtoT(slot)->renameReferences(translation).
  //   Only exported names need to be considered in the rename
  //   operation, not external pointers.
  // - collect the used slots to the beginning of the memory
  //   according to the issued translation
  // - mem_rebuild_lists
}
