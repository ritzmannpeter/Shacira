/* [sink_tst.c]  sink-Test  */

#include "stdosx.h"
#include "sink.h"

int main()
{ 
  printf("%s", Str_printf("Sink test >%d< '%s'?\n",123,"Ok") );
  BUG_CORE;
  return 0;
}
