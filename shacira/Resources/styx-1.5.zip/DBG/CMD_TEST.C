/* [cmd_test.c]  cmd-Test  */

#include "stdosx.h"
#include "cmd__cim.h"

#define somepath CTX_EVAL(string,"SomePath")
#define optpath  CTX_EVAL(string,"OptPath")

int main(int argc, string argv[])
{ int i;
  CTX_init_cmd_test(argc, argv);
  printf("SomePath = %s\n",somepath);
  printf("OptPath = %s\n",optpath);
  for( i=0; i < CTX_argcnt(); ++i )
    printf("%s\n",CTX_ARGVAL(string,i));
  CTX_list(CTX_ctx_val());
  CTX_quit();
  BUG_CORE;
  return(0);
}
