/* [rat_test.c]  rational-Test  */

#include "stdosx.h"
#include "rational.h"
#include <math.h>

void trat(long a, long b)
{ Integer xa = Int_Cto(a);
  Integer xb = Int_Cto(b);
  Rational r = Rat_Int_div(xa,xb);
  showRat(r); printf("\n");
  Rat_free(r);
  Int_free(xa); Int_free(xb);
}

Rational euler(int n)
/* euler number by 'n' iterations */
/* 1/0! + 1/1! + 1/2! + ... + 1/n! */
{ Integer fact = Int_Cto(1);
  Rational res = Rat_Int_to(fact);
  int i;
  for (i = 1; i <= n; i++)
{{ string t = Rat_to_Str(res,10,70); printf("e ~ %s\n",t); FreeMem(t); }
  { Integer ii = Int_Cto(i);
    Integer i1 = Int_mlt(ii,fact);
    Rational ri = Rat_Int_to(i1);
    Rational rii = Rat_inv(ri);
    Rational tmp = Rat_add(res,rii);
    Rat_free(ri); Rat_free(rii); Rat_free(res);
    res  = tmp;
    Int_free(fact); Int_free(ii); 
    fact = i1;
  }
}
  Int_free(fact);
  return res;
}

int main()
{
  Rational ceu   = euler(55);
  string   t = Rat_to_Str(ceu,10,70);
  Integer  x;
  printf("e = %s\n",t);
  FreeMem(t);
  printf("\ne = %.16E (cpu)\n",exp(1));
  printf("\n");
  x = Rat_nom(ceu); t=Int_itoa(x,10); printf("    %s\n",t); FreeMem(t); Int_free(x);
  printf("E = -------------------------------------------------------------------------\n");
  x = Rat_den(ceu); t=Int_itoa(x,10); printf("    %s\n",t); FreeMem(t); Int_free(x);
  Rat_free(ceu);
  BUG_CORE;
  return 0;
}

int uumain()
{ Integer a = Int_Cto(163);
  Integer b = Int_Cto(60);
  Integer c = Int_Cto(1);
  Integer d = Int_Cto(720);
  Rational ra = Rat_Int_div(a,b);
  Rational rb = Rat_Int_div(c,d);
  Rational res = Rat_add(ra,rb);
  string   s = Rat_to_Str(res,10,5);
  showRat(res); NL;
  printf("%s\n",s);
  FreeMem(s);
  Int_free(a);
  Int_free(b);
  Int_free(c);
  Int_free(d);
  Rat_free(ra);
  Rat_free(rb);
  Rat_free(res);
  BUG_CORE;
  return 0;
}

int emain()
/* computes a large number */
{
  trat(4,12); trat(-15,-3); trat(0,9);
  BUG_CORE;
  return 0;
}
