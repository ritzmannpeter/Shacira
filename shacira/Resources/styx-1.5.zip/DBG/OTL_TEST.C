/* [otl_test.c]  otab/olist-Test  */

#include "stdosx.h"
#include "olist.h"
#include "otab.h"

static int allnumbers[] = 
{
  1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20
};
static int evennumbers[] = 
{
  2,4,6,8,10,12,14,16,18,20
};
static int oddnumbers[] = 
{
  1,3,5,7,9,11,13,15,17,19
};
static string names[] =
{
  "Graf", "Sanchez", "Martinez", "Zwereva", "Hack", 
  "Huber", "Sabatini", "Graf", "Pierce", "Halard"
};

static OL_Lst x;
static OL_Lst e;
static OL_Lst o;
static OL_Lst n;
static OT_Tab t;
static OT_Tab tu;
static OT_Tab f;

static bool strLE(StdCPtr l, StdCPtr r)
{
  return strcmp((string)l,(string)r) <= 0 ? True : False;
}

static void prStr(StdCPtr o)
{
  printf("%s",(string)o);
}

static void prInt(StdCPtr o)
{
  printf("%d",(int)o);
}

void mapfun(OT_Obj* objs,StdCPtr any)
{ int cnt = *((int*)any) + 1;
  *((int*)any) = cnt;
  if( strcmp((string)objs[0],(string)objs[1]) ) BUG;
}

int main() 
{ OT_Tab ttt; OL_Lst lll; int a = 0, i;
  x = OL_CREATE_ADT(int);
  e = OL_CREATE_ADT(int);
  o = OL_CREATE_ADT(int);
  n = OL_CREATE_ADT(string);
  t = OT_CREATE_ADT(string);
  tu = OT_CREATE_ADT(string);
  f = OT_CFILL_ADT(string,"Heike",13);
  a = *((int*)OT_MAP_F(4,mapfun,&a,f,f));
  printf("MAP-RESULTAT = %d\n",a);
  OT_PRINT(f,prStr,5,0);
  OT_DEL_T(f);
  for( i=0; i < 10; ++i )
  {
    OL_H_INS(int,e,evennumbers[i]);
    OL_T_INS(int,o,oddnumbers[i]);
    OL_C_INS(int,x,allnumbers[i]);
    OL_S_INS(string,n,names[i],strLE);
    OT_S_INS(t,names[i],strcmp);
    OT_S_INS_U(tu,names[i],strcmp);
  }
  if( ! OT_EQUAL(t,( ttt = OT_COPY(t) )) ) BUG;
  if( ! OL_EQUAL(n,( lll = OL_COPY(n) )) ) BUG;
  OL_PRINT(e,prInt,10,0);
  OL_PRINT(o,prInt,10,0);
  OL_PRINT(x,prInt,10,0);
  OL_PRINT(n,prStr,5,0);
  OT_PRINT(t,prStr,5,0);
  OT_PRINT(tu,prStr,5,0);
  NL;
  for( i=0; i < 10; ++i )
  { a = ! i ? OL_LAST(int,e) : OL_PREV(int,e); 
    printf("%d\n",a);
  }
  NL;
  for( i=0; i < OL_CNT(e); ++i )
  { a = ! i ? OL_LAST(int,e) : OL_PREV(int,e); 
    if( a == 2 || a == 20 || a == 12 ) OL_DEL_E(e);
    if( a == 8 ) OL_UPD(int,e,66);
  }
  NL;
  for( i=0; i < OL_CNT(e); ++i )
  { a = ! i ? OL_LAST(int,e) : OL_PREV(int,e); 
    printf("%d\n",a);
  }
  if( OL_PREV(int,e) != 0 ) BUG;
  if( ! OT_EQUAL( OT_APPEND(t,t), OT_APPEND(ttt,ttt) ) ) BUG;
  if( ! OL_EQUAL( OL_APPEND(n,n), OL_APPEND(lll,lll) ) ) BUG;
  OL_DEL_L(x);
  OL_DEL_L(n);
  OL_CLEAR(o);
  OL_COPY_L(o,e);
  if( ! OL_EQUAL(o,e) ) BUG;
  OL_DEL_C(o);
  OL_DEL_L(e);
  OL_DEL_L(lll);
  OT_DEL_T(ttt);
  OT_DEL_T(t);
  OT_DEL_T(tu);
  BUG_CORE;
  return(0);
}
