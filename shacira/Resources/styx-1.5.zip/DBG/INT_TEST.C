/* [int_test.c]  integer-Test  */

#include "stdosx.h"
#include "integer.h"

void lputs(string s)
/* prints a looooong string */
{ long col = 0;
  while(*s)
  {
    if (col % 50 == 0)
    { printf("\\\n/* %5ld */ \\",col); }
    printf("%c",*s++);
    col += 1;
  }
  printf("\n");
  FreeMem(s);
}

void Faculty(int n)
{ Integer r; long i;
  printf("Faculty(%d) = ",n);
  r = Int_Cto(1);
  for (i = 1; i <= n; i++)
  { Integer t1 = Int_Cto(i);
    Integer t2 = Int_mlt(r,t1);
    Int_free(r); Int_free(t1);
    r = t2;
  }
  lputs(Int_itoa(r,10));
  Int_free(r);
}

int fmain()
/* computes a large number */
{
  Faculty(4);
  BUG_CORE;
  return(0);
}

int smain()
/* a speed test */
{ long i;
  Integer x = Int_Cto(200000L);
  Integer y = Int_Cto(20000L);
printf("start\n");
  for (i = 0; i < 10000; i++)
    Int_free(Int_quo(x,y));
printf("stop %ld\n",i);
  Int_free(x);
  Int_free(y);
  BUG_CORE;
  return(0);
}

int xmain()
{ Integer r = Int_atoi("2",10);
  Integer res = Int_exp(r,10);
  lputs(Int_itoa(res,10));
  Int_free(r);
  Int_free(res);
  BUG_CORE;
  return(0);
}

int cmain()
{ Integer r = Int_atoi("12334567890",10);
  lputs(Int_itoa(r,10));
  Int_free(r);
  BUG_CORE;
  return(0);
}

void tgcd(long a, long b)
{ Integer xa = Int_Cto(a); 
  Integer xb = Int_Cto(b);
  Integer res = Int_gcd(xa,xb);
  string  tmp = Int_itoa(res,10);
  printf("gcd(%ld,%ld) = %s\n",a,b,tmp);
  Int_free(xa); Int_free(xb); Int_free(res); FreeMem(tmp);
}

int main()
{
  Integer a = Int_Cto(117420L);
  Integer b = Int_Cto(43200L);
  Integer r = Int_rem(a,b);
  string  s = Int_itoa(r,10);
  string  t = Int_itoa(a,10);
  printf("res = %s\n",s);
  printf("a'  = %s\n",t);
  FreeMem(s); FreeMem(t); Int_free(a); Int_free(b); Int_free(r);
  BUG_CORE;
  return(0);
}

int umain()
{
  Integer i = Int_Cto(0);
  string s = Int_itoa(i,10);
  printf("i = >%s<\n",s);
  tgcd(4,12); tgcd(-15,-3); tgcd(0,0);
  Int_free(i);
  FreeMem(s);
  BUG_CORE;
  return 0;
}
