/* [set_test.c]  hset-Test  */

#include "stdosx.h"
#include "hmap.h"
#include "hset.h"

static int allnumbers[] = 
{
  1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20
};
static int evennumbers[] = 
{
  2,4,6,8,10,12,14,16,18,20
};
static int oddnumbers[] = 
{
  1,3,5,7,9,11,13,15,17,19
};
static string names[] =
{
  "Graf", "Sanchez", "Martinez", "Zwereva", "Hack", 
  "Huber", "Sabatini", "Navratilova", "Pierce", "Halard"
};

static HS_Set s_allnumbers; 
static HS_Set s_even_name; 
static HS_Set s_odd_name; 
static HS_Set s_all_name;

static int nrcmp(HS_Dom l, HS_Dom r)
{
  return( (int)l - (int)r );
}

static bool equalStr(StdCPtr l, StdCPtr r)
{
  return( strEqual((string)l,(string)r) );
}

static long hashStr(StdCPtr s)
{
  return( strHash((string)s) );
}

static bool set_where(HS_Elm elm)
{
  return( (int)elm % 2 == 0 );
}

static bool rel_where(HS_Elm elm)
{
  switch( HS_ARITY(elm) )
  {
    case 2:
      return( strcmp(HS_TPLCOL(string,elm,2),"Graf") == 0 );
    case 3:
      return( strcmp(HS_TPLCOL(string,elm,3),"Graf") == 0 );
    default: BUG; return False /* dummy */;
  }
}

static void prevtpl(FILE* file, HS_Elm elm)
{
  switch( HS_ARITY(elm) )
  {
    case 2:
      fprintf(file,"%s.%d",HS_TPLCOL(string,elm,1),HS_TPLCOL(int,elm,2));
      break;
    case 3:
      fprintf
      (
        file,"%s.%d.%d",
        HS_TPLCOL(string,elm,1),HS_TPLCOL(int,elm,2),HS_TPLCOL(int,elm,3)
      );
      break;
    default: BUG;
  }
}

static void prtpl(FILE* file, HS_Elm elm)
{
  switch( HS_ARITY(elm) )
  {
    case 2:
      fprintf(file,"%d.%s",HS_TPLCOL(int,elm,1),HS_TPLCOL(string,elm,2));
      break;
    case 3:
      fprintf
      (
        file,"%d.%d.%s",
        HS_TPLCOL(int,elm,1),HS_TPLCOL(int,elm,2),HS_TPLCOL(string,elm,3)
      );
      break;
    case 4:
      fprintf
      (
        file,"%d.%s.%d.%s",
        HS_TPLCOL(int,elm,1),
        HS_TPLCOL(string,elm,2),
        HS_TPLCOL(int,elm,3),
        HS_TPLCOL(string,elm,4)
      );
      break;
    case 5:
      fprintf
      (
        file,"%d.%d.%s.%d.%s",
        HS_TPLCOL(int,elm,1),
        HS_TPLCOL(int,elm,2),
        HS_TPLCOL(string,elm,3),
        HS_TPLCOL(int,elm,4),
        HS_TPLCOL(string,elm,5)
      );
      break;
    default: BUG;
  }
}

static void prnumber(FILE* file, HS_Elm elm)
{
  fprintf(file,"%d",(int)elm);
}

static void prnumbers(FILE* file, HS_Elm elm)
{
  fprintf(file,"%d.%d",HS_TPLCOL(int,elm,1),HS_TPLCOL(int,elm,2));
}

static void prname(FILE* file, HS_Elm elm)
{
  fprintf(file,"%s",(string)elm);
}

static void printSets()
{
  printf("Alle Zahlen 1 - 20\n");
  printf("------------------\n");
  HS_PRINT(s_allnumbers,2,prnumber);
  printf("\n\n");
  printf("Gerade Zahlen und Namen\n");
  printf("-----------------------\n");
  HS_PRINT(s_even_name,2,prtpl);
  printf("\n\n");
  printf("Ungerade Zahlen und Namen\n");
  printf("-------------------------\n");
  HS_PRINT(s_odd_name,2,prtpl);
  printf("\n\n");
  printf("Gerade, Ungerade Zahlen und Namen\n");
  printf("---------------------------------\n");
  HS_PRINT(s_all_name,2,prtpl);
  printf("\n\n");
}

int main() 
{ HS_Set tmp; HS_Set tmp2; HS_Set tmp3; HS_Set tmpx;
  HS_Itr itr; HS_Elm elm; 
  bool first = True; int i;

  s_allnumbers  = HS_CREATE_SET(int,primEqual,primHash);
  s_even_name   = HS_CREATE_REL_2
                  (int,primEqual,primHash,string,equalStr,hashStr);
  s_odd_name    = HS_CREATE_REL_2
                  (int,primEqual,primHash,string,equalStr,hashStr);
  s_all_name    = 
    HS_createRel(6,primEqual,primHash,primEqual,primHash,equalStr,hashStr);
  for( i=0; i < 10; ++i )
    HS_SETTPL_2(evennumbers[1],names[i],s_even_name);
  for( i=0; i < 20; ++i )
  {
    if( i < 10 )
    {
      HS_SETTPL_2(evennumbers[i],names[i],s_even_name);
      HS_SETTPL_2(oddnumbers[i],names[i],s_odd_name);
      HS_SETTPL_2(oddnumbers[i],names[i],s_odd_name);
      HS_setTpl(4,s_all_name,
                (HS_Dom)evennumbers[i],(HS_Dom)oddnumbers[i],(HS_Dom)names[i]);
      HS_setTpl(4,s_all_name,
                (HS_Dom)evennumbers[i],(HS_Dom)oddnumbers[i],(HS_Dom)names[i]);
    }
    HS_SET_ELM(allnumbers[i],s_allnumbers);
    HS_SET_ELM(allnumbers[i],s_allnumbers);
  }

  printf("Sets nach Erzeugung\n");
  printf("===================\n");
  printSets();

  printf("CLOSURES\n\n");
  tmp = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  tmp2 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  tmp3 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  HS_SETTPL_2(1,2,tmp);
  HS_SETTPL_2(1,3,tmp);
  HS_SETTPL_2(1,4,tmp);
  HS_SETTPL_2(1,11,tmp);
  HS_SETTPL_2(1,12,tmp);
  HS_SETTPL_2(1,17,tmp);
  HS_SETTPL_2(1,18,tmp);
  HS_SETTPL_2(1,19,tmp);
  HS_SETTPL_2(1,20,tmp);
  HS_SETTPL_2(3,6,tmp);
  HS_SETTPL_2(2,7,tmp);
  HS_SETTPL_2(2,8,tmp);
  HS_SETTPL_2(2,9,tmp);
  HS_SETTPL_2(4,7,tmp);
  HS_SETTPL_2(4,8,tmp);
  HS_SETTPL_2(4,9,tmp);
  HS_SETTPL_2(7,7,tmp);
  HS_SETTPL_2(7,8,tmp);
  HS_SETTPL_2(7,9,tmp);
  HS_SETTPL_2(8,7,tmp);
  HS_SETTPL_2(8,8,tmp);
  HS_SETTPL_2(8,9,tmp);
  HS_SETTPL_2(8,13,tmp);
  HS_SETTPL_2(13,14,tmp);
  HS_SETTPL_2(13,15,tmp);
  HS_SETTPL_2(13,16,tmp);
  HS_SETTPL_2(100,200,tmp);
  HS_SETTPL_2(100,300,tmp);
  HS_SETTPL_2(100,400,tmp);
  HS_SETTPL_2(100,110,tmp);
  HS_SETTPL_2(100,120,tmp);
  HS_SETTPL_2(100,170,tmp);
  HS_SETTPL_2(100,180,tmp);
  HS_SETTPL_2(100,190,tmp);
  HS_SETTPL_2(100,200,tmp);
  HS_SETTPL_2(300,600,tmp);
  HS_SETTPL_2(200,700,tmp);
  HS_SETTPL_2(200,800,tmp);
  HS_SETTPL_2(200,900,tmp);
  HS_SETTPL_2(400,700,tmp);
  HS_SETTPL_2(400,800,tmp);
  HS_SETTPL_2(400,900,tmp);
  HS_SETTPL_2(700,700,tmp);
  HS_SETTPL_2(700,800,tmp);
  HS_SETTPL_2(700,900,tmp);
  HS_SETTPL_2(800,700,tmp);
  HS_SETTPL_2(800,800,tmp);
  HS_SETTPL_2(800,900,tmp);
  HS_SETTPL_2(800,130,tmp);
  HS_SETTPL_2(130,140,tmp);
  HS_SETTPL_2(130,150,tmp);
  HS_SETTPL_2(130,160,tmp);

  HS_R_ECLOSURE(tmp3,tmp,nrcmp);
  printf("\n");
  HS_FORALL(elm,itr,tmp3) 
    printf("%d",HS_CLASS(int,HS_TPLCOL(HS_Dom,elm,1),tmp3));
  printf("\n");
  tmp2 = HS_CONCLUSION(tmp2,tmp3);
  if( ! HS_EMPTY_SET(HS_MINUS(tmp3,tmp3,tmp2)) ) BUG;
  HS_DROP_SET(tmp2);
  tmp2 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  tmp2 = HS_KERN(tmp2,tmp3);
  if( ! HS_EMPTY_SET(tmp2) ) BUG;
  HS_DROP_SET(tmp3);
  tmp3 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  HS_DROP_SET(tmp2);
  tmp2 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  printf("REFLEXIV\n");
  HS_R_RCLOSURE(tmp,tmp);
  HS_PRINT(tmp,2,prnumbers);
  printf("\n\n");
  printf("SYMMETRISCH-REFLEXIV\n");
  HS_SCLOSURE(tmp3,tmp);
  HS_PRINT(tmp3,2,prnumbers);
  printf("\n\n");
  printf("TRANSITIV-SYMMETRISCH-REFLEXIV\n");
  HS_ICLOSURE(tmp2,tmp3);
  HS_R_CLOSURE(tmp3,tmp3);
  if( ! HS_EQUAL(tmp3,tmp2) ) BUG;
  HS_R_ECLOSURE(tmp,tmp,(int (*)(HS_Dom l,HS_Dom r))NULL);
  if( ! HS_EQUAL(tmp3,tmp) ) BUG;
  HS_PRINT(tmp,2,prnumbers);
  printf("\n\n");
  printf("KLASSEN\n");
  HS_DROP_SET(tmp3);
  tmp3 = HS_COPY(tmp);
  HS_R_ECLOSURE(tmp,tmp,nrcmp);
  HS_FORALL(elm,itr,tmp) printf("%d",HS_CLASS(int,HS_TPLCOL(HS_Dom,elm,1),tmp));
  printf("\n");
  HS_QUOTIENT(tmp3,nrcmp);
  if( ! HS_EQUAL(tmp,tmp3) ) BUG;
  HS_FORALL(elm,itr,tmp) printf("%d",HS_CLASS(int,HS_TPLCOL(HS_Dom,elm,1),tmp));
  printf("\n");
/*
  HS_IR_RCLOSURE(tmp,tmp,s_allnumbers);
  HS_PRINT(tmp,2,prnumbers);
  printf("\n\n");
*/
  HS_DROP_SET(tmp3);
  HS_DROP_SET(tmp2);
  HS_DROP_SET(tmp);

  printf("COMPOSE\n\n");
  tmp = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  HS_SETTPL_2(1,2,tmp);
  HS_SETTPL_2(1,3,tmp);
  HS_SETTPL_2(1,4,tmp);
  HS_SETTPL_2(3,6,tmp);
  tmp2 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  HS_SETTPL_2(2,7,tmp2);
  HS_SETTPL_2(2,8,tmp2);
  HS_SETTPL_2(2,9,tmp2);
  HS_SETTPL_2(2,2,tmp2);
  HS_SETTPL_2(3,7,tmp2);
  HS_SETTPL_2(3,8,tmp2);
  HS_SETTPL_2(3,9,tmp2);
  HS_SETTPL_2(3,3,tmp2);
  HS_SETTPL_2(4,7,tmp2);
  HS_SETTPL_2(4,8,tmp2);
  HS_SETTPL_2(4,9,tmp2);
  HS_SETTPL_2(4,4,tmp2);
  HS_SETTPL_2(6,6,tmp2);
  HS_COMPOSE(tmp,tmp,tmp2);
  HS_PRINT(tmp,2,prnumbers);
  printf("\n\n");
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);
  tmp = HS_TRANS(s_odd_name);
  tmp2 = HS_CREATE_REL_2(int,primEqual,primHash,int,primEqual,primHash);
  HS_COMPOSE(tmp2,s_even_name,tmp);
  HS_PRINT(tmp2,2,prnumbers);
  printf("\n\n");
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);

  printf("JOIN\n\n");
  tmp = HS_JOIN(s_odd_name,s_even_name);
  HS_PRINT(tmp,2,prtpl);
  printf("\n##1##\n");
  HS_DROP_SET(tmp);
  tmp = HS_JOIN_1(s_odd_name,s_even_name,2,2);
  HS_PRINT(tmp,2,prtpl);
  printf("\n##2##\n");
  HS_DROP_SET(tmp);
  tmp = HS_JOIN_1(s_all_name,s_even_name,3,2);
  HS_PRINT(tmp,2,prtpl);
  printf("\n##3##\n");
  HS_DROP_SET(tmp);
  tmp = HS_join(6,s_all_name,s_odd_name,(long)2,(long)1,(long)3,(long)2);
  HS_PRINT(tmp,2,prtpl);
  printf("\n##4##\n");
  HS_DROP_SET(tmp);

  printf("TRANS\n\n");
  tmp = HS_TRANS(s_even_name);
  tmp2 = HS_TRANS(tmp);
  if( ! HS_EQUAL(tmp2,s_even_name) ) BUG;
  HS_PRINT(tmp,2,prevtpl);
  printf("\n##1##\n");
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);
  tmp = HS_TRANS(s_all_name);
  tmp2 = HS_TRANS(tmp);
  if( ! HS_EQUAL(tmp2,s_all_name) ) BUG;
  HS_PRINT(tmp,2,prevtpl);
  printf("\n##2##\n");
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);

  printf("PART\n\n");
  tmp = HS_PART(s_allnumbers,set_where);
  if( HS_CARD(tmp) != 10 ) BUG;
  HS_DROP_SET(tmp);
  tmp = HS_PART(s_all_name,rel_where);
  if( HS_CARD(tmp) != 1 ) BUG;
  HS_DROP_SET(tmp);
  tmp = HS_PART(s_even_name,rel_where);
  if( HS_CARD(tmp) != 2 ) BUG;
  HS_DROP_SET(tmp);

  printf("PRODUKT Set / Plane-Test\n\n");
  tmpx = HS_COPY(s_allnumbers);
  HS_CLEAR(tmpx);
  HS_SET_ELM(allnumbers[0],tmpx);
  HS_SET_ELM(allnumbers[1],tmpx);
  HS_SET_ELM(allnumbers[2],tmpx);
  HS_SET_ELM(allnumbers[3],tmpx);
  tmp3 = HS_PRODUCT(tmpx,tmpx,True);
  if( HS_CARD(tmp3) != HS_CARD(tmpx) * HS_CARD(tmpx) ) BUG;
  tmp = HS_PRODUCT(s_allnumbers,s_allnumbers,True);
  if( HS_CARD(tmp) != HS_CARD(s_allnumbers) * HS_CARD(s_allnumbers) ) BUG;
  HS_FORALL(elm,itr,tmp)
  {
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,1));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,2));
    printf("\n");
  }
  tmp2 = HS_PRODUCT(tmp3,tmpx,True);
  if( HS_CARD(tmp2) != HS_CARD(tmp3) * HS_CARD(tmpx) ) BUG;
  HS_DROP_SET(tmp2);
  tmp2 = HS_PRODUCT(tmpx,tmp3,True);
  if( HS_CARD(tmp2) != HS_CARD(tmp3) * HS_CARD(tmpx) ) BUG;
  printf("\nPLANE-Test 1\n\n");
  HS_FORALL(elm,itr,tmp2)
  {
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,1));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,2));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,3));
    printf("\n");
  }
  HS_DROP_SET(tmp2);
  tmp2 = HS_PRODUCT(tmp3,tmp3,True);
  if( HS_CARD(tmp2) != HS_CARD(tmp3) * HS_CARD(tmp3) ) BUG;
  printf("\nPLANE-Test 2\n\n");
  HS_FORALL(elm,itr,tmp2)
  {
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,1));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,2));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,3));
    printf(", ");
    prnumber(stdout,HS_TPLCOL(HS_Elm,elm,4));
    printf("\n");
  }
  HS_DROP_SET(tmp2);
  HS_DROP_SET(tmp3);
  HS_DROP_SET(tmpx);
  HS_DROP_SET(tmp);
  printf("PRODUKT BRel\n\n");
  tmp = HS_PRODUCT(s_even_name,s_even_name,False);
  if( HS_CARD(tmp) != HS_CARD(s_even_name) * HS_CARD(s_even_name) ) BUG;
  HS_FORALL(elm,itr,tmp)
  {
    prtpl(stdout,HS_TPLCOL(HS_Elm,elm,1));
    printf(", ");
    prtpl(stdout,HS_TPLCOL(HS_Elm,elm,2));
    printf("\n");
  }
  HS_DROP_SET(tmp);
  printf("PRODUKT Rel\n\n");
  tmp = HS_PRODUCT(s_all_name,s_all_name,False);
  if( HS_CARD(tmp) != HS_CARD(s_all_name) * HS_CARD(s_all_name) ) BUG;
  HS_FORALL(elm,itr,tmp)
  {
    prtpl(stdout,HS_TPLCOL(HS_Elm,elm,1));
    printf(", ");
    prtpl(stdout,HS_TPLCOL(HS_Elm,elm,2));
    printf("\n");
  }
  HS_DROP_SET(tmp);

  printf("PROJECT\n\n");
  tmp = HS_PROJECT(s_even_name,1);
  HS_PRINT(tmp,2,prnumber);
  HS_DROP_SET(tmp);
  tmp = HS_PROJECT(s_all_name,3);
  HS_PRINT(tmp,2,prname);
  printf("\n\n");
  HS_DROP_SET(tmp);

  printf("DOMAIN/RANGE\n\n");
  tmp = HS_RANGE_1(4,s_even_name);
  HS_PRINT(tmp,2,prname);
  printf("\n\n");
  HS_DROP_SET(tmp);
  tmp = HS_RANGE_1(4,s_all_name);
  HS_PRINT(tmp,2,prtpl);
  printf("\n\n");
  HS_DROP_SET(tmp);
  tmp = HS_range(3,s_all_name,(StdCPtr)2,1);
  HS_PRINT(tmp,2,prname);
  printf("\n\n");
  HS_DROP_SET(tmp);
  tmp = HS_DOMAIN_1("Graf",s_even_name);
  HS_PRINT(tmp,2,prnumber);
  printf("\n\n");
  HS_DROP_SET(tmp);
  tmp = HS_DOMAIN_1("Sanchez",s_all_name);
  HS_PRINT(tmp,2,prnumbers);
  printf("\n\n");
  HS_DROP_SET(tmp);
  tmp = HS_domain(3,s_all_name,(StdCPtr)1,"Graf");
  HS_PRINT(tmp,2,prnumber);
  printf("\n\n");
  HS_DROP_SET(tmp);

  HS_DELTPL_2(evennumbers[9],names[9],s_even_name);
  HS_DEL_ELM(allnumbers[19],s_allnumbers);
  HS_delTpl(4,s_all_name,
            (HS_Dom)evennumbers[9],(HS_Dom)oddnumbers[9],(HS_Dom)names[9]);
  printf("Sets nach dem Loeschen eines Elements\n");
  printf("=====================================\n");
  printSets();
  printf("Card s_allnumbers = %ld\n",HS_CARD(s_allnumbers));
  printf("Card s_even_name = %ld\n",HS_CARD(s_even_name));
  printf("Card s_all_name = %ld\n",HS_CARD(s_all_name));
  printf("\n\n");

  printf("REL\n\n");
  first = True;
  tmp = HS_COPY(s_all_name);
  tmp2 = HS_COPY(s_all_name);
  HS_UNION(tmp2,tmp,s_all_name);
  if( ! HS_EQUAL(s_all_name,tmp2) ) BUG;
  HS_INTER(tmp2,tmp,s_all_name);
  if( ! HS_EQUAL(s_all_name,tmp2) ) BUG;
  if( ! HS_EQUAL(s_all_name,tmp) ) BUG;
  if( ! HS_SUBSET(s_all_name,tmp) ) BUG;
  HS_FORALL(elm,itr,s_all_name)
  {
    if( first )
    {
      HS_DEL_ELM(elm,tmp);
      if( HS_MBR_ELM(elm,tmp) ) BUG;
      first = False;
    }
    else
    {
      if( ! HS_MBR_ELM(elm,tmp) ) BUG;
      if( ! HS_mbrTpl(
              4,tmp,
              HS_TPLCOL(HS_Dom,elm,1),
              HS_TPLCOL(HS_Dom,elm,2),
              HS_TPLCOL(HS_Dom,elm,3)) )
        BUG;
    }
  }
  HS_MINUS(tmp2,s_all_name,tmp);
  if( HS_CARD(tmp2) != 1 ) BUG;
  if( HS_EQUAL(s_all_name,tmp) ) BUG;
  if( HS_SUBSET(s_all_name,tmp) ) BUG;
  if( ! HS_EMPTY_SET(HS_CLEAR(tmp)) ) BUG;
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);
  printf("BREL\n\n");
  first = True;
  tmp = HS_COPY(s_even_name);
  tmp2 = HS_COPY(s_even_name);
  HS_UNION(tmp2,tmp,s_even_name);
  if( ! HS_EQUAL(s_even_name,tmp2) ) BUG;
  HS_INTER(tmp2,tmp,s_even_name);
  if( ! HS_EQUAL(s_even_name,tmp2) ) BUG;
  if( ! HS_EQUAL(s_even_name,tmp) ) BUG;
  if( ! HS_SUBSET(s_even_name,tmp) ) BUG;
  HS_FORALL(elm,itr,s_even_name)
  {
    if( first )
    {
      HS_DEL_ELM(elm,tmp);
      if( HS_MBR_ELM(elm,tmp) ) BUG;
      first = False;
    }
    else
    {
      if( ! HS_MBR_ELM(elm,tmp) ) BUG;
      if( ! HS_MBRTPL_2(HS_TPLCOL(HS_Dom,elm,1),HS_TPLCOL(HS_Dom,elm,2),tmp) ) 
        BUG;
    }
  }
  HS_MINUS(tmp2,s_even_name,tmp);
  if( HS_CARD(tmp2) != 1 ) BUG;
  if( HS_EQUAL(s_even_name,tmp) ) BUG;
  if( HS_SUBSET(s_even_name,tmp) ) BUG;
  if( ! HS_EMPTY_SET(HS_CLEAR(tmp)) ) BUG;
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);
  printf("SET\n\n");
  tmp = HS_COPY(s_allnumbers);
  tmp2 = HS_COPY(s_allnumbers);
  HS_UNION(tmp2,tmp,s_allnumbers);
  if( ! HS_EQUAL(s_allnumbers,tmp2) ) BUG;
  HS_INTER(tmp2,tmp,s_allnumbers);
  if( ! HS_EQUAL(s_allnumbers,tmp2) ) BUG;
  HS_MINUS(tmp2,tmp,s_allnumbers);
  if( ! HS_EMPTY_SET(tmp2) ) BUG;
  if( ! HS_EQUAL(s_allnumbers,tmp) ) BUG;
  if( ! HS_SUBSET(s_allnumbers,tmp) ) BUG;
  HS_FORALL(elm,itr,s_allnumbers)
  {
    if( ! HS_MBR_ELM(elm,tmp) ) BUG;
  }
  if( ! HS_EMPTY_SET(HS_CLEAR(tmp)) ) BUG;
  HS_DROP_SET(tmp);
  HS_DROP_SET(tmp2);

  HS_DROP_SET(s_allnumbers);
  HS_DROP_SET(s_all_name);
  HS_DROP_SET(s_even_name);
  HS_DROP_SET(s_odd_name);
  BUG_CORE;
  return(0);
}
