/* [bs0_test.c]  binset-Test  */

#include "stdosx.h"
#include "binset.h"

bool setrel(INT f, INT t)
{
  BUG; return False;
}

int main()
{
  BS_Set a = BS_create(0);
  BS_Set b = BS_create(0);
  BS_copy(a,b);
  BS_inter(a,a,b);
  BS_union(a,a,b);
  BS_minus(a,a,b);
  BS_setG(a,0,setrel);
  BS_trans(a,0);
  BS_rclosure(b,a,0);
  BS_sclosure(b,a,0);
  BS_iclosure(b,a,0);
  BS_eclosure(b,a,0);
  BS_closure(b,a,0);
  BS_kern(b,a,0);
  if( BS_cnt(a) || BS_cnt(b) ) BUG;
  if( ! BS_subset(a,b) ) BUG;
  if( ! BS_equal(a,b) ) BUG;
  if( ! BS_empty(a) ) BUG;
  if( ! BS_empty(b) ) BUG;
  return 0;
}
