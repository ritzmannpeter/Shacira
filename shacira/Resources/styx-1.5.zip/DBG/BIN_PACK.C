/* ------------------------------------------------------------------------ */
/*                                                                          */
/* [bin_pack.c]                 BIN Speed Test                              */
/*                                                                          */
/* Copyright (c) 1993 by D\olle, Manns                                      */
/* ------------------------------------------------------------------------ */

#include "stdosx.h"
#include "binimg.h"
#include "pathes.h"

/*I----------------------------- get & put ---------------------------------- */

void pack_file(string src, string dst)
/* sic */
{ int cc; FILE *f = OpnFile(src,"rb");
  putBgn("",dst,"");
  putHeader(src,"packed",1,0);
  putLong(Path_FileSize(src));
  for (cc = fgetc(f); cc > 0; cc = fgetc(f))
    putByte((byte)cc);
  putEnd();
  fclose(f);
}

void unpack_file(string src, string dst)
/* sic */
{ long len, i; byte cc; FILE *f = OpnFile(dst,"wb");
  getBgn("",src,"");
  getHeader("packed",1,0);
  getLong(&len);
  for (i = 0; i < len; i++)
  {
    getByte(&cc); fputc(cc,f);
  }
  getEnd();
  fclose(f);
}

#define crypt_1 (52845)
#define crypt_2 (22719)
static word  crypt_R;

static byte Decrypt(byte cipher)
/* decrypt a byte */
{
  byte plain = (cipher ^ (crypt_R >> 8));
  crypt_R = (cipher + crypt_R) * crypt_1 + crypt_2;
  return plain;
}

#define Hsize 100000L
#define Ssize 10

static void hugeput()
{ long i; byte __HUGE* h;
  putBgn("","huge_img.000","");
  putHeader("","test",1,0);
  for (i = 0; i < Ssize; i++) putByte((byte)i);
  h = (byte __HUGE*)NewHMem(Hsize);
  for (i = 0; i < Hsize; i++) h[i] = (byte)i;
  putHuge(h,Hsize);
  for (i = 0; i < Ssize; i++) putByte((byte)i);
  putEnd();
  FreeHMem(h);
}

static void hugeget()
{ long i,xsize; byte __HUGE* h; byte b;
  getBgn("","huge_img.000","");
  getHeader("test",1,0);
  for (i = 0; i < Ssize; i++) { getByte(&b); assert0(b == (byte)i,""); }
  getHuge((HugeCPtr*)(&h),&xsize); assert0(xsize == Hsize,"");
  for (i = 0; i < Hsize; i++) assert0(h[i] == (byte)i,"");
  FreeHMem(h);
  for (i = 0; i < Ssize; i++) { getByte(&b); 
printf("%d\n",b);
assert0(b == (byte)i,""); }
  getEnd();
}

int main(int argc, string argv[])
{
  assert(argc == 2,"usage: bin_pack 'upt'");
printf("begin\n");
  if (argv[1][0] == 'w')   hugeput();
  if (argv[1][0] == 'r')   hugeget();
  if (argv[1][0] == 'p')   pack_file("123","456");
  if (argv[1][0] == 'u') unpack_file("456","789");
  if (argv[1][0] == 't')
  { long i;
    for (i = 0; i < 1000000L; i++)
      Decrypt(0);
  }
printf("end\n");
  BUG_CORE;
  return 0;
}
