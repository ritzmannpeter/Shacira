/* ------------------------------------------------------------------------ */
/*                                                                          */
/* [stdmak.c]                Standard DPS Repository                        */
/*                                                                          */
/* Copyright (c) 1996 by D\olle, Manns                                      */
/* ------------------------------------------------------------------------ */

#include "stdosx.h"
#include "otab.h"
#include "hmap.h"
#include "hset.h"
#include "symbols.h"
#include "pathes.h"
#include "dicts.h"
#include "sink.h"
#include "prjfun.h"

/* -------------------- Types, Constants & Globals ----------------------- */

/* -------------------------- Auxiliary ---------------------------------- */

/* -------------------------- Interface Functions ------------------------- */

/*
main
*/

// DPS Repository, Init : DpsLib_init

_DLL_EXPORT_ long _C_DECL_ DpsLib_init(void)
/* inits dll */
{
  MAP_init();
  initSymbols();
  return 0;
}

// DPS Repository, Quit : DpsLib_quit

_DLL_EXPORT_ long _C_DECL_ DpsLib_quit(void)
/* quits dll */
{ long lResult = 0;
  freeSymbols();
  MAP_quit();
  lResult = ObjCount();
  return lResult;
}

// DPS Repository, Funktion Quell/Zieldatei-Bestimmung : 
//   void <Typname>_getFiles
//        (
//          Zielverzeichnisse ( Targets <Name> )
//          vollst�ndige Quellpfade
//          ( DstFile, DstPath )[] |--> { SrcFile }
//        )

_DLL_EXPORT_ void _C_DECL_ CMD_getFiles
                  (
                    ROW(string) pDstPathes, SET(string) pSrcPathes,
                    StdCPtr pGBag, PFN_AddGrp pAddGrpFun, 
                    PFN_AddDst pAddDstFun, PFN_AddSrc pAddSrcFun
                  )
/* determines CMD-source-target-files, expects CIMENV & CMDGEN pathes */
{ HS_Itr      pItr;
  StdCPtr     pTBag, pSBag;
  string      //szDstFile = (string)NULL, 
              szSrcPath, szSrcBase, szSrcFile, szSrcSfx;
  char        szTmp[STD_BUFFLEN+1];
  long        lCnt, lI;
  BUG_NULL(pDstPathes);
  BUG_NULL(pSrcPathes);
  BUG_NULL(pGBag);
  BUG_NULL(pAddGrpFun);
  BUG_NULL(pAddDstFun);
  BUG_NULL(pAddDstFun);
  lCnt = OT_CNT(pDstPathes);
  assert0(lCnt == 2,"missing CIMENV & CMDGEN pathes.");
  HS_FORALL(szSrcPath,pItr,pSrcPathes)
  {
    // add Source - Target - Group
    (*pAddGrpFun)(pGBag,&pTBag,&pSBag);
    szSrcSfx  = FileSuffix(szSrcPath);
    szSrcBase = BaseFile(szSrcPath);
    // CMD Source
    szSrcFile = Str_printf("%s%s",szSrcBase,szSrcSfx);
    (*pAddSrcFun)(pSBag,szSrcFile);
    // Target CIM Binary
    /*
    szDstFile = Str_printf("%s.cim",szSrcBase);
    (*pAddDstFun)(pTBag,szDstFile,OT_GET(string,pDstPathes,0));
    FreeMem(szDstFile);
    */
    // Target C Source
    for( lI=0; lI < strlen(szSrcBase) && lI < 4; ++lI )
    {
      szTmp[lI] = szSrcBase[lI];
    }
    szTmp[lI] = '\0';
    strcat(szTmp,"_cim.c");
    (*pAddDstFun)(pTBag,szTmp,OT_GET(string,pDstPathes,1));
    // free Ressources
    FreeMem(szSrcSfx);
    FreeMem(szSrcBase);
    FreeMem(szSrcFile);
  }
}

_DLL_EXPORT_ void _C_DECL_ STY_getFiles
                  (
                    ROW(string) pDstPathes, SET(string) pSrcPathes,
                    StdCPtr pGBag, PFN_AddGrp pAddGrpFun, 
                    PFN_AddDst pAddDstFun, PFN_AddSrc pAddSrcFun
                  )
/* determines STYX-source-target-files, expects GENSTYX & BINSTYX pathes */
{ HS_Itr      pItr;
  StdCPtr     pTBag, pSBag;
  string      szDstFile, szSrcPath, szSrcBase, szSrcFile, szSrcSfx;
  char        szTmp[STD_BUFFLEN+1];
  long        lCnt, lI;
  BUG_NULL(pDstPathes);
  BUG_NULL(pSrcPathes);
  BUG_NULL(pGBag);
  BUG_NULL(pAddGrpFun);
  BUG_NULL(pAddDstFun);
  BUG_NULL(pAddDstFun);
  lCnt = OT_CNT(pDstPathes);
  assert0(lCnt == 2,"missing GENSTYX & BINSTYX pathes.");
  HS_FORALL(szSrcPath,pItr,pSrcPathes)
  {
    // add Source - Target - Group
    (*pAddGrpFun)(pGBag,&pTBag,&pSBag);
    szSrcSfx  = FileSuffix(szSrcPath);
    szSrcBase = BaseFile(szSrcPath);
    // STYX Source
    szSrcFile = Str_printf("%s%s",szSrcBase,szSrcSfx);
    (*pAddSrcFun)(pSBag,szSrcFile);
    // Target C Source
    for( lI=0; lI < strlen(szSrcBase) && lI < 4; ++lI )
    {
      szTmp[lI] = szSrcBase[lI];
    }
    szTmp[lI] = '\0';
    strcat(szTmp,"_lim.c");
    (*pAddDstFun)(pTBag,szTmp,OT_GET(string,pDstPathes,0));
    // Target LIM Binary
    szDstFile = Str_printf("%s.lim",szSrcBase);
    (*pAddDstFun)(pTBag,szDstFile,OT_GET(string,pDstPathes,1));
    // free Ressources
    FreeMem(szSrcSfx);
    FreeMem(szSrcBase);
    FreeMem(szSrcFile);
    FreeMem(szDstFile);
  }
}
