/* ------------------------------------------------------------------------ */
/*                                                                          */
/* [metastyx.c]                 Meta Language Interpreter                   */
/*                                                                          */
/* Copyright (c) 1999 by D\olle, Manns, Steffen                             */
/* ------------------------------------------------------------------------ */

#include "stdosx.h"


#define infile     CTX_EVAL(c_string,"InFile")
#define outfile    CTX_EVAL(c_string,"OutFile")
#define metafile   CTX_EVAL(c_string,"MetaFile")

