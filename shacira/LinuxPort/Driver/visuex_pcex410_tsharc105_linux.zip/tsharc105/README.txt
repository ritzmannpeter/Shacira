Installation:
Unzip these files to a folder (e.g.  .../tmp) and run the shell-script TSharc.install
from the console. 
To calibrate the Touch Screen, run  the shell-script TSharc.calibrate from the console.
To unzip this archive from console, type
  tar -xpzf tsharc105.tar.gz  

Remark:
The touch driver was compiled and tested by EXTEC Oesterle GmbH for SuSE 8.2.

Additional information for installing the touch driver:
1) The subdirectory of the ./Disk1.5 contains the original files from
the Touch Screen vendor (http://www.hampshirecompany.com).
2) The files in the main directory are copied from these original files.
It is tested with SuSE 8.2.
3) The installation is NOT recommended for Linux beginners. Please have a look to
the file ./Disk1.5/Readme.txt and the script TSharc.install as an example. With
this you should be able to install the driver without problems.
4) The correct entries for the touch controller working under X (/dev/input/event???)
can be obtained by typing in:
PCEX410_SN25697# grep input /var/log/messages
[...]
Jul 22 22:10:01 PCEX410_SN25697 kernel: input0: USB HID v1.10 Keyboard [Code Mercenaries KeyWarrior16 Operator] on usb1:2.0
Jul 22 22:10:01 PCEX410_SN25697 kernel: input1: USB HID v1.10 Mouse [Hampshire Company TSHARC Octopus] on usb1:3.0

Good luck

Your EXTEC team.