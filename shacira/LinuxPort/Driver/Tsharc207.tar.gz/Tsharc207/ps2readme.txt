Hampshire TSHARC PS/2 Linux Driver Installation

Revision: 2.07

Date: May 16, 2006

**********************************************************************************
This document is divided into the following sections:
I.     System Requirements
II     Verify the current linux setup meets driver requirements
III.   Including the required components into the kernel
IV.    Final PS/2 specific steps

**********************************************************************************
I.  System Requirements
	- Kernel version 2.4.x or
	- Kernel version 2.6.9 or above

Procedure for installation of the Hampshire Linux PS/2 driver

**********************************************************************************
II.  Verify the current linux setup meets driver requirements

The components "psaux" and "serio_raw" must be included in the current kernel.   To check this, use the following procedures:

To determine if the "psaux" component is installed:

            1> Enter "cd \boot"
            2> Enter "cat System.map-<kernel version> | grep "psaux" ", where <kernel version> is the current kernel version. 

            If there are any lines displayed, then psaux is installed correctly.

 To determine if the "serio_raw" component is installed:

            1> Enter "cd \boot"
            2> Enter "cat System.map-<kernel version> | grep "serio_raw" ", where <kernel version> is the current kernel version. 

            If there are any lines displayed, then serio_raw is installed correctly.

 
Note: On some linux systems, the System.map file referenced in the previous steps may be named differently.

 If the "psaux" and "serio_raw" components already exist, then proceed to section IV; if not, proceed to section III.
 
**********************************************************************************
III. Including the required components into the kernel

 1> Download the kernel source for the current kernel version or any kernel source code version 2.6.9 or newer.

2> Log into system as root or enter "su" at the command prompt.

3> Extract the source code to a directory under "/usr/src".

4> Change the current directory to where the kernel source code was extracted.

5> Enter "make menuconfig" at the command prompt.

6> Selected the "Provide legacy /dev/psaux device" and "Raw access to serio ports" items found somewhere under "Device Driver->Input device support" (this location in the menu sometimes varies between kernel versions).  It is recommended that an asterisks be placed to the left of these two items, however these  items can be selected using an 'M' (module) if these components are loaded using "modprobe psmouse" and "modprobe serio_raw" before the "tsharc.sh" script is  executed in section III.

7> Exit and save the current configuration.

Note: You may wish to choose different varations on steps 8, 9, and 10 depending on your system configuration.

8> Enter "make" at the command prompt.

9> Enter "make modules_install" at the command prompt.

10> Enter "make install" at the command prompt.

The "make install" usually automatically adds a grub (or lilo) menu item on most newer kernel versions.  However, if this does not correctly modify the grub menu  configuration, the "menu.lst", lilo.conf or "grub.conf" file may need to be modified appropriately.

**********************************************************************************
IV. Final PS/2 specific steps

1>  Create a "tsharc.sh" file using the text editor of your choice in the "/etc" directory such that it contains the following lines:

#! /bin/sh
echo Configuring PS2 Controller
modprobe serio_raw # only add this line if serio_raw was compiled as a module in section II
echo -n "serio_raw" > /sys/bus/serio/devices/serio0/drvctl
mknod --mode=660 /dev/tsharc c 10 62

2>  Add the line "sh /etc/tsharc.sh" to the appropriate initialization file such that the script is executed before the login prompt.  For example, under  Fedora, this file would "/etc/rc.d/rc.sysinit".  Under Suse 10.0, this file would be "/etc/init.d/boot.local".

3>  Proceed with instructions the "readme.txt" file.


