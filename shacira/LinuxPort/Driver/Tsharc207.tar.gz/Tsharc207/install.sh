#! /bin/bash

echo "Installing Hampshire TSHARC Linux Driver..."
echo "Copying Files..."
cp libstdc++.so.6.0.3 /usr/lib/
cp tsharc_drv.o /usr/X11R6/lib/modules/input
echo "Creating symbolic link to library..."
ln -s /usr/lib/libstdc++.so.6.0.3 /usr/lib/libstdc++.so.6
echo "Preparing calibration files..."
touch /var/.tsharc.cal
touch /var/.tsharc.val
chmod 666 /var/.tsharc.cal
chmod 666 /var/.tsharc.val

echo "Files have been copied and moved, please continue following the steps in the readme."
