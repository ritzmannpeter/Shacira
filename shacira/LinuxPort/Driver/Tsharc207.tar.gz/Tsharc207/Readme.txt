Hampshire TSHARC Linux Driver Installation

Revision: 2.07

Date: May 16, 2006

**********************************************************************************
This document is divided into the following sections:
I.     System Requirements
II.    Some useful Linux commands
III.   Installing TSHARC controller
IV.    Calibration
V.     User Specified Calibration Location Instructions
VI.    Multi-monitor / Multi-controller support

**********************************************************************************
I.  System Requirements
	- XFree86 version 4.x or Xorg version 6.x
	- Kernel version 2.4.x or greater
	- Kernel support for USB if USB controllers are to be installed
	Note: If kernel does not include USB support, the kernel may be recompiled to support this.
	Documentation for recompiling a kernel can be found online.

**********************************************************************************
II.  Some useful Linux commands:

Kernel and GCC Version
	"cat /proc/kernel"

Xfree86 / Xorg version
	"xdpyinfo"
	Approximately the fourth line will yield the version number. This command must be launched from within the X environment in order to work.

**********************************************************************************
III. Installation of TSHARC controller

Note: If this is a PS/2 installation, please contact Hampshire Company for additional PS/2 files and information and follow the "ps2readme.txt" document prior to reading this document.

1. Verify that your Xfree86 / Xorg X-Windows manager is operating correctly.   At the command prompt, enter the command "startx".  The X-Windows environment should start correctly.  If not, diagnose any issues before continuing.  Note: if the X-Windows environment is already running, then this step may be disregarded.
2. Become root by entering "su" at a command prompt and entering root password.
3. Copy and prepare driver files using the "install.sh" script by entering the following:

sh ./install

5. Reboot computer or restart Xserver by pressing "Ctrl-Alt-Backspace" on keyboard.

6. Find out which device node the Touch Screen Controller is using and verify controller communication:

	Enter "su" at the command prompt to attain root access.

	USB instructions
	a. enter "cat /dev/input/event0"
	b. if there is a blank line, touch the screen.  If random characters show up, the
	touch screen controller is on "/dev/input/event0".
	c. if no gibberish shows up, or "No Such Device", press control-c, then
	re-try for the next event (event1) and repeat above steps, incremented the device number each time until a response is received.

	SERIAL instructions
	a. enter "cat /dev/ttyS0"  Typically, ttyS0 is equivalent to COM1, ttyS1 to COM2, etc.
	b. if there is a blank line, touch the screen.  If random characters show up, the
	touch screen controller is on "/dev/ttyS0".
	c. if no random characters show up, or "No Such Device", press control-c, then
	re-try for the next event (ttyS1) and repeat above steps, incremented the device number each time until a response is received.

	PS2 instructions	
	a. enter "cat /dev/tsharc".  
	b. if no random characters show up, or "No Such Device", refer the ps2readme.txt document to verify correct PS/2 setup.

	Note: If the terminal becomes stuck in a wierd mode after received input from the controller, the "reset" command should restore the terminal to it's original state.

	The device path that input was received on needs to be remembered or written down for the next steps.

7. Edit the X Windows Configuration file:

Typically this file is found under "/etc/X11" and may be named as "XF86Config", "XF86Config-4" or "xorg.conf".

	a. Under Section "ServerLayout" add the following line:
		InputDevice "touchscreen0"

	b. Verify that the Hampshire touch screen driver is not the core pointing device.  The core pointing device may be identified in the "ServerLayout" section, by looking for the "CorePointer" text to the right of the InputDevice.  A core pointer however is required by X-Windows and the "mouse" driver or other inputdevice driver may be used for this.

	c. If the touch screen controller being configured uses the USB interface, then ensure that no other InputDevice driver use the device path "/dev/input/mice".  This device path needs to be changed to "/dev/null" if no USB mouse is attached.  This device path needs to be changed the specific device path if a USB mouse does exist (for example, "/dev/input/mouse0").

	d. If the touch screen controller being configured uses the PS/2 interface, then ensure that no other InputDevice driver uses the device path "/dev/psaux".  This device path needs to be changed to "/dev/null" if such a device path exist for a different InputDevice driver.

	e. Add the following before or after your existing "InputDevice" sections:

Section "InputDevice"
	Identifier 	"touchscreen0"
	Driver	"tsharc"
	Option	"Device"	"/dev/ttyS0"  
	Option	"SendCoreEvents"
EndSection

	Note: The "Device" option needs to be modified to match the device path discovered in step 6.

	f.  In addition to the required sections, add additional options to modify driver behavior to specific needs.

Required Options:

 	Identifier:		- name that X-windows may refer to our driver by.

	Device: 		- the port the TSHARC controller is connected to
                              
					USB
					"/dev/input/event<X>" -  USB device node ID discovered from step 6
					
					PS2
					"/dev/tsharc"

					RS-232
					"/dev/ttyS0" - COM1
					"/dev/ttyS1" - COM2
					"/dev/ttyS2" - COM3
					etc.

	SendCoreEvents		- Use this option if you wish the touch screen to Function when X starts.  This will also allow simultaneous use of the touch screen and a mouse assuming a mouse is installed.

Conditionally Required Options:

	TSHARCBaud		- the TSHARC controller baudrate:
					2400
					4800
					9600 (Default)
					19200
				Required only if baudrate is not 9600.  All current Hampshire controllers default to 9600 baud.  


	TSHARCType		- TSHARC controller type:
					8 - for TSHARC-8
					12 - for 12 and 10 bit TSHARC controllers (Default)

	TSHARCUSB		- Set to 0 or exclude this option if not USB, set to 1 if USB.  (Default: 0)	
				Required only if InputDevice is USB controller.

	TSHARCPS2		- Set to 0 or exclude this option if not PS/2, set to 1 if PS/2 and the kernel version is between 2.6.0 and equal to or less than 2.6.8.  (Default: 0)
				Required only if InputDevice is PS2 and kernel version is between 2.6.0 and 2.6.8.

	TSHARCBUS		- Set to 0 or exclude this option if not BUS, set to 1 if BUS.  (Default: 0)
				Required only if InputDevice is BUS.

	ButtonNumber		- Button ID that is sent when the screen is being touched. (Default: 1)
				Required only if ButtonNumber for left click is not 1.

	RightClickTimeout	- This is the time delay in milliseconds before an alternate click is sent - 0 disables the right click. (Default: 0)
				Required only for Right-click emulation.

	AltButtonNumber		- Button ID that is sent after the RightClickTimeout time has expired.  (Default: 3) This value is only used if "RightClickTimeout" has a value other than 0.

	TMode			Touch Mode:
					0 - "Normal" mode (Default)
					2 - "Touch Down" mode
					4 - "Touch Up" mode
				Required only if "Touch Down" or "Touch Up" mode is desired.

				Normal: Emulates a standard mouse.  Selecting "Normal" will allow for single click, double click, drawing, dragging and right click option (if right click is enabled).
				
				Touch down:  Touch down will allow for a click event to take place at touch down.  You will not be able to draw or drag if this option is selected.
				
				Touch up:  Touch sent only at touch up.  Disables right click and double click functions.

	CalibrationFile		Alternate location of calibration file. (Default: "/var/.tsharc.cal").  See "User Specified Location Instructions" section of this document for more information on this option.

	ID			Touch screen controller ID for multiple controllers.  (Default: 0) See "Multi-monitor / Multi-controller support" section of this document for more information on this option.
	
4. Save the modified X Windows Configuration file
5. If within X-Windows environment, enter "startx", otherwise enter "reboot" at the command prompt.
6. The touch screen should now be functioning.
7. Proceed to the calibration section for details on how to calibrate the touch screen to your display.

Note:  If you wish to have the TSHARC InputDevice disabled by default, exclude the SendCoreEvents option.  The touch screen may then be enabled in an Xterminal by typing "xsetpointer TSHARC".  You can revert back to the
normal pointer (disable touch screen) by typing in an Xterminal "xsetpointer pointer".
Or you can see what pointers are available by typing in an Xterminal "xsetpointer -l".

**********************************************************************************
IV. Calibration

1.  If the "CalibrationFile" option is not used, the "tscal" calibration utility will write the calibration to the following file path by default:

	/var/.tsharc.cal

During calibration a secondary file is also used:

	/var/.tsharc.val

2.  If the "CalibrationFile" option is used.  The following procedure needs to be followed:
User Specified Calibration Location Instructions
	a.	Enter the command "touch <CalibrationFile Path>" where <CalibrationFile Path> is the same full path used to the right of the "calibrationFile" option.

	b.	Enter the command "touch <Value File Path>" where <Value File Path> is the same full path used to the right of the "calibrationFile" option except that the ".cal" extension should be replaced by a ".val" extension for the command.

	c.	The file permissions of these two files now need to be modified using the following commands:

	chmod 666 <CalibrationFile Path>
	chmod 666 <Value File Path>

3. Run the "tscal" application to calibrate the Touch Screen.  No command line
options are needed for a 4 point calibration. To perform a 20 point calibration, enter "./tscal -p 20" at the command line.


The following details the command line options that can be used by the "tscal" application:

	-p 20		Calibrate screen using 20 point calibration

	-n <ID>		Specify touch screen controller ID.  See "Multi-monitor / Multi-controller support" section.

	-c <path>	Full path to calibration file.  See "User Specified Calibration Location Instructions" section.

	-d <ID>		Specify which screen ID to display the calibration targets on.  See "Multi-monitor / Multi-controller support" section.

	-o <offset>	Percent to scale calibration points from corners of screen by.  Recommended values are 5, 10, 15, and 20.

	-i <inset>	Percent to move points from edge of screen by.  Recommended values are 5, 10, 15, and 20.

NOTE: "tscal" requires libstdc++.so.6 in the /usr/lib/ directory.  This should be done automatically using the "install.sh" script.  But if this needs to be done manually, copy libstdc++.so.6.0.3 to the "/usr/lib/" directory and set up a symbolic link to it
from libstdc++.so.6 by entering the following lines at the command prompt:

cp libstdc++.so.6.0.3 /usr/lib/
cd /usr/lib/
ln -s lib libstdc++.so.6.0.3 libstdc++.so.6

Note:  If a symbolic link libstdc++.so.6 already exists and points to a library 6.0.3 or greater, the above three commands may be skipped.

**********************************************************************************
V.  User Specified Calibration Location Instructions

This driver release supports configurable paths and file for calibration data.  In order to utilize this feature, the "CalibrationFile"  option must be added to the "InputDevice" configuration.

The following is example of how a user system may be setup:

Section "InputDevice"
	Identifier 	"touchscreen1"
	Driver	"tsharc"
	Option	"Device"	"/dev/input/event0"
	Option	"TSHARCUSB"	"1"
	Option  "CalibrationFile" "/home/testuser/.tsharc.cal"
	Option	"SendCoreEvents"
EndSection

The "CalibrationFile" option specifies the location of where the calibration
file is located.  If multiple controllers are present on the system, then each
"Inputdevice" section should specify a different calibration file.

If the "CalibrationFile" option is specified, an additional parameter must be specified for the "tscal" application.  If the TSHARC X-Windows configuration were specified like the example "touchscreen1" input above, we would specify the following:
 "tscal -c /home/testuser/.tsharc.cal"

This will cause the "tscal" application to look in "/home/testuser" for the ".tsharc.val" file and will write the file "/home/testuser/.tsharc.cal".  The file specified by the "-c" parameter must correspond to the values specified in the "XF86Config" file or the calibration will not succeed.  By default, the "tscal" application will create a "/var/.tsharc.cal" file if the "-c" parameter is not specified.

Note:  The symbol "~" and environmental variables do not work if used to specify path of calibration file.

**********************************************************************************
VI.  Multi-monitor / Multi-controller support

In order to configure multiple controllers on multiple monitor or a single monitor, each TSHARC controllers must have a separate "InputDevice" section in the X-Windows configuration with a unique "CalibrationFile" and "ID" specified in each section.

For example, to support both a serial and a usb controller on a system with two displays, the X-Windows configuration may include a configuration similar to the following:

Section "InputDevice"
	Identifier 	"touchscreen0"
	Driver	"tsharc"
	Option	"Device"	"/dev/input/event0"
	Option	"TSHARCUSB"	"1"
	Option	"ScreenNumber"	"0"
	Option  "CalibrationFile" "/var/.tsharcusb.cal"
	Option  "ID" "1"
	Option	"SendCoreEvents"
EndSection

Section "InputDevice"
	Identifier 	"touchscreen1"
	Driver	"tsharc"
	Option	"Device"	"/dev/ttyS1"
	Option	"ScreenNumber"	"1"
	Option  "CalibrationFile" "/var/.tsharcserial.cal"
        Option  "ID" "2"
	Option	"SendCoreEvents"
EndSection

The "ID" option is required to be a unique integer value between 0 and 15.  This will later be used by the "tscal" application to reference the appropriate controller.

The "tscal" application requires a "-n" parameter that corresponds with the "ID" option in the X-Windows configuration so "tscal" may know which TSHARC controller to communicate with.  

If multiple monitors are used, a "-d" parameter is required to indicate which screen the "tscal" application should cover.  This value usually corresponds to the "ScreenNumber" option in the X-Windows configuration.

Before calibrating either controller, create the calibration files and set their file permissions.   The following commands will accomplish this for this example:
touch /var/.tsharcusb.cal
touch /var/.tsharcserial.cal
chmod 666 /var/.tsharcusb.cal
chmod 666 /var/.tsharcusb.cal

After these commands are executed, the system will now be ready to calibrate the controllers in this example scenario.

To communicate with the USB controller in the example above, specify the following at the command prompt:
tscal -c /var/.tsharcusb.cal -n 1 -d 0

To communicate with the serial controller in the example, specify the following at the command prompt:
tscal -c /var/.tsharcserial.cal -n 2 -d 1

**********************************************************************************

Troubleshooting:

Q: Why is there no event device nodes under "/dev/input"?

A: The evdev module must be loaded.  To get a listing of the current modules, enter "lsmod".  If evdev is not listed, then enter modprobe evdev.  Also, if this module was missing, to ensure this module is loaded after every reboot, the line "modprobe evdev" needs to be added to the appropriate initialization file.  For example, in Fedora or Redhat, this file would be "/etc/rc.d/rc.sysinit".

Q: Why is my USB touch screen controller no longer causing the mouse cursor to move?

A: If the USB controller was removed and then plugged back in, sometimes it's event id changes .  If this is the case, the "USB instructions" need to be repeated in Section III, step 6 to determine the new event id.  After this has been determined, the device path needs to be modified in the X-Windows configuration file (XF86Config, XF86Config-4, xorg.conf).  Reboot the computer or restart X-Windows.  The USB touch screen controller will resume responding normally.

Q: Why are all of my configured touch screens no longer moving the cursor upon touching the touch screen after changing my X-Windows display settings?

A: Often when using a GUI utility such as "sax2" to configure display settings, this overwrites the existing settings contained within the X-Windows configuration file (XF86Config, XF86Config-4, xorg.conf) causing some of the previously configured items to disappear.  If this happens, the "/etc/X11" directory may be checked for a backup copy of the configuration file.
